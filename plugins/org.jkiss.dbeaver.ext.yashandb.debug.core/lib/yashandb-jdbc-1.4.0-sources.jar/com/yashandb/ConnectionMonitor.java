/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.ConnectionImpl;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.Utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

public class ConnectionMonitor {

    private Map<String, Set<SessionImpl>> observedSessions = new HashMap<>();

    private Map<String, Timer> monitorTimers = new HashMap<>();

    private Map<String, Connection> daemonConnections = new HashMap<>();

    private static final int MONITOR_CONN_SOCKET_TIMEOUT = 60;

    private static final int TIMER_DELAY = 2;

    private static final int SCHEDULE_PERIOD = 20;

    private boolean checkValid(Statement statement) {
        boolean isValid = false;
        try {
            ResultSet resultSet = statement.executeQuery("select 1 from dual");
            if (resultSet.next()) {
                isValid = true;
            }
            resultSet.close();
        } catch (SQLException ignored) {
        }

        return isValid;
    }

    public synchronized void register(SessionImpl session) throws SQLException {
        String link = session.getHostSpec().getHost() + session.getHostSpec().getPort();
        if (!observedSessions.containsKey(link)) {
            observedSessions.put(link, new HashSet<>());
        }
        observedSessions.get(link).add(session);

        if (!daemonConnections.containsKey(link)) {
            try {
                Connection daemonConnection = (Connection) ((ConnectionImpl) session.getConnection()).clone();
                daemonConnection.setNetworkTimeout(null, Utils.toMillisecond(MONITOR_CONN_SOCKET_TIMEOUT));
                daemonConnections.put(link, daemonConnection);
            } catch (Exception e) {
                throw SQLError.createSQLException(e.getMessage(), YasState.DATA_ERROR);
            }
        }

        if (!monitorTimers.containsKey(link)) {
            Statement statement = daemonConnections.get(link).createStatement();
            // start monitor timer task
            Timer timer = new Timer(true);
            timer.scheduleAtFixedRate(new TimerTask() {
                private final String taskLink = link;
                private final Statement taskStmt = statement;
                @Override
                public void run() {
                    if (!checkValid(this.taskStmt)) {
                        notifyObservers(this.taskLink);
                        try {
                            this.taskStmt.close();
                        } catch (SQLException ignored) {
                        }
                    }
                }
            }, Utils.toMillisecond(TIMER_DELAY), Utils.toMillisecond(SCHEDULE_PERIOD));
            monitorTimers.put(link, timer);
        }
    }

    private void releaseMonitorResource(String link) {
        if (monitorTimers.containsKey(link)) {
            monitorTimers.get(link).cancel();
            monitorTimers.remove(link);
        }

        if (daemonConnections.containsKey(link)) {
            Connection connection = daemonConnections.get(link);
            daemonConnections.remove(link);
            try {
                connection.close();
            } catch (SQLException ignored) {
            }
        }
    }

    public synchronized void unRegister(SessionImpl session) {
        String link = session.getHostSpec().getHost() + session.getHostSpec().getPort();
        if (!observedSessions.containsKey(link)) {
            return;
        }

        Set<SessionImpl> sessions = observedSessions.get(link);
        sessions.remove(session);
        if (!sessions.isEmpty()) {
            return;
        }

        releaseMonitorResource(link);
    }

    private synchronized void notifyObservers(String link) {
        Set<SessionImpl> sessions = observedSessions.get(link);
        if (sessions.isEmpty()) {
            return;
        }

        for (SessionImpl session : sessions) {
            session.processInvalid();
        }
        sessions.clear();
        observedSessions.remove(link);

        releaseMonitorResource(link);
    }
}
