/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb;

public class YasConstants {

    /**
     * Base time to January 1, 1970, 00:00:00 GMT in milliseconds
     */
    public static final long ERO_AFTER_BASE_MILLI_SEC = 11644473600000L;

    public static final int UNIX_EPOCH_JDATE = 2440588;

    // 365 * 400 + (100 - 3), 97 leaps per 400 years
    public static final long US_400_YEAR = 12622780800000000L;

    // 365 * 100 + 24
    public static final long US_100_YEAR = 3155673600000000L;

    // 365 * 4 + 1
    public static final long US_FOUR_YEAR = 126230400000000L;

    // 365
    public static final long US_ONE_YEAR = 31536000000000L;

    public static final long US_ONE_DAY = 86400000000L;

    public static final int US_ONE_SECOND = 1000000;

    public static final long US_ONE_HOUR = 3600000000L;

    public static final int US_ONE_MINUTE = 60000000;

    public static final int[][] MonthDayArray = {{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
        {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},};

    public static final int MONTH_PER_YEAR = 12;

    public static final int HOUR_PER_DAY = 24;

    public static final int MIN_PER_HOUR = 60;

    public static final int SEC_PER_MIN = 60;

    public static final char DS_DH_SPLIT = ' ';

    public static final char DS_NORMAL_SPLIT = ':';

    public static final char DOT_SPLIT = '.';

    public static final char YM_SPLIT = '-';

    public static final int MAX_INTERVAL_PRECISION = 9;

    public static final int MAX_FRACTION_PRECISION = 6;

    public static final int MAX_YMI_YEAR = 178000000;

    public static final int MAX_DSI_DAY = 100000000;

    public static final int[] PrecisionLimit =
        {0, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000};

    public static final long MAX_DSI = 100000000L * 24 * 60 * 60 * 1000000;

    public static final int MAX_YMI = 178000000 * 12;

    public static final long MAX_BYTE =  127L;

    public static final long MIN_BYTE = -128L;

    public static final int MAX_NUM_PRECISION = 38;

    public static final int INVALID_NUMBER_SCALE = -128;

    public static final int MAX_SIZE_BOOL = String.valueOf(false).length();

    // display: -128
    public static final int MAX_SIZE_TINY_INT = 4;

    // display: -32767
    public static final int MAX_SIZE_SMALL_INT = 6;

    // display: -2147483647
    public static final int MAX_SIZE_INT = 11;

    // display: -9223372036854775807
    public static final int MAX_SIZE_BIGINT = 20;

    // server side: ROWID_BUFFER_SIZE
    public static final int MAX_SIZE_ROWID = 42;

    // display: -1.11111115E+032
    public static final int MAX_SIZE_FLOAT = 16;

    // display: -1.2345643212345654E+029
    public static final int MAX_SIZE_DOUBLE = 24;

    // server side: ANS_DATE_FORMAT_BUFFER_SIZE
    public static final int MAX_SIZE_DATE = 64;

    // 1(sign) + 1 (space) + 9(hh:mm:ss.)
    public static final int EXTRA_SIZE_INTERVAL_DS = 11;

    // 1(sign) + 1(-) + 2(month)
    public static final int EXTRA_SIZE_INTERVAL_YM = 4;

    // display max: 1 flow with 127 zeros
    public static final int MAX_SIZE_DEFAULT_NUMBER = 128;

    public static final int DEFAULT_DISPLAY_SIZE = 20;

    public static final int LOB_LOCATOR_SIZE = 80;

    public static final int LOB_LOCATOR_SIZE_VER1 = 72;

    public static final int LOB_REQ_LOC_OFFSET = 16;

    public static final int REQ_SQL_FLAG_LEN = 4;

    public static final int MAX_SQL_SIZE = 2 * 1024 * 1024;

    public static final int ACK_CONN_PACKET_SIZE = 16;

    public static final int LONG_BIND_SIZE = 32000;

    public static final String PRIMARY_ROLE = "PRIMARY";

    public static final int ROUND_WAIT_TIME = 2;

    public static final String PRIMARY_TYPE = "primary";

    public static final String LOAD_BALANCE_TYPE = "loadBalance";

    public static final int MAX_EXECUTE_BIND_SIZE = 2000;
    public static final String DEFAULT_PORT = "1688";
    public static final String DEFUALT_HOST = "localhost";
    public static final String DEFAULT_DRIVER = "jdbc:yasdb:";
    // Driver name
    public static final String DRIVER_NAME = "YashanDB JDBC Driver";
    public static final String DRIVER_SHORT_NAME = "YasJ";
    public static final String DRIVER_VERSION = "1.4.0";
    public static final int MAJOR_VERSION =
            Integer.parseInt(DRIVER_VERSION.split("\\.")[0]);

    private static final String MINOR_VERSION_STR = DRIVER_VERSION.split("\\.")[1];
    public static final int MINOR_VERSION = Integer.parseInt(MINOR_VERSION_STR.contains("-SNAPSHOT")
            ? MINOR_VERSION_STR.split("-")[0] : MINOR_VERSION_STR);
    public static final int DEFAULT_DRIVER_VERSION = 1;
    public static final String DRIVER_FULL_NAME = DRIVER_NAME + " " + DRIVER_VERSION;
    // Driver version

    public static final int PATCH_VERSION = 15;
    // JDBC specification
    public static final String JDBC_VERSION = "4.3";
    public static final int JDBC_MINOR_VERSION = JDBC_VERSION.charAt(2) - '0';
    public static final int JDBC_MAJOR_VERSION = JDBC_VERSION.charAt(0) - '0';
    //
    public static final int MaxColumnsInIndex = 32;
    public static final int MaxColumnsInTable = 1024;
    public static final int MaxNameLength = 64;
    public static final byte LOGIN_MODE_SECURITY = (byte)0x01;
    public static final byte SSL_MODE_SECURITY = (byte)0x02;
    public static final byte USER_ROLE_NONE = (byte)0x00;
    public static final byte USER_ROLE_SYSDBA = (byte)0x80;

    public static final int MAX_ROW_SIZE_WITHOUT_LOB = 64 * 1024;
    public static final byte[] YasNumber = new byte[]{(byte) 0xAC, 0x20, 0x20, 0x08, 0x02, 0x11, 0x22, 0x59};

    public static final int LOB_WRITE_CHAR_STEP_LEN = 40000;

    public static final int LOB_WRITE_STEP_LEN = 320000;

    public static final int READER_BUFF_SIZE = 2 * 1024;

    public static final int DEBUG_BREAK_POINT_SIZE = 14;

    /**
     * blockNo + isGlobal + unused + subId + objectId + lineNo+ id + size + type + precision + scale + nullable
     * + nameLen
     */
    public static final int DEBUG_META_DATA_SIZE = 29;

    public static final int DEBUG_STATUS_OFF = 0;

    public static final int DEBUG_STATUS_ON = 1;
}
