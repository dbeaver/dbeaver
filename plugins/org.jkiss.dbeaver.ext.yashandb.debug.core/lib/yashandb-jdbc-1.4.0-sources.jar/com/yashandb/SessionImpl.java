/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */
// Copyright (c) 2021, Open Cloud Limited.

package com.yashandb;

import com.yashandb.conf.HostSpec;
import com.yashandb.conf.YasProperty;
import com.yashandb.core.DataType;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.ConnectVersion;
import com.yashandb.jdbc.DebugBreakpoint;
import com.yashandb.jdbc.DebugFrame;
import com.yashandb.jdbc.DebugVar;
import com.yashandb.jdbc.StatementImpl;
import com.yashandb.jdbc.TransactionState;
import com.yashandb.jdbc.YasBlob;
import com.yashandb.jdbc.YasClob;
import com.yashandb.jdbc.YasConnection;
import com.yashandb.jdbc.YasDebugCallableStatement;
import com.yashandb.jdbc.YasLargeObject;
import com.yashandb.jdbc.YasLobProcessor;
import com.yashandb.jdbc.YasSavepoint;
import com.yashandb.jdbc.YasStatement;
import com.yashandb.jdbc.exception.BatchError;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.jdbc.exception.YasBatchUpdateException;
import com.yashandb.jdbc.exception.YasException;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;
import com.yashandb.parameter.BlobParameter;
import com.yashandb.parameter.ClobParameter;
import com.yashandb.parameter.YasParameter;
import com.yashandb.protocol.ConnectionServerMode;
import com.yashandb.protocol.DebugOperation;
import com.yashandb.protocol.LobOperation;
import com.yashandb.protocol.MsgType;
import com.yashandb.protocol.NativeProtocol;
import com.yashandb.protocol.Packet;
import com.yashandb.protocol.PacketProcessor;
import com.yashandb.protocol.YasSocketConnection;
import com.yashandb.util.CharacterSet;
import com.yashandb.util.ConnectorFactory;
import com.yashandb.util.HostConnector;
import com.yashandb.util.Messages;
import com.yashandb.util.StreamWrapper;
import com.yashandb.util.Utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.Charset;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.Executor;

/**
 * Session implementation.
 */
public class SessionImpl implements Session {

    private static final Logger LOGGER = LoggerFactory.getLogger(SessionImpl.class.getName());

    private static final ConnectionManager connectionManager = new ConnectionManager();

    protected YasSocketConnection yasSocketConnection;

    private final String user;

    private String schema;

    private final int cancelSignalTimeout;

    private YasConnection connection;

    private Statement statement = null;

    private boolean closed = false;
    private TransactionState transactionState = TransactionState.XACT_END;
    protected final boolean logServerErrorDetail;

    // default value for server versions that don't report standard_conforming_strings
    private boolean standardConformingStrings = false;

    private SQLWarning warnings;

    // For getParameterStatuses(), GUC_REPORT tracking
    private final TreeMap<String, String> parameterStatuses
            = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);

    private boolean autoCommit = false;

    private NativeProtocol protocol;

    private HostSpec[] hostSpecs;

    private Properties info;

    private int sessionID;
    private short charset;
    private int sessionKey;

    private boolean debugExecute = false;

    private boolean debugOn = false;

    private final boolean userCaseSensitive;

    private ConnectVersion connectVersion = ConnectVersion.getMaxConnectVersion();

    private List<YasLargeObject> tempLobList = new ArrayList<>();

    private Set<YasLargeObject> updatedKnlLobs = Collections.synchronizedSet(new HashSet<>());

    private YasDebugCallableStatement runningDebugStatement = null;

    public SessionImpl(YasConnection connection, HostSpec[] hostSpecs, String user,
                       Properties info) throws SQLException {
        this.connection = connection;
        this.yasSocketConnection = null;
        if (!user.contains("\"")) {
            user = user.toUpperCase();
            userCaseSensitive = false;
        } else {
            user = user.substring(1, user.length() - 1);
            userCaseSensitive = true;
        }

        this.user = user;
        this.schema = user;
        this.cancelSignalTimeout = YasProperty.CANCEL_SIGNAL_TIMEOUT.getInt(info) * 1000;
        this.logServerErrorDetail = YasProperty.LOG_SERVER_ERROR_DETAIL.getBoolean(info);

        this.hostSpecs = hostSpecs;
        this.info = info;
        this.protocol = null;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        SessionImpl cloneSession = (SessionImpl) super.clone();

        try {
            int connectTimeout = Utils.toMillisecond(YasProperty.CONNECT_TIMEOUT.getInt(info));
            cloneSession.yasSocketConnection = new YasSocketConnection(this.yasSocketConnection, connectTimeout, true);
            cloneSession.protocol = new NativeProtocol(cloneSession, cloneSession.yasSocketConnection);
            cloneSession.protocol.setServerMode(ConnectionServerMode.DEDICATE_MODE);
            String password = YasProperty.PASSWORD.get(info);
            cloneSession.protocol.connect(this.user, password, this.info);
        } catch (IOException | SQLException exception) {
            throw new CloneNotSupportedException(
                    Messages.get("clone session attempt failed {0}", exception.getMessage()));
        }

        return cloneSession;
    }

    @Override
    public void setConnection(YasConnection connection) {
        this.connection = connection;
    }

    @Override
    public YasConnection getConnection() {
        return this.connection;
    }

    public short getCharset() {
        return this.charset;
    }

    @Override
    public synchronized long getLobLength(YasLobProcessor lobProcessor) throws SQLException {
        Packet sendPacket = protocol.getSendPacket();
        PacketProcessor.writeReqLob(sendPacket, LobOperation.LOB_GET_LEN, lobProcessor, 0, 0);

        Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_LOB, 0);

        return PacketProcessor.processLobMetaDataAck(lobProcessor, ackPacket, LobOperation.LOB_GET_LEN);
    }

    @Override
    public synchronized short getLobChunkSize(YasLobProcessor lobProcessor) throws SQLException {
        Packet sendPacket = protocol.getSendPacket();
        PacketProcessor.writeReqLob(sendPacket, LobOperation.LOB_GET_CHUNK_SIZE, lobProcessor, 0, 0);

        Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_LOB, 0);

        return (short)PacketProcessor.processLobMetaDataAck(lobProcessor, ackPacket, LobOperation.LOB_GET_CHUNK_SIZE);
    }

    @Override
    public synchronized int getLobData(YasLobProcessor lobProcessor, int reqLen,
                                       long lobOffset, byte[] cacheData) throws SQLException {
        byte[] locator = lobProcessor.getLobLocator();
        if (cacheData.length < reqLen) {
            throw new YasException("lob cache buffer size too small: " + cacheData.length,
                    YasState.OUT_OF_MEMORY);
        }

        Packet sendPacket = protocol.getSendPacket();
        PacketProcessor.writeReqLob(sendPacket, LobOperation.LOB_READ, lobProcessor, reqLen, lobOffset);

        Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_LOB, 0);
        return PacketProcessor.processLobDataAck(locator, ackPacket, cacheData);
    }

    @Override
    public synchronized YasClob createClob() throws SQLException {

        Packet sendPacket = protocol.getSendPacket();
        YasLobProcessor processor = new YasLobProcessor();
        processor.setLobLocator(null);
        processor.setLobType(DataType.CLOB);
        processor.setSession(this);
        PacketProcessor.writeReqLob(sendPacket, LobOperation.LOB_TMP_CREATE, processor, 0, 0);

        Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_LOB, 0);

        YasClob clob = new YasClob(true);
        byte[] lobLocator = PacketProcessor.processLobCreateAck(ackPacket);
        processor.setLobLocator(lobLocator);
        int lobType = lobLocator[0] & 0xFF;
        processor.setInnerLobType(lobType);
        processor.setLobLength(0);
        clob.setLobProcessor(processor);
        clob.setConnection(this.getConnection());
        return clob;
    }

    @Override
    public synchronized YasBlob createBlob() throws SQLException {
        Packet sendPacket = protocol.getSendPacket();
        YasLobProcessor processor = new YasLobProcessor();
        processor.setLobLocator(null);
        processor.setLobType(DataType.BLOB);
        processor.setSession(this);
        PacketProcessor.writeReqLob(sendPacket, LobOperation.LOB_TMP_CREATE, processor, 0, 0);

        Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_LOB, 0);

        YasBlob blob = new YasBlob(true);
        byte[] lobLocator = PacketProcessor.processLobCreateAck(ackPacket);
        processor.setLobLocator(lobLocator);
        int lobType = lobLocator[0] & 0xFF;
        processor.setInnerLobType(lobType);
        processor.setLobLength(0);
        blob.setLobProcessor(processor);
        blob.setConnection(this.getConnection());

        return blob;
    }

    @Override
    public synchronized long writeLob(YasLobProcessor lobProcessor, long lobPos, byte[] bytes, int start, int length)
            throws SQLException {
        int remainSize = length;
        int reqLobHeadLen = YasConstants.LOB_REQ_LOC_OFFSET + lobProcessor.getLobLocator().length;
        long offset = lobPos;
        long lobLength = 0L;
        Packet sendPacket = protocol.getSendPacket();
        while (remainSize > 0) {
            sendPacket.clean();
            int reqLobLen = Math.min(remainSize, sendPacket.getRemainSize() - reqLobHeadLen);
            PacketProcessor.writeReqLob(sendPacket, LobOperation.LOB_WRITE, lobProcessor, reqLobLen, offset);
            sendPacket.writeBytes(bytes, start, reqLobLen);

            Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_LOB, 0);
            lobLength = PacketProcessor.processLobMetaDataAck(lobProcessor, ackPacket, LobOperation.LOB_WRITE);
            offset += reqLobLen;
            start += reqLobLen;
            remainSize -= reqLobLen;
        }

        return lobLength;
    }

    @Override
    public synchronized long writeLobByLobLocator(YasLobProcessor lobProcessor, long lobPos, byte[] locBytes)
            throws SQLException {
        int locLength = locBytes.length;
        if (locLength != YasConstants.LOB_LOCATOR_SIZE) {
            throw new YasException("tempLob locator length is error", YasState.DATA_ERROR);
        }

        Packet sendPacket = protocol.getSendPacket();
        sendPacket.clean();

        PacketProcessor.writeReqLobByLobLocator(sendPacket, LobOperation.LOB_WRITE, lobProcessor, locLength, lobPos);
        sendPacket.writeBytes(locBytes, 0, locLength);

        Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_LOB, 0);
        return PacketProcessor.processLobMetaDataAck(lobProcessor, ackPacket, LobOperation.LOB_WRITE);
    }

    @Override
    public synchronized void closeLob(YasLobProcessor lobProcessor) throws SQLException {
        Packet sendPacket = protocol.getSendPacket();
        PacketProcessor.writeReqLob(sendPacket, LobOperation.LOB_CLOSE, lobProcessor, 0, 0);

        Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_LOB, 0);
        PacketProcessor.processLobMetaDataAck(lobProcessor, ackPacket, LobOperation.LOB_CLOSE);
    }

    @Override
    public synchronized YasResultSet directExecute(StatementImpl statement, String sql) throws SQLException {
        autoCommit = connection.getAutoCommit();

        Packet sendPacket = protocol.getSendPacket();
        PacketProcessor.writeReqExecute(statement, sendPacket, autoCommit);
        Packet ackPacket = this.sendCommandWithSql(sendPacket, sql, MsgType.CMD_DIRECT_EXECUTE);

        ackPacket = PacketProcessor.processInteractPacket(statement, ackPacket,this);
        YasResultSet resultSet = PacketProcessor.processDirectExecuteAck(statement, ackPacket, this);

        //End transaction
        if (this.autoCommit) {
            this.setTransactionState(TransactionState.XACT_END);
        }
        return resultSet;
    }

    @Override
    public synchronized YasResultSet fetchCursor(StatementImpl statement) throws SQLException {
        Packet sendPacket = protocol.getSendPacket();
        PacketProcessor.writeFetchCursor((short) statement.getID(), sendPacket, statement.getFetchSize());

        Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_FETCH_CURSOR, 0);

        YasResultSet resultSet = PacketProcessor.processDirectExecuteAck(statement, ackPacket, this);
        resultSet.setStmtQueryResult(true);

        if (this.autoCommit) {
            this.setTransactionState(TransactionState.XACT_END);
        }
        return resultSet;
    }

    @Override
    public YasResultSet fetchReturnResultSet(short cursorId) throws SQLException {
        StatementImpl statement = (StatementImpl) this.connection.createStatement();
        statement.setStmtID(cursorId, (byte) 0);
        statement.closeOnCompletion();

        Packet sendPacket = protocol.getSendPacket();
        PacketProcessor.writeFetchCursor(cursorId, sendPacket, statement.getFetchSize());
        Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_FETCH_CURSOR, 0);

        YasResultSet resultSet = PacketProcessor.processFetchImplicitResultAck(statement, ackPacket, this);

        if (this.autoCommit) {
            this.setTransactionState(TransactionState.XACT_END);
        }
        return resultSet;
    }

    private byte[] getSqlBytes(String sql) {
        Charset clientCharset = Charset.defaultCharset();
        Charset serverCharset = CharacterSet.getCharSet(charset);

        byte[] sqlBytes;
        if (clientCharset == serverCharset) {
            sqlBytes = sql.getBytes();
        } else {
            sqlBytes = sql.getBytes(serverCharset);
        }

        return sqlBytes;
    }

    private Packet sendCommandWithSql(Packet sendPacket, String sql, MsgType cmd) throws SQLException {
        byte[] sqlBytes = getSqlBytes(sql);
        int packetLen = 0;
        int sqlOffset = 0;

        if (sqlBytes.length > YasConstants.MAX_SQL_SIZE) {
            throw SQLError.createSQLException("the length of sql text exceed limit", YasState.PROTOCOL_VIOLATION);
        }

        int sqlLen = sqlBytes.length;
        boolean firstPacket = true;

        while (sqlLen > 0) {
            packetLen = sendPacket.getCapacity() - sendPacket.getPostion()
                    - YasConstants.REQ_SQL_FLAG_LEN;

            if (sqlLen < packetLen) {
                PacketProcessor.writeReqSql(sendPacket, sqlBytes, sqlOffset, sqlLen,false);
                break;
            }

            PacketProcessor.writeReqSql(sendPacket, sqlBytes, sqlOffset, packetLen,true);

            sendPacket.setHasMore(true);
            if (firstPacket) {
                protocol.sendCommandOnly(sendPacket, cmd, 0);
                firstPacket = false;
            } else {
                protocol.sendCommandOnly(sendPacket, MsgType.CMD_MORE_DATA, 0);
            }

            sendPacket.clean();
            sqlOffset += packetLen;
            sqlLen -= packetLen;
        }

        if (firstPacket) {
            return protocol.sendCommand(sendPacket, cmd, 0);
        }
        return protocol.sendCommand(sendPacket, MsgType.CMD_MORE_DATA, 0);
    }

    @Override
    public synchronized void prepare(StatementImpl statement, String sql) throws SQLException {
        autoCommit = connection.getAutoCommit();

        Packet preparePacket = protocol.getSendPacket();
        PacketProcessor.writeReqPrepare(statement, preparePacket);
        Packet ackPacket = sendCommandWithSql(preparePacket, sql, MsgType.CMD_PREPARE);

        PacketProcessor.processPrepareAck(statement, ackPacket);
    }

    @Override
    public synchronized YasResultSet execute(StatementImpl query, ParameterList[] parameters, int maxRows,
                                int fetchSize, int flags) throws SQLException {
        autoCommit = connection.getAutoCommit();

        this.debugExecute = false;
        YasResultSet resultSet;
        if (parameters == null) {
            resultSet = executeNoBind(query);
        } else {
            resultSet = executeWithBind(query, parameters);
        }

        //End transaction
        if (this.autoCommit ) {
            this.setTransactionState(TransactionState.XACT_END);
        }
        return resultSet;
    }

    private void preProcessLobBind(ParameterList[] parameters) throws SQLException {
        for (ParameterList parameterList : parameters) {
            YasParameter[] yasParameters = parameterList.getParameters();
            for (int i = 0; i < yasParameters.length; i++) {
                if ((yasParameters[i] == null) || yasParameters[i].isOutParameter()) {
                    continue;
                }
                if (yasParameters[i].getLength() > YasConstants.LONG_BIND_SIZE) {
                    parameterList.replace(i, getLobParameter(yasParameters[i]));
                }
            }
        }
    }

    private void writeBLobByStream(Blob blob, StreamWrapper streamWrapper) throws SQLException, IOException {
        InputStream inputStream = streamWrapper.getStream();
        int streamLength = streamWrapper.getLength();

        OutputStream outputStream = blob.setBinaryStream(1);
        int value = inputStream.read();
        while ((value != -1) && (streamLength > 0)) {
            outputStream.write(value);
            value = inputStream.read();
            streamLength--;
        }

        outputStream.flush();
    }

    private YasParameter getLobParameter(YasParameter parameter) throws SQLException {
        if (parameter.getType() == DataType.RAW) {
            YasBlob blob = this.createBlob();
            StreamWrapper streamWrapper = (StreamWrapper) parameter.getValue();

            try {
                this.writeBLobByStream(blob, streamWrapper);
            } catch (Exception exception) {
                throw SQLError.createSQLException(exception.getMessage(), YasState.DATA_ERROR);
            }

            BlobParameter blobParameter = new BlobParameter();
            blobParameter.setValue(blob);
            blobParameter.setInDirection();
            this.tempLobList.add(blob);
            return blobParameter;
        } else {
            YasClob clob = this.createClob();
            clob.setString(1, (String) parameter.getValue());
            ClobParameter clobParameter = new ClobParameter();
            clobParameter.setValue(clob);
            clobParameter.setInDirection();
            this.tempLobList.add(clob);
            return clobParameter;
        }
    }

    private void doFreeLobs() throws SQLException {
        if (!tempLobList.isEmpty()) {
            for (YasLargeObject largeObject : tempLobList) {
                largeObject.freeTemp();
            }
            tempLobList.clear();
        }
    }

    private void freeTempLobs() {
        try {
            doFreeLobs();
        } catch (SQLException ignored) {

        }
    }

    private YasResultSet executePartitionBinds(StatementImpl query, ParameterList[] parameters)
        throws SQLException {
        int batchSize = parameters.length;
        int beginBatch = 0;
        YasResultSet totalResult = null;
        while (batchSize > 0) {
            int subBatchSize =
                    Math.min(Math.min(YasConstants.MAX_EXECUTE_BIND_SIZE, getSameTypeNum(beginBatch, parameters)),
                            batchSize);
            ParameterList[] subParameterList = Arrays.copyOfRange(parameters, beginBatch, beginBatch + subBatchSize);
            Packet ack;
            try {
                ack = sendBindExecutePacket(query, subParameterList);
            } catch (SQLException e) {
                String batchMsg = BatchError.converMsgToBatchMsg(e.getMessage());
                if (batchMsg == null) {
                    throw e;
                }
                BatchError batchError = new BatchError(e.getErrorCode(), batchMsg);

                // If there is only one in the first batch and an error occurs.
                if (totalResult == null) {
                    int[] emptyArray = {};
                    throw new YasBatchUpdateException(0, batchError, emptyArray);
                }

                int[] preDmlRows = totalResult.getBatchUpdateCounts();
                throw new YasBatchUpdateException(preDmlRows.length, batchError,
                        preDmlRows);
            }
            if (ack.getCmd() == MsgType.CMD_DEBUG) {
                throw SQLError.createSQLException("Unexpected ack command type: CMD_DEBUG.", YasState.UNKNOWN_STATE);
            }

            try {
                YasResultSet resultSet = PacketProcessor.proocessExecuteAckInBatchMode(query, ack, this);
                if (totalResult == null) {
                    totalResult = resultSet;
                } else {
                    totalResult.appendResults(resultSet.getUpdateCount(), resultSet.getBatchUpdateCounts(),
                            resultSet.getBatchErrors());
                }
            } catch (YasBatchUpdateException e) {
                if (totalResult == null) {
                    throw e;
                }
                int[] preDmlRows = totalResult.getBatchUpdateCounts();
                int[] curDmlRows = e.getUpdateCounts();
                int[] totalDmlRows = new int[preDmlRows.length + curDmlRows.length];
                System.arraycopy(preDmlRows, 0, totalDmlRows, 0, preDmlRows.length);
                System.arraycopy(curDmlRows, 0, totalDmlRows, preDmlRows.length, curDmlRows.length);
                throw new YasBatchUpdateException(preDmlRows.length + e.getRowNum(), e.getBatchError(), totalDmlRows);
            }

            batchSize -= subParameterList.length;
            beginBatch += subParameterList.length;
        }

        return totalResult;
    }

    private Packet sendBindExecutePacket(StatementImpl statement, ParameterList[] parameters) throws SQLException {
        Packet reqExecute = protocol.getSendPacket();
        PacketProcessor.writeReqExecute(statement, reqExecute, parameters, autoCommit, this.debugExecute);

        boolean isMore = false;
        for (ParameterList parameter : parameters) {
            SimpleParameterList params = (SimpleParameterList) parameter;
            for (int j = 1; j <= params.getParameterCount(); j++) {
                if (reqExecute.getRemainSize() > params.getLength(j)) {
                    params.writeValue(j, reqExecute);
                } else {
                    reqExecute.setHasMore(true);
                    sendExecutePacketOnly(reqExecute, isMore);
                    reqExecute.clean();
                    reqExecute.setHasMore(false);
                    params.writeValue(j, reqExecute);
                    isMore = true;
                }
            }
        }

        return sendExecutePacket(statement, reqExecute, isMore);
    }

    private YasResultSet executeWithBind(StatementImpl query, ParameterList[] parameters)
            throws SQLException {
        try {
            preProcessLobBind(parameters);

            if (parameters.length > YasConstants.MAX_EXECUTE_BIND_SIZE
                    || getSameTypeNum(0, parameters) != parameters.length) {
                return executePartitionBinds(query, parameters);
            }

            Packet ack = sendBindExecutePacket(query, parameters);
            return PacketProcessor.processExecuteAck(query, ack, this);
        } finally {
            freeTempLobs();
        }
    }

    private int getSameTypeNum(int startIndex, ParameterList[] parameters) {
        ParameterList first = parameters[startIndex];
        for (int i = startIndex + 1; i < parameters.length; i++) {
            ParameterList tmpParameterList = parameters[i];
            for (int j = 0; j < tmpParameterList.getParameterCount(); j++) {
                if (first.getParameters()[j].getType() != tmpParameterList.getParameters()[j].getType()) {
                    return i - startIndex;
                }
            }
        }
        return parameters.length;
    }

    private Packet sendExecutePacket(StatementImpl statement, Packet reqExecute, boolean isMore) throws SQLException {
        Packet ackPacket;
        if (isMore) {
            ackPacket = this.protocol.sendCommand(reqExecute, MsgType.CMD_MORE_DATA, 0);
        } else {
            ackPacket = this.protocol.sendCommand(reqExecute, MsgType.CMD_EXECUTE, 0);
        }

        return PacketProcessor.processInteractPacket(statement, ackPacket, this);
    }

    /*
     * Send Execute Packet Only,and don't receive ack packet.
     */
    private void sendExecutePacketOnly(Packet reqExecute, boolean isMore) throws SQLException {
        if (isMore) {
            this.protocol.sendCommandOnly(reqExecute, MsgType.CMD_MORE_DATA, 0);
        } else {
            this.protocol.sendCommandOnly(reqExecute, MsgType.CMD_EXECUTE, 0);
        }
    }

    private YasResultSet executeNoBind(StatementImpl statement) throws SQLException {
        Packet reqExecute = protocol.getSendPacket();

        PacketProcessor.writeReqExecute(statement, reqExecute, autoCommit);

        Packet ackPacket = this.protocol.sendCommand(reqExecute, MsgType.CMD_EXECUTE, 0);
        ackPacket = PacketProcessor.processInteractPacket(statement, ackPacket, this);

        return PacketProcessor.processExecuteAck(statement, ackPacket, this);
    }

    @Override
    public synchronized Packet fetch(YasStatement query, int fetchSize)
            throws SQLException {
        Packet reqFetch = protocol.getSendPacket();

        PacketProcessor.writeReqFetch(query, reqFetch);

        return this.protocol.sendCommand(reqFetch, MsgType.CMD_FETCH, 0);
    }

    @Override
    public synchronized Packet moreData() throws SQLException {
        Packet reqExecute = protocol.getSendPacket();
        this.protocol.sendCommandOnly(reqExecute, MsgType.CMD_MORE_DATA, 0);
        return this.protocol.receivePacket();
    }

    /**
     * Commit a transaction
     *
     * @throws SQLException if commit fails
     */
    @Override
    public synchronized void commit() throws SQLException {
        Packet commit = protocol.getSendPacket();
        this.protocol.sendCommand(commit, MsgType.CMD_COMMIT, 0);
        //End transaction
        this.setTransactionState(TransactionState.XACT_END);

        for (YasLargeObject largeObject : this.updatedKnlLobs) {
            largeObject.commit();
        }
        this.updatedKnlLobs.clear();
    }

    @Override
    public synchronized Packet continueExecute() throws SQLException {
        Packet commit = protocol.getSendPacket();
        return this.protocol.sendCommand(commit, MsgType.CMD_MORE_DATA, 0);
    }

    private Statement getStatement() throws SQLException {
        if ((statement == null) || statement.isClosed()) {
            statement = this.connection.createStatement();
        }

        return statement;
    }

    public boolean isPrimaryHost() throws SQLException {
        boolean isPrimary = false;
        ResultSet resultSet = null;
        try {
            statement = this.connection.createStatement();
            resultSet = statement.executeQuery("select DATABASE_ROLE from v$database");
            if (resultSet.next()) {
                String hostRole = resultSet.getString(1);
                if (hostRole.trim().equalsIgnoreCase(YasConstants.PRIMARY_ROLE)) {
                    isPrimary = true;
                }
            }
            resultSet.close();
            statement.close();
        } catch (Exception ignored) {
        } finally {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
        }

        return isPrimary;
    }

    /**
     * Rollback a transcation
     *
     * @throws SQLException if rollback failes
     */
    @Override
    public synchronized void rollback() throws SQLException {
        Packet packet = protocol.getSendPacket();
        this.protocol.sendCommand(packet, MsgType.CMD_ROLLBACK, 0);
        //End transaction
        this.setTransactionState(TransactionState.XACT_END);

        for (YasLargeObject largeObject : this.updatedKnlLobs) {
            largeObject.rollback();
        }
        this.updatedKnlLobs.clear();
    }

    @Override
    public HostSpec getHostSpec() {
        return yasSocketConnection.getHostSpec();
    }

    @Override
    public String getUser() {
        return user;
    }

    @Override
    public synchronized void setSchema(String schema) throws SQLException {
        Statement statement = getStatement();
        String sqlStr = "alter session set current_schema = " + schema;
        statement.execute(sqlStr);

        if (!schema.contains("\"")) {
            schema = schema.toUpperCase();
        } else {
            schema = schema.substring(1, schema.length() - 1);
        }
        this.schema = schema;
    }

    @Override
    public synchronized String getSchema() throws SQLException {
        return schema;
    }

    @Override
    public void setSID(int sid) {
        this.sessionID = sid;
    }

    @Override
    public void setCharset(short charset) {
        this.charset = charset;
    }

    @Override
    public void setSessionKey(int key) {
        this.sessionKey = key;
    }

    @Override
    public int getSessionKey() {
        return sessionKey;
    }

    @Override
    public String getDatabase() {
        return "";
    }

    @Override
    public void setNetworkTimeout(int milliseconds) throws IOException {
        yasSocketConnection.setNetworkTimeout(milliseconds);
    }

    @Override
    public int getNetworkTimeout() throws IOException {
        return yasSocketConnection.getNetworkTimeout();
    }

    @Override
    public void abort(Executor executor) {
        if (closed) {
            return;
        }

        closed = true;
        executor.execute(new Runnable() {
            @Override
            public void run() {
                doClose();
            }
        });
    }

    public void setProtocol(NativeProtocol protocol) {
        this.protocol = protocol;
    }

    public void setYasSocketConnection(YasSocketConnection yasSocketConnection) {
        this.yasSocketConnection = yasSocketConnection;
    }

    private void doClose() {
        try {
            if (statement != null) {
                statement.close();
            }
            doFreeLobs();
        } catch (SQLException exception) {
            LOGGER.error("Discarding SQLException on close: {}", exception.getMessage());
        }

        try {
            sendCloseMessage();
        } catch (SQLException sqlException) {
            LOGGER.error("Discarding SQLException on close: {}", sqlException.getMessage());
        }

        try {
            yasSocketConnection.flush();
            yasSocketConnection.close();
        } catch (IOException ioe) {
            LOGGER.error("Discarding IOException on close: {}", ioe.getMessage());
        }

        this.updatedKnlLobs.clear();
    }

    @Override
    public void close() {
        if (closed) {
            return;
        }

        LOGGER.debug(" FE=> Terminate");

        doClose();
        closed = true;
        connectionManager.unRegister(this);
    }

    @Override
    public void processInvalid() {
        LOGGER.error("The heartbeat time exceeds 60s, will force close socket.");
        closeStream(yasSocketConnection);
    }

    @Override
    public boolean isClosed() {
        return closed;
    }

    @Override
    public synchronized void closeStmt(int stmtID) throws SQLException {
        Packet reqClose = protocol.getSendPacket();
        reqClose.writeShort(stmtID);
        reqClose.writeShort(0);
        Packet ack = protocol.sendCommand(reqClose, MsgType.CMD_FREE_STMT, 0);

    }

    @Override
    public synchronized void addWarning(SQLWarning newWarning) {
        if (this.warnings == null) {
            this.warnings = newWarning;
        } else {
            warnings.setNextWarning(newWarning);
        }
    }

    @Override
    public synchronized SQLWarning getWarnings() {
        SQLWarning chain = warnings;
        warnings = null;
        return chain;
    }

    public synchronized void setTransactionState(TransactionState state) {
        transactionState = state;
    }

    public synchronized void setTransactionIsolation(int level) throws SQLException {
        Statement statement = getStatement();
        String isolationPara;
        switch (level) {
            case Connection.TRANSACTION_SERIALIZABLE: {
                isolationPara = "SERIALIZABLE";
                break;
            }
            case Connection.TRANSACTION_READ_COMMITTED:
            default: {
                isolationPara = "READ COMMITTED";
                break;
            }
        }

        String sqlStr = "alter session set isolation_level = " + isolationPara;
        statement.execute(sqlStr);
    }

    @Override
    public int getSID() {
        return sessionID;
    }

    public synchronized void setStandardConformingStrings(boolean value) {
        standardConformingStrings = value;
    }

    @Override
    public synchronized boolean getStandardConformingStrings() {
        return standardConformingStrings;
    }

    @Override
    public synchronized TransactionState getTransactionState() {
        return transactionState;
    }

    @Override
    public final Map<String, String> getParameterStatuses() {
        return Collections.unmodifiableMap(parameterStatuses);
    }

    @Override
    public final String getParameterStatus(String parameterName) {
        return parameterStatuses.get(parameterName);
    }

    protected synchronized void sendCloseMessage() throws SQLException {
        Packet logOut = protocol.getSendPacket();
        this.protocol.sendCommand(logOut, MsgType.CMD_LOGOUT, 0);
    }

    public void receiveParameterStatus() throws IOException, SQLException {
    }

    /**
     * Update the parameter status map in response to a new ParameterStatus wire protocol message.
     *
     * <p>The server sends ParameterStatus messages when GUC_REPORT settings are
     * initially assigned and whenever they change.</p>
     *
     * <p>A future version may invoke a client-defined listener class at this point,
     * so this should be the only access path.</p>
     *
     * <p>Keys are case-insensitive and case-preserving.</p>
     *
     * <p>The server doesn't provide a way to report deletion of a reportable
     * parameter so we don't expose one here.</p>
     *
     * @param parameterName   case-insensitive case-preserving name of parameter to create or update
     * @param parameterStatus new value of parameter
     * @see YasConnection#getParameterStatuses
     * @see YasConnection#getParameterStatus
     */
    protected void onParameterStatus(String parameterName, String parameterStatus) {
        if (parameterName == null || parameterName.equals("")) {
            throw new IllegalStateException(
                    "attempt to set GUC_REPORT parameter with null or empty-string name");
        }

        parameterStatuses.put(parameterName, parameterStatus);
    }

    @Override
    public void cancel() throws SQLException {
        int connectTimeout = Utils.toMillisecond(YasProperty.CONNECT_TIMEOUT.getInt(info));

        try {
            YasSocketConnection dupConn = new YasSocketConnection(yasSocketConnection, connectTimeout, true);
            NativeProtocol tempProtocol = new NativeProtocol(this, dupConn);
            tempProtocol.cancel();

            closeStream(dupConn);
        } catch (IOException ioe) {
            throw SQLError.createSQLException(Messages.get("The connection attempt failed."),
                    YasState.CONNECTION_UNABLE_TO_CONNECT, ioe);
        }
    }

    @Override
    public void connect() throws SQLException {
        String serverType = this.connection.getServerType();
        HostConnector connector = ConnectorFactory.generateConnector(this, hostSpecs, serverType);
        connector.checkConfigurations(info);
        connector.connect(getUser(), info);
        connectionManager.register(this);
    }

    /**
     * Safely close the given stream.
     *
     * @param newStream The stream to close.
     */
    protected void closeStream(YasSocketConnection newStream) {
        if (newStream != null) {
            try {
                newStream.close();
            } catch (IOException ignored) {
            }
        }
    }

    public synchronized Savepoint setSavepoint() throws SQLException {
        Savepoint savepoint = new YasSavepoint();
        Statement statement = getStatement();

        String sqlStr = "savepoint yas_autosvpt_" + savepoint.getSavepointId();
        statement.execute(sqlStr);

        return savepoint;
    }

    public synchronized Savepoint setSavepoint(String name) throws SQLException {
        Savepoint savepoint = new YasSavepoint(name);
        Statement statement = getStatement();

        String sqlStr = "savepoint " + savepoint.getSavepointName();
        statement.execute(sqlStr);

        return savepoint;
    }

    public synchronized void rollback(Savepoint savepoint) throws SQLException {
        if (savepoint == null) {
            return;
        }

        Statement statement = getStatement();
        String pointStr;
        try {
            pointStr = savepoint.getSavepointName();
        } catch (SQLException sqlException) {
            pointStr = "yas_autosvpt_" + savepoint.getSavepointId();
        }

        statement.execute("rollback to " + pointStr);
        //End transaction
        this.setTransactionState(TransactionState.XACT_END);

        for (YasLargeObject largeObject : this.updatedKnlLobs) {
            largeObject.rollback();
        }
        this.updatedKnlLobs.clear();
    }

    public boolean isUserCaseSensitive() {
        return userCaseSensitive;
    }

    public ConnectVersion getConnectVersion() {
        return this.connectVersion;
    }

    public void setConnectVersion(ConnectVersion connectVersion) {
        this.connectVersion = connectVersion;
    }

    public long trimLob(YasLobProcessor lobProcessor, long len) throws SQLException {
        Packet sendPacket = protocol.getSendPacket();
        PacketProcessor.writeReqLob(sendPacket, LobOperation.LOB_TRIM, lobProcessor, 0, len);
        Packet ackPacket = protocol.sendCommand(sendPacket, MsgType.CMD_LOB, 0);
        return PacketProcessor.processLobMetaDataAck(lobProcessor, ackPacket, LobOperation.LOB_TRIM);
    }

    public void addUpdatedKnlLob(YasLargeObject yasLargeObject) {
        updatedKnlLobs.add(yasLargeObject);
    }

    public void removeUpdatedKnlLob(YasLargeObject yasLargeObject) {
        updatedKnlLobs.remove(yasLargeObject);
    }

    @Override
    public YasClob preProcessReaderBinding(Reader reader, char[] readBuf, long maxLength) throws SQLException {
        YasClob clob = (YasClob)this.connection.createClob();
        StringBuilder stringBuilder = new StringBuilder(readBuf.length);
        stringBuilder.append(readBuf, 0, readBuf.length);

        int bufferSize = Math.min(readBuf.length, YasConstants.READER_BUFF_SIZE);
        int nRead;
        try {
            long tempLength = maxLength - readBuf.length;
            while (tempLength > 0L) {
                nRead = reader.read(readBuf, 0, (int)Math.min(bufferSize, tempLength));
                if (nRead < 0) {
                    break;
                } else if (nRead == 0) {
                    continue;
                }

                stringBuilder.append(readBuf, 0, nRead);
                tempLength -= nRead;
                if (stringBuilder.length() >= YasConstants.LOB_WRITE_CHAR_STEP_LEN - bufferSize) {
                    clob.setString(clob.length() + 1, stringBuilder.toString());
                    stringBuilder.setLength(0);
                }
            }

            if (stringBuilder.length() > 0) {
                clob.setString(clob.length() + 1, stringBuilder.toString());
                stringBuilder.setLength(0);
            }
        } catch (IOException ioe) {
            clob.free();
            throw SQLError.createSQLException(Messages.get("Access Provided Reader failed."),
                    YasState.UNEXPECTED_ERROR, ioe);
        }

        this.tempLobList.add(clob);
        return clob;
    }

    @Override
    public synchronized YasResultSet pdbgExecute(YasDebugCallableStatement statement, ParameterList[] parameters)
            throws SQLException {
        autoCommit = connection.getAutoCommit();
        this.debugExecute = true;

        YasResultSet resultSet;
        if (parameters == null) {
            resultSet = pdbgExecuteNoBind(statement);
        } else {
            resultSet = pdbgExecuteWithBind(statement, parameters);
        }

        //End transaction
        if (this.autoCommit ) {
            this.setTransactionState(TransactionState.XACT_END);
        }

        this.debugExecute = false;
        return resultSet;
    }

    private YasResultSet pdbgExecuteWithBind(YasDebugCallableStatement statement, ParameterList[] parameters)
            throws SQLException {
        YasResultSet yasResultSet = null;
        try {
            preProcessLobBind(parameters);

            if (parameters.length > YasConstants.MAX_EXECUTE_BIND_SIZE
                    || getSameTypeNum(0, parameters) != parameters.length) {
                return executePartitionBinds(statement, parameters);
            }

            Packet ack = sendBindExecutePacket(statement, parameters);
            yasResultSet = PacketProcessor.processDebugExecutePacket(statement, ack, this,
                    DebugOperation.DBG_START);
            if (yasResultSet != null) {
                freeTempLobs();
            }
            return yasResultSet;
        } catch (SQLException e) {
            freeTempLobs();
            throw e;
        }
    }

    private YasResultSet pdbgExecuteNoBind(YasDebugCallableStatement statement) throws SQLException {
        Packet reqExecute = protocol.getSendPacket();

        PacketProcessor.writeReqExecute(statement, reqExecute, autoCommit, this.debugExecute);

        Packet ackPacket = this.protocol.sendCommand(reqExecute, MsgType.CMD_EXECUTE, 0);
        ackPacket = PacketProcessor.processInteractPacket(statement, ackPacket, this);

        return PacketProcessor.processDebugExecutePacket(statement, ackPacket, this, DebugOperation.DBG_START);
    }

    @Override
    public synchronized void pdbgAbort(YasDebugCallableStatement statement) throws SQLException {
        Packet reqDebug = protocol.getSendPacket();

        PacketProcessor.writeReqDebug(statement, reqDebug, DebugOperation.DBG_ABORT, 0);

        Packet ackPacket;
        try {
            ackPacket = this.protocol.sendCommand(reqDebug, MsgType.CMD_DEBUG, 0);
        } catch (SQLException e) {
            this.setDebugOff();
            throw e;
        }

        ackPacket = PacketProcessor.processInteractPacket(statement, ackPacket, this);

        PacketProcessor.processDebugExecutePacket(statement, ackPacket, this, DebugOperation.DBG_ABORT);
    }

    @Override
    public synchronized void pdbgAddBreakpoint(YasDebugCallableStatement statement,
                                               List<DebugBreakpoint> debugBreakpointList) throws SQLException {

        for (DebugBreakpoint debugBreakpoint : debugBreakpointList) {
            Packet reqDebug = protocol.getSendPacket();

            PacketProcessor.writeReqDebug(statement, reqDebug, DebugOperation.DBG_ADD_BP,
                    YasConstants.DEBUG_BREAK_POINT_SIZE);

            reqDebug.writeLong(debugBreakpoint.getObjectId());
            reqDebug.writeShort(debugBreakpoint.getSubprogramId());
            reqDebug.writeInt(debugBreakpoint.getLineNum());

            Packet ackPacket;
            try {
                ackPacket = this.protocol.sendCommand(reqDebug, MsgType.CMD_DEBUG, 0);
            } catch (SQLException e) {
                this.setDebugOff();
                throw e;
            }

            int id = (int)PacketProcessor.processDebugMetaDataAck(this, statement,
                    ackPacket, DebugOperation.DBG_ADD_BP);
            debugBreakpoint.setId(id);
        }

    }

    @Override
    public synchronized void pdbgDeleteBreakpoint(YasDebugCallableStatement statement,
                                                  List<DebugBreakpoint> debugBreakpointList) throws SQLException {
        for (DebugBreakpoint debugBreakpoint : debugBreakpointList) {
            Packet reqDebug = protocol.getSendPacket();

            PacketProcessor.writeReqDebug(statement, reqDebug, DebugOperation.DBG_DEL_BP,
                    4);

            reqDebug.writeInt(debugBreakpoint.getId());

            Packet ackPacket;
            try {
                ackPacket = this.protocol.sendCommand(reqDebug, MsgType.CMD_DEBUG, 0);
            } catch (SQLException e) {
                this.setDebugOff();
                throw e;
            }

            PacketProcessor.processDebugMetaDataAck(this, statement, ackPacket, DebugOperation.DBG_ABORT);
        }
    }

    @Override
    public synchronized void pdbgCheckVersion(YasDebugCallableStatement statement, long objectId, int subprogramId,
                                              int version) throws SQLException {
        Packet reqDebug = protocol.getSendPacket();

        PacketProcessor.writeReqDebug(statement, reqDebug, DebugOperation.DBG_CHECK_VERSION,
                YasConstants.DEBUG_BREAK_POINT_SIZE);

        reqDebug.writeLong(objectId);
        reqDebug.writeShort(subprogramId);
        reqDebug.writeInt(version);

        Packet ackPacket;
        try {
            ackPacket = this.protocol.sendCommand(reqDebug, MsgType.CMD_DEBUG, 0);
        } catch (SQLException e) {
            this.setDebugOff();
            throw e;
        }

        PacketProcessor.processDebugMetaDataAck(this, statement, ackPacket, DebugOperation.DBG_CHECK_VERSION);
    }

    @Override
    public synchronized YasResultSet pdbgStepDebug(YasDebugCallableStatement statement, DebugOperation dbgStepInto)
            throws SQLException {
        try {
            Packet reqDebug = protocol.getSendPacket();

            PacketProcessor.writeReqDebug(statement, reqDebug, dbgStepInto, 0);

            Packet ackPacket;
            try {
                ackPacket = this.protocol.sendCommand(reqDebug, MsgType.CMD_DEBUG, 0);
            } catch (SQLException e) {
                this.setDebugOff();
                throw e;
            }

            ackPacket = PacketProcessor.processInteractPacket(statement, ackPacket, this);

            YasResultSet yasResultSet = PacketProcessor.processDebugExecutePacket(statement, ackPacket, this,
                    dbgStepInto);
            if (yasResultSet != null) {
                freeTempLobs();
            }
            return yasResultSet;
        } catch (SQLException e) {
            freeTempLobs();
            throw e;
        }
    }

    @Override
    public synchronized List<DebugVar> pdbgShowVars(YasDebugCallableStatement statement) throws SQLException {
        Packet reqDebug = protocol.getSendPacket();

        PacketProcessor.writeReqDebug(statement, reqDebug, DebugOperation.DBG_SHOW_VARS, 0);

        Packet ackPacket;
        try {
            ackPacket = this.protocol.sendCommand(reqDebug, MsgType.CMD_DEBUG, 0);
        } catch (SQLException e) {
            this.setDebugOff();
            throw e;
        }

        List<DebugVar> result = (List<DebugVar>)PacketProcessor.processDebugMetaDataAck(this,
                statement, ackPacket, DebugOperation.DBG_SHOW_VARS);
        return result;
    }

    @Override
    public synchronized List<DebugFrame> pdbgShowFrames(YasDebugCallableStatement statement) throws SQLException {
        Packet reqDebug = protocol.getSendPacket();

        PacketProcessor.writeReqDebug(statement, reqDebug, DebugOperation.DBG_SHOW_FRAMES, 0);

        Packet ackPacket;
        try {
            ackPacket = this.protocol.sendCommand(reqDebug, MsgType.CMD_DEBUG, 0);
        } catch (SQLException e) {
            this.setDebugOff();
            throw e;
        }

        List<DebugFrame> result = (List<DebugFrame>)PacketProcessor.processDebugMetaDataAck(this,
                statement, ackPacket, DebugOperation.DBG_SHOW_FRAMES);
        return result;
    }

    public void abortDebug() throws SQLException {
        if (this.debugOn) {
            this.pdbgAbort(this.runningDebugStatement);
        }
    }

    public void updateDebugStatus(YasDebugCallableStatement statement, long objectId, int subprogramId,
                                  int lineNum) {
        if (!this.debugOn) {
            this.debugOn = true;
            this.runningDebugStatement = statement;
        }
        this.runningDebugStatement.setDebugStatus(YasConstants.DEBUG_STATUS_ON, objectId, subprogramId, lineNum);
    }

    public void setDebugOff() {
        if (!this.debugOn) {
            return;
        }

        this.runningDebugStatement.setDebugStatus(YasConstants.DEBUG_STATUS_OFF, -1L, -1,
                -1);
        this.debugOn = false;
        this.runningDebugStatement = null;
    }
}
