/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.ConnectVersion;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.SQLException;

public class Packet extends BaseBuffer {
    public static final int HEAD_PACKET_LEN = 8;

    public static final int SUCESS = 0;
    public static final int SUCCESS_WITH_INFO = 1;
    public static final int ERROR = -1;

    public static final int COLHEAD_NULL = 255;
    public static final int COLHEAD_LONG = 253;

    private static final int HEAD_FLAG_MORE_DATA = 0x01;
    private static final int HEAD_FLAG_NO_MORE_DATA = 0xfe;

    private static final int HEAD_PACKET_SIZE_OFFSET = 0;
    private static final int HEAD_CMD_OFFSET = 4;
    private static final int HEAD_RESULT_OFFSET = 5;
    private static final int HEAD_FLAG_OFFSET = 6;
    private static final int HEAD_CMD_VER_OFFSET = 7;

    MsgType msgType;
    int result;
    int flag = 0;

    public Packet(int capacity) {
        super(capacity);
    }

    public Packet(Buffer buffer) {
        super(buffer);
    }

    public int getRowSize() {
        int colHead = getByte() & 0xff;

        if (colHead == COLHEAD_NULL) {
            // is null
            return 0;
        }
        if (colHead < COLHEAD_LONG) {
            return colHead;
        }

        return getShort() & 0xffff;
    }

    public void encode(ConnectVersion clientVersion) {
        writeInt(HEAD_PACKET_SIZE_OFFSET, position);
        writeByte(HEAD_CMD_OFFSET, (byte) msgType.getValue());
        writeByte(HEAD_RESULT_OFFSET, (byte) result);
        writeByte(HEAD_FLAG_OFFSET, (byte) flag);
        writeByte(HEAD_CMD_VER_OFFSET, (byte) msgType.getVersion(clientVersion));
    }

    public int getMessageSize() {
        int msgSize = getInt(HEAD_PACKET_SIZE_OFFSET);
        return msgSize - HEAD_PACKET_LEN;
    }

    public MsgType getCmd() throws SQLException {
        byte cmdType = getByte(HEAD_CMD_OFFSET);
        if (cmdType >= MsgType.values().length) {
            SQLError.createSQLException("protocol error, invalid command type", YasState.PROTOCOL_VIOLATION);
        }

        return MsgType.values()[cmdType];
    }

    public void setCmd(MsgType cmd) {
        msgType = cmd;
    }

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    /*
     * 0 SUCCESS
     * 1 SUCCESS with info
     * 2 error
     * */
    public boolean isError() {
        return (getByte(HEAD_RESULT_OFFSET) == ERROR);
    }

    public boolean hasInfo() {
        return (getByte(HEAD_RESULT_OFFSET) == SUCCESS_WITH_INFO);
    }

    public byte getCmdVersion() {
        return getByte(HEAD_CMD_VER_OFFSET);
    }

    public void setHasMore(boolean hasMore) {
        if (hasMore) {
            flag = (byte) (flag | HEAD_FLAG_MORE_DATA);
        } else {
            flag = (byte) (flag & HEAD_FLAG_NO_MORE_DATA);
        }
    }

    @Override
    public void clean() {
        super.clean();
        this.result = 0;
        this.flag = 0;
    }

    public boolean hasReadToEnd() {
        return this.position >= (this.getMessageSize() + HEAD_PACKET_LEN);
    }
}
