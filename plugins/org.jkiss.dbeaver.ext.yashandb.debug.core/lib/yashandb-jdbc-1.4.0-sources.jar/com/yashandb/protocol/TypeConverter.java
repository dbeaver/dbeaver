/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.YasTime;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.sql.Clob;
import java.sql.Date;
import java.sql.JDBCType;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;

public class TypeConverter {

    private static String asString(final Clob in) throws SQLException {
        return in.getSubString(1, (int) in.length());
    }

    public static int castToInt(final Object in, int targetType) throws SQLException {
        try {
            if (in instanceof String) {
                return Integer.parseInt((String) in);
            }
            if (in instanceof Number) {
                return ((Number) in).intValue();
            }
            if (in instanceof Boolean) {
                return (Boolean) in ? 1 : 0;
            }
            if (in instanceof Clob) {
                return Integer.parseInt(asString((Clob) in));
            }
            if (in instanceof Character) {
                return Integer.parseInt(in.toString());
            }
        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName(), e);
        }
        throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName());
    }

    public static short castToShort(final Object in, int targetType) throws SQLException {
        try {
            if (in instanceof String) {
                return Short.parseShort((String) in);
            }
            if (in instanceof Number) {
                return ((Number) in).shortValue();
            }
            if (in instanceof Boolean) {
                return (Boolean) in ? (short) 1 : (short) 0;
            }
            if (in instanceof Clob) {
                return Short.parseShort(asString((Clob) in));
            }
            if (in instanceof Character) {
                return Short.parseShort(in.toString());
            }
        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName(), e);
        }
        throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName());
    }

    public static long castToLong(final Object in, int targetType) throws SQLException {
        try {
            if (in instanceof String) {
                return Long.parseLong((String) in);
            }
            if (in instanceof Number) {
                return ((Number) in).longValue();
            }
            if (in instanceof Boolean) {
                return (Boolean) in ? 1L : 0L;
            }
            if (in instanceof Clob) {
                return Long.parseLong(asString((Clob) in));
            }
            if (in instanceof Character) {
                return Long.parseLong(in.toString());
            }
        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName(), e);
        }
        throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName());
    }

    public static float castToFloat(final Object in, int targetType) throws SQLException {
        try {
            if (in instanceof String) {
                return Float.parseFloat((String) in);
            }
            if (in instanceof Number) {
                return ((Number) in).floatValue();
            }
            if (in instanceof Boolean) {
                return (Boolean) in ? 1f : 0f;
            }
            if (in instanceof Clob) {
                return Float.parseFloat(asString((Clob) in));
            }
            if (in instanceof Character) {
                return Float.parseFloat(in.toString());
            }
        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName(), e);
        }
        throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName());
    }

    public static double castToDouble(final Object in, int targetType) throws SQLException {
        try {
            if (in instanceof String) {
                return Double.parseDouble((String) in);
            }
            if (in instanceof Number) {
                return ((Number) in).doubleValue();
            }
            if (in instanceof Boolean) {
                return (Boolean) in ? 1d : 0d;
            }
            if (in instanceof Clob) {
                return Double.parseDouble(asString((Clob) in));
            }
            if (in instanceof Character) {
                return Double.parseDouble(in.toString());
            }
        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName(), e);
        }
        throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName());
    }

    public static BigDecimal castToBigDecimal(final Object in, final int scale, int targetType) throws SQLException {
        try {
            BigDecimal rc = null;
            if (in instanceof String) {
                rc = new BigDecimal((String) in);
            } else if (in instanceof BigDecimal) {
                rc = ((BigDecimal) in);
            } else if (in instanceof BigInteger) {
                rc = new BigDecimal((BigInteger) in);
            } else if (in instanceof Long || in instanceof Integer || in instanceof Short
                    || in instanceof Byte) {
                rc = BigDecimal.valueOf(((Number) in).longValue());
            } else if (in instanceof Double || in instanceof Float) {
                rc = BigDecimal.valueOf(((Number) in).doubleValue());
            } else if (in instanceof Boolean) {
                rc = (Boolean) in ? BigDecimal.ONE : BigDecimal.ZERO;
            } else if (in instanceof Clob) {
                rc = new BigDecimal(asString((Clob) in));
            } else if (in instanceof Character) {
                rc = new BigDecimal(new char[]{(Character) in});
            }
            if (rc != null) {
                if (scale >= 0) {
                    rc = rc.setScale(scale, RoundingMode.HALF_UP);
                }
                return rc;
            }
        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName(), e);
        }
        throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName());
    }

    public static String castToString(final Object in, int targetType, int scale) throws SQLException {
        try {
            if (in instanceof String) {
                return (String) in;
            }
            if (in instanceof Clob) {
                return asString((Clob) in);
            }
            if (in instanceof byte[]) {
                return new String((byte[]) in);
            }
            if (in instanceof InputStream) {
                return new String(getBytesByInputStream((InputStream) in, scale));
            }
            if (in instanceof Boolean || in instanceof Number || in instanceof java.util.Date
                    || in instanceof java.util.Calendar
                    || in instanceof java.time.LocalDate || in instanceof java.time.LocalTime
                    || in instanceof java.time.LocalDateTime || in instanceof java.time.OffsetTime
                    || in instanceof java.time.OffsetDateTime) {
                return in.toString();
            }
        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName(), e);
        }
        throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetType).getName());
    }

    public static Timestamp castToTimeStamp(final Object in) throws SQLException {
        try {
            if (in instanceof Timestamp) {
                return (Timestamp) in;
            }
            if (in instanceof java.sql.Date) {
                return new Timestamp(((java.util.Date) in).getTime());
            }
            if (in instanceof java.sql.Time) {
                return new Timestamp(((java.sql.Time) in).getTime());
            }
            if (in instanceof java.util.Date) {
                return new Timestamp(((java.util.Date) in).getTime());
            }
            if (in instanceof java.util.Calendar) {
                return new Timestamp(((java.util.Calendar) in).getTimeInMillis());
            }
            if (in instanceof LocalDateTime) {
                return Timestamp.valueOf((LocalDateTime) in);
            }
            if (in instanceof String) {
                return Timestamp.valueOf((String)in);
            }
        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), "Timestamp", e);
        }

        throw SQLError.TransformException(in.getClass().getName(), "Timestamp");
    }

    public static boolean castToBoolean(final Object in) throws SQLException {
        try {
            if (in instanceof String) {
                if ("TRUE".equalsIgnoreCase((String) in) || "ON".equalsIgnoreCase((String) in)
                        || "YES".equalsIgnoreCase((String) in) || "T".equalsIgnoreCase((String) in)
                        || "Y".equalsIgnoreCase((String) in) || "1".equals((String)in) ) {
                    return true;
                } else if ("FALSE".equalsIgnoreCase((String) in) || "OFF".equalsIgnoreCase((String) in)
                        || "NO".equalsIgnoreCase((String) in) || "F".equalsIgnoreCase((String) in)
                        || "N".equalsIgnoreCase((String) in) || "0".equals((String)in)) {
                    return false;
                }
            }

            if (in instanceof Boolean) {
                return (Boolean) in;
            }

            if (in instanceof Number) {
                return ((Number)in).doubleValue() != 0;
            }
        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), "Boolean", e);
        }
        throw SQLError.TransformException(in.getClass().getName(), "Boolean");
    }

    /**
     * Cast Object to Time datatype
     * String format: hh:mm:ss
     * @param in Convert Support Time/Timestamp/Date/Calendar/String
     * @return Time
     * @throws SQLException cannotCastException
     */
    public static Time castToTime(final Object in) throws SQLException {
        try {
            if (in instanceof Time) {
                return (Time) in;
            }
            if (in instanceof Timestamp) {
                YasTime at = new YasTime(((Timestamp) in).getTime());
                at.setNanos(((Timestamp) in).getNanos());
                return at;
            }
            if (in instanceof java.util.Date) {
                return new Time(((java.util.Date) in).getTime());
            }
            if (in instanceof LocalTime) {
                return YasTime.valueOf((LocalTime)in);
            }
            if (in instanceof java.util.Calendar) {
                return new Time(((java.util.Calendar) in).getTimeInMillis());
            }
            if (in instanceof LocalDate) {
                return Time.valueOf((LocalTime) in);
            }
            if (in instanceof LocalDateTime) {
                return Time.valueOf(((LocalDateTime) in).toLocalTime());
            }
            if (in instanceof String) {
                return YasTime.valueOf((String)in);
            }
        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), "Time", e);
        }

        throw SQLError.TransformException(in.getClass().getName(), "Time");
    }

    public static java.sql.Date castToDate(final Object in) throws SQLException {
        try {
            if (in instanceof java.sql.Date) {
                return (Date)in;
            }
            if (in instanceof String) {
                return Date.valueOf((String)in);
            }
            if (in instanceof Timestamp) {
                return new Date(((Timestamp)in).getTime());
            }
            if (in instanceof Time) {
                return new Date(((Time)in).getTime());
            }
            if (in instanceof java.util.Date) {
                return new Date(((java.util.Date) in).getTime());
            }
            if (in instanceof LocalDate) {
                return Date.valueOf((LocalDate) in);
            }
            if (in instanceof LocalDateTime) {
                return Date.valueOf(((LocalDateTime) in).toLocalDate());
            }
            if (in instanceof java.util.Calendar) {
                return new Date(((java.util.Calendar) in).getTimeInMillis());
            }

        } catch (final Exception e) {
            throw SQLError.TransformException(in.getClass().getName(), "Date", e);
        }

        throw SQLError.TransformException(in.getClass().getName(), "Date");
    }

    public static long castToDsInterval(final Object objectInterval) throws SQLException {
        try {
            if (objectInterval instanceof String) {
                return IntervalType.convertStringToDsInterval((String)objectInterval);
            } else if (objectInterval instanceof Duration) {
                Duration duration = (Duration) objectInterval;
                return duration.getSeconds() * 1000000L + duration.getNano() / 1000L;
            }
        } catch (Exception e) {
            throw SQLError.TransformException(objectInterval.getClass().getName(), "DsInterval", e);
        }
        throw SQLError.TransformException(objectInterval.getClass().getName(), "DsInterval");
    }

    public static int castToYmInterval(final Object objectInterval) throws SQLException {
        try {
            if (objectInterval instanceof String) {
                return IntervalType.convertStringToYmInterval((String) objectInterval);
            } else if (objectInterval instanceof Period) {
                Period period = (Period) objectInterval;
                return (int) period.toTotalMonths();
            }
        } catch (Exception e) {
            throw SQLError.TransformException(objectInterval.getClass().getName(), "YmInterval", e);
        }
        throw SQLError.TransformException(objectInterval.getClass().getName(), "YmInterval");
    }

    public static byte[] getBytesByInputStream(InputStream inputStream, int scale) throws SQLException {
        try {
            byte[] bytes = new byte[scale > 0 ? Math.min(inputStream.available(), scale) : inputStream.available()];
            inputStream.read(bytes);
            return bytes;
        } catch (IOException e) {
            throw  SQLError.createSQLException(e.getMessage(), YasState.IO_ERROR, e);
        }
    }
}
