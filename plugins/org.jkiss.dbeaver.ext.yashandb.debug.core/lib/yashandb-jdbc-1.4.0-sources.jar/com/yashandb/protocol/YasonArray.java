/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.util.ByteConverter;

import java.sql.SQLException;

public class YasonArray extends Yason {

    private static final int ARRAY_ELEMENT_LENGTH = 5;

    public YasonArray(byte[] data, short charset) throws SQLException {
        super(data, charset);
    }

    protected void init() throws SQLException {
        this.size = ByteConverter.int2(data, 0);
        Object[] array = new Object[size];
        int[] arrayOffsets = new int[size];
        for (int i = 0; i < size; i++) {
            int typeIndex = Yason.SIZE_OFFSET + i * YasonArray.ARRAY_ELEMENT_LENGTH;
            int valueType = data[typeIndex];
            switch (valueType) {
                case OBJECT_TYPE:
                case ARRAY_TYPE:
                case STRING_TYPE:
                case NUMBER_TYPE:
                    arrayOffsets[i] = ByteConverter.int4(data, typeIndex + 1);
                    break;
                case BOOL_TYPE:
                    array[i] = data[typeIndex + 1] == 1;
                    arrayOffsets[i] = 0;
                    break;
                case NULL_TYPE:
                    arrayOffsets[i] = 0;
                    break;
            }
        }
        for (int i = 0; i < size; i++) {
            if (arrayOffsets[i] != 0) {
                Object value = null;
                int valueType = data[arrayOffsets[i]];
                if (valueType == STRING_TYPE) {
                    value = getStringValue(data,arrayOffsets[i] + 1, charset);
                } else if (valueType == OBJECT_TYPE || valueType == ARRAY_TYPE) {
                    value = getChildYason(valueType,data,arrayOffsets[i] + 1, charset);
                } else if (valueType == NUMBER_TYPE) {
                    value = getNumberValue(data, arrayOffsets[i] + 1);
                }
                array[i] = value;
            }
        }
        self = array;
    }

    @Override
    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("[");
        if (self instanceof Object[]) {
            Object[] objects = (Object[]) self;
            for (Object value : objects) {
                if (buffer.length() != 1) {
                    buffer.append(",");
                }
                appendValueToJsonBuffer(buffer, value);
            }
        }
        buffer.append("]");
        return buffer.toString();
    }
}
