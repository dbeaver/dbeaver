/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.ParameterList;
import com.yashandb.SessionImpl;
import com.yashandb.YasConstants;
import com.yashandb.YasResultSet;
import com.yashandb.core.DataType;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.DebugFrame;
import com.yashandb.jdbc.DebugFrameImpl;
import com.yashandb.jdbc.DebugVar;
import com.yashandb.jdbc.DebugVarImpl;
import com.yashandb.jdbc.Field;
import com.yashandb.jdbc.ResultSetFactory;
import com.yashandb.jdbc.ResultSetImpl;
import com.yashandb.jdbc.Row;
import com.yashandb.jdbc.RowData;
import com.yashandb.jdbc.RowDataFactory;
import com.yashandb.jdbc.StatementImpl;
import com.yashandb.jdbc.YasDebugCallableStatement;
import com.yashandb.jdbc.YasLobProcessor;
import com.yashandb.jdbc.YasStatement;
import com.yashandb.jdbc.exception.BatchError;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.jdbc.exception.YasBatchUpdateException;
import com.yashandb.jdbc.exception.YasException;
import com.yashandb.parameter.YasParameter;
import com.yashandb.protocol.accessor.Accessor;
import com.yashandb.protocol.accessor.AccessorFactory;
import com.yashandb.util.ByteConverter;
import com.yashandb.util.CharacterSet;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;

public class PacketProcessor {

    private static final int PREPARE_MASK_LEN = 0xFFFFFFFE;
    private static final int SQL_LEN_MORE_FLAG = 0x01;
    private static final int PREPARE_ACK_NULLABLE_FLAG = 0x01;
    private static final int EXECUTE_FLAG_AUTO_COMMIT = 0x01;
    private static final int EXECUTE_FLAG_DML_ROW = 0x04;
    private static final int EXECUTE_FLAG_BATCH_ERROR = 0x08;
    private static final int EXECUTE_FLAG_DEBUG = 0x80;

    public static void writeReqSql(Packet sendPacket, byte[] sqlBytes,
                                   int start, int sqlLen, boolean sqlMore) {
        if (sqlLen <= 0) {
            return;
        }

        int reqLenFlag = 0;
        int reqLen = sqlLen << 1;
        reqLen &= PREPARE_MASK_LEN;
        reqLenFlag |= reqLen;

        if (sqlMore) {
            reqLenFlag |= SQL_LEN_MORE_FLAG;
        }

        sendPacket.writeInt(reqLenFlag);

        // put sql string
        sendPacket.writeBytes(sqlBytes, start, sqlLen);
    }

    public static void writeReqPrepare(StatementImpl statement, Packet preparePacket) {
        preparePacket.writeShort(statement.getID());
        preparePacket.skip(2);
    }

    private static byte getExecFlag(boolean autoCommit) {
        byte executeFlag = 0;
        if (autoCommit) {
            executeFlag |= EXECUTE_FLAG_AUTO_COMMIT;
        }

        return executeFlag;
    }

    private static byte getExecFlag(boolean autoCommit, boolean isDebug) {
        byte executeFlag = 0;
        if (autoCommit) {
            executeFlag |= EXECUTE_FLAG_AUTO_COMMIT;
        }

        if (isDebug) {
            executeFlag |= EXECUTE_FLAG_DEBUG;
        }

        return executeFlag;
    }

    private static byte getExecFlag(boolean autoCommit,boolean dmlRow,boolean batchError) {
        byte executeFlag = 0;
        if (autoCommit) {
            executeFlag |= EXECUTE_FLAG_AUTO_COMMIT;
        }

        if (dmlRow) {
            executeFlag |= EXECUTE_FLAG_DML_ROW;
        }

        if (batchError) {
            executeFlag |= EXECUTE_FLAG_BATCH_ERROR;
        }

        return executeFlag;
    }

    private static byte getExecFlag(boolean autoCommit, boolean dmlRow, boolean batchError, boolean isDebug) {
        byte executeFlag = 0;
        if (autoCommit) {
            executeFlag |= EXECUTE_FLAG_AUTO_COMMIT;
        }

        if (dmlRow) {
            executeFlag |= EXECUTE_FLAG_DML_ROW;
        }

        if (batchError) {
            executeFlag |= EXECUTE_FLAG_BATCH_ERROR;
        }

        if (isDebug) {
            executeFlag |= EXECUTE_FLAG_DEBUG;
        }

        return executeFlag;
    }

    public static void writeReqLob(Packet sendPacket, LobOperation lobOperation,
                                   YasLobProcessor lobProcessor, int reqLen, long offset) {
        byte[] lobLocator = lobProcessor.getLobLocator();
        int lobType = lobProcessor.getLobType();
        sendPacket.writeByte((byte) lobOperation.getValue());
        sendPacket.writeByte((byte) 0);  // flag
        sendPacket.writeByte((byte) lobType);  // lobType
        if (lobLocator == null) {
            sendPacket.writeByte((byte) lobProcessor.getCsLobLocatorSize());  // locator length
        } else {
            sendPacket.writeByte((byte) lobLocator.length);
        }
        sendPacket.writeInt(reqLen);       // reqLen
        sendPacket.writeLong(offset);      // offset
        if (lobLocator == null) {
            sendPacket.skip(YasConstants.LOB_LOCATOR_SIZE);
        } else {
            sendPacket.writeBytes(lobLocator);  // locator
        }
    }

    public static void writeReqLobByLobLocator(Packet sendPacket, LobOperation lobOperation,
                                               YasLobProcessor lobProcessor, int reqLen, long offset) {
        byte[] lobLocator = lobProcessor.getLobLocator();
        int lobType = lobProcessor.getLobType();
        sendPacket.writeByte((byte) lobOperation.getValue());
        sendPacket.writeByte((byte) 1);  // flag
        sendPacket.writeByte((byte) lobType);  // lobType
        if (lobLocator == null) {
            sendPacket.writeByte((byte) lobProcessor.getCsLobLocatorSize());  // locator length
        } else {
            sendPacket.writeByte((byte) lobLocator.length);
        }
        sendPacket.writeInt(reqLen);       // reqLen
        sendPacket.writeLong(offset);      // offset
        if (lobLocator == null) {
            sendPacket.skip(YasConstants.LOB_LOCATOR_SIZE);
        } else {
            sendPacket.writeBytes(lobLocator);  // locator
        }
    }

    public static void writeReqExecute(YasStatement statement, Packet sendPacket, boolean autoCommit) {
        sendPacket.writeShort(statement.getID());
        sendPacket.writeByte(getExecFlag(autoCommit));
        sendPacket.skip(1);
        sendPacket.writeShort(0);  //Parameter Count
        sendPacket.writeShort(1);  //Parameter Size

        int fetchSize = 0;
        try {
            fetchSize = statement.getFetchSize();
        } catch (Exception e) { }  //No Exception should be throw
        sendPacket.writeInt(fetchSize);  //Prefetch Size
    }

    public static void writeReqExecute(YasStatement statement, Packet sendPacket, boolean autoCommit, boolean isDebug) {
        sendPacket.writeShort(statement.getID());
        sendPacket.writeByte(getExecFlag(autoCommit, isDebug));
        sendPacket.skip(1);
        sendPacket.writeShort(0);  //Parameter Count
        sendPacket.writeShort(1);  //Parameter Size

        int fetchSize = 0;
        try {
            fetchSize = statement.getFetchSize();
        } catch (Exception e) { }  //No Exception should be throw
        sendPacket.writeInt(fetchSize);  //Prefetch Size
    }

    public static void writeFetchCursor(short cursorId, Packet sendPacket, int preFetchSize) {
        sendPacket.writeShort(cursorId);
        sendPacket.writeByte(getExecFlag(false));
        sendPacket.skip(1);
        sendPacket.writeShort(0);
        sendPacket.writeShort(1);
        sendPacket.writeInt(preFetchSize);
    }

    public static void writeReqFetch(YasStatement statement, Packet sendPacket) {
        sendPacket.writeShort(statement.getID());
        sendPacket.writeShort(0);
    }

    public static void writeReqExecute(StatementImpl statement, Packet sendPacket, ParameterList[] parameters,
        boolean autoCommit, boolean isDebug) throws SQLException {
        sendPacket.writeShort(statement.getID());  // stmtId
        if (parameters.length > 1) {
            boolean dmlRow = true;
            sendPacket.writeByte(getExecFlag(autoCommit,dmlRow,statement.getIsBatchError(), isDebug));
        } else {
            sendPacket.writeByte(getExecFlag(autoCommit, isDebug));
        }
        sendPacket.skip(1);
        if ( parameters.length > 0) {
            sendPacket.writeShort(parameters[0].getParameterCount());  //Parameter Count
        } else {
            sendPacket.writeShort(0);
        }
        sendPacket.writeShort((short)parameters.length);  //Parameter Size
        sendPacket.writeInt(statement.getFetchSize());  //Prefetch Size

        putParamType(parameters[0], sendPacket);
    }

    private static void putParamType(ParameterList parameter, Packet reqExecute) throws YasException {
        if (parameter != null) {
            for (int i = 0; i < parameter.getParameterCount(); i++) {
                YasParameter yasParameter = parameter.getParameters()[i];
                if (yasParameter == null) {
                    throw SQLError.createSQLException("Parameter is missing,index:" + (i + 1),
                            YasState.UNKNOWN_STATE);
                } else {
                    yasParameter.writeInfo(reqExecute);
                }
            }
        }
    }

    public static long processLobMetaDataAck(YasLobProcessor lobProcessor, Packet ackPacket, LobOperation operation)
            throws SQLException {
        byte[] lobLocator = lobProcessor.getLobLocator();
        byte locatorLen = ackPacket.getByte();
        byte dataInfo = ackPacket.getByte();
        boolean hasData = (dataInfo & 0x01) != 0;
        boolean dataEof = (dataInfo & 0x02) != 0;

        ackPacket.skip(2);
        int dataLen = ackPacket.getInt();
        long retValue = ackPacket.getLong();
        byte[] ackLocator = ackPacket.getBytes(locatorLen);

        if (operation == LobOperation.LOB_WRITE || operation == LobOperation.LOB_TRIM) {
            //update lobLocator
            lobProcessor.setLobLocator(ackLocator);
        } else {
            for (int i = 0; i < locatorLen; i++) {
                if (ackLocator[i] != lobLocator[i]) {
                    throw new YasException("ack lob locator verify fail", YasState.DATA_ERROR);
                }
            }
        }

        return retValue;
    }

    public static byte[] processLobCreateAck(Packet ackPacket) throws SQLException {
        byte locatorLen = ackPacket.getByte();
        byte dataInfo = ackPacket.getByte();
        ackPacket.skip(2);
        int dataLen = ackPacket.getInt();
        long retValue = ackPacket.getLong();

        return ackPacket.getBytes(locatorLen);
    }

    public static int processLobDataAck(byte[] lobLocator, Packet ackPacket, byte[] cacheData) throws SQLException {
        byte locatorLen = ackPacket.getByte();
        byte dataInfo = ackPacket.getByte();
        boolean hasData = (dataInfo & 0x01) != 0;
        boolean dataEof = (dataInfo & 0x02) != 0;

        ackPacket.skip(2);
        int dataLen = ackPacket.getInt();
        long retValue = ackPacket.getLong();
        byte[] ackLocator = ackPacket.getBytes(locatorLen);

        for (int i = 0; i < locatorLen; i++) {
            if (ackLocator[i] != lobLocator[i]) {
                throw new YasException("ack lob locator verify fail", YasState.DATA_ERROR);
            }
        }

        if (hasData) {
            if (dataLen < 0) {
                throw new YasException("lob data length wrong: " + dataLen, YasState.DATA_ERROR);
            }

            if (cacheData.length < dataLen) {
                throw new YasException("lob cache buffer size: " + cacheData.length
                        + " is small than ack data length: " + dataLen, YasState.OUT_OF_MEMORY);
            }
            ackPacket.getBytes(dataLen, cacheData);
            return dataLen;
        }

        return 0;
    }

    public static Packet processInteractPacket(StatementImpl statement, Packet ackPacket, SessionImpl session)
            throws SQLException {
        while (true) {
            if (ackPacket.getCmd() != MsgType.CMD_RETURN_RESULT) {
                return ackPacket;
            }

            short cursorId = ackPacket.getShort();
            YasResultSet resultSet = session.fetchReturnResultSet(cursorId);
            statement.addImplicitResultSet(resultSet);

            ackPacket = session.continueExecute();
        }
    }

    public static YasResultSet processFetchImplicitResultAck(StatementImpl stmt, Packet fetchCursorAck,
                                                             SessionImpl session) throws SQLException {
        // ack prepare
        short stmtID = fetchCursorAck.getShort();
        short columnCount = fetchCursorAck.getShort();
        short paramCount = fetchCursorAck.getShort();
        byte sqlType = fetchCursorAck.getByte();
        fetchCursorAck.skip(1);

        // ack execute
        ExecuteResult exeResult = new ExecuteResult(fetchCursorAck);

        stmt.setStmtID(stmtID, sqlType);
        if ((columnCount <= 0) || (paramCount > 0)) {
            throw SQLError.createSQLException("invalid return result", YasState.DATA_ERROR);
        }

        Field[] resultFields = getPrepColumns(fetchCursorAck, columnCount);
        stmt.setFields(resultFields);
        return getCacheResultSetFromExecResult(stmt, resultFields, exeResult, fetchCursorAck, session);
    }

    public static YasResultSet processDirectExecuteAck(StatementImpl stmt, Packet ackPacket, SessionImpl session)
            throws SQLException {

        // ack prepare
        short stmtID = ackPacket.getShort();
        short columnCount = ackPacket.getShort();
        short paramCount = ackPacket.getShort();
        byte sqlType = ackPacket.getByte();
        ackPacket.skip(1);

        // ack execute
        ExecuteResult result = new ExecuteResult(ackPacket);

        stmt.setStmtID(stmtID, sqlType);
        if (columnCount > 0) {
            Field[] resultFields = getPrepColumns(ackPacket, columnCount);
            stmt.setFields(resultFields);
        } else {
            stmt.setFields(null);
        }

        if (paramCount > 0) {
            Field[] parameterFields = getPrepParams(ackPacket, paramCount);
            stmt.setParameters(parameterFields);
        }

        return getResultSetFromExecResult(stmt, result, ackPacket, session);
    }

    public static YasResultSet processExecuteAck(StatementImpl stmt, Packet ack, SessionImpl session)
            throws SQLException {
        ExecuteResult result = new ExecuteResult(ack);
        return getResultSetFromExecResult(stmt, result, ack, session);
    }

    public static YasResultSet proocessExecuteAckInBatchMode(StatementImpl stmt, Packet ack, SessionImpl session)
        throws SQLException {
        ExecuteResult result = new ExecuteResult(ack,true);
        return getResultSetFromExecResult(stmt, result, ack, session);
    }

    public static void processPrepareAck(StatementImpl query, Packet ack) throws SQLException {
        short stmtID = ack.getShort();
        short columnCount = ack.getShort();
        short paramCount = ack.getShort();
        byte sqlType = ack.getByte();
        ack.skip(1);

        query.setStmtID(stmtID, sqlType);
        if (columnCount > 0) {
            Field[] resultFields = getPrepColumns(ack, columnCount);
            query.setFields(resultFields);
        }

        if (paramCount > 0) {
            Field[] parameterFields = getPrepParams(ack, paramCount);
            query.setParameters(parameterFields);
        }
    }

    private static Field[] getPrepParams(Packet ack, short paramCount) {
        Field[] fields = new Field[paramCount];
        for (short i = 0; i < paramCount; i++) {
            int packSize = ack.getRowSize();
            String name = ack.getString(packSize);
            fields[i] = new Field(i, name, 0, -1, 0, 0, 0);
        }
        return fields;
    }

    private static Field[] getPrepColumns(Packet ack, short columnCount) throws SQLException {
        Field[] fields = new Field[columnCount];
        for (short i = 0; i < columnCount; i++) {
            int packSize = ack.getRowSize();
            int id = ack.getShort();
            int size = ack.getShort();
            int type = ack.getByte();
            int precision = ack.getByte();
            int scale = ack.getByte();
            int nullable = (ack.getByte() & PREPARE_ACK_NULLABLE_FLAG);
            int nameLen = ack.getByte();
            String name = ack.getString(nameLen);
            if (nameLen + 9 != packSize) {
                throw SQLError.createSQLException("prepare ack protocol error", YasState.UNKNOWN_STATE);
            }
            fields[i] = new Field(id, name, type, size, nullable, precision, scale);
        }
        return fields;
    }

    private static YasResultSet getCacheResultSetFromExecResult(StatementImpl statement, Field[] fields,
                                                                ExecuteResult exeResult, Packet ackPacket,
                                                                SessionImpl session) throws SQLException {
        session.setTransactionState(exeResult.getXactStatus());
        RowData rowData = RowDataFactory.createRowDataImpl(session, statement, ackPacket, exeResult);
        rowData.decodeRows(0);

        return ResultSetFactory.createCachedResultSet(statement, fields, rowData);
    }

    private static YasResultSet getResultSetFromExecResult(StatementImpl statement, ExecuteResult result,
                                                           Packet ackPacket, SessionImpl session) throws SQLException {
        YasResultSet results;
        if (result.getOutParams() > 0) {
            byte[][] row = new byte[result.getOutParams()][];
            for (int i = 0; i < result.getOutParams(); i++) {
                if (ackPacket.hasReadToEnd()) {
                    ackPacket = session.moreData();
                }

                int len = ackPacket.getRowSize();
                if (len == 0) {
                    row[i] = null;
                    continue;
                }

                row[i] = ackPacket.getBytes(len);
            }
            Row outParameterRow = new Row(row);

            statement.createParameterResult(outParameterRow);
        }

        session.setTransactionState(result.getXactStatus());

        if (statement.getColumnCount() == 0) {
            if (result.isHasBatchRows()) {
                if (result.isHasBatchError() && !statement.getIsBatchError()) {
                    int num = result.getBatchErrors().keySet().iterator().next();
                    BatchError batchError = result.getBatchErrors().values().iterator().next();
                    throw new YasBatchUpdateException(num, batchError, result.getDmlRows());
                }

                results = new ResultSetImpl(result.getAffectedRows(), session.getConnection(), statement,
                        result.getDmlRows(),result.getBatchErrors());
            } else {
                results = new ResultSetImpl(result.getAffectedRows(), session.getConnection(), statement);
            }
        } else {
            RowData r = RowDataFactory.createRowDataImpl(session, statement, ackPacket, result);
            r.decodeRows(0);
            results = statement.createResultSet(r);
        }

        return results;
    }

    public static void writeReqDebug(YasStatement statement, Packet sendPacket,DebugOperation debugOperation,
                                     int reqLength) {
        sendPacket.writeShort(statement.getID()); //stmtId
        sendPacket.writeByte((byte) debugOperation.getValue());
        sendPacket.writeByte((byte) 0); //unused
        sendPacket.writeInt(reqLength); //reqLen
        sendPacket.writeInt(0); //reserved
    }

    public static Object processDebugMetaDataAck(SessionImpl session, YasDebugCallableStatement statement,
                                                 Packet ackPacket, DebugOperation operation) throws SQLException {
        byte debugCmd = ackPacket.getByte();
        int debugStatus = ackPacket.getByte();
        ackPacket.skip(2);
        int varCount = ackPacket.getInt();

        DebugOperation ackOperation =  DebugOperation.valueOf(debugCmd);
        if (ackOperation == DebugOperation.DBG_ADD_BP) {
            ackPacket.skip(YasConstants.DEBUG_META_DATA_SIZE);
            int valueLength = ackPacket.getRowSize();
            return ackPacket.getInt();
        }
        if (ackOperation == DebugOperation.DBG_SHOW_VARS) {
            ArrayList<DebugVar> debugVarList = new ArrayList<>();
            if (varCount > 0) {
                getDebugVars(session, ackPacket, varCount, debugVarList);
            }
            return debugVarList;
        }
        if (ackOperation == DebugOperation.DBG_SHOW_FRAMES) {
            ArrayList<DebugFrame> debugFrameList = new ArrayList<>();
            if (varCount > 0) {
                getDebugFrames(session, ackPacket, varCount, debugFrameList);
            }
            return debugFrameList;
        }
        if (ackOperation == DebugOperation.DBG_START || ackOperation == DebugOperation.DBG_CONTINUE
                || ackOperation == DebugOperation.DBG_STEP_INTO || ackOperation == DebugOperation.DBG_STEP_NEXT
                || ackOperation == DebugOperation.DBG_STEP_OUT) {
            updateDebugStatus(session, statement, ackPacket);
            return null;
        }

        return null;
    }

    public static YasResultSet processDebugExecutePacket(YasDebugCallableStatement statement, Packet ackPacket,
                                                         SessionImpl session, DebugOperation operation)
            throws SQLException {

        if (ackPacket.getCmd() == MsgType.CMD_DEBUG) {
            processDebugMetaDataAck(session, statement, ackPacket, operation);
            return null;
        }
        session.setDebugOff();

        return processExecuteAck(statement, ackPacket, session);
    }

    private static void getDebugVars(SessionImpl session, Packet ack, int varCount, ArrayList<DebugVar> debugVarList)
            throws SQLException {
        for (short i = 0; i < varCount; i++) {
            //get DebugVarInfo
            if (ack.hasReadToEnd()) {
                ack = session.moreData();
            }
            DebugVarImpl var = new DebugVarImpl();
            DebugVarInfo debugVarInfo = new DebugVarInfo(ack);
            int type = debugVarInfo.getType();

            var.setName(debugVarInfo.getName());
            var.setDataType(type);
            var.setBlockNo(debugVarInfo.getBlockNo());
            var.setGlobal(debugVarInfo.isGlobal());
            if (type == DataType.UNKNOWN) {
                var.setVar(null);
                debugVarList.add(var);
                continue;
            }

            //get data
            if (ack.hasReadToEnd()) {
                ack = session.moreData();
            }
            int varLength = ack.getRowSize();
            if (varLength <= 0) {
                var.setVar(null);
                debugVarList.add(var);
                continue;
            }
            byte[] bytes = ack.getBytes(varLength);
            if (type == DataType.JSON || type == DataType.CLOB || type == DataType.BLOB) {
                type = DataType.VARCHAR;
            }
            Accessor accessor = AccessorFactory.generateAccessorByDataType(type, session);
            switch (type) {
                case DataType.CHAR:
                case DataType.VARCHAR:
                case DataType.NCHAR:
                case DataType.NVARCHAR:
                case DataType.YM_INTERVAL:
                case DataType.DS_INTERVAL:
                    var.setVar(accessor.getString(bytes));
                    break;
                case DataType.TINYINT:
                case DataType.SMALLINT:
                case DataType.INTEGER:
                case DataType.BIGINT:
                case DataType.FLOAT:
                case DataType.DOUBLE:
                case DataType.NUMBER:
                    var.setVar(accessor.getBigDecimal(bytes));
                    break;
                case DataType.DATE:
                case DataType.SHORTDATE:
                    var.setVar(accessor.getDate(bytes, null));
                    break;
                case DataType.SHORTTIME:
                    var.setVar(accessor.getTime(bytes, null));
                    break;
                case DataType.TIMESTAMP:
                case DataType.TIMESTAMP_TZ:
                case DataType.TIMESTAMP_LTZ:
                    var.setVar(accessor.getTimestamp(bytes, null));
                    break;
                case DataType.BOOLEAN:
                    var.setVar(accessor.getBoolean(bytes));
                    break;
                case DataType.BIT:
                    var.setVar(accessor.getString(bytes));
                    break;
                case DataType.ROWID:
                    var.setVar(accessor.getRowId(bytes));
                    break;
                case DataType.RAW:
                    var.setVar(accessor.getString(bytes));
                    break;
                case DataType.CURSOR:
                    var.setVar(null);
                    break;
                default:
                    throw SQLError.createSQLException("Unexpected DataType " + type, YasState.DATA_ERROR);
            }
            debugVarList.add(var);
        }
    }

    private static void getDebugFrames(SessionImpl session, Packet ack, int varCount,
                                       ArrayList<DebugFrame> debugFrameList) throws SQLException {
        for (short i = 0; i < varCount; i++) {
            //get DebugVarInfo
            if (ack.hasReadToEnd()) {
                ack = session.moreData();
            }
            DebugFrameImpl frame = new DebugFrameImpl();
            DebugVarInfo debugVarInfo = new DebugVarInfo(ack);
            int type = debugVarInfo.getType();

            frame.setClassInfo(debugVarInfo.getName());
            frame.setLineNum(debugVarInfo.getLineNo());
            frame.setBlockNo(debugVarInfo.getBlockNo());

            if (type != DataType.CHAR && type != DataType.VARCHAR && type != DataType.NCHAR
                    && type != DataType.NVARCHAR) {
                throw SQLError.createSQLException("Unexpected DataType", YasState.UNKNOWN_STATE);
            }

            //get data
            if (ack.hasReadToEnd()) {
                ack = session.moreData();
            }
            int strLength = ack.getRowSize();
            if (strLength > 0) {
                byte[] strBytes = new byte[strLength];
                ack.getBytes(strLength, strBytes);
                String strValue = new String(strBytes, CharacterSet.getCharSet(session.getCharset()));
                frame.setMethodInfo(strValue);
            }
            debugFrameList.add(frame);
        }
    }

    private static void updateDebugStatus(SessionImpl session, YasDebugCallableStatement statement, Packet ack)
            throws SQLException {
        DebugVarInfo debugVarInfo = new DebugVarInfo(ack);
        int type = debugVarInfo.getType();

        if (type != DataType.SMALLINT && type != DataType.INTEGER && type != DataType.BIGINT && type != DataType.TINYINT
                && type != DataType.FLOAT && type != DataType.DOUBLE && type != DataType.NUMBER) {
            throw SQLError.createSQLException("Unexpected DataType", YasState.UNKNOWN_STATE);
        }

        int valueLength = ack.getRowSize();
        if (valueLength > 0 ) {
            BigDecimal bigDecimal = ByteConverter.toBigDecimal(ack.getBytes(valueLength), 0);
            session.updateDebugStatus(statement, debugVarInfo.getObjectId(), debugVarInfo.getSubId(),
                    bigDecimal.intValue());
        }
    }
}
