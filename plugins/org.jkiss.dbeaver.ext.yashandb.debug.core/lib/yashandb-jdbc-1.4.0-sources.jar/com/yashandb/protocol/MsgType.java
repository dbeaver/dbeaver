/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.jdbc.ConnectVersion;

public enum MsgType {
    CMD_NONE(0),
    CMD_LOGIN(1),
    CMD_LOGOUT(2),
    CMD_PREPARE(3),
    CMD_EXECUTE(4),
    CMD_FETCH(5),
    CMD_FREE_STMT(6),
    CMD_COMMIT(7),
    CMD_ROLLBACK(8),
    CMD_2PC_PREPARE(9),
    CMD_MORE_DATA(10),
    CMD_OUTPUT(11),
    CMD_DIRECT_EXECUTE(12),
    CMD_CANCEL_CURR(13),
    CMD_SESSION_PARAM(14),
    CMD_LOB(15),
    CMD_DIGEST(16),
    CMD_BATCH_PREPARE(17),
    CMD_BATCH_EXECUTE(18),
    CMD_FETCH_CURSOR(19),
    CMD_CHANGE_USER(20),
    CMD_RETURN_RESULT(21),
    CMD_LOAD_PREPARE(22),
    CMD_LOAD_EXECUTE(23),
    CMD_DEBUG(24);

    private static final int CMD_VER1 = 0;

    private static final int CMD_VER2 = 1;

    private final int value;

    MsgType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public int getVersion() {
        return CMD_VER1;
    }

    public int getVersion(ConnectVersion clientVersion) {
        if ((this.value != CMD_LOB.value) || (clientVersion == ConnectVersion.VER1)) {
            return CMD_VER1;
        }

        return CMD_VER2;
    }
}
