/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.Messages;

import java.sql.SQLException;

public enum ConnectionServerMode {

    SHARED_MODE("shared", 0),
    DEDICATE_MODE("dedicated", 1);

    ConnectionServerMode(String mode,  int value) {
        this.mode = mode;
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public static ConnectionServerMode getServerMode(String mode) throws SQLException {
        for (ConnectionServerMode serverMode : ConnectionServerMode.values()) {
            if (serverMode.mode.equalsIgnoreCase(mode)) {
                return serverMode;
            }
        }

        throw SQLError.createSQLException(
                Messages.get("invalid server mode {0}", mode), YasState.DATA_ERROR);
    }

    private final int value;
    private final String mode;
}
