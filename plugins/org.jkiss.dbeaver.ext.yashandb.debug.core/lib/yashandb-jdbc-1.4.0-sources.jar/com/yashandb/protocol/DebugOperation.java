/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

public enum DebugOperation {
    DBG_CMD_NONE(0),
    DBG_START(1),
    DBG_CONTINUE(2),
    DBG_STEP_INTO(3),
    DBG_STEP_NEXT(4),
    DBG_STEP_OUT(5),
    DBG_ABORT(6),
    DBG_ADD_BP(7),
    DBG_DEL_BP(8),
    DBG_SHOW_VARS(9),
    DBG_SHOW_FRAMES(10),
    DBG_CHECK_VERSION(11);

    private final int value;

    public static DebugOperation valueOf(byte value) {
        switch (value) {
            case 1:
                return DBG_START;
            case 2:
                return DBG_CONTINUE;
            case 3:
                return DBG_STEP_INTO;
            case 4:
                return DBG_STEP_NEXT;
            case 5:
                return DBG_STEP_OUT;
            case 6:
                return DBG_ABORT;
            case 7:
                return DBG_ADD_BP;
            case 8:
                return DBG_DEL_BP;
            case 9:
                return DBG_SHOW_VARS;
            case 10:
                return DBG_SHOW_FRAMES;
            case 11:
                return DBG_CHECK_VERSION;
            default:
                return DBG_CMD_NONE;
        }
    }

    DebugOperation(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
