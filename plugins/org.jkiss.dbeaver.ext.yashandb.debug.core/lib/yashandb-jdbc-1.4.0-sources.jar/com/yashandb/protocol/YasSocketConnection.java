/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.conf.HostSpec;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.FileInputStream;
import java.io.Flushable;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateFactory;
import java.sql.SQLException;

import javax.net.SocketFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

public class YasSocketConnection implements Closeable, Flushable {

    private String sslRootCer;
    private final SocketFactory socketFactory;
    private SSLSocketFactory sslSocketFactory;
    private final HostSpec hostSpec;

    private Socket socket;
    private YasFilterInputStream yashanInput;
    private BufferedOutputStream yashanOutput;

    /**
     * Constructor: Connect to the Dtabase back end and return a stream connection.
     *
     * @param socketFactory socket factory to use when creating sockets
     * @param hostSpec      the host and port to connect to
     * @param timeout       timeout in milliseconds, or 0 if no timeout set
     * @throws IOException if an IOException occurs below it.
     */
    public YasSocketConnection(SocketFactory socketFactory, HostSpec hostSpec, int timeout)
            throws IOException {
        this.socketFactory = socketFactory;
        this.hostSpec = hostSpec;

        Socket socket = createSocket(timeout);
        changeSocket(socket);
    }

    public YasSocketConnection(YasSocketConnection yasSocketConnection, int timeout, boolean duplicate)
            throws IOException {
        int sendBufferSize = 1024;
        int receiveBufferSize = 1024;
        int soTimeout = 0;
        boolean keepAlive = false;

        try {
            sendBufferSize = yasSocketConnection.getSocket().getSendBufferSize();
            receiveBufferSize = yasSocketConnection.getSocket().getReceiveBufferSize();
            soTimeout = yasSocketConnection.getSocket().getSoTimeout();
            keepAlive = yasSocketConnection.getSocket().getKeepAlive();

        } catch (SocketException ignored) {
        }

        if (!duplicate) {
            yasSocketConnection.close();
        }

        this.socketFactory = yasSocketConnection.socketFactory;
        this.hostSpec = yasSocketConnection.hostSpec;
        this.sslSocketFactory = yasSocketConnection.sslSocketFactory;
        Socket socket = createSocket(timeout);

        socket.setReceiveBufferSize(receiveBufferSize);
        socket.setSendBufferSize(sendBufferSize);
        setNetworkTimeout(soTimeout);
        socket.setKeepAlive(keepAlive);
    }

    public HostSpec getHostSpec() {
        return hostSpec;
    }

    public Socket getSocket() {
        return socket;
    }

    public void setSslRootCer(String sslRootCer) {
        this.sslRootCer = sslRootCer;
    }

    private Socket createSocket(int timeout) throws IOException {

        Socket socket = socketFactory.createSocket();
        if (!socket.isConnected()) {
            InetSocketAddress address = hostSpec.shouldResolve()
                    ? new InetSocketAddress(hostSpec.getHost(), hostSpec.getPort())
                    : InetSocketAddress.createUnresolved(hostSpec.getHost(), hostSpec.getPort());
            socket.connect(address, timeout);
        }
        changeSocket(socket);
        return socket;
    }

    public void initSSLSocket() throws SQLException {
        if (sslSocketFactory != null) {
            return;
        }
        if (sslRootCer == null) {
            throw SQLError.createSQLException("sslRootCer can not be null", YasState.CONNECTION_FAILURE);
        }
        try {
            String provider = "SunX509";
            String storeType = "JKS";
            SSLContext sslContext = SSLContext.getInstance("TLS");
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(provider);
            KeyStore keyStore = KeyStore.getInstance(storeType);
            keyStore.load(null);
            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            String certificateAlias = "ca";
            keyStore.setCertificateEntry(certificateAlias,
                    certificateFactory.generateCertificate(new FileInputStream(sslRootCer)));
            trustManagerFactory.init(keyStore);
            sslContext.init(null, trustManagerFactory.getTrustManagers(), null);
            sslContext.getSocketFactory();
            sslSocketFactory = sslContext.getSocketFactory();
        } catch (NoSuchAlgorithmException e) {
            throw SQLError.createSQLException("Failed to obtain the sslContext instance. Please check the java version",
                    YasState.UNKNOWN_STATE);
        } catch (Exception e) {
            throw SQLError.createSQLException(e.getMessage(), YasState.UNKNOWN_STATE, e);
        }
    }

    /**
     * Switch this stream to using a new socket. Any existing socket is <em>not</em> closed; it's
     * assumed that we are changing to a new socket that delegates to the original socket (e.g. SSL).
     *
     * @param socket the new socket to change to
     * @throws IOException if something goes wrong
     */
    public void changeSocket(Socket socket) throws IOException {
        this.socket = socket;
        this.socket.setTcpNoDelay(true);
        yashanInput = new YasFilterInputStream(this.socket.getInputStream());
        yashanOutput = new BufferedOutputStream(this.socket.getOutputStream(), 8192);
    }

    public void send(Buffer buffer) throws IOException {
        yashanOutput.write(buffer.getBuffer(), 0, buffer.getPostion());
    }

    public void receive(Buffer buffer) throws IOException {
        yashanInput.readFully(buffer.getBuffer());
    }

    public void receive(Buffer buffer, int offset, int len) throws IOException {
        yashanInput.readFully(buffer.getBuffer(), offset, len);
    }

    /**
     * Flush any pending output to the backend.
     *
     * @throws IOException if an I/O error occurs
     */
    @Override
    public void flush() throws IOException {
        yashanOutput.flush();
    }

    /**
     * Closes the connection.
     *
     * @throws IOException if an I/O Error occurs
     */
    @Override
    public void close() throws IOException {
        yashanOutput.close();
        yashanInput.close();
        socket.close();
    }

    public void setNetworkTimeout(int milliseconds) throws IOException {
        socket.setSoTimeout(milliseconds);
    }

    public int getNetworkTimeout() throws IOException {
        return socket.getSoTimeout();
    }

    public void changeSocketToSsl() throws SQLException, IOException {
        initSSLSocket();
        changeSocket(sslSocketFactory.createSocket(socket, hostSpec.getHost(), hostSpec.getPort(), true));
    }

}
