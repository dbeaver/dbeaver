/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

public class DebugVarInfo {

    private static final int PREPARE_ACK_NULLABLE_FLAG = 0x01;

    private int blockNo;

    private boolean isGlobal;

    private int subId;

    private long objectId;

    private int lineNo;

    private int id;

    private int size;

    private int type;

    private int precision;

    private int scale;

    private int nullable;

    private int nameLen;

    private String name = null;

    public DebugVarInfo(Packet packet) {
        blockNo = packet.getInt();
        isGlobal = packet.getByte() != 0;
        packet.skip(1);
        subId = packet.getShort();
        objectId = packet.getLong();
        lineNo = packet.getInt();
        id = packet.getShort();
        size = packet.getShort();
        type = packet.getByte() & 0xFF;
        precision = packet.getByte();
        scale = packet.getByte();
        nullable = (packet.getByte() & PREPARE_ACK_NULLABLE_FLAG);
        nameLen = packet.getRowSize();
        if (nameLen > 0) {
            name = packet.getString(nameLen);
        }
    }

    public int getBlockNo() {
        return blockNo;
    }

    public boolean isGlobal() {
        return isGlobal;
    }

    public int getSubId() {
        return subId;
    }

    public long getObjectId() {
        return objectId;
    }

    public int getLineNo() {
        return lineNo;
    }

    public int getType() {
        return type;
    }

    public String getName() {
        return name;
    }

}
