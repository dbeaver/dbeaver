/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.ByteConverter;
import com.yashandb.util.CharacterSet;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public abstract class Yason {
    protected int size;
    protected short charset;
    protected byte[] data;
    protected Object self;

    public static final int SIZE_OFFSET = 2;

    public static final int JSON_TYPE_POS  = 0;
    public static final int LENGTH_OFFSET  = 4;

    private static final int JASON_STR_LEN_MASK = 0x7F;
    public static final int MAX_STR_LEN_BYTE_SIZE = 4;
    public static final int OBJECT_TYPE = 1;
    public static final int ARRAY_TYPE = 2;

    public static final int STRING_TYPE = 3;
    public static final int NUMBER_TYPE = 4;
    public static final int BOOL_TYPE = 5;
    public static final int NULL_TYPE = 6;

    public static final Map<Character,String> escapedSymbols = new HashMap<Character,String>() {
        {
            put('\b',"\\b");
            put('\t',"\\t");
            put('\n',"\\n");
            put('\f',"\\f");
            put('\r',"\\r");
            put('"',"\\\"");
            put('\\',"\\\\");
        }};

    public Yason(byte[] data, short charset) throws SQLException {
        this.data = data;
        this.charset = charset;
        init();
    }

    protected abstract void init() throws SQLException;

    /**
     * Use up to 4 bytes to represent the length of the string.For each byte,The highest bit indicates
     * whether the next byte will continue to be the string length. The remaining 7 bits represent the real StringSize.
     * @param bytes bytes
     * @param start Start position
     * @param sizeLength Number of bytes used to represent the String size
     * @return String length
     */
    protected static int getStringLen(byte[] bytes, int start, int sizeLength) {
        int length = 0;
        for (int i = 0; i < sizeLength; i++) {
            length += ((bytes[start + i] & JASON_STR_LEN_MASK) << i * 7);
        }
        return length;
    }

    protected static String getStringValue(byte[] data, int start, short charset) {
        int strLenByteSize = getStrLenByteSize(data, start);
        int stringSize = getStringLen(data, start, strLenByteSize);
        return "\"" + Yason.decodeJsonString(data, start + strLenByteSize, stringSize, charset) + "\"";
    }

    public static String decodeJsonString(byte[] bytes, int start, int length, short charset) {
        String str = new String(bytes, start, length, CharacterSet.getCharSet(charset));

        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < str.length(); i++) {
            if (escapedSymbols.containsKey(str.charAt(i))) {
                stringBuffer.append(escapedSymbols.get(str.charAt(i)));
            } else {
                stringBuffer.append(str.charAt(i));
            }
        }
        return stringBuffer.toString();
    }

    public static Object getInstance(int valueType, byte[] data, int start, short charset) throws SQLException {
        Object value = null;
        if (valueType == STRING_TYPE) {
            value = getStringValue(data, start, charset);
        } else if (valueType == OBJECT_TYPE || valueType == ARRAY_TYPE) {
            value = getChildYason(valueType, data, start, charset);
        } else if (valueType == NUMBER_TYPE) {
            value = getNumberValue(data,start);
        } else if (valueType == BOOL_TYPE) {
            value = data[start] == 1;
        } else if (valueType == NULL_TYPE) {
            value = null;
        } else {
            throw SQLError.createSQLException("protocol error, invalid json type", YasState.PROTOCOL_VIOLATION);
        }
        return value;
    }

    protected static BigDecimal getNumberValue(byte[] data,int start) {
        int length = data[start] & 0xff;
        byte[] arr2 = Arrays.copyOfRange(data, start + 1, start + 1 + length);
        return ByteConverter.toBigDecimal(arr2, 0);
    }

    protected static Yason getChildYason(int type,byte[] data, int start, short charset) throws SQLException {
        int length = ByteConverter.int4(data, start);
        byte[] childData = Arrays.copyOfRange(data, start + LENGTH_OFFSET, start + LENGTH_OFFSET + length);
        switch (type) {
            case Yason.OBJECT_TYPE:
                return new YasonObject(childData, charset);
            case Yason.ARRAY_TYPE:
                return new YasonArray(childData, charset);
            default:
                throw SQLError.createSQLException("protocol error, invalid json type", YasState.PROTOCOL_VIOLATION);
        }
    }

    /**
     * Use up to 4 bytes to represent the length of the string.For each byte,The highest bit indicates
     * whether the next byte will continue to be the string length. The remaining 7 bits represent the real
     * length data.
     * @param bytes bytes
     * @param start Start position
     * @return Number of bytes used to represent the String size
     */
    protected static int getStrLenByteSize(byte[] bytes, int start) {
        for (int i = 0; i < Yason.MAX_STR_LEN_BYTE_SIZE; i++) {
            if ((bytes[start + i] & 0b10000000) == 0) {
                return i + 1;
            }
        }
        return Yason.MAX_STR_LEN_BYTE_SIZE;
    }

    protected void appendValueToJsonBuffer(StringBuffer jsonBuffer, Object value) {
        if (value == null) {
            jsonBuffer.append("null");
        } else if (value instanceof String) {
            jsonBuffer.append(value);
        } else if (value instanceof BigDecimal) {
            jsonBuffer.append(value);
        } else if (value instanceof Boolean) {
            jsonBuffer.append((boolean) value ? "true" : "false");
        } else if (value instanceof Yason) {
            jsonBuffer.append(value);
        }
    }
}
