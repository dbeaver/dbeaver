/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.util.ByteConverter;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class YasonObject extends Yason {
    public YasonObject(byte[] data, short charset) throws SQLException {
        super(data, charset);
    }

    protected void init() throws SQLException {
        Map<String, Object> map = new HashMap<>();
        this.size = ByteConverter.int2(data, 0);
        int[] offsets = new int[this.size];
        for (int i = 0; i < offsets.length; i++) {
            offsets[i] = ByteConverter.int4(data, Yason.SIZE_OFFSET + i * LENGTH_OFFSET);
        }
        for (int j = 0; j < offsets.length; j++) {
            int keySize = ByteConverter.int2(data, offsets[j]);
            final int keySizeLength = 2;
            final int typeSize = 1;
            String key = Yason.decodeJsonString(data, offsets[j] + keySizeLength, keySize, charset);
            int valueType = data[offsets[j] + keySizeLength + keySize];

            int start = offsets[j] + keySizeLength + keySize + typeSize;
            Object value = getInstance(valueType, data, start, charset);
            map.put(key, value);

        }
        self = map;
    }

    @Override
    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("{");
        if (self instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) self;
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                if (buffer.length() != 1) {
                    buffer.append(",");
                }
                buffer.append("\"");
                buffer.append(entry.getKey());
                buffer.append("\"");
                buffer.append(":");
                Object value = entry.getValue();
                appendValueToJsonBuffer(buffer, value);
            }

        }
        buffer.append("}");
        return buffer.toString();
    }
}
