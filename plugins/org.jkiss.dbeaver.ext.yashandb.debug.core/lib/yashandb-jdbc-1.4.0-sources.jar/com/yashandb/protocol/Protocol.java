/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import java.sql.SQLException;
import java.util.Properties;

public interface Protocol {
    /**
     * Create a new session. This generally happens once at the beginning of a connection.
     *
     * @param user     DB user name
     * @param password DB user password
     */
    void connect(String user, String password, Properties info) throws SQLException;

    /**
     * Send a packet to server
     *
     * @param buffer buffer to server
     */
    void sendBuffer(Buffer buffer) throws SQLException;

    /**
     * @param packet to sever include header
     */
    void sendPacket(Packet packet) throws SQLException;

    /**
     * receive message to packet
     */
    Packet receivePacket() throws SQLException;

    Packet sendCommand(Packet packet, MsgType msgType, int flags) throws SQLException;

    Packet getSendPacket();

    void setServerMode(ConnectionServerMode mode);

    Object getSocketConnection();
}
