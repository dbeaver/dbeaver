/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

public interface Buffer {
    byte[] getBuffer();

    // void setPostion(int pos);

    int getPostion();

    int getCapacity();

    int getRemainSize();

    void writeLong(long v);

    void writeInt(int v);

    void writeShort(int v);

    void writeByte(byte v);

    void writeFloat(float v);

    void writeDouble(double v);

    void writeFixString(String str, int i);

    void writeString(String str);

    void writeBytes(byte[] i);

    void writeBytes(byte[] data, int start, int len);

    int getInt();

    long getLong();

    short getShort();

    byte getByte();

    float getFloat();

    double getDouble();

    String getString(int len);

    byte[] getBytes(int len);

    void skip(int size);

    void clean();
}
