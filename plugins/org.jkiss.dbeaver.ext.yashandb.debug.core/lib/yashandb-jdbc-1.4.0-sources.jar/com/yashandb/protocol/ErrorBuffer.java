/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

/**
 * TextPos
 * int line;
 * int column;
 * int errCode;
 * int msgLen;
 * String msg;
 */
public class ErrorBuffer extends BaseBuffer {

    public ErrorBuffer(int len) {
        super(len);
    }

    private static final int startPos = 8;
    private int line;
    private int column;
    private int errCode;
    private String errMsg;

    public ErrorBuffer(Packet packet) {
        super(packet);
        this.position = startPos;
        line = packet.getInt();
        column = packet.getInt();
        errCode = packet.getInt();
        int errLen = packet.getInt();
        errMsg = packet.getString(errLen);
    }

    public int getLine() {
        return line;
    }

    public int getColumn() {
        return column;
    }

    public int getErrorCode() {
        return errCode;
    }

    public String getErrorMsg() {
        return errMsg;
    }
}
