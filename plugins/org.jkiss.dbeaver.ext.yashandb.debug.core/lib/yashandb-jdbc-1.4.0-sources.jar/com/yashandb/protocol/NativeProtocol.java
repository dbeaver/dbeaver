/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.Session;
import com.yashandb.YasConstants;
import com.yashandb.conf.YasProperty;
import com.yashandb.exception.YasRuntimeException;
import com.yashandb.exception.YasState;
import com.yashandb.exception.YasWarning;
import com.yashandb.jdbc.ConnectVersion;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.jdbc.exception.ServerErrorMessage;
import com.yashandb.jdbc.exception.YasException;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;
import com.yashandb.util.Messages;
import com.yashandb.util.Utils;
import com.yashandb.util.YasEncrypt;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Properties;

public class NativeProtocol implements Protocol {
    private static final Logger LOGGER = LoggerFactory.getLogger(NativeProtocol.class.getName());

    protected final YasSocketConnection yasSocketConnection;
    protected final Session session;

    private int packetSize = 0;
    private boolean isBigEndian;
    private boolean isPasswordEncrypt = false;
    private short charset;

    private Packet send;
    private Packet receive;

    private byte conServerMode = 0;

    public NativeProtocol(Session session, YasSocketConnection stream) {
        this.yasSocketConnection = stream;
        this.session = session;
        this.send = null;
        this.receive = null;
    }

    @Override
    public void connect(String user, String password, Properties info)
            throws SQLException {
        int socketTimeoutBackup;
        try {
            socketTimeoutBackup = this.yasSocketConnection.getNetworkTimeout();
            int loginTimeout = Utils.toMillisecond(YasProperty.LOGIN_TIMEOUT.getInt(info));
            if (loginTimeout > 0) {
                this.yasSocketConnection.setNetworkTimeout(loginTimeout);
            }
            String sslRootCer = YasProperty.SSL_ROOT_CER.get(info);
            if (sslRootCer != null && !sslRootCer.trim().equals("")) {
                this.yasSocketConnection.setSslRootCer(sslRootCer);
            }
            ackConnection();
            doAuthentication(user, password, info);
            this.yasSocketConnection.setNetworkTimeout(socketTimeoutBackup);
        } catch (IOException e) {
            LOGGER.error("login fail: " + e.getMessage());
            throw SQLError.createSQLException("login fail: " + e.getMessage(), YasState.IO_ERROR, e);
        }
    }

    public void cancel() throws SQLException {
        ackConnection();

        Packet sendPacket = getSendPacket();
        sendPacket.writeShort(session.getSID());
        sendPacket.skip(2);
        sendPacket.writeInt(session.getSessionKey());

        sendCommand(sendPacket, MsgType.CMD_CANCEL_CURR, 0);
    }

    @Override
    public void sendBuffer(Buffer buffer) throws SQLException {
        try {
            yasSocketConnection.send(buffer);
        } catch (IOException e) {
            throw SQLError.createSQLException("io fail:" + e.getMessage(), YasState.IO_ERROR, e);
        }
    }

    @Override
    public void sendPacket(Packet packet) throws SQLException {
        packet.encode(this.session.getConnectVersion());
        sendBuffer(packet);
        try {
            yasSocketConnection.flush();
        } catch (IOException e) {
            throw SQLError.createSQLException(Messages.get("protocol error"), YasState.IO_ERROR);
        }

    }

    @Override
    public YasSocketConnection getSocketConnection() {
        return this.yasSocketConnection;
    }

    private void receiveHeader(Packet packet) throws YasException {
        try {
            yasSocketConnection.receive(packet, 0, Packet.HEAD_PACKET_LEN);
        } catch (IOException e) {
            throw SQLError.createSQLException("io fail:" + e.getMessage(), YasState.IO_ERROR, e);
        }
    }

    @Override
    public Packet receivePacket() throws SQLException {
        if (this.receive == null) {
            receive = new Packet(packetSize);
        }
        receive.clean();
        receiveHeader(receive);
        try {
            yasSocketConnection.receive(receive, Packet.HEAD_PACKET_LEN,
                receive.getMessageSize());
        } catch (IOException e) {
            throw SQLError.createSQLException("io fail:" + e.getMessage(), YasState.IO_ERROR, e);
        }

        checkServerCmdVersion(receive);
        checkServerError(receive);
        return receive;
    }

    @Override
    public Packet sendCommand(Packet packet, MsgType msgType, int flags) throws SQLException {
        packet.setCmd(msgType);
        sendPacket(packet);
        return receivePacket();
    }

    public void sendCommandOnly(Packet packet, MsgType msgType, int flags) throws SQLException {
        packet.setCmd(msgType);
        sendPacket(packet);
    }

    @Override
    public Packet getSendPacket() {
        if (send == null) {
            send = new Packet(this.packetSize);
        }
        send.clean();
        return send;
    }

    @Override
    public void setServerMode(ConnectionServerMode mode) {
        this.conServerMode = (byte) mode.getValue();
    }

    /**
     * byte  isBigEndian
     * byte encryptMode,
     * short   charset
     * int packetSize
     * byte[8] anchorNumber;
     */
    private void ackConnection() throws SQLException {
        AckConnBuffer conMsg = new AckConnBuffer();
        try {
            yasSocketConnection.receive(conMsg, 0, YasConstants.ACK_CONN_PACKET_SIZE);
            isBigEndian = conMsg.getEndian();
            packetSize = conMsg.getPacketSize();
            conMsg.setPostion(1);
            byte encryptMode = conMsg.getByte();
            if (encryptMode == YasConstants.LOGIN_MODE_SECURITY) {
                isPasswordEncrypt = true;
            } else if (encryptMode == YasConstants.SSL_MODE_SECURITY) {
                isPasswordEncrypt = true;
                yasSocketConnection.changeSocketToSsl();
            }

            charset = conMsg.getShort();
            conMsg.setPostion(8);
            if (!Arrays.equals(conMsg.getBytes(8), YasConstants.YasNumber)) {
                throw new YasRuntimeException("Incorrect protocol implementation");
            }
        } catch (IOException e) {
            throw SQLError.createSQLException("io fail:" + e.getMessage(), YasState.IO_ERROR, e);
        }
    }

    private void doAuthentication(String user, String password, Properties info)
            throws SQLException {
        sendLogin(user, password, info);
        session.setSID(receive.getShort());
        receive.skip(2);  // skip 2 byte, unused
        session.setCharset(this.charset);

        int revConnectVersion = receive.getInt();
        if (ConnectVersion.valueOf(revConnectVersion) == ConnectVersion.UNINITIALIZED) {
            revConnectVersion = ConnectVersion.VER1.getValue();
        }
        this.session.setConnectVersion(ConnectVersion.valueOf(revConnectVersion));

        session.setSessionKey(receive.getInt());
    }

    private void sendLogin(String user, String password, Properties info) throws SQLException {
        if (isPasswordEncrypt) {
            doSecretLogin(user, password, info);
            return;
        }

        doNormalLogin(user, password, info);
    }

    private void doNormalLogin(String user, String password, Properties info) throws SQLException {
        String osUser = System.getProperty("user.name");
        String localName = yasSocketConnection.getSocket().getLocalAddress().getCanonicalHostName();
        if (localName == null) {
            localName = "";
        }

        String program = YasProperty.PROGRAM_NAME.get(info);

        Packet packet = getSendPacket();
        packet.writeInt(this.session.getConnectVersion().getValue());

        user = transformUser(user);
        packet.writeFixString(user, 68);
        packet.writeFixString(password, 64);
        packet.writeFixString(osUser, 68);
        packet.writeFixString(localName, 256);
        packet.writeFixString(program, 256);
        sendCommand(packet, MsgType.CMD_LOGIN, 0);
    }

    private String getHostName() {
        String hostName;
        String osName = System.getProperty("os.name").toLowerCase();
        if (osName.contains("windows")) {
            hostName = System.getenv("COMPUTERNAME");
        } else {
            hostName = System.getenv("HOSTNAME");
        }

        if (hostName != null) {
            return hostName;
        }

        return yasSocketConnection.getSocket().getLocalAddress().getCanonicalHostName();
    }

    private String transformUser(String user) {
        if (session.isUserCaseSensitive()) {
            user = "\"" + user + "\"";
        }
        return user;
    }

    public void doSecretLogin(String user, String password,Properties info) throws SQLException {
        String osUser = System.getProperty("user.name");
        String localName = getHostName();
        if (localName == null) {
            localName = "";
        }

        String program = YasProperty.PROGRAM_NAME.get(info);
        Packet packet = getSendPacket();
        packet.writeInt(this.session.getConnectVersion().getValue());
        packet.writeByte(YasConstants.LOGIN_MODE_SECURITY);
        packet.writeByte(YasConstants.USER_ROLE_NONE);
        packet.writeByte(conServerMode);
        packet.skip(1); //unused

        user = transformUser(user);
        packet.writeByte((byte)user.getBytes().length);
        packet.writeString(user);
        packet.writeByte((byte)osUser.getBytes().length);
        packet.writeString(osUser);
        packet.writeByte((byte)localName.getBytes().length);
        packet.writeString(localName);
        packet.writeByte((byte)program.getBytes().length);
        packet.writeString(program);

        Packet revPacket = sendCommand(packet, MsgType.CMD_LOGIN, 0);

        //Get security key + salt
        int encryVersion = revPacket.getInt();
        int transEncryVersion = revPacket.getInt();
        int saltLen = revPacket.getShort();
        String salt = revPacket.getString(saltLen);
        int secretKeyLen = revPacket.getShort();
        byte[] secretKeyArray = revPacket.getBytes(secretKeyLen);

        //Encrypt Password
        String keyPassword = YasEncrypt.encryptSHA(password,salt,encryVersion);
        if (keyPassword == null) {
            throw SQLError.createSQLException("Encrypt SHA password fail", YasState.UNKNOWN_STATE);
        }

        byte[] plainKey = YasEncrypt.decryptAES(keyPassword.getBytes(),secretKeyArray,transEncryVersion);
        if (plainKey == null) {
            throw SQLError.createSQLException("decryptDes plainKey fail", YasState.UNKNOWN_STATE);
        }

        byte[] secretPassword = YasEncrypt.encryptAES(plainKey,password.getBytes(),transEncryVersion);
        if (secretPassword == null) {
            throw SQLError.createSQLException("encryptDes secretPassword fail", YasState.UNKNOWN_STATE);
        }

        //Send secret Password
        Packet packet2 = getSendPacket();
        packet2.writeShort((short)secretPassword.length);
        packet2.writeBytes(secretPassword);

        sendCommand(packet2, MsgType.CMD_DIGEST, 0);
    }

    private void checkServerCmdVersion(Packet packet) throws SQLException {
        MsgType msgType = packet.getCmd();
        if (packet.getCmdVersion() != msgType.getVersion(this.session.getConnectVersion())) {
            throw SQLError.createSQLException("protocol error, command version is not compatible",
                    YasState.PROTOCOL_VIOLATION);
        }
    }

    public void checkServerError(Packet packet) throws SQLException {
        if (packet.isError()) {
            ErrorBuffer errorPacket = new ErrorBuffer(packet);

            ServerErrorMessage errorMessage = new ServerErrorMessage(errorPacket.getErrorCode(),
                    errorPacket.getLine(), errorPacket.getColumn(), errorPacket.getErrorMsg());
            LOGGER.error(errorMessage.toString());
            throw SQLError.createSQLException(errorMessage, true);
        } else if (packet.hasInfo()) {
            ErrorBuffer warningPacket = new ErrorBuffer(packet);

            ServerErrorMessage warningMessage = new ServerErrorMessage(warningPacket.getErrorCode(),
                    warningPacket.getLine(), warningPacket.getColumn(), warningPacket.getErrorMsg());
            YasWarning warning = new YasWarning(warningMessage);
            session.addWarning(warning);
            LOGGER.warn(warningMessage.toString());
        }
    }

}
