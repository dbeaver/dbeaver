/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.TransactionState;
import com.yashandb.jdbc.exception.BatchError;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.SQLException;
import java.util.HashMap;

public class ExecuteResult {
    private int batchRows;
    private final short outParams;
    private final short marginColumns;
    private final long affectedRows;
    private final long xactStatus;
    private final long xisoLevel;
    private final boolean hasMoreRows;
    private boolean hasBatchRows;
    private final boolean hasBatchError;

    private int[] dmlRows;
    private HashMap<Integer, BatchError> batchErrors;

    public ExecuteResult(Packet ack) throws SQLException {
        this(ack,false);
    }

    public ExecuteResult(Packet ack,boolean inBatchMode) throws SQLException {
        batchRows = ack.getInt();
        outParams = ack.getShort();
        marginColumns = ack.getShort();
        long flag = ack.getLong();
        affectedRows = (flag & 0xffffffffffL);
        xactStatus = (flag & 0x30000000000L) >>> 40;
        xisoLevel = (flag & 0xC0000000000L) >>> 42;
        hasMoreRows = (flag & 0x100000000000L) == 0x100000000000L;
        hasBatchRows = (flag & 0x200000000000L) == 0x200000000000L;
        hasBatchError = (flag & 0x400000000000L) == 0x400000000000L;

        if (hasBatchRows) {
            dmlRows = processDMLRows(ack);

            if (hasBatchError) {
                batchErrors = processBatchErrors(ack,dmlRows);
            }
        }
        if (inBatchMode && dmlRows == null) {
            hasBatchRows = true;
            batchRows = 1;
            dmlRows = new int[1];
            dmlRows[0] = (int) affectedRows;
        }
    }

    public boolean isHasMoreRows() {
        return hasMoreRows;
    }

    public int getBatchRows() {
        return batchRows;
    }

    public short getOutParams() {
        return outParams;
    }

    public short getMarginColumns() {
        return marginColumns;
    }

    public long getAffectedRows() {
        return affectedRows;
    }

    public TransactionState getXactStatus() {
        return TransactionState.values()[(int) xactStatus];
    }

    public long getXisoLevel() {
        return xisoLevel;
    }

    private int[] processDMLRows(Packet ack) {
        int len = ack.getInt();
        int[] dmlRows = new int[len];
        for (int i = 0;i < len;i++) {
            dmlRows[i]  = ack.getInt();
        }
        return dmlRows;
    }

    private HashMap<Integer,BatchError> processBatchErrors(Packet ack,int[] dmlRows) throws SQLException {
        HashMap<Integer,BatchError> batchErrors = new HashMap<>();
        int len = ack.getInt();
        for (int i = 0;i < len;i++) {
            int num = ack.getInt();
            if ( num < 0 || dmlRows == null || num > dmlRows.length) {
                throw SQLError.createSQLException("BatchError protocol wrong.", YasState.UNKNOWN_STATE);
            }

            int errCode = ack.getInt();
            int msgLen = ack.getInt();
            String errMsg = ack.getString(msgLen);
            batchErrors.put(num,new BatchError(errCode,errMsg));
        }
        return batchErrors;
    }

    public int[] getDmlRows() {
        return dmlRows;
    }

    public HashMap<Integer, BatchError> getBatchErrors() {
        return batchErrors;
    }

    public boolean isHasBatchRows() {
        return hasBatchRows;
    }

    public boolean isHasBatchError() {
        return hasBatchError;
    }

}
