/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.util.Messages;

import java.io.EOFException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class YasFilterInputStream extends FilterInputStream {

    /**
     * Creates a new buffer around the given stream.
     *
     * @param in The stream to buffer.
     */
    public YasFilterInputStream(InputStream in) {
        super(in);
    }

    public int readFully(byte[] b) throws IOException {
        return readFully(b, 0, b.length);
    }

    public int readFully(byte[] b, int off, int len) throws IOException {
        if (len < 0) {
            throw new IndexOutOfBoundsException();
        }

        int n = 0;

        while (n < len) {
            int count = read(b, off + n, len - n);

            if (count < 0) {
                throw new EOFException(Messages.get("IO.EOF", len, n));
            }

            n += count;
        }

        return n;
    }

}
