/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.Session;
import com.yashandb.core.DataType;
import com.yashandb.jdbc.YasBlob;
import com.yashandb.jdbc.YasLobProcessor;
import com.yashandb.util.CharacterSet;

import java.io.InputStream;
import java.nio.charset.Charset;
import java.sql.Blob;
import java.sql.SQLException;

public class BlobAccessor extends LobAccessor {

    private static final int HEX_CHAR_CNT_PER_BYTE = 2;

    private static final int BITS_PER_BYTE = 8;

    private static final int HEX_BYTE_LEN = 4;

    @Override
    public YasBlob getBlob(byte[] bytes, Session session) throws SQLException {
        YasLobProcessor lobProcessor = getLobProcessor(bytes, session, DataType.BLOB);

        YasBlob blob = new YasBlob(false);
        blob.setLobProcessor(lobProcessor);
        blob.setConnection(session.getConnection());
        return blob;
    }

    @Override
    public byte[] getBytes(byte[] bytes) throws SQLException {
        YasBlob blob = this.getBlob(bytes, this.session);
        return blob.getBytes(1, (int) blob.length());
    }

    @Override
    public InputStream getBinaryStream(byte[] bytes) throws SQLException {
        YasBlob blob = this.getBlob(bytes, this.session);
        return blob.getBinaryStream();
    }

    private String getString(Blob blob, Charset charset) throws SQLException {
        int strBufSize = (int) blob.length() * HEX_CHAR_CNT_PER_BYTE;
        byte[] strBuf = new byte[strBufSize];
        byte[] lobBytes = blob.getBytes(1, (int)blob.length());

        int index = 0;
        int pos = 0;
        byte value = 0;
        for (int i = 0; i < strBufSize; i++) {
            index = i / HEX_CHAR_CNT_PER_BYTE;
            value = (byte) (((pos % BITS_PER_BYTE) != 0)
                    ? lobBytes[index] & 0xF : (lobBytes[index] & 0xF0) >> HEX_BYTE_LEN);
            strBuf[i] = (byte) ((value >= 10) ? (value - 10 + 'A') : (value + '0'));
            pos += HEX_BYTE_LEN;
        }

        return new String(strBuf, charset);
    }

    @Override
    public String getString(byte[] bytes) throws SQLException {
        YasBlob blob = this.getBlob(bytes, this.session);
        return getString(blob, CharacterSet.getCharSet(session.getCharset()));
    }
}
