/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.YasConstants;
import com.yashandb.core.DataType;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.ByteConverter;

import java.math.BigDecimal;
import java.sql.SQLException;

public class BitAccessor implements Accessor {

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.BIT);
    }

    @Override
    public String getString(byte[] bytes) throws SQLException {
        return ByteConverter.bitBytesToString(bytes);
    }

    @Override
    public boolean getBoolean(byte[] bytes) throws SQLException {
        long value = ByteConverter.bitBytesToLong(bytes);
        return (value != 0L);
    }

    @Override
    public byte getByte(byte[] bytes) throws SQLException {
        long value = ByteConverter.bitBytesToLong(bytes);
        if (value < YasConstants.MIN_BYTE || value > YasConstants.MAX_BYTE) {
            throw SQLError.OverFlowException("Bit", "Byte");
        }

        return (byte) value;
    }

    @Override
    public short getShort(byte[] bytes) throws SQLException {
        long value = ByteConverter.bitBytesToLong(bytes);
        if (value < Short.MIN_VALUE || value > Short.MAX_VALUE) {
            throw SQLError.OverFlowException("Bit", "Short");
        }
        return (short)value;
    }

    @Override
    public int getInt(byte[] bytes) throws SQLException {
        long value = ByteConverter.bitBytesToLong(bytes);
        if (value < Integer.MIN_VALUE || value > Integer.MAX_VALUE) {
            throw SQLError.OverFlowException("Bit", "Int");
        }
        return (int)value;
    }

    @Override
    public long getLong(byte[] bytes) throws SQLException {
        return ByteConverter.bitBytesToLong(bytes);
    }

    @Override
    public float getFloat(byte[] bytes) throws SQLException {
        long value = ByteConverter.bitBytesToLong(bytes);
        if (value < Float.MIN_VALUE || value > Float.MAX_VALUE) {
            throw SQLError.OverFlowException("Bit", "Float");
        }
        return (float)value;
    }

    @Override
    public double getDouble(byte[] bytes) throws SQLException {
        long value = ByteConverter.bitBytesToLong(bytes);
        if (value < Double.MIN_VALUE || value > Double.MAX_VALUE) {
            throw SQLError.OverFlowException("Bit", "Double");
        }
        return (double)value;
    }

    @Override
    public BigDecimal getBigDecimal(byte[] bytes) throws SQLException {
        long value = ByteConverter.bitBytesToLong(bytes);
        return BigDecimal.valueOf(value);
    }
}
