/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.YasConstants;
import com.yashandb.core.DataType;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.ByteConverter;

import java.math.BigDecimal;
import java.sql.SQLException;

public class IntAccessor implements Accessor {

    int getValue(byte[] bytes) {
        return ByteConverter.int4(bytes, 0);
    }

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.INTEGER);
    }

    @Override
    public String getString(byte[] bytes) {
        int value = getValue(bytes);
        return String.valueOf(value);
    }

    @Override
    public boolean getBoolean(byte[] bytes) throws SQLException {
        int value = getValue(bytes);
        return (value != 0);
    }

    @Override
    public byte getByte(byte[] bytes) throws SQLException {
        int value = getValue(bytes);

        if ((long)value < YasConstants.MIN_BYTE || (long)value > YasConstants.MAX_BYTE) {
            throw SQLError.OverFlowException("Int", "Byte");
        }

        return (byte) value;
    }

    @Override
    public short getShort(byte[] bytes) throws SQLException {
        int value = getValue(bytes);
        if ((long)value < Short.MIN_VALUE || (long)value > Short.MAX_VALUE) {
            throw SQLError.OverFlowException("Int", "Short");
        }
        return (short)value;
    }

    @Override
    public int getInt(byte[] bytes) throws SQLException {
        return getValue(bytes);
    }

    @Override
    public long getLong(byte[] bytes) throws SQLException {
        return getValue(bytes);
    }

    @Override
    public float getFloat(byte[] bytes) throws SQLException {
        long value = getValue(bytes);
        return (float)value;
    }

    @Override
    public double getDouble(byte[] bytes) throws SQLException {
        long value = getValue(bytes);
        return (double)value;
    }

    @Override
    public BigDecimal getBigDecimal(byte[] bytes) throws SQLException {
        return BigDecimal.valueOf(getValue(bytes));
    }
}
