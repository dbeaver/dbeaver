/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.YasConstants;
import com.yashandb.core.DataType;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.ByteConverter;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;

public class DoubleAccessor implements Accessor {

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.DOUBLE);
    }

    private double getValue(byte[] bytes) {
        return ByteConverter.float8(bytes, 0);
    }

    @Override
    public String getString(byte[] bytes) {
        double value = getValue(bytes);
        return String.valueOf(value);
    }

    @Override
    public byte getByte(byte[] bytes) throws SQLException {
        Double value = getValue(bytes);
        Double minByte = (double) YasConstants.MIN_BYTE - 1;
        Double maxByte = (double) YasConstants.MAX_BYTE + 1;

        if ((value.compareTo(minByte) <= 0) || (value.compareTo(maxByte) >= 0)) {
            throw SQLError.OverFlowException("Double", "Byte");
        }

        return value.byteValue();
    }

    @Override
    public short getShort(byte[] bytes) throws SQLException {
        Double value = getValue(bytes);
        Double minValue = (double) Short.MIN_VALUE - 1;
        Double maxValue = (double) Short.MAX_VALUE + 1;
        if ((value.compareTo(minValue) <= 0) || (value.compareTo(maxValue) >= 0)) {
            throw SQLError.OverFlowException("Double", "Short");
        }
        return value.shortValue();
    }

    @Override
    public int getInt(byte[] bytes) throws SQLException {
        Double value = getValue(bytes);
        Double minValue = (double) (Integer.MIN_VALUE - 1L);
        Double maxValue = (double) (Integer.MAX_VALUE + 1L);
        if ((value.compareTo(minValue) <= 0) || (value.compareTo(maxValue) >= 0)) {
            throw SQLError.OverFlowException("Double", "Int");
        }
        return value.intValue();
    }

    @Override
    public long getLong(byte[] bytes) throws SQLException {
        Double value = getValue(bytes);
        Double minValue = (double) Long.MIN_VALUE;
        Double maxValue = (double) Long.MAX_VALUE;
        if ((value.compareTo(minValue) < 0) || (value.compareTo(maxValue) > 0)) {
            throw SQLError.OverFlowException("Double", "Long");
        }
        return value.longValue();
    }

    @Override
    public float getFloat(byte[] bytes) throws SQLException {
        double value = getValue(bytes);
        return (float) value;
    }

    @Override
    public double getDouble(byte[] bytes) throws SQLException {
        return getValue(bytes);
    }

    @Override
    public BigDecimal getBigDecimal(byte[] bytes) throws SQLException {
        return new BigDecimal(String.valueOf(getValue(bytes)));
    }

    @Override
    public BigInteger getBigInteger(byte[] bytes) throws SQLException {
        return new BigInteger(this.getBigDecimal(bytes).toPlainString());
    }

    @Override
    public boolean getBoolean(byte[] bytes) throws SQLException {
        double value = getValue(bytes);
        return (value != 0.0D);
    }
}
