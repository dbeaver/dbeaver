/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.Session;
import com.yashandb.core.DataType;
import com.yashandb.jdbc.YasClob;
import com.yashandb.jdbc.YasLobProcessor;
import com.yashandb.jdbc.exception.SQLError;

import java.io.InputStream;
import java.io.Reader;
import java.sql.SQLException;

public class ClobAccessor extends LobAccessor {

    @Override
    public YasClob getClob(byte[] bytes, Session session) throws SQLException {
        YasLobProcessor lobProcessor = getLobProcessor(bytes, session, DataType.CLOB);

        YasClob clob = new YasClob(false);
        clob.setLobProcessor(lobProcessor);
        clob.setConnection(session.getConnection());
        return clob;
    }

    @Override
    public String getString(byte[] bytes) throws SQLException {
        YasClob clob = getClob(bytes, this.session);
        return clob.getSubString(1, (int) clob.length());
    }

    @Override
    public Reader getCharacterStream(byte[] bytes) throws SQLException {
        YasClob clob = this.getClob(bytes, this.session);
        return clob.getCharacterStream();
    }

    @Override
    public InputStream getBinaryStream(byte[] bytes) throws SQLException {
        YasClob clob = this.getClob(bytes, this.session);
        return clob.getAsciiStream();
    }

    @Override
    public byte[] getBytes(byte[] bytes) throws SQLException {
        throw SQLError.TransformException("CLOB", "BYTES");
    }
}
