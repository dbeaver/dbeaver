/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.Session;
import com.yashandb.core.DataType;
import com.yashandb.jdbc.YasBlob;
import com.yashandb.jdbc.YasLobProcessor;
import com.yashandb.protocol.Yason;

import java.sql.SQLException;

public class JSONAccessor extends LobAccessor {

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.JSON);
    }

    @Override
    public String getString(byte[] bytes) throws SQLException {
        YasBlob blob = getBlob(bytes, this.session);
        byte[] blobBytes = blob.getBytes(1, (int) blob.length());
        int type = blobBytes[Yason.JSON_TYPE_POS];
        Object value = Yason.getInstance(type, blobBytes, 1, this.session.getCharset());
        if (value == null) {
            return "null";
        } else {
            return value.toString();
        }
    }

    @Override
    public YasBlob getBlob(byte[] bytes, Session session) throws SQLException {
        YasLobProcessor lobProcessor = getLobProcessor(bytes, session, DataType.BLOB);
        YasBlob blob = new YasBlob(false);
        blob.setLobProcessor(lobProcessor);
        blob.setConnection(session.getConnection());
        return blob;
    }
}
