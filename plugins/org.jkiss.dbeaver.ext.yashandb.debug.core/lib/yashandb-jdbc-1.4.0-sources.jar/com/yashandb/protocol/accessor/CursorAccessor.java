/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.jdbc.StatementImpl;
import com.yashandb.jdbc.YasConnection;
import com.yashandb.util.ByteConverter;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CursorAccessor implements Accessor {

    short getCursorId(byte[] bytes) {
        return ByteConverter.int2(bytes, 0);
    }

    @Override
    public ResultSet getCursor(byte[] bytes, YasConnection connection) throws SQLException {
        short cursorId = getCursorId(bytes);

        // fetch cursor
        StatementImpl statement = (StatementImpl)connection.createStatement();
        statement.setStmtID(cursorId, (byte) 0);
        statement.closeOnCompletion();

        return connection.getSession().fetchCursor(statement);
    }
}
