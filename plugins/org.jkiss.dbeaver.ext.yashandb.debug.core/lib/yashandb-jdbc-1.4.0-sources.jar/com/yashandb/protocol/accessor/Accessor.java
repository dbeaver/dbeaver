/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.Session;
import com.yashandb.jdbc.YasBlob;
import com.yashandb.jdbc.YasClob;
import com.yashandb.jdbc.YasConnection;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.protocol.ClassInstanceConverter;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.Period;
import java.time.ZonedDateTime;
import java.util.Calendar;

public interface Accessor {

    default String getCurrentTypeName() {
        return this.getClass().getName();
    }

    default String getString(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "STRING");
    }

    default boolean getBoolean(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "BOOLEAN");
    }

    default byte getByte(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "BYTE");
    }

    default int getInt(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "INT");
    }

    default BigInteger getBigInteger(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "BIGINTEGER");
    }

    default short getShort(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "SHORT");
    }

    default long getLong(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "LONG");
    }

    default float getFloat(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "FLOAT");
    }

    default double getDouble(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "DOUBLE");
    }

    default BigDecimal getBigDecimal(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "BIGDECIMAL");
    }

    default Time getTime(byte[] bytes, java.util.Calendar cal) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "TIME");
    }

    default Date getDate(byte[] bytes, java.util.Calendar cal) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "DATE");
    }

    default Timestamp getTimestamp(byte[] bytes, java.util.Calendar cal) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "TIMESTAMP");
    }

    default LocalDateTime getLocalDateTime(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), LocalDateTime.class.getTypeName());
    }

    default LocalDate getLocalDate(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), LocalDate.class.getTypeName());
    }

    default LocalTime getLocalTime(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), LocalTime.class.getTypeName());
    }

    default OffsetDateTime getOffsetDateTime(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), OffsetDateTime.class.getTypeName());
    }

    default OffsetTime getOffsetTime(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), OffsetTime.class.getTypeName());
    }

    default ZonedDateTime getZonedDateTime(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), ZonedDateTime.class.getTypeName());
    }

    default YasClob getClob(byte[] bytes, Session session) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "CLOB");
    }

    default YasBlob getBlob(byte[] bytes, Session session) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "BLOB");
    }

    default RowId getRowId(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "ROWID");
    }

    default byte[] getBytes(byte[] bytes) throws SQLException {
        return bytes;
    }

    default ResultSet getCursor(byte[] bytes, YasConnection connection) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "CURSOR");
    }

    default Reader getCharacterStream(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "READER");
    }

    default InputStream getBinaryStream(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "INPUTSTREAM");
    }

    default java.util.Date getJavaUtilDate(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "JAVA.UTIL.DATE");
    }

    default Calendar getCalendar(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "CALENDAR");
    }

    default Period getPeriod(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "PERIOD");
    }

    default Duration getDuration(byte[] bytes) throws SQLException {
        throw SQLError.TransformException(getCurrentTypeName(), "DURATION");
    }

    default void config(Session session) {
    }

    default  <T> T getObject(byte[] bytes, Class<T> type, YasConnection connection) throws SQLException {
        ClassInstanceConverter<T> classConverter = ClassInstanceConverter.getClassConverter(type);
        if (classConverter == null) {
            throw SQLError.TransformException(getCurrentTypeName(), type.getTypeName());
        }

        return classConverter.redirect(this, bytes, connection);
    }

}
