/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.core.DataType;

import java.math.BigDecimal;
import java.sql.SQLException;

public class TinyIntAccessor implements Accessor {

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.TINYINT);
    }

    @Override
    public String getString(byte[] bytes) {
        byte value = bytes[0];
        return String.valueOf(value);
    }

    @Override
    public boolean getBoolean(byte[] bytes) throws SQLException {
        return (bytes[0] != 0);
    }

    @Override
    public byte getByte(byte[] bytes) throws SQLException {
        return bytes[0];
    }

    @Override
    public short getShort(byte[] bytes) throws SQLException {
        return bytes[0];
    }

    @Override
    public int getInt(byte[] bytes) throws SQLException {
        return bytes[0];
    }

    @Override
    public long getLong(byte[] bytes) throws SQLException {
        return bytes[0];
    }

    @Override
    public float getFloat(byte[] bytes) throws SQLException {
        return (float)bytes[0];
    }

    @Override
    public double getDouble(byte[] bytes) throws SQLException {
        return (double)bytes[0];
    }

    @Override
    public BigDecimal getBigDecimal(byte[] bytes) throws SQLException {
        return BigDecimal.valueOf(bytes[0]);
    }
}
