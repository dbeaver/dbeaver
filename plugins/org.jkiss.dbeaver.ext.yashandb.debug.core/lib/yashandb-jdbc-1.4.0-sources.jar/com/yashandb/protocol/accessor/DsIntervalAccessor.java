/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.core.DataType;
import com.yashandb.protocol.IntervalType;
import com.yashandb.util.ByteConverter;

import java.sql.SQLException;
import java.time.Duration;

public class DsIntervalAccessor implements Accessor {

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.DS_INTERVAL);
    }

    @Override
    public String getString(byte[] bytes) {
        long interval = ByteConverter.int8(bytes, 0);
        return IntervalType.convertDsIntervalToString(interval);
    }

    @Override
    public Duration getDuration(byte[] bytes) throws SQLException {
        long interval = ByteConverter.int8(bytes, 0);
        return IntervalType.convertDsIntervalToDuration(interval);
    }
}
