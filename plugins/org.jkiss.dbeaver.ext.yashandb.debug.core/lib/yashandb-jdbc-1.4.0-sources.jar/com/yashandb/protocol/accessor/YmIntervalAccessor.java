/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.core.DataType;
import com.yashandb.protocol.IntervalType;
import com.yashandb.util.ByteConverter;

import java.sql.SQLException;
import java.time.Period;

public class YmIntervalAccessor implements Accessor {

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.YM_INTERVAL);
    }

    @Override
    public String getString(byte[] bytes) {
        int interval = ByteConverter.int4(bytes, 0);
        return IntervalType.convertYmIntervalToString(interval);
    }

    @Override
    public Period getPeriod(byte[] bytes) throws SQLException {
        int interval = ByteConverter.int4(bytes, 0);
        return IntervalType.convertYmIntervalToPeriod(interval);
    }
}
