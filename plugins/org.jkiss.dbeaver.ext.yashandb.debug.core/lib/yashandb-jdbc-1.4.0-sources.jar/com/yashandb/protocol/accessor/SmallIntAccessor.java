/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.YasConstants;
import com.yashandb.core.DataType;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.ByteConverter;

import java.math.BigDecimal;
import java.sql.SQLException;

public class SmallIntAccessor implements Accessor {

    short getValue(byte[] bytes) {
        return ByteConverter.int2(bytes, 0);
    }

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.SMALLINT);
    }

    @Override
    public String getString(byte[] bytes) {
        short value = getValue(bytes);
        return String.valueOf(value);
    }

    @Override
    public boolean getBoolean(byte[] bytes) throws SQLException {
        short value = getValue(bytes);
        return (value != 0);
    }

    @Override
    public byte getByte(byte[] bytes) throws SQLException {
        short value = getValue(bytes);

        if ((long)value < YasConstants.MIN_BYTE || (long)value > YasConstants.MAX_BYTE) {
            throw SQLError.OverFlowException("SmallInt", "Byte");
        }

        return (byte) value;
    }

    @Override
    public short getShort(byte[] bytes) throws SQLException {
        return getValue(bytes);
    }

    @Override
    public int getInt(byte[] bytes) throws SQLException {
        return getValue(bytes);
    }

    @Override
    public long getLong(byte[] bytes) throws SQLException {
        return getValue(bytes);
    }

    @Override
    public float getFloat(byte[] bytes) throws SQLException {
        long value = getValue(bytes);
        return (float)value;
    }

    @Override
    public double getDouble(byte[] bytes) throws SQLException {
        long value = getValue(bytes);
        return (double)value;
    }

    @Override
    public BigDecimal getBigDecimal(byte[] bytes) throws SQLException {
        return BigDecimal.valueOf(getValue(bytes));
    }
}
