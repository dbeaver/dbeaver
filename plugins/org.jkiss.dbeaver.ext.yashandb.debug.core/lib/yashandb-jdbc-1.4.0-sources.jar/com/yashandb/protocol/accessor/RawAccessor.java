/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.util.Utils;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.sql.SQLException;

public class RawAccessor implements Accessor {

    @Override
    public String getString(byte[] bytes) throws SQLException {
        return Utils.toHexString(bytes);
    }

    @Override
    public InputStream getBinaryStream(byte[] bytes) throws SQLException {
        return new ByteArrayInputStream(bytes);
    }

    @Override
    public Reader getCharacterStream(byte[] bytes) throws SQLException {
        return new StringReader(this.getString(bytes));
    }
}
