/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.YasConstants;
import com.yashandb.core.DataType;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.ByteConverter;

import java.math.BigDecimal;
import java.sql.SQLException;

public class NumberAccessor implements Accessor {

    BigDecimal getValue(byte[] bytes) {
        return ByteConverter.toBigDecimal(bytes, 0);
    }

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.NUMBER);
    }

    @Override
    public String getString(byte[] bytes) {
        BigDecimal bigDecimal = getValue(bytes);
        return String.valueOf(bigDecimal);
    }

    @Override
    public boolean getBoolean(byte[] bytes) throws SQLException {
        BigDecimal bigDecimal = getValue(bytes);
        return (bigDecimal.compareTo(BigDecimal.ZERO) != 0);
    }

    @Override
    public byte getByte(byte[] bytes) throws SQLException {
        BigDecimal bigDecimal = getValue(bytes);
        BigDecimal minByte = BigDecimal.valueOf(YasConstants.MIN_BYTE - 1);
        BigDecimal maxByte = BigDecimal.valueOf(YasConstants.MAX_BYTE + 1);

        if ((bigDecimal.compareTo(minByte) <= 0) || (bigDecimal.compareTo(maxByte) >= 0)) {
            throw SQLError.OverFlowException("Number", "Byte");
        }
        return bigDecimal.byteValue();
    }

    @Override
    public short getShort(byte[] bytes) throws SQLException {
        BigDecimal value = getValue(bytes);
        BigDecimal minValue = BigDecimal.valueOf( Short.MIN_VALUE - 1);
        BigDecimal maxValue = BigDecimal.valueOf( Short.MAX_VALUE + 1);
        if ((value.compareTo(minValue) <= 0) || (value.compareTo(maxValue) >= 0)) {
            throw SQLError.OverFlowException("Number", "Short");
        }
        return value.shortValue();
    }

    @Override
    public int getInt(byte[] bytes) throws SQLException {
        BigDecimal value = getValue(bytes);
        BigDecimal minValue = BigDecimal.valueOf( Integer.MIN_VALUE - 1L);
        BigDecimal maxValue = BigDecimal.valueOf( Integer.MAX_VALUE + 1L);
        if ((value.compareTo(minValue) <= 0) || (value.compareTo(maxValue) >= 0)) {
            throw SQLError.OverFlowException("Number", "Int");
        }
        return value.intValue();
    }

    @Override
    public long getLong(byte[] bytes) throws SQLException {
        BigDecimal value = getValue(bytes);
        BigDecimal minValue = BigDecimal.valueOf( Long.MIN_VALUE );
        BigDecimal maxValue = BigDecimal.valueOf( Long.MAX_VALUE );
        if ((value.compareTo(minValue) < 0) || (value.compareTo(maxValue) > 0)) {
            throw SQLError.OverFlowException("Number", "Long");
        }
        return value.longValue();
    }

    @Override
    public float getFloat(byte[] bytes) throws SQLException {
        BigDecimal value = getValue(bytes);
        return value.floatValue();
    }

    @Override
    public double getDouble(byte[] bytes) throws SQLException {
        BigDecimal value = getValue(bytes);
        return value.doubleValue();
    }

    @Override
    public BigDecimal getBigDecimal(byte[] bytes) throws SQLException {
        return getValue(bytes);
    }
}
