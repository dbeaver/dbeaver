/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.core.DataType;

import java.math.BigDecimal;
import java.sql.SQLException;

public class BooleanAccessor implements Accessor {

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.BOOLEAN);
    }

    @Override
    public String getString(byte[] bytes) {

        if (bytes[0] != 0) {
            return "true";
        }
        return "false";
    }

    @Override
    public boolean getBoolean(byte[] bytes) throws SQLException {
        return (bytes[0] != 0);
    }

    @Override
    public byte getByte(byte[] bytes) throws SQLException {
        if (bytes[0] != 0) {
            return 1;
        }
        return 0;
    }

    @Override
    public short getShort(byte[] bytes) throws SQLException {
        if (bytes[0] != 0) {
            return 1;
        }
        return 0;
    }

    @Override
    public int getInt(byte[] bytes) throws SQLException {
        if (bytes[0] != 0) {
            return 1;
        }
        return 0;
    }

    @Override
    public long getLong(byte[] bytes) throws SQLException {
        if (bytes[0] != 0) {
            return 1;
        }
        return 0;
    }

    @Override
    public float getFloat(byte[] bytes) throws SQLException {
        if (bytes[0] != 0) {
            return 1F;
        }
        return 0F;
    }

    @Override
    public double getDouble(byte[] bytes) throws SQLException {
        if (bytes[0] != 0) {
            return 1D;
        }
        return 0.0D;
    }

    @Override
    public BigDecimal getBigDecimal(byte[] bytes) throws SQLException {
        if (bytes[0] != 0) {
            return BigDecimal.ONE;
        }
        return BigDecimal.ZERO;
    }
}
