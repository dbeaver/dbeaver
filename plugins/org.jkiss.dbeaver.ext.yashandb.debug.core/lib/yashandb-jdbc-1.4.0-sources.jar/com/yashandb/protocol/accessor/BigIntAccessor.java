/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.YasConstants;
import com.yashandb.core.DataType;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.ByteConverter;

import java.math.BigDecimal;
import java.sql.SQLException;

public class BigIntAccessor implements Accessor {

    private long getValue(byte[] bytes) {
        return ByteConverter.int8(bytes, 0);
    }

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.BIGINT);
    }

    @Override
    public String getString(byte[] bytes) {
        long value = getValue(bytes);
        return String.valueOf(value);
    }

    @Override
    public boolean getBoolean(byte[] bytes) throws SQLException {
        long value = getValue(bytes);
        return (value != 0L);
    }

    @Override
    public byte getByte(byte[] bytes) throws SQLException {
        long value = getValue(bytes);
        if (value < YasConstants.MIN_BYTE || value > YasConstants.MAX_BYTE) {
            throw SQLError.OverFlowException("Long", "Byte");
        }

        return (byte) value;
    }

    @Override
    public short getShort(byte[] bytes) throws SQLException {
        long value = getValue(bytes);
        if (value < Short.MIN_VALUE || value > Short.MAX_VALUE) {
            throw SQLError.OverFlowException("Long", "Short");
        }
        return (short)value;
    }

    @Override
    public int getInt(byte[] bytes) throws SQLException {
        long value = getValue(bytes);
        if (value < Integer.MIN_VALUE || value > Integer.MAX_VALUE) {
            throw SQLError.OverFlowException("Long", "Int");
        }
        return (int)value;
    }

    @Override
    public long getLong(byte[] bytes) throws SQLException {
        return getValue(bytes);
    }

    @Override
    public float getFloat(byte[] bytes) throws SQLException {
        long value = getValue(bytes);
        return (float)value;
    }

    @Override
    public double getDouble(byte[] bytes) throws SQLException {
        long value = getValue(bytes);
        return (double)value;
    }

    @Override
    public BigDecimal getBigDecimal(byte[] bytes) throws SQLException {
        return BigDecimal.valueOf(getValue(bytes));
    }
}
