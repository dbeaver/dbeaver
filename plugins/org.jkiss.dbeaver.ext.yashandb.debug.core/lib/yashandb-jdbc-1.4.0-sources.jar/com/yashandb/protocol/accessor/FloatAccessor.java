/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.YasConstants;
import com.yashandb.core.DataType;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.ByteConverter;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;

public class FloatAccessor implements Accessor {

    float getValue(byte[] bytes) {
        float value = ByteConverter.float4(bytes, 0);
        return value;
    }

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.FLOAT);
    }

    @Override
    public String getString(byte[] bytes) {
        float value = getValue(bytes);
        return String.valueOf(value);
    }

    @Override
    public byte getByte(byte[] bytes) throws SQLException {
        Float value = getValue(bytes);
        Float minByte = (float) YasConstants.MIN_BYTE - 1;
        Float maxByte = (float) YasConstants.MAX_BYTE + 1;

        if ((value.compareTo(minByte) <= 0) || (value.compareTo(maxByte) >= 0)) {
            throw SQLError.OverFlowException("Float", "Byte");
        }

        return value.byteValue();
    }

    @Override
    public short getShort(byte[] bytes) throws SQLException {
        Float value = getValue(bytes);
        Float minValue = (float) Short.MIN_VALUE - 1;
        Float maxValue = (float) Short.MAX_VALUE + 1;
        if ((value.compareTo(minValue) <= 0) || (value.compareTo(maxValue) >= 0)) {
            throw SQLError.OverFlowException("Float", "Short");
        }
        return value.shortValue();
    }

    @Override
    public int getInt(byte[] bytes) throws SQLException {
        Float value = getValue(bytes);
        Float minValue = (float) (Integer.MIN_VALUE - 1L);
        Float maxValue = (float) (Integer.MAX_VALUE + 1L);
        if ((value.compareTo(minValue) <= 0) || (value.compareTo(maxValue) >= 0)) {
            throw SQLError.OverFlowException("Float", "Int");
        }
        return value.intValue();
    }

    @Override
    public long getLong(byte[] bytes) throws SQLException {
        Float value = getValue(bytes);
        Float minValue = (float) Long.MIN_VALUE;
        Float maxValue = (float) Long.MAX_VALUE;
        if ((value.compareTo(minValue) < 0) || (value.compareTo(maxValue) > 0)) {
            throw SQLError.OverFlowException("Float", "Long");
        }
        return value.longValue();
    }

    @Override
    public float getFloat(byte[] bytes) throws SQLException {
        return getValue(bytes);
    }

    @Override
    public double getDouble(byte[] bytes) throws SQLException {
        return getValue(bytes);
    }

    @Override
    public BigDecimal getBigDecimal(byte[] bytes) throws SQLException {
        return new BigDecimal(String.valueOf(getValue(bytes)));
    }

    @Override
    public BigInteger getBigInteger(byte[] bytes) throws SQLException {
        return new BigInteger(this.getBigDecimal(bytes).toPlainString());
    }

    @Override
    public boolean getBoolean(byte[] bytes) throws SQLException {
        float value = getValue(bytes);
        return (value != 0F);
    }
}
