/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.Session;
import com.yashandb.core.DataType;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.Field;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.Messages;

import java.sql.SQLException;

public class AccessorFactory {

    private static Accessor generateAccessor(int dataType) throws SQLException {
        Accessor accessor;

        switch (dataType) {
            case DataType.CHAR:
            case DataType.VARCHAR:
            case DataType.NCHAR:
            case DataType.NVARCHAR:
                accessor =  new CharCommonAccessor(dataType);
                break;
            case DataType.TINYINT:
                accessor = new TinyIntAccessor();
                break;
            case DataType.SMALLINT:
                accessor = new SmallIntAccessor();
                break;
            case DataType.INTEGER:
                accessor = new IntAccessor();
                break;
            case DataType.BIGINT:
                accessor = new BigIntAccessor();
                break;
            case DataType.FLOAT:
                accessor = new FloatAccessor();
                break;
            case DataType.DOUBLE:
                accessor = new DoubleAccessor();
                break;
            case DataType.NUMBER:
                accessor = new NumberAccessor();
                break;
            case DataType.SHORTTIME:
                accessor = new TimeAccessor();
                break;
            case DataType.DATE:
                accessor = new DateAccessor();
                break;
            case DataType.TIMESTAMP:
                accessor = new TimeStampAccessor();
                break;
            case DataType.DS_INTERVAL:
                accessor = new DsIntervalAccessor();
                break;
            case DataType.YM_INTERVAL:
                accessor = new YmIntervalAccessor();
                break;
            case DataType.BOOLEAN:
                accessor = new BooleanAccessor();
                break;
            case DataType.BIT:
                accessor = new BitAccessor();
                break;
            case DataType.ROWID:
                accessor = new RowIdAccessor();
                break;
            case DataType.CLOB:
                accessor = new ClobAccessor();
                break;
            case DataType.JSON:
                accessor = new JSONAccessor();
                break;
            case DataType.BLOB:
                accessor = new BlobAccessor();
                break;
            case DataType.RAW:
                accessor = new RawAccessor();
                break;
            case DataType.CURSOR:
                accessor = new CursorAccessor();
                break;
            default:
                throw SQLError.createSQLException(Messages.get("unsupported datatype {0}", dataType),
                        YasState.DATA_ERROR);
        }

        return accessor;
    }

    public static Accessor[] generateAccessors(Field[] fields, Session session) throws SQLException {

        Accessor[] accessors = new Accessor[fields.length];

        for (int i = 0; i < accessors.length; i++) {
            accessors[i] = generateAccessor(fields[i].getYasType());
            accessors[i].config(session);
        }

        return accessors;
    }

    public static Accessor generateAccessorByDataType(int dataType, Session session) throws SQLException {
        Accessor accessor = generateAccessor(dataType);
        accessor.config(session);
        return accessor;
    }
}
