/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.core.DataType;
import com.yashandb.protocol.InternalTimeStamp;
import com.yashandb.util.ByteConverter;
import com.yashandb.util.YasTime;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class DateAccessor implements Accessor {

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.DATE);
    }

    @Override
    public String getString(byte[] bytes) {

        long timeFromBase = ByteConverter.int8(bytes, 0);
        InternalTimeStamp internalTimeStamp = InternalTimeStamp.transValueToTimeStamp(timeFromBase);

        Calendar cal = Calendar.getInstance();
        cal.set(internalTimeStamp.year, internalTimeStamp.month - 1, internalTimeStamp.date,
                internalTimeStamp.hour, internalTimeStamp.minute, internalTimeStamp.second);
        cal.set(Calendar.MILLISECOND, internalTimeStamp.fraction / 1000);

        Date date =  new Date(cal.getTimeInMillis());
        return String.valueOf(date);
    }

    @Override
    public Time getTime(byte[] bytes, java.util.Calendar cal) throws SQLException {
        long timeFromBase = ByteConverter.int8(bytes, 0);
        if (cal == null) {
            cal = Calendar.getInstance();
        }

        InternalTimeStamp internalTimeStamp = InternalTimeStamp.transValueToTimeStamp(timeFromBase);
        cal.set(internalTimeStamp.year, internalTimeStamp.month - 1, internalTimeStamp.date,
                internalTimeStamp.hour, internalTimeStamp.minute, internalTimeStamp.second);
        cal.set(Calendar.MILLISECOND, internalTimeStamp.fraction / 1000);

        YasTime time = new YasTime(cal.getTimeInMillis());
        time.setNanos(internalTimeStamp.fraction * 1000);

        return time;
    }

    @Override
    public Date getDate(byte[] bytes, java.util.Calendar cal) throws SQLException {
        long timeFromBase = ByteConverter.int8(bytes, 0);
        InternalTimeStamp internalTimeStamp = InternalTimeStamp.transValueToTimeStamp(timeFromBase);

        if (cal == null) {
            cal = Calendar.getInstance();
        }
        cal.set(internalTimeStamp.year, internalTimeStamp.month - 1, internalTimeStamp.date,
                internalTimeStamp.hour, internalTimeStamp.minute, internalTimeStamp.second);
        cal.set(Calendar.MILLISECOND, internalTimeStamp.fraction / 1000);
        return new Date(cal.getTimeInMillis());
    }

    public Timestamp getTimestamp(byte[] bytes, java.util.Calendar cal) throws SQLException {
        long timeFromBase = ByteConverter.int8(bytes, 0);
        if (cal == null) {
            cal = Calendar.getInstance();
        }
        InternalTimeStamp internalTimeStamp = InternalTimeStamp.transValueToTimeStamp(timeFromBase);

        cal.set(internalTimeStamp.year, internalTimeStamp.month - 1, internalTimeStamp.date,
                internalTimeStamp.hour, internalTimeStamp.minute, internalTimeStamp.second);
        cal.set(Calendar.MILLISECOND, internalTimeStamp.fraction / 1000);

        Timestamp timestamp = new Timestamp(cal.getTimeInMillis());
        timestamp.setNanos(internalTimeStamp.fraction * 1000);
        return  timestamp;
    }

    @Override
    public LocalDateTime getLocalDateTime(byte[] bytes) {
        long timeFromBase = ByteConverter.int8(bytes, 0);
        InternalTimeStamp internalTimeStamp = InternalTimeStamp.transValueToTimeStamp(timeFromBase);

        return LocalDateTime.of(internalTimeStamp.year, internalTimeStamp.month, internalTimeStamp.date,
                internalTimeStamp.hour, internalTimeStamp.minute, internalTimeStamp.second,
                internalTimeStamp.fraction * 1000);
    }

    @Override
    public LocalDate getLocalDate(byte[] bytes) throws SQLException {
        long timeFromBase = ByteConverter.int8(bytes, 0);
        InternalTimeStamp internalTimeStamp = InternalTimeStamp.transValueToTimeStamp(timeFromBase);

        return LocalDate.of(internalTimeStamp.year, internalTimeStamp.month, internalTimeStamp.date);
    }

    @Override
    public LocalTime getLocalTime(byte[] bytes) throws SQLException {
        long timeFromBase = ByteConverter.int8(bytes, 0);
        InternalTimeStamp internalTimeStamp = InternalTimeStamp.transValueToTimeStamp(timeFromBase);

        return LocalTime.of(internalTimeStamp.hour, internalTimeStamp.minute, internalTimeStamp.second,
                internalTimeStamp.fraction * 1000);
    }

    @Override
    public OffsetDateTime getOffsetDateTime(byte[] bytes) throws SQLException {
        LocalDateTime localDateTime = this.getLocalDateTime(bytes);

        return OffsetDateTime.of(localDateTime, ZoneOffset.UTC);
    }

    @Override
    public OffsetTime getOffsetTime(byte[] bytes) throws SQLException {
        long timeFromBase = ByteConverter.int8(bytes, 0);
        InternalTimeStamp internalTimeStamp = InternalTimeStamp.transValueToTimeStamp(timeFromBase);

        LocalTime localTime = LocalTime.of(internalTimeStamp.hour, internalTimeStamp.minute, internalTimeStamp.second,
                internalTimeStamp.fraction * 1000);

        return OffsetTime.of(localTime, ZoneOffset.UTC);
    }

    @Override
    public ZonedDateTime getZonedDateTime(byte[] bytes) throws SQLException {
        long timeFromBase = ByteConverter.int8(bytes, 0);
        InternalTimeStamp internalTimeStamp = InternalTimeStamp.transValueToTimeStamp(timeFromBase);

        LocalDateTime localDateTime = LocalDateTime.of(internalTimeStamp.year, internalTimeStamp.month,
                internalTimeStamp.date, internalTimeStamp.hour, internalTimeStamp.minute, internalTimeStamp.second,
                internalTimeStamp.fraction * 1000);

        OffsetDateTime offsetDateTime = OffsetDateTime.of(localDateTime, ZoneOffset.UTC);
        return offsetDateTime.atZoneSameInstant(offsetDateTime.getOffset());
    }

    @Override
    public java.util.Date getJavaUtilDate(byte[] bytes) throws SQLException {
        Calendar calendar = this.getCalendar(bytes);
        return calendar.getTime();
    }

    @Override
    public Calendar getCalendar(byte[] bytes) throws SQLException {
        long timeFromBase = ByteConverter.int8(bytes, 0);
        InternalTimeStamp internalTimeStamp = InternalTimeStamp.transValueToTimeStamp(timeFromBase);

        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(Calendar.YEAR, internalTimeStamp.year);
        calendar.set(Calendar.MONTH, internalTimeStamp.month - 1);
        calendar.set(Calendar.DATE, internalTimeStamp.date);
        calendar.set(Calendar.HOUR_OF_DAY, internalTimeStamp.hour);
        calendar.set(Calendar.MINUTE, internalTimeStamp.minute);
        calendar.set(Calendar.SECOND, internalTimeStamp.second);
        calendar.set(Calendar.MILLISECOND, internalTimeStamp.fraction / 1000);

        if (internalTimeStamp.year > 0 && calendar.isSet(Calendar.ERA)) {
            calendar.set(Calendar.ERA, GregorianCalendar.AD);
        }

        return calendar;
    }
}
