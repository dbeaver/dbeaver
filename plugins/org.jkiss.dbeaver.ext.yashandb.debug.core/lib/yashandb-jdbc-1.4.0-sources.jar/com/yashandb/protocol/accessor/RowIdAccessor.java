/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol.accessor;

import com.yashandb.core.DataType;
import com.yashandb.jdbc.YasRowID;

import java.sql.RowId;
import java.sql.SQLException;

public class RowIdAccessor implements Accessor {

    @Override
    public String getCurrentTypeName() {
        return DataType.getTypeName(DataType.ROWID);
    }

    private YasRowID generateRowId(byte[] bytes) throws SQLException {
        return new YasRowID(bytes);
    }

    @Override
    public String getString(byte[] bytes) throws SQLException {
        YasRowID rowID = generateRowId(bytes);
        return rowID.toString();
    }

    @Override
    public RowId getRowId(byte[] bytes) throws SQLException {
        return generateRowId(bytes);
    }
}
