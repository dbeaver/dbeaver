/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.YasConstants;

public class InternalTimeStamp {
    public int year;
    public int month;
    public int date;
    public int hour;
    public int minute;
    public int second;
    public int fraction;

    public static InternalTimeStamp transValueToTimeStamp(long timeValue) {

        InternalTimeStamp internalTimeStamp = new InternalTimeStamp();

        long jDateUs = timeValue + YasConstants.UNIX_EPOCH_JDATE * YasConstants.US_ONE_DAY;
        int jDate = (int)(jDateUs / YasConstants.US_ONE_DAY);

        int tmpYear;
        jDate += 32044;
        int quad = jDate / 146097;
        int extra = (jDate - quad * 146097) * 4 + 3;
        jDate += 60 + quad * 3 + extra / 146097;
        quad = jDate / 1461;
        jDate -= quad * 1461;
        tmpYear = jDate * 4 / 1461;
        jDate = ((tmpYear != 0) ? (jDate + 305) % 365 : (jDate + 306) % 366) + 123;
        tmpYear += quad * 4;
        internalTimeStamp.year = tmpYear - 4800;

        quad = jDate * 2141 / 65536;
        internalTimeStamp.date = jDate - 7834 * quad / 256;
        internalTimeStamp.month = (quad + 10) % 12 + 1;

        long remainUs = jDateUs % YasConstants.US_ONE_DAY;
        internalTimeStamp.hour = (int) (remainUs / YasConstants.US_ONE_HOUR);
        remainUs -= internalTimeStamp.hour * YasConstants.US_ONE_HOUR;
        internalTimeStamp.minute = (int) (remainUs / YasConstants.US_ONE_MINUTE);
        remainUs -= (long) internalTimeStamp.minute * YasConstants.US_ONE_MINUTE;
        internalTimeStamp.second = (int) (remainUs / YasConstants.US_ONE_SECOND);
        internalTimeStamp.fraction = (int) (remainUs % YasConstants.US_ONE_SECOND);

        return internalTimeStamp;
    }

    private static boolean isLeapYear(int year) {
        return (year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0);
    }

    public static long transTimeStampToValue(InternalTimeStamp internalTimeStamp) {
        int year = internalTimeStamp.year;
        int month =  internalTimeStamp.month;
        if (month > 2) {
            month += 1;
            year += 4800;
        } else {
            month += 13;
            year += 4799;
        }

        int century = year / 100;
        int jDate = year * 365 - 32167;
        jDate += year / 4 - century + century / 4;
        jDate += 7834 * month / 256 + internalTimeStamp.date;

        long tmpDate = jDate * YasConstants.US_ONE_DAY;
        tmpDate += internalTimeStamp.hour * YasConstants.US_ONE_HOUR;
        tmpDate += (long) internalTimeStamp.minute * YasConstants.US_ONE_MINUTE;
        tmpDate += internalTimeStamp.second * YasConstants.US_ONE_SECOND;
        tmpDate += internalTimeStamp.fraction;

        long timeValue = tmpDate - YasConstants.UNIX_EPOCH_JDATE * YasConstants.US_ONE_DAY;
        return timeValue;
    }

    public static InternalTimeStamp transValueToTime(long timeValue) {
        InternalTimeStamp internalTimeStamp = new InternalTimeStamp();

        long remainUs = timeValue % YasConstants.US_ONE_DAY;
        internalTimeStamp.hour = (int) (remainUs / YasConstants.US_ONE_HOUR);
        remainUs -= internalTimeStamp.hour * YasConstants.US_ONE_HOUR;
        internalTimeStamp.minute = (int) (remainUs / YasConstants.US_ONE_MINUTE);
        remainUs -= (long) internalTimeStamp.minute * YasConstants.US_ONE_MINUTE;
        internalTimeStamp.second = (int) (remainUs / YasConstants.US_ONE_SECOND);
        internalTimeStamp.fraction = (int) (remainUs % YasConstants.US_ONE_SECOND);

        return internalTimeStamp;
    }

    public static long transTimeToValue(InternalTimeStamp internalTimeStamp) {
        long tmpDate = 0;
        tmpDate += internalTimeStamp.hour * YasConstants.US_ONE_HOUR;
        tmpDate += (long) internalTimeStamp.minute * YasConstants.US_ONE_MINUTE;
        tmpDate += internalTimeStamp.second * YasConstants.US_ONE_SECOND;
        tmpDate += internalTimeStamp.fraction;

        long timeValue = tmpDate ;
        return timeValue;
    }
}
