/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.YasConstants;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.SQLException;
import java.time.Duration;
import java.time.Period;

public class IntervalType {

    private static int getIntervalSign(String strInterval) {
        int sign = 0;
        if (strInterval.charAt(0) == '-') {
            sign = 1;
        }

        return sign;
    }

    private static String stripSign(String strInterval) {
        char firstChar = strInterval.charAt(0);

        if ((firstChar == '-') || (firstChar == '+')) {
            return strInterval.substring(1);
        }
        return strInterval;
    }

    private static String getIntervalElement(String strInterval) throws SQLException {
        checkInterval(strInterval);

        int iCount;
        for (iCount = 0; iCount < strInterval.length(); iCount++) {
            if (!Character.isDigit(strInterval.charAt(iCount))) {
                break;
            }
        }

        if (iCount > YasConstants.MAX_INTERVAL_PRECISION) {
            throw SQLError.createSQLException("the leading precision is too small", YasState.DATA_ERROR);
        }

        return strInterval.substring(0, iCount);
    }

    private static int getElementValue(String digitPart) throws SQLException {
        long value;
        try {
            value = Long.parseLong(digitPart);
        } catch (NumberFormatException exception) {
            throw SQLError.createSQLException("the interval is invalid", YasState.DATA_ERROR);
        }

        if (value > 0xFFFFFFFFL) {
            throw SQLError.createSQLException("the leading precision is too small", YasState.DATA_ERROR);
        }

        return (int) value;
    }

    private static String skipSplitChar(String strInterval, char split) throws SQLException {
        checkInterval(strInterval);

        if (strInterval.charAt(0) != split) {
            throw SQLError.createSQLException("the interval is invalid", YasState.DATA_ERROR);
        }

        return strInterval.substring(1);
    }

    private static void checkInterval(String strInterval) throws SQLException {
        if (strInterval.isEmpty()) {
            throw SQLError.createSQLException("the interval is invalid", YasState.DATA_ERROR);
        }
    }

    private static int getYear(String strDigit) throws SQLException {
        int year = getElementValue(strDigit);
        if (year > YasConstants.MAX_YMI_YEAR) {
            throw SQLError.createSQLException("the year is out of range", YasState.DATA_ERROR);
        }

        return year;
    }

    private static int getMonth(String strDigit) throws SQLException {
        int month = getElementValue(strDigit);
        if (month >= YasConstants.MONTH_PER_YEAR) {
            throw SQLError.createSQLException("not a valid month", YasState.DATA_ERROR);
        }

        return month;
    }

    private static int getDay(String strDigit) throws SQLException {
        int day = getElementValue(strDigit);
        if (day > YasConstants.MAX_DSI_DAY) {
            throw SQLError.createSQLException("the day is out of range", YasState.DATA_ERROR);
        }

        return day;
    }

    private static int getHour(String strDigit) throws SQLException {
        int hour = getElementValue(strDigit);
        if (hour >= YasConstants.HOUR_PER_DAY) {
            throw SQLError.createSQLException("not a valid hour", YasState.DATA_ERROR);
        }

        return hour;
    }

    private static int getMinute(String strDigit) throws SQLException {
        int minute = getElementValue(strDigit);
        if (minute >= YasConstants.MIN_PER_HOUR) {
            throw SQLError.createSQLException("not a valid minute", YasState.DATA_ERROR);
        }

        return minute;
    }

    private static int getSecond(String strDigit) throws SQLException {
        int second = getElementValue(strDigit);
        if (second >= YasConstants.SEC_PER_MIN) {
            throw SQLError.createSQLException("not a valid second", YasState.DATA_ERROR);
        }

        return second;
    }

    private static int getFraction(String strInterval) throws SQLException {
        checkInterval(strInterval);

        int fraction = 0;
        for (int i = 0; i < strInterval.length(); i++) {
            if (!Character.isDigit(strInterval.charAt(i))) {
                throw SQLError.createSQLException("not a valid fraction", YasState.DATA_ERROR);
            }

            fraction *= 10;
            fraction += (strInterval.charAt(i) - '0');
        }

        if (strInterval.length() > YasConstants.MAX_INTERVAL_PRECISION) {
            throw SQLError.createSQLException("the leading precision is too small", YasState.DATA_ERROR);
        }

        if (strInterval.length() > YasConstants.MAX_FRACTION_PRECISION) {
            double tempFraction = (double) fraction
                    / (YasConstants.PrecisionLimit[strInterval.length() - YasConstants.MAX_FRACTION_PRECISION]);
            fraction = (int) Math.round(tempFraction);
        }

        if (strInterval.length() < YasConstants.MAX_FRACTION_PRECISION) {
            fraction *= YasConstants.PrecisionLimit[YasConstants.MAX_FRACTION_PRECISION - strInterval.length()];
        }

        return fraction;
    }

    public static long convertStringToDsInterval(String strInterval) throws SQLException {
        strInterval = strInterval.trim();
        long dsInterVal = 0L;

        // sign
        checkInterval(strInterval);
        int sign = getIntervalSign(strInterval);

        // day
        strInterval = stripSign(strInterval).trim();
        String digitPart = getIntervalElement(strInterval);
        int day = getDay(digitPart);
        dsInterVal += day * YasConstants.US_ONE_DAY;

        // hour
        strInterval = strInterval.substring(digitPart.length());
        strInterval = skipSplitChar(strInterval, YasConstants.DS_DH_SPLIT).trim();
        digitPart = getIntervalElement(strInterval);
        int hour = getHour(digitPart);
        dsInterVal += hour * YasConstants.US_ONE_HOUR;

        // minute
        strInterval = strInterval.substring(digitPart.length()).trim();
        strInterval = skipSplitChar(strInterval, YasConstants.DS_NORMAL_SPLIT).trim();

        digitPart = getIntervalElement(strInterval);
        int minute = getMinute(digitPart);
        dsInterVal += (long) minute * YasConstants.US_ONE_MINUTE;

        // second
        strInterval = strInterval.substring(digitPart.length()).trim();
        strInterval = skipSplitChar(strInterval, YasConstants.DS_NORMAL_SPLIT).trim();

        digitPart = getIntervalElement(strInterval);
        int second = getSecond(digitPart);
        dsInterVal += (long)second * YasConstants.US_ONE_SECOND;

        // fraction
        strInterval = strInterval.substring(digitPart.length());
        if (strInterval.length() > 0) {
            strInterval = strInterval.trim();
            strInterval = skipSplitChar(strInterval, YasConstants.DOT_SPLIT).trim();

            int fraction = getFraction(strInterval);
            dsInterVal += fraction;
        }

        if (dsInterVal > YasConstants.MAX_DSI) {
            throw SQLError.createSQLException("the interval is out of range", YasState.UNKNOWN_STATE);
        }

        if (sign > 0) {
            dsInterVal = -dsInterVal;
        }

        return dsInterVal;
    }

    public static String convertDsIntervalToString(long interval) {
        String strInterval = "";

        String sign = "+";
        if (interval < 0L) {
            sign = "-";
            interval = -interval;
        }

        strInterval += sign;

        int day = (int) (interval / YasConstants.US_ONE_DAY);
        strInterval += String.format("%02d", day);
        strInterval += YasConstants.DS_DH_SPLIT;

        int hour = (int) ((interval / YasConstants.US_ONE_HOUR) % YasConstants.HOUR_PER_DAY);
        strInterval += String.format("%02d", hour);
        strInterval += YasConstants.DS_NORMAL_SPLIT;

        int minute = (int) ((interval / YasConstants.US_ONE_MINUTE) % YasConstants.MIN_PER_HOUR);
        strInterval += String.format("%02d", minute);
        strInterval += YasConstants.DS_NORMAL_SPLIT;

        int second = (int) ((interval / YasConstants.US_ONE_SECOND) % YasConstants.SEC_PER_MIN);
        strInterval += String.format("%02d", second);
        strInterval += YasConstants.DOT_SPLIT;

        int fraction = (int) (interval % YasConstants.US_ONE_SECOND);
        strInterval += String.format("%06d", fraction);

        return strInterval;
    }

    public static Duration convertDsIntervalToDuration(long interval) {
        int day = (int) (interval / YasConstants.US_ONE_DAY);

        Duration duration = Duration.ofDays(day);
        int hour = (int) ((interval / YasConstants.US_ONE_HOUR) % YasConstants.HOUR_PER_DAY);
        duration = duration.plusHours(hour);

        int minute = (int) ((interval / YasConstants.US_ONE_MINUTE) % YasConstants.MIN_PER_HOUR);
        duration = duration.plusMinutes(minute);

        int second = (int) ((interval / YasConstants.US_ONE_SECOND) % YasConstants.SEC_PER_MIN);
        duration = duration.plusSeconds(second);

        int fraction = (int) (interval % YasConstants.US_ONE_SECOND);
        duration = duration.plusNanos(fraction * 1000);

        return duration;
    }

    public static int convertStringToYmInterval(String strInterval) throws SQLException {
        strInterval = strInterval.trim();
        int ymInterVal = 0;

        // sign
        checkInterval(strInterval);
        int sign = getIntervalSign(strInterval);

        // year
        strInterval = stripSign(strInterval).trim();
        String digitPart = getIntervalElement(strInterval);
        int year = getYear(digitPart);
        ymInterVal += year * YasConstants.MONTH_PER_YEAR;

        // month
        strInterval = strInterval.substring(digitPart.length());
        strInterval = skipSplitChar(strInterval, YasConstants.YM_SPLIT).trim();
        digitPart = getIntervalElement(strInterval);
        int month = getMonth(digitPart);
        ymInterVal += month;

        strInterval = strInterval.substring(digitPart.length());
        if (strInterval.length() != 0) {
            throw SQLError.createSQLException("the interval is invalid", YasState.DATA_ERROR);
        }

        if (ymInterVal > YasConstants.MAX_YMI) {
            throw SQLError.createSQLException("the interval is out of range", YasState.DATA_ERROR);
        }

        if (sign > 0) {
            ymInterVal = -ymInterVal;
        }

        return ymInterVal;
    }

    public static String convertYmIntervalToString(int interval) {
        String strInterval = "";

        String sign = "+";
        if (interval < 0) {
            sign = "-";
            interval = -interval;
        }
        strInterval += sign;

        int year = interval / YasConstants.MONTH_PER_YEAR;
        strInterval += String.format("%02d", year);
        strInterval += YasConstants.YM_SPLIT;

        int month = interval % YasConstants.MONTH_PER_YEAR;
        strInterval += String.format("%02d", month);

        return strInterval;
    }

    public static Period convertYmIntervalToPeriod(int interval) {
        int year = interval / YasConstants.MONTH_PER_YEAR;
        int month = interval % YasConstants.MONTH_PER_YEAR;

        return Period.of(year, month, 0);
    }
}
