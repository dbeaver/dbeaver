/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.util.ByteConverter;

public abstract class BaseBuffer implements Buffer {
    @Override
    public byte[] getBuffer() {
        return buffer;
    }

    @Override
    public int getPostion() {
        return this.position;
    }

    @Override
    public int getRemainSize() {
        return capacity - position;
    }

    @Override
    public int getCapacity() {
        return capacity;
    }

    @Override
    public void writeFixString(String str, int i) {
        ensureCapacity(i);
        byte[] b = this.buffer;
        System.arraycopy(str.getBytes(), 0, b, this.position, str.getBytes().length);
        this.position += i;
    }

    @Override
    public void writeString(String str) {
        ensureCapacity(str.getBytes().length);
        byte[] b = this.buffer;
        System.arraycopy(str.getBytes(), 0, b, this.position, str.getBytes().length);
        this.position += str.getBytes().length;
    }

    @Override
    public void writeLong(long v) {
        ensureCapacity(8);
        ByteConverter.int8(buffer, position, v);
        this.position += 8;
    }

    @Override
    public void writeInt(int v) {
        ensureCapacity(4);
        ByteConverter.int4(buffer, position, v);
        this.position += 4;
    }

    @Override
    public void writeShort(int v) {
        ensureCapacity(2);
        writeShort(position, v);
        this.position += 2;
    }

    @Override
    public void writeByte(byte v) {
        ensureCapacity(1);
        buffer[this.position++] = v;
    }

    @Override
    public void writeFloat(float v) {
        ensureCapacity(4);
        writeFloat(position, v);
        position += 4;
    }

    @Override
    public void writeDouble(double v) {
        ensureCapacity(8);
        writeDouble(position, v);
        position += 8;
    }

    @Override
    public float getFloat() {
        return 0;
    }

    @Override
    public double getDouble() {
        return 0;
    }

    @Override
    public void writeBytes(byte[] i) {
        ensureCapacity(i.length);
        byte[] b = this.buffer;
        System.arraycopy(i, 0, b, this.position, i.length);
        this.position += i.length;
    }

    @Override
    public byte[] getBytes(int len) {
        byte[] b = new byte[len];
        System.arraycopy(this.buffer, this.position, b, 0, len);
        this.position += len;
        return b;
    }

    public byte[] getBytes(int len,byte[] bytes) {
        byte[] b = bytes;
        System.arraycopy(this.buffer, this.position, b, 0, len);
        this.position += len;
        return b;
    }

    @Override
    public int getInt() {
        int p = this.position;
        this.position += 4;
        return getInt(p);
    }

    @Override
    public long getLong() {
        int p = this.position;
        this.position += 8;
        return getLong(p);
    }

    @Override
    public String getString(int len) {
        int p = this.position;
        this.position += len;
        return getString(p, len);
    }

    @Override
    public short getShort() {
        int p = this.position;
        this.position += 2;
        return getShort(p);
    }

    @Override
    public byte getByte() {
        int p = this.position;
        this.position += 1;
        return getByte(p);
    }

    @Override
    public void skip(int size) {
        this.position += size;
    }

    @Override
    public void clean() {
        this.position = 8;
    }

    /**
     * Checks that underlying buffer has enough space to store additionalData bytes starting from current position.
     * If buffer size is smaller than required then it is re-allocated with bigger size.
     *
     * @param additionalData additional data size in bytes
     */
    public final void ensureCapacity(int additionalData) {
        if ((this.position + additionalData) > this.buffer.length) {
            throw new OutOfMemoryError("pos out message capcity");
        }
    }

    public BaseBuffer(int capacity) {
        this.capacity = capacity;
        buffer = new byte[capacity];
    }

    public BaseBuffer(Buffer buffer) {
        this.buffer = buffer.getBuffer();
        this.capacity = buffer.getCapacity();
    }

    protected int getInt(int pos) {
        return ByteConverter.int4(buffer, pos);
    }

    protected long getLong(int pos) {
        return ByteConverter.int8(buffer, pos);
    }

    protected String getString(int pos, int len) {
        return new String(buffer, pos, len);
    }

    protected byte getByte(int pos) {
        return buffer[pos];
    }

    protected short getShort(int pos) {
        return ByteConverter.int2(buffer, pos);
    }

    protected void setByte(int i, byte value) {
        buffer[i] = value;
    }

    protected void writeShort(int p, int value) {
        ByteConverter.int2(buffer, p, value);
    }

    protected void writeByte(int p, byte v) {
        buffer[p] = v;
    }

    protected void writeFloat(int p, float v) {
        ByteConverter.float4(buffer, p, v);
    }

    protected void writeDouble(int p, double v) {
        ByteConverter.float8(buffer, p, v);
    }

    protected void writeInt(int i, int value) {
        ByteConverter.int4(buffer, i, value);
    }

    @Override
    public void writeBytes(byte[] i, int start, int len) {
        ensureCapacity(len);
        byte[] b = this.buffer;
        System.arraycopy(i, start, b, this.position, len);
        this.position += len;
    }

    protected void setPostion(int pos) {
        this.position = pos;
        if (this.position > this.capacity) {
            throw new OutOfMemoryError("pos out message capcity");
        }
    }

    private byte[] buffer;
    protected int position = 0;
    private int capacity;
}
