/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

import com.yashandb.YasConstants;

public class AckConnBuffer extends BaseBuffer {
    public AckConnBuffer() {
        super(YasConstants.ACK_CONN_PACKET_SIZE);
    }

    boolean getEndian() {
        byte b = getByte(position);
        position++;
        return (b == 1);
    }

    int getPacketSize() {
        return getInt(4);
    }
}
