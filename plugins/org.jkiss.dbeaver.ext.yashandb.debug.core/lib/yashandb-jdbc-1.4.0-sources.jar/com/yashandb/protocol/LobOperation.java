/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.protocol;

public enum LobOperation {
    LOB_GET_LEN(1),
    LOB_READ(2),
    LOB_TRIM(3),
    LOB_WRITE(4),
    LOB_TMP_CREATE(5),
    LOB_TMP_FREE(6),
    LOB_OPEN(7),
    LOB_CLOSE(8),
    LOB_ISOPEN(9),
    LOB_GET_CHUNK_SIZE(10);

    private final int value;

    LobOperation(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
