/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */
// Copyright (c) 2021, Open Cloud Limited.

package com.yashandb;

import com.yashandb.conf.HostSpec;
import com.yashandb.jdbc.ConnectVersion;
import com.yashandb.jdbc.DebugBreakpoint;
import com.yashandb.jdbc.DebugFrame;
import com.yashandb.jdbc.DebugVar;
import com.yashandb.jdbc.StatementImpl;
import com.yashandb.jdbc.TransactionState;
import com.yashandb.jdbc.YasBlob;
import com.yashandb.jdbc.YasClob;
import com.yashandb.jdbc.YasConnection;
import com.yashandb.jdbc.YasDebugCallableStatement;
import com.yashandb.jdbc.YasLargeObject;
import com.yashandb.jdbc.YasLobProcessor;
import com.yashandb.jdbc.YasStatement;
import com.yashandb.protocol.DebugOperation;
import com.yashandb.protocol.Packet;

import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Savepoint;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

public interface Session extends Cloneable {

    /**
     * Flag for query execution that indicates that a resultset isn't expected and the query executor
     * can safely discard any rows (although the resultset should still appear to be from a
     * resultset-returning query).
     */
    int QUERY_NO_RESULTS = 4;

    /**
     * Flag for query execution that indicates a forward-fetch-capable cursor should be used if
     * possible.
     */
    int QUERY_FORWARD_CURSOR = 8;

    /**
     * Flag for query execution that indicates the automatic BEGIN on the first statement when outside
     * a transaction should not be done.
     */
    int QUERY_SUPPRESS_BEGIN = 16;

    void connect() throws SQLException;

    void cancel() throws SQLException;

    YasResultSet directExecute(StatementImpl statement, String sql) throws SQLException;

    void setConnection(YasConnection connection);

    YasConnection getConnection();

    YasResultSet fetchCursor(StatementImpl statement) throws SQLException;

    YasResultSet fetchReturnResultSet(short cursorId) throws SQLException;

    long getLobLength(YasLobProcessor lobProcessor) throws SQLException;

    short getLobChunkSize(YasLobProcessor lobProcessor) throws SQLException;

    int getLobData(YasLobProcessor lobProcessor, int reqLen, long lobOffset, byte[] cacheData) throws SQLException;

    void prepare(StatementImpl query, String sql) throws SQLException;

    YasClob createClob() throws SQLException;

    YasBlob createBlob() throws SQLException;

    long writeLob(YasLobProcessor lobProcessor, long pos, byte[] bytes, int start, int length) throws SQLException;

    long writeLobByLobLocator(YasLobProcessor lobProcessor, long pos, byte[] locBytes) throws SQLException;

    void closeLob(YasLobProcessor lobProcessor) throws SQLException;

    void processInvalid();

    /**
     * Execute a Query, passing results to a provided ResultHandler.
     *
     * @param query      the query to execute; must be a query returned from calling {@link
     *                   #wrap(List)} on this QueryExecutor object.
     * @param parameters the parameters for the query. Must be non-<code>null</code> if the query
     *                   takes parameters. Must be a parameter object returned by {@link
     *                   Query#createParameterList()}.
     * @param maxRows    the maximum number of rows to retrieve
     * @param fetchSize  if QUERY_FORWARD_CURSOR is set, the preferred number of rows to retrieve
     *                   before suspending
     * @param flags      a combination of QUERY_* flags indicating how to handle the query.
     * @throws SQLException if query execution fails
     */
    YasResultSet execute(StatementImpl query, ParameterList[] parameters, int maxRows,
                         int fetchSize, int flags) throws SQLException;

    /**
     * Fetch additional rows from a cursor.
     *
     * @param query     the handler to feed results from
     * @param fetchSize the preferred number of rows to retrieve before suspending
     * @return server ack packet
     * @throws SQLException if query execution fails
     */
    Packet fetch(YasStatement query, int fetchSize) throws SQLException;

    Packet moreData() throws SQLException;

    /**
     * Commit a transaction
     *
     * @throws SQLException if commit failes
     */
    void commit() throws SQLException;

    Packet continueExecute() throws SQLException;

    /**
     * Rollback a transcation
     *
     * @throws SQLException if rollback failes
     */
    void rollback() throws SQLException;

    /**
     * @return the host and port this connection is connected to.
     */
    HostSpec getHostSpec();

    /**
     * @return the user this connection authenticated as.
     */
    String getUser();

    void setSchema(String schema) throws SQLException;

    String getSchema() throws SQLException;

    /**
     * @return the database this connection is connected to.
     */
    String getDatabase();

    /**
     * Abort at network level without sending the Terminate message to the backend.
     */
    void abort(Executor executor);

    /**
     * Close this connection cleanly.
     */
    void close();

    /**
     * Check if this connection is closed.
     *
     * @return true iff the connection is closed.
     */
    boolean isClosed();

    /**
     * Retrieve and clear the chain of warnings accumulated on this connection.
     *
     * @return the first SQLWarning in the chain; subsequent warnings can be found via
     * SQLWarning.getNextWarning().
     */
    SQLWarning getWarnings();

    /**
     * Get the current transaction state of this connection.
     *
     * @return a ProtocolConnection.TRANSACTION_* constant.
     */
    TransactionState getTransactionState();

    boolean getStandardConformingStrings();

    void setNetworkTimeout(int milliseconds) throws IOException;

    int getNetworkTimeout() throws IOException;

    Map<String, String> getParameterStatuses();

    String getParameterStatus(String parameterName);

    int getSID();

    void setSID(int sid);

    void setCharset(short charset);

    short getCharset();

    void setSessionKey(int key);

    int getSessionKey();

    void setTransactionState(TransactionState value);

    void setTransactionIsolation(int level) throws SQLException;

    void closeStmt(int stmtID) throws SQLException;

    void addWarning(SQLWarning warning);

    Savepoint setSavepoint() throws SQLException;

    Savepoint setSavepoint(String name) throws SQLException;

    void rollback(Savepoint savepoint) throws SQLException;

    boolean isUserCaseSensitive();

    ConnectVersion getConnectVersion();

    void setConnectVersion(ConnectVersion clientVersion);

    long trimLob(YasLobProcessor lobProcessor, long len) throws SQLException;

    void addUpdatedKnlLob(YasLargeObject yasLargeObject);

    void removeUpdatedKnlLob(YasLargeObject yasLargeObject);

    YasClob preProcessReaderBinding(Reader reader, char[] readBuf, long length) throws SQLException;

    YasResultSet pdbgExecute(YasDebugCallableStatement statement, ParameterList[] parameters) throws SQLException;

    void pdbgAbort(YasDebugCallableStatement statement) throws SQLException;

    void pdbgAddBreakpoint(YasDebugCallableStatement statement, List<DebugBreakpoint> debugBreakpointList)
            throws SQLException;

    void pdbgDeleteBreakpoint(YasDebugCallableStatement statement, List<DebugBreakpoint> debugBreakpointList)
            throws SQLException;

    void pdbgCheckVersion(YasDebugCallableStatement statement, long objectId, int subprogramId, int version)
            throws SQLException;

    YasResultSet pdbgStepDebug(YasDebugCallableStatement statement, DebugOperation dbgStepInto) throws SQLException;

    List<DebugVar> pdbgShowVars(YasDebugCallableStatement statement) throws SQLException;

    List<DebugFrame> pdbgShowFrames(YasDebugCallableStatement statement) throws SQLException;

    void abortDebug() throws SQLException;
}
