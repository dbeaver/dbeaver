/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb;

import java.sql.SQLException;

public class ConnectionManager {

    private static ConnectionMonitor connectionMonitor = new ConnectionMonitor();

    public void register(SessionImpl session) throws SQLException {
        connectionMonitor.register(session);
    }

    public void unRegister(SessionImpl session) {
        connectionMonitor.unRegister(session);
    }
}
