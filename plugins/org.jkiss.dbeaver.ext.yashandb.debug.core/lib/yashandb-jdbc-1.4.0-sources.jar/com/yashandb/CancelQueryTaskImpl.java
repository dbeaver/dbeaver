/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb;

import java.sql.SQLException;
import java.util.TimerTask;

public class CancelQueryTaskImpl extends TimerTask implements CancelQueryTask {

    Query queryToCancel;
    Throwable caughtWhileCancelling = null;

    public CancelQueryTaskImpl(Query cancellee) {
        this.queryToCancel = cancellee;
    }

    @Override
    public Throwable getCaughtWhileCancelling() {
        return this.caughtWhileCancelling;
    }

    @Override
    public void setCaughtWhileCancelling(Throwable caughtWhileCancelling) {
        this.caughtWhileCancelling = caughtWhileCancelling;
    }

    @Override
    public Query getQueryToCancel() {
        return this.queryToCancel;
    }

    @Override
    public void setQueryToCancel(Query queryToCancel) {
        this.queryToCancel = queryToCancel;
    }

    @Override
    public void run() {
        Query localQueryToCancel = CancelQueryTaskImpl.this.queryToCancel;
        if (localQueryToCancel == null) {
            return;
        }
        try {
            localQueryToCancel.cancel();
        } catch (SQLException t) {
            CancelQueryTaskImpl.this.caughtWhileCancelling = t;
        } finally {
            setQueryToCancel(null);
        }
    }
}
