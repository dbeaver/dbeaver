/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.core;

public enum SqlKind {
    SELECT(false, false, true, false, (byte)1),
    INSERT(false, true, false, false, (byte)2),
    UPDATE(false, true, false, false, (byte)3),
    DELETE(false, true, false, false, (byte)4),
    MERGE(false, true, false, false, (byte)5),
    PLSQL_BLOCK(true, false, false, false, (byte)7),
    CALL_BLOCK(true, false, false, false, (byte)7),
    OTHER(false, false, false, true, (byte)-128),
    UNINITIALIZED(false, false, false, false, (byte)0);

    private final boolean dml;
    private final boolean plsqlOrCall;
    private final boolean select;
    private final boolean other;
    private final byte kind;

    SqlKind(boolean plsql, boolean dml, boolean select, boolean other, byte kind) {
        this.dml = dml;
        this.plsqlOrCall = plsql;
        this.select = select;
        this.other = other;
        this.kind = kind;
    }

    public static SqlKind valueOf(byte kind) {
        switch (kind) {
            case 1:
                return SELECT;
            case 2:
                return INSERT;
            case 3:
                return UPDATE;
            case 4:
                return DELETE;
            case 5:
                return MERGE;
            case 7:
                return PLSQL_BLOCK;
            case 0:
                return UNINITIALIZED;
            default:
                return OTHER;
        }
    }

    public boolean isPlsqlOrCall() {
        return this.plsqlOrCall;
    }

    public boolean isDML() {
        return this.dml;
    }

    public boolean isSELECT() {
        return this.select;
    }

    public boolean isOTHER() {
        return this.other;
    }

    public byte getKind() {
        return this.kind;
    }
}
