/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb;

import com.yashandb.conf.HostSpec;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/*
 * DownHostsCache will manage multiple hosts in the connection url.
 * When one host can't connect DB(timeout),DownHostsCache will mark the host and
 * cache the host in it's  downHostsCacheMap .Then in follow connection request,
 * it will set the host with low priority.
 */
public class DownHostsCache {
    static DownHostsCache downHostsCache;
    int refreshCacheTime = Integer.MAX_VALUE;          // Unit: second ,Time to refresh the cache
    int refreshInterval = 120;                         // default refresh interval is 2 min
    LocalDateTime lastRefreshTime = LocalDateTime.now();   // Log the lastRefreshTime
    Map<HostSpec, LocalDateTime> downHostsCacheMap = new ConcurrentHashMap<HostSpec,LocalDateTime>();

    public static DownHostsCache getInstance() {
        if (downHostsCache == null) {
            downHostsCache = new DownHostsCache();
        }
        return downHostsCache;
    }

    //Make it a singleton
    private DownHostsCache() {

    }

    /*
     * Check the host whether in DownHostCache
     */
    public boolean isDownHost(HostSpec hostSpec) {
        return downHostsCacheMap.containsKey(hostSpec);
    }

    /*
     * Make the Down Host
     */
    public void markDownHost(HostSpec hostSpec) {
        if (!downHostsCacheMap.containsKey(hostSpec)) {
            downHostsCacheMap.put(hostSpec,LocalDateTime.now());
        }
    }

    /*
        Refresh DownHostsCache
     */
    void refreshCache() {
        if (refreshCacheTime < Integer.MAX_VALUE
                && LocalDateTime.now().minus(refreshInterval,ChronoUnit.SECONDS).isAfter(lastRefreshTime)) {
            for (HostSpec hostSpec : downHostsCacheMap.keySet()) {
                if (LocalDateTime.now().minus(refreshCacheTime, ChronoUnit.SECONDS)
                        .compareTo(downHostsCacheMap.get(hostSpec)) > 0) {
                    downHostsCacheMap.remove(hostSpec);
                }
            }
            lastRefreshTime = LocalDateTime.now();
        }
    }

    /*
        Reorder the Hosts to set the down host with low priority
     */
    public void reorderHosts(HostSpec[] hostSpecs) {
        if (downHostsCacheMap.isEmpty()) {
            return;
        }

        refreshCache();

        int left = 0;
        int right = hostSpecs.length - 1;
        while (left < right) {
            while (left <= right && !isDownHost(hostSpecs[left])) {
                left++;
            }

            while (left <= right && isDownHost(hostSpecs[right])) {
                right--;
            }

            // Swap the host
            if (left < right) {
                HostSpec tempHS = hostSpecs[left];
                hostSpecs[left] = hostSpecs[right];
                hostSpecs[right] = tempHS;
            }
        }
    }

    public int getRefreshCacheTime() {
        return refreshCacheTime;
    }

    public void setRefreshCacheTime(int refreshCacheTime) {
        this.refreshCacheTime = refreshCacheTime;
    }

    public int getRefreshInterval() {
        return refreshInterval;
    }

    public void setRefreshInterval(int refreshInterval) {
        this.refreshInterval = refreshInterval;
    }
}