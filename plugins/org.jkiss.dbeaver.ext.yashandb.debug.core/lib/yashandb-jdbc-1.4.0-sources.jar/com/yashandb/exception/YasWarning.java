/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.exception;

import com.yashandb.jdbc.exception.ServerErrorMessage;

import java.sql.SQLWarning;

public class YasWarning extends SQLWarning {

    private ServerErrorMessage serverError;

    public YasWarning(ServerErrorMessage err) {
        super(err.toString(), err.getSQLState());
        this.serverError = err;
    }

    public String getMessage() {
        return serverError.getMessage();
    }

    public ServerErrorMessage getServerErrorMessage() {
        return serverError;
    }
}
