/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.exception;

import java.sql.SQLWarning;

public class DatabaseError {

    private final SQLWarning firstWarning;
    private SQLWarning lastWarning;

    public DatabaseError(SQLWarning warning) {
        firstWarning = warning;
        lastWarning = warning;
    }

    public void addWarning(SQLWarning sqlWarning) {
        lastWarning.setNextWarning(sqlWarning);
        lastWarning = sqlWarning;
    }

    public SQLWarning getFirstWarning() {
        return firstWarning;
    }

}
