/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.exception;

public class YasRuntimeException extends RuntimeException {
    public YasRuntimeException() {
        super();
    }

    public YasRuntimeException(String message) {
        super(message);
    }
}
