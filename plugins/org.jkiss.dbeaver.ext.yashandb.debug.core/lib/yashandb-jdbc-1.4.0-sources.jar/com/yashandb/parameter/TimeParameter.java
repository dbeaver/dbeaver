/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.InternalTimeStamp;
import com.yashandb.protocol.Packet;
import com.yashandb.util.YasTime;

import java.sql.Time;
import java.util.Calendar;

public class TimeParameter extends YasParameter {

    private static final int TIME_PARAM_LEN = 9;

    public TimeParameter() {
        super();
        this.type = DataType.SHORTTIME;
    }

    @Override
    protected int processWrite(Packet packet) {
        packet.writeByte((byte)8);
        long intervalFromBase = ((long) value);
        packet.writeLong(intervalFromBase);
        return 8;
    }

    @Override
    public void setValue(Object obj) {
        if (obj == null) {
            this.value = ParameterFactory.getNullObject();
            return;
        }

        if (obj == ParameterFactory.getNullObject()) {
            this.value = obj;
            return;
        }

        long timeInterval = ((Time) obj).getTime();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(timeInterval);

        InternalTimeStamp internalTimeStamp = new InternalTimeStamp();
        internalTimeStamp.hour = calendar.get(Calendar.HOUR_OF_DAY);
        internalTimeStamp.minute = calendar.get(Calendar.MINUTE);
        internalTimeStamp.second = calendar.get(Calendar.SECOND);
        internalTimeStamp.fraction = calendar.get(Calendar.MILLISECOND) * 1000;
        
        if (obj instanceof YasTime) {
            internalTimeStamp.fraction = ((YasTime) obj).getNanos() / 1000;
        }

        this.value = InternalTimeStamp.transTimeToValue(internalTimeStamp);
    }

    @Override
    protected int getParamLength() {
        return TIME_PARAM_LEN;
    }
}
