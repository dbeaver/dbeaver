/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.Packet;

public class FloatParameter extends YasParameter {

    private static final int FLOAT_PARAM_LEN = 5;

    public FloatParameter() {
        super();
        this.type = DataType.FLOAT;
    }

    @Override
    public int processWrite(Packet packet) {
        packet.writeByte((byte) 4);
        packet.writeFloat((Float) value);
        return 4;
    }

    @Override
    public int getParamLength() {
        return FLOAT_PARAM_LEN;
    }
}
