/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.Packet;

public class BitParameter extends YasParameter {

    public BitParameter() {
        super();
        this.type = DataType.BIT;
    }

    @Override
    public int processWrite(Packet packet) {
        byte[] bits = (byte[]) value;
        packet.writeByte((byte)bits.length);
        packet.writeBytes(bits);
        return bits.length;
    }

    @Override
    public int getParamLength() {
        byte[] bits = (byte[]) value;
        return bits.length + 1;
    }
}
