/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.Packet;

public class BigIntParameter extends YasParameter {

    private static final int BIGINT_PARAM_LEN = 9;

    public BigIntParameter() {
        super();
        this.type = DataType.BIGINT;
    }

    @Override
    public int processWrite(Packet packet) {
        packet.writeByte((byte)8);
        packet.writeLong(((Long) value));
        return 8;
    }

    @Override
    public int getParamLength() {
        return BIGINT_PARAM_LEN;
    }
}
