/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.jdbc.YasClob;
import com.yashandb.protocol.Packet;

public class ClobParameter extends YasParameter {

    public ClobParameter() {
        super();
        this.type = DataType.CLOB;
    }

    private YasClob getClob() {
        return (YasClob) this.value;
    }

    @Override
    public void setValue(Object obj) {
        if ((obj == null) || (obj == ParameterFactory.getNullObject())) {
            this.value = ParameterFactory.getNullObject();
            return;
        }

        this.value = obj;
    }

    @Override
    protected int processWrite(Packet packet) {
        byte[] locator = getClob().getLobLocator();
        packet.writeByte((byte)locator.length);
        packet.writeBytes(getClob().getLobLocator());
        return locator.length;
    }

    @Override
    protected int getParamLength() {
        return getClob().getLobLocator().length + 1;
    }
}
