/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.SQLException;

public class ParameterLittleEndianFactory extends ParameterFactory {

    public YasParameter getParameter(int type) throws SQLException {

        YasParameter parameter;
        switch (type) {
            case DataType.BOOLEAN: {
                parameter = new BooleanParameter();
                break;
            }
            case DataType.BIT: {
                parameter = new BitParameter();
                break;
            }
            case DataType.TINYINT: {
                parameter = new TinyIntParameter();
                break;
            }
            case DataType.SMALLINT: {
                parameter = new SmallIntParameter();
                break;
            }
            case DataType.INTEGER: {
                parameter = new IntegerParameter();
                break;
            }
            case DataType.BIGINT: {
                parameter = new BigIntParameter();
                break;
            }
            case DataType.CHAR:
            case DataType.VARCHAR:
            case DataType.JSON:
            case DataType.UNKNOWN: {
                parameter = new VarcharParameter();
                break;
            }
            case DataType.DOUBLE: {
                parameter = new DoubleParameter();
                break;
            }
            case DataType.FLOAT: {
                parameter = new FloatParameter();
                break;
            }
            case DataType.NUMBER: {
                parameter = new NumberParameter();
                break;
            }
            case DataType.DATE: {
                parameter = new DateParameter();
                break;
            }
            case DataType.TIMESTAMP: {
                parameter = new TimeStampParameter();
                break;
            }
            case DataType.SHORTTIME: {
                parameter = new TimeParameter();
                break;
            }
            case DataType.DS_INTERVAL: {
                parameter = new DsIntervalParameter();
                break;
            }
            case DataType.YM_INTERVAL: {
                parameter = new YmIntervalParameter();
                break;
            }
            case DataType.ROWID: {
                parameter = new RowIdParameter();
                break;
            }
            case DataType.RAW: {
                parameter = new RawParameter();
                break;
            }
            case DataType.CURSOR: {
                parameter = new SmallIntParameter();
                break;
            }
            case DataType.CLOB: {
                parameter = new ClobParameter();
                break;
            }
            case DataType.BLOB: {
                parameter = new BlobParameter();
                break;
            }
            default: {
                throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                        " Bind Type " + DataType.getTypeName(type));
            }
        }

        return parameter;
    }
}
