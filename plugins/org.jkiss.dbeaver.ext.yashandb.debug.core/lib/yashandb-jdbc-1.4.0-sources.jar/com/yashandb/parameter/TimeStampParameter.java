/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.InternalTimeStamp;
import com.yashandb.protocol.Packet;

import java.sql.Timestamp;
import java.util.Calendar;

public class TimeStampParameter extends YasParameter {

    private static final int TIMESTAMP_PARAM_LEN = 12;

    public TimeStampParameter() {
        super();
        this.type = DataType.TIMESTAMP;
    }

    @Override
    protected int processWrite(Packet packet) {
        packet.writeByte((byte)TIMESTAMP_PARAM_LEN);
        long intervalFromBase = ((long) value);
        packet.writeLong(intervalFromBase);
        packet.writeShort(0);
        packet.writeShort(0);
        return TIMESTAMP_PARAM_LEN;
    }

    @Override
    public void setValue(Object obj) {
        if (obj == null) {
            this.value = ParameterFactory.getNullObject();
            return;
        }

        if (obj == ParameterFactory.getNullObject()) {
            this.value = obj;
            return;
        }

        long timeInterval = ((Timestamp) obj).getTime();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(timeInterval);

        InternalTimeStamp internalTimeStamp = new InternalTimeStamp();
        internalTimeStamp.year = calendar.get(Calendar.YEAR);
        internalTimeStamp.month = calendar.get(Calendar.MONTH) + 1;
        internalTimeStamp.date = calendar.get(Calendar.DATE);
        internalTimeStamp.hour = calendar.get(Calendar.HOUR_OF_DAY);
        internalTimeStamp.minute = calendar.get(Calendar.MINUTE);
        internalTimeStamp.second = calendar.get(Calendar.SECOND);
        internalTimeStamp.fraction = calendar.get(Calendar.MILLISECOND) * 1000 ;

        internalTimeStamp.fraction = ((Timestamp) obj).getNanos() / 1000;

        this.value = InternalTimeStamp.transTimeStampToValue(internalTimeStamp);
    }

    @Override
    protected int getParamLength() {
        return TIMESTAMP_PARAM_LEN + 1;
    }
}
