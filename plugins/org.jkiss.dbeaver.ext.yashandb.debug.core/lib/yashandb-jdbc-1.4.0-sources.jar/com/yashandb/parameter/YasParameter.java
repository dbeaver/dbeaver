/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.Packet;

import java.sql.SQLException;

public abstract class YasParameter implements Cloneable {

    protected static final byte IN = 1;
    protected static final byte OUT = 2;
    protected static final byte INOUT = IN | OUT;

    protected byte direction = 0;
    protected int type = DataType.UNKNOWN;
    protected Object value = ParameterFactory.getNullObject();

    protected short charset = 0;

    public YasParameter() {

    }

    @Override
    public YasParameter clone() throws CloneNotSupportedException {
        return (YasParameter) super.clone();
    }

    protected abstract int processWrite(Packet packet) throws SQLException;

    /**
     * Returns value len + 1; if the len > 253, returns value len + 3
     */
    protected abstract int getParamLength() throws SQLException;

    public int getLength() throws SQLException {
        if (isValueNull()) {
            return 1;
        }
        return getParamLength();
    }

    public void setCharset(short charset) {
        this.charset = charset;
    }

    public int writeValue(Packet packet) throws SQLException {
        if (this.direction == OUT) {
            return 0;
        }

        if (isValueNull()) {
            packet.writeByte((byte)Packet.COLHEAD_NULL);
            return 1;
        }
        return processWrite(packet);
    }

    public boolean isValueNull() {
        return (value == ParameterFactory.getNullObject());
    }

    public void writeInfo(Packet packet) {
        packet.writeByte((byte) type);
        packet.writeByte(direction);
    }

    public void setValue(Object obj) {
        this.value = obj;
    }

    public Object getValue() {
        return this.value;
    }

    public void setType(int yashanDataType) {
        this.type = yashanDataType;
    }

    public void setOutDirection() {
        this.direction |= OUT;
    }

    public void setInDirection() {
        this.direction |= IN;
    }

    public boolean isOutParameter() {
        return (this.direction == OUT);
    }

    public int getType() {
        return this.type;
    }
}
