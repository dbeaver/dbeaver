/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.Packet;

public class IntegerParameter extends YasParameter {

    private static final int INTEGER_PARAM_LEN = 5;

    public IntegerParameter() {
        super();
        this.type = DataType.INTEGER;
    }

    @Override
    public int processWrite(Packet packet) {
        packet.writeByte((byte) 4);
        packet.writeInt(((Integer) value));
        return 4;
    }

    @Override
    public int getParamLength() {
        return INTEGER_PARAM_LEN;
    }
}
