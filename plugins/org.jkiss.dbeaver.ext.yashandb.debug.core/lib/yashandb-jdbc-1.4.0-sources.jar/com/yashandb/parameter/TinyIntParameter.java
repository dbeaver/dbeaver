/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.Packet;

public class TinyIntParameter extends YasParameter {

    private static final int TINY_INT_PARAM_LEN = 2;

    public TinyIntParameter() {
        super();
        this.type = DataType.TINYINT;
    }

    @Override
    public int processWrite(Packet packet) {
        packet.writeByte((byte) 1);
        packet.writeByte(((Integer)value).byteValue());
        return 1;
    }

    @Override
    public int getParamLength() {
        return TINY_INT_PARAM_LEN;
    }

}
