/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;

public class DsIntervalParameter extends BigIntParameter {

    public DsIntervalParameter() {
        super();
        this.type = DataType.DS_INTERVAL;
    }
}
