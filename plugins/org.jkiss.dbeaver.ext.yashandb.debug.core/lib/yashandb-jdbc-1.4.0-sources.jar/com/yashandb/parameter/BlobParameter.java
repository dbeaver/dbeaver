/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.jdbc.YasBlob;
import com.yashandb.protocol.Packet;

public class BlobParameter extends YasParameter {

    public BlobParameter() {
        super();
        this.type = DataType.BLOB;
    }

    private YasBlob getBlob() {
        return (YasBlob) this.value;
    }

    @Override
    public void setValue(Object obj) {
        if ((obj == null) || (obj == ParameterFactory.getNullObject())) {
            this.value = ParameterFactory.getNullObject();
            return;
        }

        this.value = obj;
    }

    @Override
    protected int processWrite(Packet packet) {
        byte[] locator = getBlob().getLobProcessor().getLobLocator();
        packet.writeByte((byte) locator.length);
        packet.writeBytes(locator);
        return locator.length;
    }

    @Override
    protected int getParamLength() {
        return getBlob().getLobProcessor().getLobLocator().length + 1;
    }
}
