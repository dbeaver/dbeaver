/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.YasConstants;
import com.yashandb.core.DataType;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.protocol.Packet;
import com.yashandb.util.StreamWrapper;

import java.io.IOException;
import java.sql.SQLException;

public class RawParameter extends YasParameter {

    public RawParameter() {
        super();
        this.type = DataType.RAW;
    }

    private byte[] rawByteBuffer = null;

    private byte[] getByteBuffer() {
        if (rawByteBuffer != null) {
            return rawByteBuffer;
        }

        rawByteBuffer = new byte[YasConstants.LONG_BIND_SIZE];
        return rawByteBuffer;
    }

    @Override
    public int processWrite(Packet packet) throws SQLException {
        StreamWrapper streamWrapper = (StreamWrapper) value;

        byte[] bytes = streamWrapper.getBytes();
        int byteOffset = streamWrapper.getOffset();
        int dataLen = streamWrapper.getLength();
        dataLen = Math.min(dataLen, YasConstants.LONG_BIND_SIZE);

        if (bytes == null) {
            bytes = getByteBuffer();
            byteOffset = 0;
            try {
                dataLen = streamWrapper.getStream().read(bytes, 0, dataLen);
                if (dataLen <= 0) {
                    packet.writeByte((byte)Packet.COLHEAD_NULL);
                    return 1;
                }
            } catch (IOException ioException) {
                throw SQLError.createSQLException(ioException.getMessage(), YasState.DATA_ERROR);
            }
        }

        if (bytes.length == 0) {
            packet.writeByte((byte)Packet.COLHEAD_NULL);
            return 1;
        }

        if (dataLen < Packet.COLHEAD_LONG) {
            packet.writeByte((byte)dataLen);
        } else {
            packet.writeByte((byte) Packet.COLHEAD_LONG);
            packet.writeShort((short) dataLen);
        }
        packet.writeBytes(bytes, byteOffset, dataLen);
        return dataLen;
    }

    @Override
    public int getParamLength() {
        StreamWrapper streamWrapper = (StreamWrapper) value;
        int dataLen = streamWrapper.getLength();

        if (dataLen < Packet.COLHEAD_LONG) {
            return dataLen + 1;
        } else {
            return dataLen + 3;
        }
    }
}
