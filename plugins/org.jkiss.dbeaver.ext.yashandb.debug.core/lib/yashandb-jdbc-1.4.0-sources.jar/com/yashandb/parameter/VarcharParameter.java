/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.Packet;
import com.yashandb.util.CharacterSet;

public class VarcharParameter extends YasParameter {

    public VarcharParameter() {
        super();
        this.type = DataType.VARCHAR;
    }

    @Override
    public int processWrite(Packet packet) {
        String str = (String) value;
        byte[] convBytes = str.getBytes(CharacterSet.getCharSet(this.charset));
        int slen = convBytes.length;
        if (slen < Packet.COLHEAD_LONG) {
            packet.writeByte((byte)slen);
        } else {
            packet.writeByte((byte) Packet.COLHEAD_LONG);
            packet.writeShort((short) slen);
        }
        packet.writeBytes(convBytes);
        return slen;
    }

    @Override
    public int getParamLength() {
        String str = (String) value;
        int slen = str.getBytes(CharacterSet.getCharSet(this.charset)).length;
        if (slen < Packet.COLHEAD_LONG) {
            return slen + 1;
        } else {
            return slen + 3;
        }
    }
}
