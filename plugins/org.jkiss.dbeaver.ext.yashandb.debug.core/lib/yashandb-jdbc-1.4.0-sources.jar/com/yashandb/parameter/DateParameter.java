/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.InternalTimeStamp;
import com.yashandb.protocol.Packet;

import java.sql.Date;
import java.util.Calendar;

public class DateParameter extends YasParameter {

    private static final int DATE_PARAM_LEN = 9;

    public DateParameter() {
        super();
        this.type = DataType.DATE;
    }

    @Override
    protected int processWrite(Packet packet) {
        packet.writeByte((byte)8);
        long intervalFromBase = ((long) value);
        packet.writeLong(intervalFromBase);
        return 8;
    }

    @Override
    protected int getParamLength() {
        return DATE_PARAM_LEN;
    }

    @Override
    public void setValue(Object obj) {
        if (obj == null) {
            this.value = ParameterFactory.getNullObject();
            return;
        }

        if (obj == ParameterFactory.getNullObject()) {
            this.value = obj;
            return;
        }

        long timeInterval = ((Date) obj).getTime();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(timeInterval);

        InternalTimeStamp internalTimeStamp = new InternalTimeStamp();
        internalTimeStamp.year = calendar.get(Calendar.YEAR);
        internalTimeStamp.month = calendar.get(Calendar.MONTH) + 1;
        internalTimeStamp.date = calendar.get(Calendar.DATE);
        internalTimeStamp.hour = calendar.get(Calendar.HOUR_OF_DAY);
        internalTimeStamp.minute = calendar.get(Calendar.MINUTE);
        internalTimeStamp.second = calendar.get(Calendar.SECOND);
        internalTimeStamp.fraction = calendar.get(Calendar.MILLISECOND) * 1000;

        this.value = InternalTimeStamp.transTimeStampToValue(internalTimeStamp);
    }
}
