/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import java.sql.SQLException;

public abstract class ParameterFactory {

    /**
     * Marker object representing NULL; this distinguishes "parameter never set" from "parameter set
     * to null".
     */
    private static final Object NULL_OBJECT = new Object();

    public static Object getNullObject() {
        return NULL_OBJECT;
    }

    public abstract YasParameter getParameter(int type) throws SQLException;
}
