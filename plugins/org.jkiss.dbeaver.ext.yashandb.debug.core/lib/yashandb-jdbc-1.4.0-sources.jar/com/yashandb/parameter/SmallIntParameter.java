/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.Packet;

public class SmallIntParameter extends YasParameter {

    private static final int SMALL_INT_PARAM_LEN = 3;

    public SmallIntParameter() {
        super();
        this.type = DataType.SMALLINT;
    }

    @Override
    public int processWrite(Packet packet) {
        packet.writeByte((byte)2);
        packet.writeShort(((Integer) value).shortValue());
        return 2;
    }

    @Override
    public int getParamLength() {
        return SMALL_INT_PARAM_LEN;
    }
}
