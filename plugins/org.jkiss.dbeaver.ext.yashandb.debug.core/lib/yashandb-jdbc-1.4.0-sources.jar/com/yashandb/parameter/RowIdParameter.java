/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.jdbc.YasRowID;
import com.yashandb.protocol.Packet;

public class RowIdParameter extends YasParameter {

    private static final int ROW_ID_LEN = 16;

    public RowIdParameter() {
        super();
        this.type = DataType.ROWID;
    }

    @Override
    protected int processWrite(Packet packet) {
        YasRowID rowID = (YasRowID) value;
        byte[] bytes = rowID.getRowIdBytes();

        packet.writeByte((byte)ROW_ID_LEN);
        packet.writeBytes(bytes);
        return ROW_ID_LEN;
    }

    @Override
    protected int getParamLength() {
        return ROW_ID_LEN + 1;
    }
}
