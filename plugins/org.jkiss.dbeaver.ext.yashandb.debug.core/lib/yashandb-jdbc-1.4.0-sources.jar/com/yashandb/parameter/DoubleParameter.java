/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;
import com.yashandb.protocol.Packet;

public class DoubleParameter extends YasParameter {

    private static final int DOUBLE_PARAM_LEN = 9;

    public DoubleParameter() {
        super();
        this.type = DataType.DOUBLE;
    }

    @Override
    public int processWrite(Packet packet) {
        packet.writeByte((byte) 8);
        packet.writeDouble((Double)value);
        return 8;
    }

    @Override
    public int getParamLength() {
        return DOUBLE_PARAM_LEN;
    }
}
