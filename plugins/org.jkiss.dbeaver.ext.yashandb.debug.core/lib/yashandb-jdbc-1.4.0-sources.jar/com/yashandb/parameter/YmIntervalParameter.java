/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.parameter;

import com.yashandb.core.DataType;

public class YmIntervalParameter extends IntegerParameter {
    public YmIntervalParameter() {
        super();
        this.type = DataType.YM_INTERVAL;
    }
}
