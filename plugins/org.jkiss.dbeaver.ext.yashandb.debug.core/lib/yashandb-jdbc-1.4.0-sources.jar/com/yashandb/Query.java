/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */
// Copyright (c) 2021, Open Cloud Limited.

package com.yashandb;

import com.yashandb.jdbc.Field;

import java.sql.SQLException;
import java.util.Map;

/**
 * <p>Abstraction of a generic Query, hiding the details of any protocol-version-specific data
 * needed to execute the query efficiently.</p>
 *
 * <p>Query objects should be explicitly closed when no longer needed; if resources are allocated
 * on the server for this query, their cleanup is triggered by closing the Query.</p>
 */
public interface Query {

    /**
     * Return a statement ID assigned by the server
     *
     * @return statement id
     */
    int getID();

    Session getSession();

    /**
     * <p>Close this query and free any server-side resources associated with it. The resources may
     * not be immediately deallocated, but closing a Query may make the deallocation more prompt.</p>
     *
     * <p>A closed Query should not be executed.</p>
     */
    void closeQuery();

    boolean isStatementDescribed();

    boolean isEmpty();

    /**
     * Get a map that a result set can use to find the index associated to a name.
     *
     * @return null if the query implementation does not support this method.
     */
    Map<String, Integer> getResultSetColumnNameIndexMap();

    /**
     * Return a list of the Query objects that make up this query. If this object is already a
     * SimpleQuery, returns null (avoids an extra array construction in the common case).
     *
     * @return an array of single-statement queries, or <code>null</code> if this object is already a
     * single-statement query.
     */
    Query[] getSubqueries();

    /**
     * To cancel a query, client need to send a cancel message to the server through a new connection
     */
    void cancel() throws SQLException;

    void setParameters(Field[] parameterFields) throws SQLException;
}
