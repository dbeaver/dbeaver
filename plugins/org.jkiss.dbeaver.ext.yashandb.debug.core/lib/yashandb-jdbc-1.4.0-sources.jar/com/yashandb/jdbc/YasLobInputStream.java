/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

public class YasLobInputStream extends InputStream {

    private YasLargeObject largeObject = null;

    private int cachePos = 0;

    private int cacheLen = 0;

    private long steamLobRemainSize = 0L;

    private long lobOffset = 0L;

    private byte[] cacheData = null;

    private boolean isClosed = false;

    public YasLobInputStream(YasLargeObject largeObject) throws SQLException {
        this.largeObject = largeObject;
        cachePos = 0;

        int stepSize = largeObject.getStepSize();
        if (stepSize > 0) {
            cacheData = new byte[stepSize];
        } else {
            int length = (int)largeObject.getLobLength();
            cacheData = new byte[length];
        }
        cacheLen = largeObject.getBytes(0, cacheData);
        steamLobRemainSize = largeObject.getLobLength();
    }

    public YasLobInputStream(YasLargeObject largeObject, long pos, long length) throws SQLException {
        if ((pos < 1) || (length < 0)) {
            throw SQLError.createSQLException("invalid parameter", YasState.INVALID_PARAMETER_VALUE);
        }

        long start = pos - 1;
        long lobLength = largeObject.getLobLength();
        if ((length == 0) || (lobLength == 0) || (start >= lobLength)) {
            return;
        }

        this.largeObject = largeObject;
        long byteLen = Math.min(length, lobLength);
        if (start + byteLen > lobLength) {
            byteLen = lobLength - start;
        }

        cachePos = 0;
        steamLobRemainSize = byteLen;

        int stepSize = largeObject.getStepSize();
        if (stepSize > 0) {
            cacheData = new byte[stepSize];
        } else {
            int dataLen = (int)largeObject.getLobLength();
            cacheData = new byte[dataLen];
        }
        lobOffset = start;
        cacheLen = largeObject.getBytes(start, cacheData);
    }

    private void ensureOpen() throws IOException {
        if (isClosed) {
            throw new IOException("stream closed");
        }
    }

    @Override
    public int read() throws IOException {
        ensureOpen();
        if (steamLobRemainSize <= 0) {
            return -1;
        }

        int value = (cacheData[cachePos++] & 0xFF);
        steamLobRemainSize--;

        if (cachePos >= cacheLen) {
            lobOffset += cacheLen;
            try {
                cacheLen = this.largeObject.getBytes(lobOffset, cacheData);
                cachePos = 0;
            } catch (SQLException sqlException) {
                throw new IOException(sqlException.getMessage());
            }
        }

        return value;
    }

    @Override
    public int available() throws IOException {
        ensureOpen();
        if (cacheLen > 0) {
            return cacheLen - cachePos;
        }

        return 0;
    }

    @Override
    public void close() throws IOException {
        if (isClosed) {
            return;
        }

        super.close();
        isClosed = true;
    }
}
