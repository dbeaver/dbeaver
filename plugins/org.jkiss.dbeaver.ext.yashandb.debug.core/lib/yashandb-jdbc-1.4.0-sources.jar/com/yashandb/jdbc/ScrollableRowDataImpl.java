/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.SessionImpl;
import com.yashandb.protocol.ExecuteResult;
import com.yashandb.protocol.Packet;

import java.sql.SQLException;

public class ScrollableRowDataImpl extends RowDataImpl implements RowData {

    public ScrollableRowDataImpl(SessionImpl session, YasStatement stmt, Packet ack, ExecuteResult result) {
        super( session,  stmt,  ack,  result);
    }

    @Override
    public void afterLast() throws SQLException {
        while (this.hasMore) {
            fetchMoreWithoutClear();
        }
        if (this.rows.size() > 0) {
            this.currRows = this.rows.size();
        }
    }

    @Override
    public void beforeFirst() throws SQLException {
        if (this.rows.size() > 0) {
            this.currRows = -1;
        }
    }

    @Override
    public void beforeLast() throws SQLException {
        while (this.hasMore) {
            fetchMoreWithoutClear();
        }
        if (this.rows.size() > 0) {
            this.currRows = this.rows.size() - 2;
        }
    }

    @Override
    public boolean isAfterLast() throws SQLException {
        if (this.hasMore) {
            return false;
        } else {
            return this.currRows >= this.rows.size() && this.rows.size() != 0;
        }
    }

    @Override
    public boolean isBeforeFirst() throws SQLException {
        return this.currRows == -1 && this.rows.size() != 0;
    }

    @Override
    public boolean isFirst() throws SQLException {
        return this.currRows == 0;
    }

    @Override
    public boolean isLast() throws SQLException {
        if (this.hasMore) {
            return false;
        } else {
            return this.currRows == (this.rows.size() - 1) && this.rows.size() != 0;
        }
    }

    @Override
    public void moveRowRelative(long moveRows) throws SQLException {
        long rowNumber = this.currRows + moveRows;
        absolute(rowNumber);
    }

    @Override
    public void setCurrentRow(long rowNumber) throws SQLException {
        absolute(rowNumber);
    }

    @Override
    public Row next() throws SQLException {
        if (currRows + 1 < fetchedRowCount) {
            return getAt(++currRows);
        } else if (hasMore) {
            fetchMoreWithoutClear();
            if (batchRows == 0) {
                return null;
            }
            return getAt(++currRows);
        } else {
            //after last
            currRows = fetchedRowCount;
        }
        return null;
    }

    @Override
    public void absolute(long index) throws SQLException {
        while (index >= this.fetchedRowCount && this.hasMore) {
            fetchMoreWithoutClear();
        }

        if (index >= this.rows.size()) {
            // if row is great than last,set it to afterLast
            this.currRows = this.rows.size();
        } else if (index < 0) {
            this.currRows = -1;
        } else {
            this.currRows = index;
        }
    }

    @Override
    public boolean hasNext() throws SQLException {
        if (currRows < fetchedRowCount) {
            return true;
        }

        if ((currRows == fetchedRowCount) && hasMore) {
            return true;
        }

        return false;
    }
}
