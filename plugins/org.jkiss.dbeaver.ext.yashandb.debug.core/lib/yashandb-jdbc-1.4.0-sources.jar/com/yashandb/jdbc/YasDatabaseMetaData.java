/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.YasConstants;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.RowIdLifetime;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class YasDatabaseMetaData implements DatabaseMetaData {

    private static final Set<Integer> numberTypeSet = new HashSet<Integer>() {{
            add(Types.DOUBLE);
            add(Types.INTEGER);
            add(Types.TINYINT);
            add(Types.SMALLINT);
            add(Types.REAL);
            add(Types.FLOAT);
            add(Types.NUMERIC);
            add(Types.DECIMAL);
        }};
    private static final Set<Integer> canConvertToNumber = new HashSet<Integer>() {{
            addAll(numberTypeSet);
            add(Types.VARCHAR);
            add(Types.BOOLEAN);
            add(Types.CLOB);
            add(Types.CHAR);
        }};
    private static final Set<Integer> canConvertToBoolean = new HashSet<Integer>() {{
            addAll(numberTypeSet);
            add(Types.VARCHAR);
            add(Types.BOOLEAN);
        }};
    private static final Set<Integer> canConvertToBit = new HashSet<Integer>() {{
            addAll(numberTypeSet);
            add(Types.VARCHAR);
            add(Types.BOOLEAN);
            add(Types.BIT);
        }};
    private static final Set<Integer> canConvertToString = new HashSet<Integer>() {{
            addAll(numberTypeSet);
            add(Types.VARCHAR);
            add(Types.CLOB);
            add(Types.BOOLEAN);
            add(Types.DATE);
            add(Types.TIME);
            add(Types.TIME_WITH_TIMEZONE);
        }};
    private static final Set<Integer> canConvertToDate = new HashSet<Integer>() {{
            add(Types.DATE);
            add(Types.TIME);
            add(Types.VARCHAR);
            add(Types.TIME_WITH_TIMEZONE);
            add(Types.TIMESTAMP);
            add(Types.TIMESTAMP_WITH_TIMEZONE);
        }};

    public YasDatabaseMetaData(ConnectionImpl conn) {
        this.connection = conn;
    }

    protected final ConnectionImpl connection; // The connection association

    public static final Pattern VERSION_PATTERN = Pattern.compile("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}");

    public static Pattern sqlEscapePattern = null;

    public static final Pattern sqlWildcardPattern = Pattern.compile("^%|[^/]%");

    public boolean allProceduresAreCallable() {
        return false; // For now...
    }

    public boolean allTablesAreSelectable() {
        return false; // For now...
    }

    public String getURL() throws SQLException {
        return this.connection.getURL();
    }

    public String getUserName() throws SQLException {
        return this.connection.getUserName();
    }

    public boolean isReadOnly() throws SQLException {
        return this.connection.isReadOnly();
    }

    public boolean nullsAreSortedHigh() {
        return true;
    }

    public boolean nullsAreSortedLow() {
        return false;
    }

    public boolean nullsAreSortedAtStart() {
        return false;
    }

    public boolean nullsAreSortedAtEnd() {
        return false;
    }

    public String getDatabaseProductName() {
        return "YashanDB";
    }

    public String getDatabaseProductVersion() throws SQLException {
        String sql = "select * from V$INSTANCE";
        try (Statement statement = this.connection.createStatement();
                ResultSet resultSet = statement.executeQuery(sql))  {
            if (resultSet.next()) {
                return resultSet.getString("VERSION");
            } else {
                throw SQLError.createSQLException("System view error:V$INSTANCE",YasState.SYSTEM_ERROR);
            }
        }
    }

    public String getDriverName() {
        return YasConstants.DRIVER_NAME;
    }

    @Override
    public String getDriverVersion() {
        return YasConstants.DRIVER_VERSION;
    }

    @Override
    public int getDriverMajorVersion() {
        try {
            return Integer.valueOf(getDriverVersion().split("\\.")[0]);
        } catch (Exception e) {
            return YasConstants.DEFAULT_DRIVER_VERSION;
        }
    }

    @Override
    public int getDriverMinorVersion() {
        try {
            return Integer.valueOf(getDriverVersion().split("-")[0].split("\\.")[1]);
        } catch (Exception e) {
            return YasConstants.DEFAULT_DRIVER_VERSION;
        }
    }

    public boolean usesLocalFiles() {
        return false;
    }

    public boolean usesLocalFilePerTable() {
        return false;
    }

    public boolean supportsMixedCaseIdentifiers() {
        return false;
    }

    public boolean storesUpperCaseIdentifiers() {
        return true;
    }

    public boolean storesLowerCaseIdentifiers() {
        return false;
    }

    public boolean storesMixedCaseIdentifiers() {
        return false;
    }

    public boolean supportsMixedCaseQuotedIdentifiers() {
        return true;
    }

    public boolean storesUpperCaseQuotedIdentifiers() {
        return false;
    }

    public boolean storesLowerCaseQuotedIdentifiers() {
        return false;
    }

    public boolean storesMixedCaseQuotedIdentifiers() {
        return false;
    }

    public String getIdentifierQuoteString() {
        return "\"";
    }

    public String getSQLKeywords() {
        return "ACCESS, ADD, ALTER, AUDIT, CLUSTER, COLUMN, COMMENT, COMPRESS, CONNECT, DATE, DROP,"
            + " EXCLUSIVE, FILE, IDENTIFIED, IMMEDIATE, INCREMENT, INDEX, INITIAL, INTERSECT, "
            + "LEVEL, LOCK, LONG, MAXEXTENTS, MINUS, MODE, NOAUDIT, NOCOMPRESS, NOWAIT, NUMBER, "
            + "OFFLINE, ONLINE, PCTFREE, PRIOR, all_PL_SQL_reserved_ words";
    }

    public String getNumericFunctions() throws SQLException {
        String numberFuncFilter = "AND name IN ('ABS', 'ACOS', 'ASIN', 'ATAN', 'ATAN2', 'BIN_TO_NUM', 'BITAND', "
                + "'BITOR', 'BITXOR', 'CEIL', 'COS', 'COT', 'COUNT', 'DIV', 'EXP', 'FLOOR', 'LN', 'LOG', 'MAX', 'MOD', "
                + "'MIN', 'PI', 'POW', 'POWER', 'RANDOM', 'ROUND', 'SIGN', 'SIN', 'SINH', 'SQRT', 'STDDEV',"
                + " 'STDDEV_POP', 'STDDEV_SAMP', 'SUM', 'TAN', 'TANH', 'TRUNCATE', 'VARIANCE', 'VAR_POP', 'VAR_SAMP')";
        return getFilterFunctions(numberFuncFilter);
    }

    public String getStringFunctions() throws SQLException {
        String strFuncFilter = "AND name IN ('ASCII', 'BIT_LENGTH', 'CHAR_LENGTH', 'CHARACTER_LENGTH', 'CHR', "
                + "'CONCAT', 'CONCAT_WS', 'FIND_IN_SET', 'GROUP_CONCAT', 'INITCAP', 'INSTR', 'LISTAGG', 'LEFT',"
                + " 'LENGTH', 'LENGTHB', 'LOWER', 'LPAD', 'LTRIM', 'NLSSORT', 'OCTET_LENGTH', 'POSITION', "
                + "'REGEXP_COUNT', 'REGEXP_INSTR', 'REGEXP_LIKE', 'REGEXP_REPLACE', 'REGEXP_SUBSTR', 'REPLACE', "
                + "'RIGHT', 'RPAD', 'RTRIM', 'SPLIT', 'STRING_AGG', 'STRPOS', 'SUBSTR', 'SUBSTRING', "
                + "'SUBSTRING_INDEX', 'TO_CHAR', 'TRANSLATE', 'TRIM', 'UPPER', 'WM_CONCAT')";
        return getFilterFunctions(strFuncFilter);
    }

    private String getFilterFunctions(String sqlFilter) throws SQLException {
        Statement statement = this.connection.createStatement();
        String sql = "select name from v$function where 1=1 ";
        sql += sqlFilter;

        statement.closeOnCompletion();
        ResultSet resultSet = statement.executeQuery(sql);
        String strFunctions = "";
        while (resultSet.next()) {
            strFunctions = strFunctions + resultSet.getString(1) + ",";
        }
        resultSet.close();

        if (!strFunctions.isEmpty()) {
            return strFunctions.substring(0, strFunctions.length() - 1);
        }
        return strFunctions;
    }

    public String getSystemFunctions() throws SQLException {
        String systemFuncFilter = "AND name IN ('USERENV', 'SYS_CONNECT_BY_PATH', 'SYS_CONTEXT', 'SYS_GUID')";
        return getFilterFunctions(systemFuncFilter);
    }

    public String getTimeDateFunctions() throws SQLException {
        String timeFunFilter = "AND name IN ('ADD_MONTHS', 'AGE', 'CURRENT_TIMESTAMP', 'DATE', 'DATE_ADD', "
                + "'DATE_FORMAT', 'DAYOFWEEK', 'EXTRACT', 'LAST_DAY', 'LOCALTIME', 'LOCALTIMESTAMP', 'MONTHS_BETWEEN', "
                + "'NEXT_DAY', 'NOW', 'NUMTODSINTERVAL', 'NUMTOYMINTERVAL', 'SCN_TO_TIMESTAMP', 'SYSDATE', "
                + "'SYSTIMESTAMP', 'TIME', 'TIMEDIFF', 'TIMESTAMPDIFF', 'TIMESTAMP_TO_SCN', 'TO_DATE', "
                + "'TO_DSINTERVAL', 'TO_TIMESTAMP', 'TO_YMINTERVAL', 'UTC_TIMESTAMP')";
        return getFilterFunctions(timeFunFilter);
    }

    public String getSearchStringEscape() {
        return "/";
    }

    public String getExtraNameCharacters() {
        return "$#";
    }

    public boolean supportsAlterTableWithAddColumn() {
        return true;
    }

    public boolean supportsAlterTableWithDropColumn() {
        return true;
    }

    public boolean supportsColumnAliasing() {
        return true;
    }

    public boolean nullPlusNonNullIsNull() {
        return true;
    }

    public boolean supportsConvert() {
        return false;
    }

    public boolean supportsConvert(int fromType, int toType) {
        switch (toType) {
            case Types.INTEGER:
            case Types.TINYINT:
            case Types.SMALLINT:
            case Types.BIGINT:
            case Types.REAL:
            case Types.DOUBLE:
            case Types.FLOAT:
            case Types.DECIMAL:
            case Types.NUMERIC:
                return canConvertToNumber.contains(fromType);
            case Types.BOOLEAN:
                return canConvertToBoolean.contains(fromType);
            case Types.BIT:
                return canConvertToBit.contains(fromType);
            case Types.CHAR:
            case Types.VARCHAR:
            case Types.LONGVARCHAR:
                return canConvertToString.contains(fromType);
            case Types.DATE:
            case Types.TIME:
            case Types.TIMESTAMP:
                return canConvertToDate.contains(fromType);
            case YasTypes.DS_INTERVAL:
            case YasTypes.YM_INTERVAL:
            case Types.BINARY:
            case Types.VARBINARY:
            case Types.LONGVARBINARY:
            case Types.NCHAR:
            case Types.NVARCHAR:
            case Types.LONGNVARCHAR:
                return fromType == Types.VARCHAR;
            default:
                return false;
        }
    }

    public boolean supportsTableCorrelationNames() {
        return true;
    }

    public boolean supportsDifferentTableCorrelationNames() {
        return true;
    }

    public boolean supportsExpressionsInOrderBy() {
        return true;
    }

    public boolean supportsOrderByUnrelated() {
        return true;
    }

    public boolean supportsGroupBy() {
        return true;
    }

    public boolean supportsGroupByUnrelated() {
        return true;
    }

    public boolean supportsGroupByBeyondSelect() {
        return true;
    }

    public boolean supportsLikeEscapeClause() {
        return true;
    }

    public boolean supportsMultipleResultSets() {
        return false;
    }

    public boolean supportsMultipleTransactions() {
        return true;
    }

    public boolean supportsNonNullableColumns() {
        return true;
    }

    public boolean supportsMinimumSQLGrammar() {
        return true;
    }

    public boolean supportsCoreSQLGrammar() {
        return true;
    }

    public boolean supportsExtendedSQLGrammar() {
        return true;
    }

    public boolean supportsANSI92EntryLevelSQL() {
        return true;
    }

    public boolean supportsANSI92IntermediateSQL() {
        return true;
    }

    public boolean supportsANSI92FullSQL() {
        return true;
    }

    public boolean supportsIntegrityEnhancementFacility() {
        return true;
    }

    public boolean supportsOuterJoins() {
        return true;
    }

    public boolean supportsFullOuterJoins() {
        return true;
    }

    public boolean supportsLimitedOuterJoins() {
        return true;
    }

    public String getSchemaTerm() {
        return "schema";
    }

    public String getProcedureTerm() {
        return "procedure";
    }

    public String getCatalogTerm() {
        return "";
    }

    public boolean isCatalogAtStart() {
        return false;
    }

    public String getCatalogSeparator() {
        return "";
    }

    public boolean supportsSchemasInDataManipulation() {
        return true;
    }

    public boolean supportsSchemasInProcedureCalls() {
        return true;
    }

    public boolean supportsSchemasInTableDefinitions() {
        return true;
    }

    public boolean supportsSchemasInIndexDefinitions() {
        return true;
    }

    public boolean supportsSchemasInPrivilegeDefinitions() {
        return true;
    }

    public boolean supportsCatalogsInDataManipulation() {
        return false;
    }

    public boolean supportsCatalogsInProcedureCalls() {
        return false;
    }

    public boolean supportsCatalogsInTableDefinitions() {
        return false;
    }

    public boolean supportsCatalogsInIndexDefinitions() {
        return false;
    }

    public boolean supportsCatalogsInPrivilegeDefinitions() {
        return false;
    }

    public boolean supportsPositionedDelete() {
        return false;
    }

    public boolean supportsPositionedUpdate() {
        return false;
    }

    public boolean supportsSelectForUpdate() {
        return true;
    }

    public boolean supportsStoredProcedures() {
        return true;
    }

    public boolean supportsSubqueriesInComparisons() {
        return true;
    }

    public boolean supportsSubqueriesInExists() {
        return true;
    }

    public boolean supportsSubqueriesInIns() {
        return true;
    }

    public boolean supportsSubqueriesInQuantifieds() {
        return true;
    }

    public boolean supportsCorrelatedSubqueries() {
        return true;
    }

    public boolean supportsUnion() {
        return true;
    }

    public boolean supportsUnionAll() {
        return true;
    }

    public boolean supportsOpenCursorsAcrossCommit() {
        return false;
    }

    public boolean supportsOpenCursorsAcrossRollback() {
        return false;
    }

    public boolean supportsOpenStatementsAcrossCommit() {
        return false;
    }

    public boolean supportsOpenStatementsAcrossRollback() {
        return false;
    }

    public int getMaxBinaryLiteralLength() {
        return 4000;
    }

    public int getMaxCharLiteralLength() {
        return 8000;
    }

    protected int getIdentifierLength() {
        return YasConstants.MaxNameLength;
    }

    public int getMaxColumnNameLength() {
        return getIdentifierLength();
    }

    public int getMaxColumnsInGroupBy() {
        return 0; // no limit
    }

    public int getMaxColumnsInIndex() {
        return YasConstants.MaxColumnsInIndex;
    }

    public int getMaxColumnsInOrderBy() {
        return 0; // no limit
    }

    public int getMaxColumnsInSelect() {
        return 0; // no limit
    }

    public int getMaxColumnsInTable() {
        return YasConstants.MaxColumnsInTable;
    }

    public int getMaxConnections() {
        return 8192;
    }

    public int getMaxCursorNameLength() {
        return getIdentifierLength();
    }

    public int getMaxIndexLength() {
        return getIdentifierLength();
    }

    public int getMaxSchemaNameLength() {
        return getIdentifierLength();
    }

    public int getMaxProcedureNameLength() {
        return getIdentifierLength();
    }

    public int getMaxCatalogNameLength() {
        return 0;
    }

    public int getMaxRowSize() {
        return YasConstants.MAX_ROW_SIZE_WITHOUT_LOB;
    }

    public boolean doesMaxRowSizeIncludeBlobs() {
        return false;
    }

    public int getMaxStatementLength() {
        return 0;
    }

    public int getMaxStatements() {
        return 0;
    }

    public int getMaxTableNameLength() {
        return getIdentifierLength();
    }

    public int getMaxTablesInSelect() {
        return 128;
    }

    public int getMaxUserNameLength() {
        return getIdentifierLength();
    }

    public int getDefaultTransactionIsolation() {
        return Connection.TRANSACTION_READ_COMMITTED;
    }

    public boolean supportsTransactions() {
        return true;
    }

    public boolean supportsTransactionIsolationLevel(int level) {
        return (level == Connection.TRANSACTION_READ_COMMITTED
                || level == Connection.TRANSACTION_SERIALIZABLE);

    }

    public boolean supportsDataDefinitionAndDataManipulationTransactions() {
        return true;
    }

    public boolean supportsDataManipulationTransactionsOnly() {
        return false;
    }

    public boolean dataDefinitionCausesTransactionCommit() {
        return true;
    }

    public boolean dataDefinitionIgnoredInTransactions() {
        return false;
    }

    public synchronized ResultSet getProcedures(String catalog, String schemaPattern,
        String procedureNamePattern) throws SQLException {

        String sql = "SELECT DECODE(PROCEDURE_NAME,\n"
                + "        NULL,\n"
                + "        NULL,\n"
                + "        object_name) AS procedure_cat,\n"
                + "        owner AS procedure_schem,\n"
                + "         DECODE(PROCEDURE_NAME,\n"
                + "        null,\n"
                + "        object_name,\n"
                + "        PROCEDURE_NAME) AS procedure_name,\n"
                + "        null,\n"
                + "         null,\n"
                + "        null,\n"
                + "        '' AS remarks, 1 AS procedure_type,"
                + " DECODE(PROCEDURE_NAME,null,OBJECT_NAME,OBJECT_NAME||'.'||PROCEDURE_NAME) AS specific_name "
                + "FROM all_procedures proc\n"
                + "WHERE 1=1\n"
                + "        AND owner LIKE ? escape '/'\n"
                + "        AND NOT EXISTS\n"
                + "    (SELECT *\n"
                + "    FROM all_arguments arg1\n"
                + "    WHERE (arg1.ARGUMENT_NAME is null\n"
                + "            OR length(arg1.ARGUMENT_NAME) = 0)\n"
                + "            AND arg1.IN_OUT = 'OUT'\n"
                + "            AND arg1.OBJECT_ID = proc.OBJECT_ID\n"
                + "            AND (arg1.SUBPROGRAM_ID = proc.SUBPROGRAM_ID\n"
                + "            OR (arg1.SUBPROGRAM_ID is null)))\n"
                + "        AND ( ( ? =1\n"
                + "        AND ((OBJECT_NAME LIKE ? ESCAPE '/'\n"
                + "        AND PROCEDURE_NAME is null)\n"
                + "        OR PROCEDURE_NAME LIKE ? ESCAPE '/' ))\n"
                + "        OR (? =2\n"
                + "        AND OBJECT_NAME LIKE ? ESCAPE '/'\n"
                + "        AND PROCEDURE_NAME is NULL )\n"
                + "        OR (? =3\n"
                + "        AND OBJECT_NAME LIKE ? ESCAPE '/'\n"
                + "        AND PROCEDURE_NAME LIKE ? ESCAPE '/' ))order by procedure_cat, procedure_schem, "
                + "procedure_name ";
        PreparedStatement stmt = this.connection.prepareStatement(sql);
        int catalogType = catalog == null ? 1 : (catalog.equals("") ? 2 : 3);
        stmt.setString(1, getSchemaParam(schemaPattern));
        stmt.setInt(2, catalogType);
        stmt.setString(3, getLikeParam(procedureNamePattern, "procedureNamePattern"));
        stmt.setString(4, getLikeParam(procedureNamePattern, "procedureNamePattern"));
        stmt.setInt(5, catalogType);
        stmt.setString(6, getLikeParam(procedureNamePattern, "procedureNamePattern"));
        stmt.setInt(7, catalogType);
        stmt.setString(8, catalog);
        stmt.setString(9, getLikeParam(procedureNamePattern, "procedureNamePattern"));
        stmt.closeOnCompletion();

        return stmt.executeQuery();
    }

    public synchronized ResultSet getProcedureColumns(String catalog, String schemaPattern,
                                         String procedureNamePattern, String columnNamePattern) throws SQLException {
        String decodeColumnType = " DECODE(arg.ARGUMENT_NAME, NULL, " + DatabaseMetaData.procedureColumnReturn + ",\n"
                + "DECODE(arg.in_out, 'IN', " + DatabaseMetaData.procedureColumnIn + ",\n"
                + "'OUT', " + DatabaseMetaData.procedureColumnOut + ",\n"
                + "'IN/OUT', " + DatabaseMetaData.procedureColumnInOut + ",\n"
                + DatabaseMetaData.procedureColumnUnknown + ")) ";

        String colType = getJDBCDataTypeClause("arg.data_type");
        String sql = "SELECT DECODE(arg.SUBPROGRAM_NAME,NULL,NULL,arg.object_name) AS procedure_cat,\n"
                + "       arg.owner AS procedure_schem,\n"
                + "       DECODE(arg.SUBPROGRAM_NAME,null,arg.object_name,arg.SUBPROGRAM_NAME) AS procedure_name,\n"
                + "       arg.argument_name AS column_name,\n"
                + decodeColumnType + " AS column_type,\n"
                + colType
                + " AS data_type,\n"
                + "       arg.data_type AS type_name,\n"
                + "       DECODE (arg.data_precision, NULL, arg.data_length,\n"
                + "                               arg.data_precision) AS precision,\n"
                + "       arg.data_length AS length,\n"
                + "       arg.data_scale AS scale,\n"
                + "       10 AS radix,\n"
                + DatabaseMetaData.attributeNullable + " AS nullable,\n"
                + "       NULL AS remarks,\n"
                + "       arg.default_value AS column_def,\n"
                + "       NULL as sql_data_type,\n"
                + "       NULL AS sql_datetime_sub,\n"
                + "       DECODE(arg.data_type,\n"
                + "                         'CHAR', 8000,\n"
                + "                         'VARCHAR', 8000,\n"
                + "                         'RAW', 8000,\n"
                + "                         NULL) AS char_octet_length,\n"
                + "       arg.sequence AS ordinal_position,\n"
                + "       'YES' AS is_nullable,\n"
                + " DECODE(arg.SUBPROGRAM_NAME,null,arg.OBJECT_NAME,arg.OBJECT_NAME||'.'||arg.SUBPROGRAM_NAME) "
                + " AS specific_name"
                + " FROM all_arguments arg, all_procedures proc\n"
                + " WHERE arg.owner LIKE ? ESCAPE '/'\n"
                + " AND (( ? =1 and ((proc.OBJECT_NAME LIKE ?  ESCAPE '/' and proc.PROCEDURE_NAME is null) or "
                + "proc.PROCEDURE_NAME LIKE ?  ESCAPE '/' )) "
                + " OR (? =2 and proc.OBJECT_NAME LIKE ?  ESCAPE '/' and proc.PROCEDURE_NAME is null )"
                + " or (? =3 and proc.OBJECT_NAME LIKE ?  ESCAPE '/' and proc.PROCEDURE_NAME LIKE ?  ESCAPE '/' ))\n"
                + " AND arg.owner = proc.owner\n"
                + " AND (arg.SUBPROGRAM_ID = proc.SUBPROGRAM_ID OR arg.SUBPROGRAM_ID is null)\n"
                + " AND arg.object_id = proc.object_id\n"
                + " AND not EXISTS(select * from all_arguments arg1  "
                + "     where (arg1.ARGUMENT_NAME  is null or length(arg1.ARGUMENT_NAME) = 0)"
                + "     and arg1.IN_OUT = 'OUT' "
                + "     and arg1.OBJECT_ID = arg.OBJECT_ID   "
                + "     and (arg1.SUBPROGRAM_ID = arg.SUBPROGRAM_ID or (arg1.SUBPROGRAM_ID is null))) \n"
                + "AND arg.argument_name LIKE ? ESCAPE '/' \n"
                + "ORDER BY PROCEDURE_CAT,procedure_schem, procedure_name, SPECIFIC_NAME";

        PreparedStatement stmt = this.connection.prepareStatement(sql);
        int catalogType = catalog == null ? 1 : (catalog.equals("") ? 2 : 3);
        stmt.setString(1, getSchemaParam(schemaPattern));
        stmt.setInt(2, catalogType);
        stmt.setString(3, getLikeParam(procedureNamePattern, "procedureNamePattern"));
        stmt.setString(4, getLikeParam(procedureNamePattern, "procedureNamePattern"));

        stmt.setInt(5, catalogType);
        stmt.setString(6, getLikeParam(procedureNamePattern, "procedureNamePattern"));

        stmt.setInt(7, catalogType);
        stmt.setString(8, catalog);
        stmt.setString(9, getLikeParam(procedureNamePattern, "procedureNamePattern"));
        stmt.setString(10, getLikeParam(columnNamePattern, "columnNamePattern"));
        stmt.closeOnCompletion();
        return stmt.executeQuery();
    }

    private String getLikeParam(String pattern, String name) throws SQLException {
        if (pattern == null) {
            return "%";
        } else if (pattern.equals("")) {
            throw SQLError.createSQLException("invalid parameter \"" + name + "\"",
                    YasState.INVALID_PARAMETER_VALUE);
        }
        return pattern;
    }

    private String getSchemaParam(String schemaPattern) throws SQLException {
        if (schemaPattern == null) {
            return  "%";
        }
        if (!schemaPattern.equals("")) {
            return schemaPattern;
        }
        if (this.connection.getSession().isUserCaseSensitive()) {
            return  "\"" + this.connection.getUserName() + "\"";
        }
        return this.connection.getUserName().toUpperCase();
    }

    public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern,
                               String[] types) throws SQLException {
        StringBuilder str = new StringBuilder("select null as table_cat,\n"
            + "o.owner as table_schem,\n"
            + "o.object_name as table_name,\n"
            + "o.object_type as table_type,\n"
            + "c.comments as remarks,\n"
            + "null as type_cat,\n"
            + "null as type_schem,\n"
            + "null as type_name,\n"
            + "null as self_referencing_col_name,\n"
            + "null as ref_generation\n"
            + "from all_objects o left join all_tab_comments c on "
            + " o.owner = c.owner "
            + " and o.object_name = c.table_name "
            + " where o.owner like ? escape '/' "
            + " and o.object_name like ? escape '/' "
            );

        if (types != null) {
            ResultSet resultSet = this.getTableTypes();
            ArrayList<String> tableTypes = new ArrayList<>();
            while (resultSet.next()) {
                tableTypes.add(resultSet.getString(1));
            }
            resultSet.close();

            str.append(" and o.object_type in ('DDD'");
            for (String tstr : types) {
                if (tableTypes.contains(tstr)) {
                    str.append(",'").append(tstr).append("'");
                }
            }
            str.append(")");
        } else {
            str.append(" and o.object_type in ('TABLE', 'VIEW', 'SYNONYM')");
        }

        str.append(" ORDER BY table_type, table_schem, table_name\n");

        PreparedStatement stmt = this.connection.prepareStatement(str.toString());
        if (schemaPattern != null) {
            stmt.setString(1, schemaPattern);
        } else {
            stmt.setString(1, "%");
        }

        if (tableNamePattern != null) {
            stmt.setString(2, tableNamePattern);
        } else {
            stmt.setString(2, "%");
        }

        stmt.closeOnCompletion();
        return stmt.executeQuery();
    }

    public ResultSet getSchemas() throws SQLException {
        return getSchemas(null, null);
    }

    public ResultSet getCatalogs() throws SQLException {
        Statement statement = this.connection.createStatement();
        String str = "select 'nothing' as table_cat from dual where 1 = 2";
        statement.closeOnCompletion();
        return statement.executeQuery(str);
    }

    public ResultSet getTableTypes() throws SQLException {
        Statement statement = this.connection.createStatement();

        String str = "select 'TABLE' as table_type from dual "
            + "union select 'VIEW' as table_type from dual "
            + "union select 'SYNONYM' as table_type from dual order by table_type";
        statement.closeOnCompletion();
        return statement.executeQuery(str);
    }

    public ResultSet getColumns(String catalog, String schemaPattern, String tableNamePattern,
                                String columnNamePattern) throws SQLException {
        String colType = getJDBCDataTypeClause("c.data_type");
        String leftJoinTableClause = "";
        String tableNamePatternParam = tableNamePattern;
        if (tableNamePattern != null) {
            if (this.hasSqlWildcard(tableNamePattern)) {
                leftJoinTableClause = " where r1.table_name like ? " + " escape '/' selectivity 0.00001 ";
            } else {
                tableNamePatternParam = this.stripSqlEscapes(tableNamePattern);
                leftJoinTableClause = " where r1.table_name = ? ";
            }
        }

        String colNullable = "decode(c.nullable, 'Y', 1, 'N', 0)";
        String colSize = "decode(c.data_precision, null, c.data_length, "
                + "decode(c.data_type,'NUMBER', decode(c.data_scale,null, 0 , c.data_precision),"
                + "c.data_precision))";
        String decimalDigits = "decode(c.data_type,'NUMBER', "
                + " decode(c.data_scale,null, -127, c.data_scale),"
                + " c.data_scale)";
        String str = "select null as table_cat,"
            + "c.owner as table_schem,"
            + "c.table_name as table_name,"
            + "c.column_name as column_name,"
            + colType + " as data_type,"
            + "c.data_type as type_name,"
            + colSize + " as column_size,"
            + "0 as buffer_length,"
            + decimalDigits + " as decimal_digits,"
            + "10 as num_prec_radix,"
            + colNullable + " as nullable,"
            + "r.comments as remarks,"
            + "data_default as column_def,"
            + "0 as sql_data_type,"
            + "null as sql_datetime_sub,"
            + "null as char_octet_length,"
            + "c.column_id + 1 as ordinal_position,"
            + "nullable as is_nullable,"
            + "null as scope_catalog,"
            + "null as scope_schema,"
            + "null as scope_table,"
            + "0 as source_data_type,"
            + " '' as is_autoincrement,"
            + " '' as is_generatedcolumn"
            + " from all_tab_cols c left join  (select * from all_col_comments r1  " + leftJoinTableClause + ") r on "
            + " c.owner = r.owner and c.table_name = r.table_name "
            + " and c.column_name = r.column_name "
            + " where c.USER_GENERATED = 'Y' ";

        String schemaPatternParam = schemaPattern;

        String columnNamePatternParam = columnNamePattern;
        if (schemaPattern != null) {
            if (this.hasSqlWildcard(schemaPattern)) {
                str += "AND c.owner like ? " + " escape '/' selectivity 0.00001 ";
            } else {
                schemaPatternParam = this.stripSqlEscapes(schemaPattern);
                str += "AND c.owner = ? ";
            }
        }

        if (tableNamePattern != null) {
            if (this.hasSqlWildcard(tableNamePattern)) {
                str += " AND c.table_name like ? " + " escape '/' selectivity 0.00001 ";
            } else {
                tableNamePatternParam = this.stripSqlEscapes(tableNamePattern);
                str += " AND c.table_name = ? ";
            }
        }

        if (columnNamePattern != null) {
            if (this.hasSqlWildcard(columnNamePattern)) {
                str += " AND c.column_name like ? " + " escape '/' selectivity 0.00001 ";
            } else {
                columnNamePatternParam = this.stripSqlEscapes(columnNamePattern);
                str += " AND c.column_name = ? " ;
            }

        }
        
        str += " order by TABLE_CAT,TABLE_SCHEM, TABLE_NAME, ORDINAL_POSITION";

        PreparedStatement preparedStatement = this.connection.prepareStatement(str);
        int parameterIndex = 1;

        if (tableNamePattern != null) {
            preparedStatement.setString(parameterIndex, tableNamePatternParam);
            parameterIndex++;
        }

        if (schemaPattern != null) {
            preparedStatement.setString(parameterIndex, schemaPatternParam);
            parameterIndex++;
        }

        if (tableNamePattern != null) {
            preparedStatement.setString(parameterIndex, tableNamePatternParam);
            parameterIndex++;
        }

        if (columnNamePattern != null) {
            preparedStatement.setString(parameterIndex, columnNamePatternParam);
        }

        preparedStatement.closeOnCompletion();
        return preparedStatement.executeQuery();
    }

    public synchronized ResultSet getColumnPrivileges(String catalog, String schema, String table,
                                         String columnNamePattern) throws SQLException {
        return emptyResult();

    }

    public synchronized ResultSet getTablePrivileges(String catalog, String schemaPattern,
                                        String tableNamePattern) throws SQLException {
        PreparedStatement preparedStatement = this.connection.prepareStatement("SELECT NULL AS table_cat,\n"
                + "       OWNER AS table_schem,\n"
                + "       table_name,\n"
                + "grantor,\n"
                + "       grantee,\n"
                + "       privilege,\n"
                + "       decode(grantable,'N','NO','Y','YES',NULL) AS is_grantable\n"
                + "FROM ALL_TAB_PRIVS\n"
                + "WHERE OWNER LIKE :1 ESCAPE '/'\n"
                + "  AND table_name LIKE :2 ESCAPE '/'\n"
                + "ORDER BY OWNER,table_name, privilege");
        preparedStatement.setString(1, schemaPattern == null ? "%" : schemaPattern);
        preparedStatement.setString(2, tableNamePattern == null ? "%" : tableNamePattern);
        preparedStatement.closeOnCompletion();
        return preparedStatement.executeQuery();
    }

    public synchronized ResultSet getBestRowIdentifier(String catalog, String schema, String table,
                                          int scope, boolean nullable) throws SQLException {
        String sql1 = "SELECT 1 AS scope, 'ROWID' AS column_name, -8 AS data_type,\n"
            + " 'ROWID' AS type_name, 0 AS column_size, 0 AS buffer_length,\n"
            + "       0 AS decimal_digits, 2 AS pseudo_column\n"
            + "FROM DUAL\n"
            + "WHERE :1 = 1\n"
            + "UNION\n"
            + "SELECT 2 AS scope,\n"
            + " t.column_name,\n"
            + getJDBCDataTypeClause("t.data_type")
            + " AS data_type,\n"
            + " t.data_type AS type_name,\n"
            + " t.DATA_LENGTH AS column_size,\n"
            + "  0 AS buffer_length,\n"
            + "  t.data_scale AS decimal_digits,\n"
            + "       1 AS pseudo_column\n"
            + "FROM all_tab_columns t, all_ind_columns i\n"
            + "WHERE :2 = 1\n"
            + "  AND t.table_name = :3\n"
            + "  AND t.owner like :4 escape '/'\n"
            + "  AND t.nullable = :5\n"
            + "  AND t.owner = i.table_owner\n"
            + "  AND t.table_name = i.table_name\n"
            + "  AND t.column_name = i.column_name\n";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sql1);
        switch (scope) {
            case 0:
                preparedStatement.setInt(1, 0);
                preparedStatement.setInt(2, 0);
                break;
            case 1:
                preparedStatement.setInt(1, 1);
                preparedStatement.setInt(2, 1);
                break;
            case 2:
                preparedStatement.setInt(1, 0);
                preparedStatement.setInt(2, 1);
        }

        preparedStatement.setString(3, table);
        preparedStatement.setString(4, schema == null ? "%" : schema);
        preparedStatement.setString(5, nullable ?  "Y" : "N");
        preparedStatement.closeOnCompletion();
        return preparedStatement.executeQuery();
    }

    public synchronized ResultSet getVersionColumns(String catalog, String schema, String table)
            throws SQLException {
        // 这个应该指的是有触发器的列
        String sql = "  SELECT 0 AS scope,\n"
                + " t.column_name,\n"
                + getJDBCDataTypeClause("c.data_type") + " AS data_type,\n"
                + " c.data_type AS type_name,\n"
                + " c.DATA_LENGTH AS column_size,\n"
                + "       0 as buffer_length,\n"
                + "   c.data_scale as decimal_digits,\n"
                + "   0 as pseudo_column\n"
                + "FROM all_trigger_cols t, all_tab_columns c\n"
                + "WHERE t.table_name = :1\n"
                + "  AND c.owner like :2 escape '/'\n"
                + " AND t.table_owner = c.owner\n"
                + "  AND t.table_name = c.table_name\n"
                + " AND t.column_name = c.column_name";
        PreparedStatement preparedStatement = this.connection.prepareStatement(sql);
        preparedStatement.setString(1, table);
        preparedStatement.setString(2, schema == null ? "%" : schema);
        ResultSet resultSet = preparedStatement.executeQuery();
        preparedStatement.closeOnCompletion();
        return resultSet;
    }

    private static String getJDBCDataTypeClause(String colName) {
        return "decode(" + colName + ",\n"
                + "\t'BOOLEAN', " + YasTypes.BOOLEAN + ",\n"
                + "\t'TINYINT', " + YasTypes.TINYINT + ",\n"
                + "\t'SMALLINT', " + YasTypes.SMALLINT + ",\n"
                + "\t'INTEGER', " + YasTypes.INTEGER + ",\n"
                + "\t'BIGINT', " + YasTypes.BIGINT + ",\n"
                + "\t'FLOAT', " + YasTypes.REAL + ",\n"
                + "\t'DOUBLE', " + YasTypes.DOUBLE + ",\n"
                + "\t'NUMBER', " + YasTypes.NUMBER + ",\n"
                + "\t'DATE', " + YasTypes.DATE + ",\n"
                + "\t'TIME', " + YasTypes.TIME + ",\n"
                + "\t'TIMESTAMP', " + YasTypes.TIMESTAMP + ",\n"
                + "\t'TIMESTAMP_TZ', " + YasTypes.TIMESTAMP_TZ + ",\n"
                + "\t'TIMESTAMP_LTZ', " + YasTypes.TIMESTAMP_LTZ + ",\n"
                + "\t'INTERVAL YEAR TO MONTH', " + YasTypes.YM_INTERVAL + ",\n"
                + "\t'INTERVAL DAY TO SECOND', " + YasTypes.DS_INTERVAL + ",\n"
                + "\t'CHAR', " + YasTypes.CHAR + ",\n"
                + "\t'NCHAR', " + YasTypes.NCHAR + ",\n"
                + "\t'VARCHAR', " + YasTypes.VARCHAR + ",\n"
                + "\t'NVARCHAR', " + YasTypes.NVARCHAR + ",\n"
                + "\t'RAW', " + YasTypes.RAW + ",\n"
                + "\t'CLOB', " + YasTypes.CLOB + ",\n"
                + "\t'BLOB', " + YasTypes.BLOB + ",\n"
                + "\t'BIT', " + YasTypes.BIT + ",\n"
                + "\t'CURSOR', " + YasTypes.REF_CURSOR + ",\n"
                + "\t'NCLOB', " + YasTypes.NCLOB + ",\n"
                + "\t'JSON', " + YasTypes.JSON + ",\n"
                + "\t'ROWID', " + YasTypes.ROWID + ",\n"
                + "\t1111)";
    }

    public synchronized ResultSet getPrimaryKeys(String catalog, String schema, String table)
            throws SQLException {
        String sql = "SELECT NULL AS table_cat, c.owner AS table_schem, c.table_name, c.column_name, "
                + "c.position + 1 AS key_seq,\n"
                + "c.constraint_name AS pk_name\n"
                + "FROM all_cons_columns c,\n"
                + "all_constraints k\n"
                + "WHERE k.constraint_type in ('PRIMARY KEY','P')\n"
                + "AND k.table_name = ?\n"
                + "AND k.owner like ?\n"
                + "AND k.constraint_name = c.constraint_name\n"
                + "AND k.table_name = c.table_name\n"
                + "AND k.owner = c.owner\n"
                + "ORDER BY column_name";
        PreparedStatement stmt = this.connection
            .prepareStatement(sql);

        stmt.setString(1, table);
        stmt.setString(2, schema == null ? "%" : schema);

        ResultSet rs = stmt.executeQuery();

        stmt.closeOnCompletion();
        return rs;
    }

    /**
     * Todo
     * Get a description of the primary key columns that are
     * referenced by a table's foreign key columns (the primary keys
     * imported by a table).
     */
    public synchronized ResultSet getImportedKeys(String catalog, String schema, String table)
        throws SQLException {

        return queryKeys(null,null,schema,table,
                "ORDER BY pktable_schem, pktable_name, key_seq");
    }

    /**
     * Todo
     * Get a description of a foreign key columns that reference a
     * table's primary key columns (the foreign keys exported by a
     * table).  They are ordered by FKTABLE_CAT, FKTABLE_SCHEM,
     * FKTABLE_NAME, and KEY_SEQ.
     */
    public synchronized ResultSet getExportedKeys(String catalog, String schema, String table)
            throws SQLException {
        return queryKeys(schema,table,null,null,
                "ORDER BY fktable_schem, fktable_name, key_seq");
    }


    /**
     * Todo
     * Return the common part of the query for the 3 entrypoints
     * getImportedKeys, getExportedKeys and getCrossReference.
     * If a schema or table is null it is not put in the where clause.
     */
    ResultSet queryKeys(String pSchema, String pTable, String fSchema,
                        String fTable, String orderByClause) throws SQLException {

        String pTableClause = pTable != null ? " AND p.table_name = ? " : "";
        String fTableClause = fTable != null ? " AND f.table_name = ? " : "";
        String pSchemaClause = pSchema != null ? " AND p.owner =  ? " : "";
        String fSchemaClause = fSchema != null ? " AND f.owner = ? " : "";
        String sql =
                "SELECT NULL AS pktable_cat,\n"
                        + "       p.owner as pktable_schem,\n"
                        + "       p.table_name as pktable_name,\n"
                        + "       pc.column_name as pkcolumn_name,\n"
                        + "       NULL as fktable_cat,\n"
                        + "       f.owner as fktable_schem,\n"
                        + "       f.table_name as fktable_name,\n"
                        + "       fc.column_name as fkcolumn_name,\n"
                        + "       fc.position as key_seq,\n"
                        + "       decode (f.update_rule, 'CASCADE', 0, 'SET NULL', 2, 3) as update_rule,\n"
                        + "       decode (f.delete_rule, 'CASCADE', 0, 'SET NULL', 2, 3) as delete_rule,\n"
                        + "       f.constraint_name as fk_name,\n"
                        + "       p.constraint_name as pk_name,\n"
                        + "       7 as deferrability \n"
                        + "      FROM all_cons_columns pc, all_constraints p,\n"
                        + "      all_cons_columns fc, all_constraints f\n"
                        + "WHERE 1 = 1"
                        + pTableClause + fTableClause + pSchemaClause + fSchemaClause
                        + " AND f.constraint_type in ('FOREIGN KEY','R')\n"
                        + "  AND p.owner = f.r_owner\n"
                        + "  AND p.constraint_name = f.r_constraint_name\n"
                        + "  AND p.constraint_type in ('PRIMARY KEY','P')\n"
                        + "  AND pc.owner = p.owner\n"
                        + "  AND pc.constraint_name = p.constraint_name\n"
                        + "  AND pc.table_name = p.table_name\n"
                        + "  AND fc.owner = f.owner\n"
                        + "  AND fc.constraint_name = f.constraint_name\n"
                        + "  AND fc.table_name = f.table_name\n"
                        + "  AND fc.position = pc.position\n" + orderByClause;

        PreparedStatement stmt = this.connection.prepareStatement(sql);
        int index = 1;
        if (pTable != null) {
            stmt.setString(index++, pTable);
        }
        if (fTable != null) {
            stmt.setString(index++, fTable);
        }
        if (pSchema != null) {
            stmt.setString(index++, pSchema);
        }
        if (fSchema != null) {
            stmt.setString(index, fSchema);
        }
        stmt.closeOnCompletion();
        return stmt.executeQuery();
    }

    public ResultSet getCrossReference(String primaryCatalog, String primarySchema,
                                       String primaryTable, String foreignCatalog,
                                       String foreignSchema, String foreignTable) throws SQLException {
        return queryKeys(primarySchema, primaryTable, foreignSchema, foreignTable,
                       "ORDER BY fktable_schem, fktable_name, key_seq");
    }

    public ResultSet getTypeInfo() throws SQLException {
        Statement statement = this.connection.createStatement();
        String tintIntStr = "select\n"
            + "'TINYINT' as type_name, " + Types.TINYINT + " as data_type, 3 as precision,\n"
            + "NULL as literal_prefix, NULL as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 1 as fixed_prec_scale, 1 as auto_increment,\n"
            + "'TINYINT' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n";
        String smallIntStr = "union select \n"
            + "'SMALLINT' as type_name, " + Types.SMALLINT + " as data_type, 5 as precision,\n"
            + "NULL as literal_prefix, NULL as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 1 as fixed_prec_scale, 1 as auto_increment,\n"
            + "'SMALLINT' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n";
        String intStr = "union select \n"
            + "'INTEGER' as type_name, " + Types.INTEGER + " as data_type, 10 as precision,\n"
            + "NULL as literal_prefix, NULL as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 1 as fixed_prec_scale, 1 as auto_increment,\n"
            + "'INTEGER' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n";
        String bigIntStr = "union select \n"
            + "'BIGINT' as type_name, " + Types.BIGINT + " as data_type, 19 as precision,\n"
            + "NULL as literal_prefix, NULL as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 1 as fixed_prec_scale, 1 as auto_increment,\n"
            + "'BIGINT' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n";

        String charStr = "union select\n"
            + "'CHAR' as type_name, " + Types.CHAR + " as data_type, 8000 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n"
            + "1 as nullable, 1 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'CHAR' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n";
        String varcharStr = "union select\n"
            + "'VARCHAR' as type_name, " + Types.VARCHAR + " as data_type, 8000 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n"
            + "1 as nullable, 1 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'VARCHAR' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n";

        String intervalYmStr = "union select\n"
                + "'INTERVAL YEAR TO MONTH' as type_name, " + YasTypes.YM_INTERVAL
                + " as data_type, 9 as precision,\n"
                + "'''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n"
                + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
                + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
                + "'INTERVAL YEAR TO MONTH' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n"
                + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
                + "from dual\n";

        String intervalDsStr = "union select\n"
                + "'INTERVAL DAY TO SECOND' as type_name, " + YasTypes.DS_INTERVAL
                + " as data_type, 9 as precision,\n"
                + "'''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n"
                + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
                + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
                + "'INTERVAL DAY TO SECOND' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n"
                + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
                + "from dual\n";

        String unionStr = tintIntStr
            + smallIntStr
            + intStr
            + bigIntStr
            + "union select \n"
            + "'FLOAT' as type_name, " + Types.REAL + " as data_type, 63 as precision,\n"
            + "NULL as literal_prefix, NULL as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'FLOAT' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select \n"
            + "'DOUBLE' as type_name, " + Types.DOUBLE + " as data_type, 63 as precision,\n"
            + "NULL as literal_prefix, NULL as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'DOUBLE' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select \n"
            + "'NUMBER' as type_name, " + Types.NUMERIC + " as data_type, 38 as precision,\n"
            + "NULL as literal_prefix, NULL as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'NUMBER' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select \n"
            + "'DATE' as type_name, " + Types.DATE + " as data_type, 35 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'DATE' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select \n"
            + "'TIME' as type_name, " + Types.TIME + " as data_type, 35 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'TIME' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select \n"
            + "'TIMESTAMP' as type_name, " + Types.TIMESTAMP + " as data_type, 35 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'TIMESTAMP' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select \n"
            + "'TIMESTAMP WITH TIME ZONE' as type_name, " + Types.TIMESTAMP_WITH_TIMEZONE
            + " as data_type, 35 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'TIMESTAMP WITH TIME ZONE' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select \n"
            + "'TIMESTAMP WITH LOCAL TIME ZONE' as type_name, " + Types.TIMESTAMP_WITH_TIMEZONE
            + " as data_type, 35 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'TIMESTAMP WITH LOCAL TIME ZONE' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + intervalYmStr
            + intervalDsStr
            + charStr
            + "union select 'NCHAR' as type_name, " + Types.NCHAR + " as data_type, 8000 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 1 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'NCHAR' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + varcharStr
            + "union select \n"
            + "'NVARCHAR' as type_name, " + Types.NVARCHAR + " as data_type, 8000 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 1 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'NVARCHAR' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select\n"
            + " 'RAW' as type_name, " + Types.BINARY + " as data_type, 8000 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 1 as case_sensitive, 0 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'RAW' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select\n"
            + " 'CLOB' as type_name, " + Types.CLOB + " as data_type, -1 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 1 as case_sensitive, 0 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'CLOB' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select\n"
            + " 'BLOB' as type_name, " + Types.BLOB + " as data_type, -1 as precision,\n"
            + "NULL as literal_prefix, NULL as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 0 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'BLOB' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select\n"
            + "'BIT' as type_name, " + Types.BIT + " as data_type, 64 as precision,\n"
            + "'b''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'BIT' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select\n"
            + " 'BOOLEAN' as type_name, " + Types.BOOLEAN + " as data_type, 1 as precision,\n"
            + "NULL as literal_prefix, NULL as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'BOOLEAN' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n"
            + "union select\n"
            + "'ROWID' as type_name, " + Types.ROWID + " as data_type, 42 as precision,\n"
            + "'''' as literal_prefix, '''' as literal_suffix, null as create_params,\n"
            + "1 as nullable, 0 as case_sensitive, 3 as searchable,\n"
            + "0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n"
            + "'ROWID' as local_type_name, null as minimum_scale, null as maximum_scale,\n"
            + "NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n"
            + "from dual\n";
        String sql = "select * from (" + unionStr + ") order by data_type";
        statement.closeOnCompletion();
        return statement.executeQuery(sql);
    }

    private static String quoteDatabaseObjectName(String paramString) {
        if (paramString == null || paramString.length() == 0) {
            return "''";
        }
        return ((paramString.charAt(0) == '"') ? "Q'" : "'") + paramString + "'";
    }

    public synchronized ResultSet getIndexInfo(String catalog, String schema, String tableName,
                                  boolean unique, boolean approximate) throws SQLException {
        String sql = "select null as table_cat, "
                + "owner as table_schem, "
                + "table_name, "
                + "0 as NON_UNIQUE, "
                + "null as index_qualifier, "
                + "null as index_name, "
                + "0 as type, "
                + "0 as ordinal_position, "
                + "null as column_name, "
                + "null as asc_or_desc, "
                + "num_rows as cardinality, "
                + "blocks as pages, "
                + "null as filter_condition "
                + "from all_tables "
                + "where table_name = " + quoteDatabaseObjectName(tableName) + "\n";

        if (schema != null && schema.length() > 0) {
            sql = sql + "  and owner = " + quoteDatabaseObjectName(schema) + "\n";
        }

        sql += " union\n";
        sql += "select null as table_cat, "
                + "i.owner as table_schem, "
                + "i.table_name, "
                + "decode (i.uniqueness, 'Y', 0, 1), "
                + "null as index_qualifier, "
                + "i.index_name, "
                + "1 as type, "
                + "c.column_position + 1 as ordinal_position, "
                + "c.column_name, "
                + "decode (c.descend, 'N', 'A', 'D') as asc_or_desc, "
                + "i.distinct_keys as cardinality, "
                + "i.leaf_blocks as pages, "
                + "null as filter_condition "
                + "from all_indexes i, all_ind_columns c "
                + "where i.table_name = " + quoteDatabaseObjectName(tableName) + "\n";
        if (schema != null && schema.length() > 0) {
            sql += " and i.owner = " + quoteDatabaseObjectName(schema) + "\n";
        }
        if (unique) {
            sql += "  and i.uniqueness = 'Y' ";
        }
        sql += " and i.index_name = c.index_name and i.table_owner = c.table_owner "
                + "and i.table_name = c.table_name and i.owner = c.index_owner ";
        sql += " order by non_unique, type, index_name, ordinal_position";
        Statement stmt = connection.createStatement();
        stmt.closeOnCompletion();
        return stmt.executeQuery(sql);
    }

    public boolean supportsResultSetType(int type) {
        return type == ResultSet.TYPE_FORWARD_ONLY || type == ResultSet.TYPE_SCROLL_INSENSITIVE
                || type == ResultSet.TYPE_SCROLL_SENSITIVE;
    }

    public boolean supportsResultSetConcurrency(int type, int concurrency) {
        return (type == ResultSet.TYPE_FORWARD_ONLY || type == ResultSet.TYPE_SCROLL_INSENSITIVE
                || type == ResultSet.TYPE_SCROLL_SENSITIVE) && (concurrency == ResultSet.CONCUR_READ_ONLY
                || concurrency == ResultSet.CONCUR_UPDATABLE);
    }

    public boolean ownUpdatesAreVisible(int type) {
        return type != ResultSet.TYPE_FORWARD_ONLY;
    }

    public boolean ownDeletesAreVisible(int type) {
        return type != ResultSet.TYPE_FORWARD_ONLY;
    }

    public boolean ownInsertsAreVisible(int type) {
        return false;
    }

    public boolean othersUpdatesAreVisible(int type) {
        return type == ResultSet.TYPE_SCROLL_SENSITIVE;
    }

    public boolean othersDeletesAreVisible(int i) {
        return false;
    }

    public boolean othersInsertsAreVisible(int type) {
        return false;
    }

    public boolean updatesAreDetected(int type) {
        return false;
    }

    public boolean deletesAreDetected(int i) {
        return false;
    }

    public boolean insertsAreDetected(int type) {
        return false;
    }

    public boolean supportsBatchUpdates() {
        return true;
    }

    // Todo
    public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern,
                             int[] types) throws SQLException {
        String sql = "SELECT NULL AS TYPE_CAT, NULL AS TYPE_SCHEM, "
                + "NULL AS TYPE_NAME, NULL AS CLASS_NAME, 'STRUCT' AS DATA_TYPE, "
                + "NULL AS REMARKS FROM DUAL WHERE 1=2 ";

        PreparedStatement stmt = this.connection.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        stmt.closeOnCompletion();
        return rs;
    }

    public Connection getConnection() {
        return connection;
    }

    public boolean supportsSavepoints() {
        return true;
    }

    public boolean supportsNamedParameters() {
        return false;
    }

    public boolean supportsMultipleOpenResults() {
        return true;
    }

    public boolean supportsGetGeneratedKeys() {
        return true;
    }

    public boolean generatedKeyAlwaysReturned() {
        return true;
    }

    public ResultSet getSuperTypes(String catalog, String schemaPattern, String typeNamePattern)
        throws SQLException {
        return emptyResult();
    }

    public ResultSet getSuperTables(String catalog, String schemaPattern, String tableNamePattern)
        throws SQLException {
        return emptyResult();
    }

    public ResultSet getAttributes(String catalog, String schemaPattern, String typeNamePattern,
        String attributeNamePattern) throws SQLException {
        return emptyResult();
    }

    public boolean supportsResultSetHoldability(int holdability) {
        return holdability == ResultSet.HOLD_CURSORS_OVER_COMMIT;
    }

    public int getResultSetHoldability() {
        return ResultSet.HOLD_CURSORS_OVER_COMMIT;
    }

    private String checkVersion(String versionStr) throws SQLException {
        Matcher matcher = YasDatabaseMetaData.VERSION_PATTERN.matcher(versionStr);
        if (!matcher.find()) {
            throw SQLError.createSQLException("Incorrect version format: " + versionStr,YasState.UNKNOWN_STATE);
        }
        return matcher.group();
    }

    public int getDatabaseMajorVersion() throws SQLException {
        return Integer.valueOf(checkVersion(getDatabaseProductVersion()).split("\\.")[0]);
    }

    public int getDatabaseMinorVersion() throws SQLException {
        return Integer.valueOf(checkVersion(getDatabaseProductVersion()).split("\\.")[1]);
    }

    public int getJDBCMajorVersion() {
        return YasConstants.JDBC_MAJOR_VERSION;
    }

    public int getJDBCMinorVersion() {
        return YasConstants.JDBC_MINOR_VERSION;
    }

    public int getSQLStateType() {
        return sqlStateSQL;
    }

    public boolean locatorsUpdateCopy() {
        return true;
    }

    public boolean supportsStatementPooling() {
        return true;
    }

    public RowIdLifetime getRowIdLifetime() {
        return RowIdLifetime.ROWID_VALID_FOREVER;
    }

    public ResultSet getSchemas(String catalog, String schemaPattern) throws SQLException {
        String str = "select username as table_schem, null as table_catalog from all_users where "
            + " username like ? "
            + " order by table_schem";
        PreparedStatement stmt = this.connection.prepareStatement(str);
        if (schemaPattern != null) {
            stmt.setString(1, schemaPattern);
        } else {
            stmt.setString(1, "%");
        }
        stmt.closeOnCompletion();
        return stmt.executeQuery();
    }

    public boolean supportsStoredFunctionsUsingCallSyntax() {
        return true;
    }

    public boolean autoCommitFailureClosesAllResultSets() {
        return false;
    }

    public ResultSet getClientInfoProperties() throws SQLException {
        return emptyResult();
    }

    public ResultSet getFunctions(String catalog, String schemaPattern, String functionNamePattern)
            throws SQLException {
        String sql = "SELECT DECODE(PROCEDURE_NAME,\n"
                + "        NULL,\n"
                + "        NULL,\n"
                + "        object_name) AS FUNCTION_CAT,\n"
                + "        owner AS FUNCTION_SCHEM,\n"
                + "         DECODE(PROCEDURE_NAME,\n"
                + "        null,\n"
                + "        object_name,\n"
                + "        PROCEDURE_NAME) AS FUNCTION_NAME,\n"
                + "        DECODE(PROCEDURE_NAME,null,'Standalone function','Packaged function') AS remarks,"
                + " 0 AS FUNCTION_TYPE,  "
                + " DECODE(PROCEDURE_NAME,null,OBJECT_NAME,OBJECT_NAME||'.'||PROCEDURE_NAME) AS specific_name "
                + "FROM all_procedures proc\n"
                + "WHERE owner LIKE ? escape '/'\n"
                + "        AND EXISTS\n"
                + "    (SELECT *\n"
                + "    FROM all_arguments arg1\n"
                + "    WHERE (arg1.ARGUMENT_NAME is null\n"
                + "            OR length(arg1.ARGUMENT_NAME) = 0)\n"
                + "            AND arg1.IN_OUT = 'OUT'\n"
                + "            AND arg1.OBJECT_ID = proc.OBJECT_ID\n"
                + "            AND (arg1.SUBPROGRAM_ID = proc.SUBPROGRAM_ID\n"
                + "            OR (arg1.SUBPROGRAM_ID is null)))\n"
                + "        AND ( ( ? =1\n"
                + "        AND ((OBJECT_NAME LIKE ? ESCAPE '/'\n"
                + "        AND PROCEDURE_NAME is null)\n"
                + "        OR PROCEDURE_NAME LIKE ? ESCAPE '/' ))\n"
                + "        OR (? =2\n"
                + "        AND OBJECT_NAME LIKE ? ESCAPE '/'\n"
                + "        AND PROCEDURE_NAME is NULL )\n"
                + "        OR (? =3\n"
                + "        AND OBJECT_NAME LIKE ? ESCAPE '/'\n"
                + "        AND PROCEDURE_NAME LIKE ? ESCAPE '/' ))order by FUNCTION_CAT, FUNCTION_SCHEM, "
                + "FUNCTION_NAME ";
        PreparedStatement stmt = this.connection.prepareStatement(sql);
        int catalogType = catalog == null ? 1 : (catalog.equals("") ? 2 : 3);
        stmt.setString(1, getSchemaParam(schemaPattern));
        stmt.setInt(2, catalogType);
        stmt.setString(3, getLikeParam(functionNamePattern, "functionNamePattern"));
        stmt.setString(4, getLikeParam(functionNamePattern, "functionNamePattern"));
        stmt.setInt(5, catalogType);
        stmt.setString(6, getLikeParam(functionNamePattern, "functionNamePattern"));
        stmt.setInt(7, catalogType);
        stmt.setString(8, catalog);
        stmt.setString(9, getLikeParam(functionNamePattern, "functionNamePattern"));
        stmt.closeOnCompletion();

        return stmt.executeQuery();
    }

    public boolean isWrapperFor(Class<?> iface) {
        return iface.isAssignableFrom(getClass());
    }

    public <T> T unwrap(Class<T> iface) throws SQLException {
        if (iface.isAssignableFrom(getClass())) {
            return iface.cast(this);
        }
        throw new SQLException("Cannot unwrap to " + iface.getName());
    }

    public ResultSet getFunctionColumns(String catalog, String schemaPattern,
                                        String functionNamePattern, String columnNamePattern)
            throws SQLException {
        String decodeColumnType = " DECODE(arg.ARGUMENT_NAME, NULL, " + DatabaseMetaData.procedureColumnReturn + ",\n"
                + "DECODE(arg.in_out, 'IN', " + DatabaseMetaData.procedureColumnIn + ",\n"
                + "'OUT', " + DatabaseMetaData.procedureColumnOut + ",\n"
                + "'IN/OUT', " + DatabaseMetaData.procedureColumnInOut + ",\n"
                + DatabaseMetaData.procedureColumnUnknown + ")) ";

        String colType = getJDBCDataTypeClause("arg.data_type");

        String sql = "SELECT DECODE(arg.SUBPROGRAM_NAME,NULL,NULL,arg.object_name) AS FUNCTION_CAT,\n"
                + "       arg.owner AS FUNCTION_SCHEM,\n"
                + "       DECODE(arg.SUBPROGRAM_NAME,null,arg.object_name,arg.SUBPROGRAM_NAME) AS FUNCTION_NAME,\n"
                + "       arg.argument_name AS column_name,\n"
                + decodeColumnType + " AS column_type,\n"
                + colType
                + " AS data_type,\n"
                + "       arg.data_type AS type_name,\n"
                + "       DECODE (arg.data_precision, NULL, arg.data_length,\n"
                + "                               arg.data_precision) AS precision,\n"
                + "       arg.data_length AS length,\n"
                + "       arg.data_scale AS scale,\n"
                + "       10 AS radix,\n"
                + DatabaseMetaData.attributeNullable + " AS nullable,\n"
                + "       NULL AS remarks,\n"
                + "       arg.default_value AS column_def,\n"
                + "       NULL as sql_data_type,\n"
                + "       NULL AS sql_datetime_sub,\n"
                + "       DECODE(arg.data_type,\n"
                + "                         'CHAR', 8000,\n"
                + "                         'VARCHAR', 8000,\n"
                + "                         'RAW', 8000,\n"
                + "                         NULL) AS char_octet_length,\n"
                + "       arg.sequence - 1 AS ordinal_position,\n"
                + "       'YES' AS is_nullable,\n"
                + " DECODE(arg.SUBPROGRAM_NAME,null,arg.OBJECT_NAME,arg.OBJECT_NAME||'.'||arg.SUBPROGRAM_NAME) "
                + " AS specific_name"
                + " FROM all_arguments arg, all_procedures proc\n"
                + " WHERE arg.owner LIKE ? ESCAPE '/'\n"
                + " AND (( ? =1 and ((proc.OBJECT_NAME LIKE ?  ESCAPE '/' and proc.PROCEDURE_NAME is null) or "
                + "proc.PROCEDURE_NAME LIKE ?  ESCAPE '/' )) "
                + " OR (? =2 and proc.OBJECT_NAME LIKE ?  ESCAPE '/' and proc.PROCEDURE_NAME is null )"
                + " or (? =3 and proc.OBJECT_NAME LIKE ?  ESCAPE '/' and proc.PROCEDURE_NAME LIKE ?  ESCAPE '/' ))\n"
                + " AND arg.owner = proc.owner\n"
                + " AND (arg.SUBPROGRAM_ID = proc.SUBPROGRAM_ID OR arg.SUBPROGRAM_ID is null)\n"
                + " AND arg.object_id = proc.object_id\n"
                + " AND EXISTS(select * from all_arguments arg1  "
                + "     where (arg1.ARGUMENT_NAME  is null or length(arg1.ARGUMENT_NAME) = 0)"
                + "     and arg1.IN_OUT = 'OUT' "
                + "     and arg1.OBJECT_ID = arg.OBJECT_ID   "
                + "     and (arg1.SUBPROGRAM_ID = arg.SUBPROGRAM_ID or (arg1.SUBPROGRAM_ID is null))) \n"
                + "  AND (arg.argument_name LIKE ? ESCAPE '/'\n"
                + "       OR ((arg.ARGUMENT_NAME is null or length(arg.ARGUMENT_NAME) = 0)\n"
                + "           AND arg.IN_OUT = 'OUT'))\n"
                + "ORDER BY FUNCTION_CAT,FUNCTION_SCHEM, FUNCTION_NAME, SPECIFIC_NAME";

        PreparedStatement stmt = this.connection.prepareStatement(sql);
        int catalogType = catalog == null ? 1 : (catalog.equals("") ? 2 : 3);
        stmt.setString(1, getSchemaParam(schemaPattern));
        stmt.setInt(2, catalogType);
        stmt.setString(3, getLikeParam(functionNamePattern, "procedureNamePattern"));
        stmt.setString(4, getLikeParam(functionNamePattern, "procedureNamePattern"));

        stmt.setInt(5, catalogType);
        stmt.setString(6, getLikeParam(functionNamePattern, "procedureNamePattern"));

        stmt.setInt(7, catalogType);
        stmt.setString(8, catalog);
        stmt.setString(9, getLikeParam(functionNamePattern, "procedureNamePattern"));
        stmt.setString(10, getLikeParam(columnNamePattern, "columnNamePattern"));
        stmt.closeOnCompletion();
        return stmt.executeQuery();
    }

    public ResultSet getPseudoColumns(String catalog, String schemaPattern, String tableNamePattern,
                                      String columnNamePattern) throws SQLException {
        String sql =
                 " select * from(  select null as TABLE_CAT,\n"
                + "  owner as TABLE_SCHEM,\n"
                + "  table_name as TABLE_NAME,\n"
                + "  'ROWID' as COLUMN_NAME,\n"
                + "  -8 as DATA_TYPE,\n"
                + "  18 as COLUMN_SIZE,\n"
                + "  null as DECIMAL_DIGITS,\n"
                + "  10 as NUM_PREC_RADIX,\n"
                + "  'NO_USAGE_RESTRICTONS' as COLUMN_USAGE,\n"
                + "  null as REMARKS,\n"
                + "  null as CHAR_OCTET_LENGTH,\n"
                + "  'NO' as IS_NULLABLE\n"
                + "from all_tables\n"
                + "where\n"
                + "  owner like ? and\n"
                + "  table_name like ? ESCAPE '/'\n"
                + "  and 'ROWID' like ? ESCAPE '/'\n"
                + "union\n"
                + "  select null as TABLE_CAT,\n"
                + "  owner as TABLE_SCHEM,\n"
                + "  table_name as TABLE_NAME,\n"
                + "  'ROWNUM' as COLUMN_NAME,\n"
                + "  2 as DATA_TYPE,\n"
                + "  10 as COLUMN_SIZE,\n"
                + "  38 as DECIMAL_DIGITS,\n"
                + "  10 as NUM_PREC_RADIX,\n"
                + "  'NO_USAGE_RESTRICTONS' as COLUMN_USAGE,\n"
                + "  null as REMARKS,\n"
                + "  null as CHAR_OCTET_LENGTH,\n"
                + "  'NO' as IS_NULLABLE\n"
                + "from all_tables\n"
                + "where\n"
                + "  owner like ? and\n"
                + "  table_name like ? ESCAPE '/'"
                + "and 'ROWNUM' like ? ESCAPE '/'"
                + "union\n"
                + "  select null as TABLE_CAT,\n"
                + "  owner as TABLE_SCHEM,\n"
                + "  table_name as TABLE_NAME,\n"
                + "  'ROWSCN' as COLUMN_NAME,\n"
                + "  2 as DATA_TYPE,\n"
                + "  10 as COLUMN_SIZE,\n"
                + "  38 as DECIMAL_DIGITS,\n"
                + "  10 as NUM_PREC_RADIX,\n"
                + "  'NO_USAGE_RESTRICTONS' as COLUMN_USAGE,\n"
                + "  null as REMARKS,\n"
                + "  null as CHAR_OCTET_LENGTH,\n"
                + "  'NO' as IS_NULLABLE\n"
                + "from all_tables\n"
                + "where\n"
                + "  owner like ? and\n"
                + "  table_name like ? ESCAPE '/'\n"
                + "  and 'ROWSCN' like ? ESCAPE '/') order by TABLE_CAT,TABLE_SCHEM,TABLE_NAME,COLUMN_NAME \n";
        PreparedStatement stmt = this.connection.prepareStatement(sql);
        stmt.setString(1,getSchemaParam(schemaPattern));
        stmt.setString(2,getLikeParam(tableNamePattern,"tableNamePattern"));
        stmt.setString(3,getLikeParam(columnNamePattern,"columnNamePattern"));
        stmt.setString(4,getSchemaParam(schemaPattern));
        stmt.setString(5,getLikeParam(tableNamePattern,"tableNamePattern"));
        stmt.setString(6,getLikeParam(columnNamePattern,"columnNamePattern"));
        stmt.setString(7,getSchemaParam(schemaPattern));
        stmt.setString(8,getLikeParam(tableNamePattern,"tableNamePattern"));
        stmt.setString(9,getLikeParam(columnNamePattern,"columnNamePattern"));
        return stmt.executeQuery();
    }

    public long getMaxLogicalLobSize() {
        return 0;
    }

    public boolean supportsRefCursors() {
        return true;
    }

    /**
     * Create an empty resultSet for test
     * It should be replaced when the server side is ready.
     */
    ResultSet emptyResult() throws SQLException {
        String sql = "SELECT NULL AS TYPE_CAT, NULL AS TYPE_SCHEM, "
                + "NULL AS TYPE_NAME, NULL AS CLASS_NAME, 'STRUCT' AS DATA_TYPE, "
                + "NULL AS REMARKS FROM DUAL WHERE 1=2 ";

        Statement stmt = this.connection.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        stmt.closeOnCompletion();
        return rs;
    }

    protected boolean hasSqlWildcard(String sql) {
        Matcher matcher = sqlWildcardPattern.matcher(sql);
        return matcher.find();
    }

    protected String stripSqlEscapes(String sql) {
        if (sqlEscapePattern == null) {
            sqlEscapePattern = Pattern.compile("/");
        }

        Matcher matcher = sqlEscapePattern.matcher(sql);
        StringBuffer strBuffer = new StringBuffer();

        while (matcher.find()) {
            matcher.appendReplacement(strBuffer, "");
        }

        matcher.appendTail(strBuffer);
        return strBuffer.toString();
    }
}
