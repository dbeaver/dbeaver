/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

public class YasReturnResultSet extends ResultSetImpl {
    @Override
    public boolean next() throws SQLException {
        return super.next();
    }

    YasReturnResultSet(YasStatement statement) throws SQLException {
        super((YasConnection) statement.getConnection(),statement);
        this.setStmtQueryResult(true);

    }

    YasReturnResultSet(YasStatement statement, Field[] fields, RowData rows) throws SQLException {
        super((StatementImpl) statement, fields, rows, 1, 0, ResultSet.TYPE_FORWARD_ONLY,
                ResultSet.CONCUR_READ_ONLY, 0);
        this.setStmtQueryResult(true);

    }

    public void addRow(Row row) throws SQLException {
        rowData.addRow(row);
        this.maxRows++;
        this.currentRow = -1;
    }
}
