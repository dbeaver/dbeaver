/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.core.DataType;

/**
 * Field is a class used to describe fields in a ResultSet
 */
public class Field {
    private int id;
    private final int size; // Internal Length of this field
    private int yasType; // ID of the type
    private final int nullable;
    private final int precision;
    private final int scale;
    private final String name; // Column label

    /**
     * Construct a field based on the information fed to it.
     *
     * @param name       the name (column name and label) of the field
     * @param yasType the type of the field
     * @param size       the length of the field
     * @param nullable   this field is nullable
     * @param precision  the precision is the number of digits in a number
     * @param scale      the scale is the number of digits to the right of the decimal point in a number
     */
    public Field(int id, String name, int yasType, int size, int nullable, int precision, int scale) {
        this.id = id;
        this.name = name;
        this.yasType = yasType;
        this.size = size;
        this.nullable = nullable;
        this.precision = precision;
        this.scale = scale;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSize() {
        return size;
    }

    public int getYasType() {
        return yasType;
    }

    public void setYasType(int yasType) {
        this.yasType = yasType;
    }

    public int getNullable() {
        return nullable;
    }

    public int getPrecision() {
        return precision;
    }

    public int getScale() {
        return scale;
    }

    public String getName() {
        return name;
    }

    public String getTypeName() {
        return DataType.getTypeName(yasType);
    }

    public String toString() {
        return "Field("
                + "name=" + (name != null ? name : "")
                + ",type=" + getTypeName()
                + ",lenght=" + size
                + "," + (nullable == 1 ? "NULL ABLE" : "NOT NULL")
                + ",precision=" + precision
                + ",scale=" + scale
                + ")";
    }

    public int getSQLType() {
        return YasTypes.getSQLType(yasType);
    }
}
