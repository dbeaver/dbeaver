/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.YasConstants;
import com.yashandb.conf.YasProperty;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;

import java.io.PrintWriter;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Properties;

import javax.naming.NamingException;
import javax.naming.Reference;
import javax.naming.Referenceable;
import javax.naming.StringRefAddr;
import javax.sql.DataSource;

/*
 * YasDataSource is a factory for Connection objects.  An
 * object that implements the DataSource interface will typically be
 * registered with a JNDI service provider.
 */
public class YasDataSource implements DataSource, Referenceable, Serializable {
    private static final Logger LOGGER = LoggerFactory.getLogger(YasDataSource.class);

    private static final long serialVersionUID = 7624091928606233036L;
    YasDriver yasDriver = new YasDriver();

    protected PrintWriter logWriter = null;
    protected int loginTimeout = 0;

    // State Variables
    protected String databaseName = null;// SID
    protected String serviceName = null; // SERVICE_NAME
    protected String dataSourceName = "YasDataSource";
    protected String description = "YashanDB Connector/J Data Source";
    protected String networkProtocol = "tcp";
    protected int portNumber = Integer.valueOf(YasConstants.DEFAULT_PORT);
    protected String user = null;
    protected String password = null;
    protected String serverName = null;  // Server Name
    protected String url = null;
    protected String sslRootCer = null;
    protected Properties connectionProperties = null;

    @Override
    public Reference getReference() throws NamingException {
        Reference ref = new Reference(this.getClass().getName(),
                "com.yashandb.jdbc.YasDataSourceFactory",null);
        addRefProperties(ref);
        return ref;
    }

    protected void addRefProperties(Reference ref) {
        // Save all the properties that are set
        if (url != null) {
            ref.add(new StringRefAddr("url", url));
        }

        if (user != null) {
            ref.add(new StringRefAddr("user", user));
        }

        if (password != null ) {
            ref.add(new StringRefAddr("password", password));
        }

        if (description != null) {
            ref.add(new StringRefAddr("description", description));
        }

        if (serverName != null) {
            ref.add(new StringRefAddr("serverName", serverName));
        }

        if (databaseName != null) {
            ref.add(new StringRefAddr("databasename", databaseName));
        }

        if (networkProtocol != null) {
            ref.add(new StringRefAddr("networkProtocol", networkProtocol));
        }

        if (portNumber != 0) {
            ref.add(new StringRefAddr("portNumber", Integer.toString(portNumber)));
        }

        if (sslRootCer != null) {
            ref.add(new StringRefAddr("sslRootCer", sslRootCer));
        }
    }

    @Override
    public Connection getConnection() throws SQLException {
        return getConnection(this.user, this.password);
    }

    @Override
    public Connection getConnection(String username, String password) throws SQLException {
        Properties props = new Properties();
        if (connectionProperties != null && !connectionProperties.isEmpty()) {
            connectionProperties.stringPropertyNames().stream()
                    .forEach(k -> props.setProperty(k, connectionProperties.getProperty(k)));
        }

        if (username != null) {
            props.setProperty("user", username);
        } else {
            if (this.user != null) {
                props.setProperty("user", this.user);
            }
        }

        if (password != null) {
            props.setProperty("password", password);
        } else {
            if (this.password != null) {
                props.setProperty("password", this.password);
            }
        }

        if (loginTimeout != 0) {
            props.setProperty(YasProperty.LOGIN_TIMEOUT.getName(), "" + loginTimeout);
        }
        if (sslRootCer != null) {
            props.setProperty(YasProperty.SSL_ROOT_CER.getName(), sslRootCer);
        }
        return getConnection(props);
    }

    /**
     * Creates a connection using the specified properties.
     *
     * @param props
     *            the properties to connect with
     *
     * @return a connection to the database
     *
     * @throws SQLException
     *             if an error occurs
     */
    protected Connection getConnection(Properties props) throws SQLException {
        String url = this.url;
        if (url == null) {
            //Get URL from host port databaseName
            if (this.serverName != null && this.portNumber != 0 && this.databaseName != null ) {
                StringBuilder sbUrl = new StringBuilder(YasConstants.DEFAULT_DRIVER);
                sbUrl.append("//").append(serverName).append(":").append(portNumber);
                sbUrl.append("/").append(databaseName);
                url = sbUrl.toString();
            }
        }

        if (url == null) {
            //Get URL from host port databaseName
            url = props.getProperty("url","");
        }

        checkConnectionProp(url,props);
        return yasDriver.connect(url, props);
    }


    /**
     * Check the Connection properties and url before connect
     * @param url
     *            connection url
     * @param props
     *            the properties to connect with
     *
     * @throws SQLException
     *             if an error occurs
     */
    void checkConnectionProp(String url,Properties props) throws SQLException {
        String user = props.getProperty("user","");
        String password = props.getProperty("password","");

        if ( "".equalsIgnoreCase(user)) {
            throw SQLError.createSQLException("No connection user!Please set user.",
                    YasState.INVALID_PARAMETER_VALUE);
        }

        if ( "".equalsIgnoreCase(password)) {
            throw SQLError.createSQLException("No connection password!Please set password.",
                    YasState.INVALID_PARAMETER_VALUE);
        }

        if ( "".equalsIgnoreCase(url)) {
            throw SQLError.createSQLException("No connection URL!Please set URL.",
                    YasState.INVALID_PARAMETER_VALUE);
        }
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        return null;
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        return false;
    }

    @Override
    public PrintWriter getLogWriter() throws SQLException {
        return this.logWriter;
    }

    @Override
    public void setLogWriter(PrintWriter out) throws SQLException {
        this.logWriter = out;
    }

    public String getSslRootCer() {
        return sslRootCer;
    }

    public void setSslRootCer(String sslRootCer) {
        this.sslRootCer = sslRootCer;
    }

    @Override
    public synchronized void setLoginTimeout(int seconds) throws SQLException {
        this.loginTimeout = seconds;
    }

    @Override
    public synchronized int getLoginTimeout() throws SQLException {
        return loginTimeout;
    }

    @Override
    public java.util.logging.Logger getParentLogger() throws SQLFeatureNotSupportedException {
        return null;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Sets the database name.
     *
     * @param dbName
     *            the name of the database
     */
    public synchronized void setDatabaseName(String dbName) {
        this.databaseName = dbName;
    }

    /**
     * Gets the name of the database
     *
     * @return the name of the database for this data source
     */
    public synchronized String getDatabaseName() {
        return (this.databaseName != null) ? this.databaseName : "";
    }

    /**
     * Sets the password
     *
     * @param password
     *            the password
     */
    public synchronized void setPassword(String password) {
        this.password = password;
    }

    /**
     * Sets the port number
     *
     * @param port
     *            the port
     */
    public synchronized void setPortNumber(int port) {
        this.portNumber = port;
    }

    /**
     * Returns the port number
     *
     * @return the port number
     */
    public synchronized int getPortNumber() {
        return this.portNumber;
    }

    /**
     * Set the name of the Server on which database is  running.
     * If URL is set, this property will be ignored.
     *
     * @param sn server/host name to be set.
     */
    public synchronized void setServerName(String sn) {
        serverName = sn;
    }

    /**
     * Get the name of the server on which database is  running.
     *
     * @return server name set on this instance or null if not set.
     */
    public synchronized String getServerName() {
        return serverName;
    }

    /**
     * Sets the URL for this connection
     *
     * @param url
     *            the URL for this connection
     */
    public synchronized void setURL(String url) {
        this.url = url;
    }

    /**
     * Returns the URL for this connection
     *
     * @return the URL for this connection
     */
    public synchronized String getURL() {
        return this.url;
    }

    /**
     * Sets the user ID.
     *
     * @param userID
     *            the User ID
     */
    public synchronized void setUser(String userID) {
        this.user = userID;
    }

    /**
     * Returns the configured user for this connection
     *
     * @return the user for this connection
     */
    public synchronized String getUser() {
        return this.user;
    }

    public synchronized Properties getConnectionProperties() {
        return connectionProperties;
    }

    public synchronized void setConnectionProperties(Properties connectionProperties) {
        this.connectionProperties = connectionProperties;
    }

}
