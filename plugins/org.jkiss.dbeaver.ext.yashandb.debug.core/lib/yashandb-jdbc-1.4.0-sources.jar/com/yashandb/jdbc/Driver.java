/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.YasConstants;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * <p>The Java SQL framework allows for multiple database drivers. Each driver should supply a
 * class that implements the Driver interface</p>
 *
 * <p>The DriverManager will try to load as many drivers as it can find and then for any given
 * connection request, it will ask each driver in turn to try to connect to the target URL.</p>
 *
 * <p>It is strongly recommended that each Driver class should be small and standalone so that the
 * Driver class can be loaded and queried without bringing in vast quantities of supporting
 * code.</p>
 *
 * <p>When a Driver class is loaded, it should create an instance of itself and register it with
 * the DriverManager. This means that a user can load and register a driver by doing
 * Class.forName("foo.bah.Driver")</p>
 *
 * @see YasConnection
 * @see java.sql.Driver
 */
public class Driver extends YasDriver implements java.sql.Driver {

    private static Driver registeredDriver;

    static {
        try {
            register();
        } catch (SQLException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    /**
     * Register the driver against {@link DriverManager}. This is done automatically when the class is
     * loaded. Dropping the driver from DriverManager's list is possible using {@link #deregister()}
     * method.
     *
     * @throws IllegalStateException if the driver is already registered
     * @throws SQLException          if registering the driver fails
     */
    public static void register() throws SQLException {
        if (isRegistered()) {
            throw new IllegalStateException(
                    "Driver is already registered. It can only be registered once.");
        }
        Driver registeredDriver = new Driver();
        DriverManager.registerDriver(registeredDriver);
        Driver.registeredDriver = registeredDriver;
    }

    /**
     * According to JDBC specification, this driver is registered against {@link DriverManager} when
     * the class is loaded. To avoid leaks, this method allow unregistering the driver so that the
     * class can be gc'ed if necessary.
     *
     * @throws IllegalStateException if the driver is not registered
     * @throws SQLException          if deregistering the driver fails
     */
    public static void deregister() throws SQLException {
        if (!isRegistered()) {
            throw new IllegalStateException(
                    "Driver is not registered (or it has not been registered using Driver.register() method)");
        }
        DriverManager.deregisterDriver(registeredDriver);
        registeredDriver = null;
    }

    /**
     * @return {@code true} if the driver is registered against {@link DriverManager}
     */
    public static boolean isRegistered() {
        return registeredDriver != null;
    }

    public static void main(String[] args) {

        java.net.URL url = Driver.class.getResource("/com/yashandb/jdbc/Driver.class");
        System.out.printf("%n%s%n", YasConstants.DRIVER_FULL_NAME);
        System.out.printf("Found in: %s%n%n", url);

        System.out.printf("The YashanDB driver is not an executable Java program.%n%n"
                + "You must install it according to the JDBC driver installation "
                + "instructions for your application / container / appserver, "
                + "then use it by specifying a JDBC URL of the form %n    jdbc:yasdb:@%n"
                + "or using an application specific method.%n%n"
                + "This command has had no effect.%n");

        System.exit(1);
    }
}
