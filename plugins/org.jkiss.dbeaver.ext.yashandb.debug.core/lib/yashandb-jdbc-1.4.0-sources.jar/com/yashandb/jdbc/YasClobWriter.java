/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.YasConstants;

import java.io.IOException;
import java.io.Writer;
import java.sql.SQLException;

public class YasClobWriter extends Writer {

    private YasLargeObject largeObject = null;

    private StringBuilder stringBuilder = null;

    private long lobPos = 0L;

    private boolean isClosed = false;

    private void ensureOpen() throws IOException {
        if (isClosed) {
            throw new IOException("writer closed");
        }
    }

    YasClobWriter(YasLargeObject yasLargeObject, long lobPos) throws SQLException {
        this.largeObject = yasLargeObject;
        this.lobPos = lobPos;

        int stepSize = largeObject.getStepSize();
        if (stepSize > 0) {
            stringBuilder = new StringBuilder(stepSize);
        } else {
            stringBuilder = new StringBuilder(YasConstants.LONG_BIND_SIZE);
        }
    }

    @Override
    public void write(char[] cbuf, int off, int len) throws IOException {
        synchronized (this.lock) {
            ensureOpen();

            if (this.stringBuilder.length() >= this.stringBuilder.capacity()) {
                flush();
            }
            this.stringBuilder.append(cbuf, off, len);
        }
    }

    @Override
    public void flush() throws IOException {
        synchronized (this.lock) {
            ensureOpen();

            if (this.stringBuilder.length() > 0) {
                try {
                    String strValue = stringBuilder.toString();
                    this.largeObject.writeString(this.largeObject.getLobLength() + 1, strValue);
                } catch (Exception exception) {
                    throw new IOException(exception.getMessage());
                }
                this.stringBuilder.delete(0, this.stringBuilder.length());
            }
        }
    }

    @Override
    public void close() throws IOException {
        synchronized (this.lock) {
            if (isClosed) {
                return;
            }

            this.flush();
            isClosed = true;
        }
    }
}
