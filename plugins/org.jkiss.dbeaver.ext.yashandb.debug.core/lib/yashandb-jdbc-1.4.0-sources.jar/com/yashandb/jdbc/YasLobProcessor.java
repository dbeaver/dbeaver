/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.Session;
import com.yashandb.YasConstants;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.CharacterSet;

import java.sql.SQLException;

public class YasLobProcessor {

    // total lob data length
    private long lobLength = 0;

    private long lobCharLength = 0;

    private long startPos = 0;

    private long endPos = 0;

    private int chunkSize = 0;

    private static final int STEP_COUNT = 4;

    private byte[] stepBuffer = null;

    private byte[] lobLocator = null;

    private byte[] cacheData = null;

    private Session session = null;

    private int innerLobType = -1;

    private YasLargeObject yasLob = null;

    public static final int LOB_LOCATOR_KNL = 0;

    public static final int LOB_LOCATOR_TEMP = 1;

    public static final int LOB_LOCATOR_MEM = 2;

    public static final int LOB_LOCATOR_KNL_IN_ROW = 3;

    public static final int LOB_LOCATOR_TEMP_IN_ROW = 4;

    private static final int LOB_WRITE_APPEND_DATA_FLAG = -1;

    private int lobType = 0;

    private boolean updated = false;

    public int getInnerLobType() {
        return innerLobType;
    }

    public void setInnerLobType(int innerLobType) {
        this.innerLobType = innerLobType;
    }

    public YasLobProcessor() {
    }

    public long getLobLength() {
        return lobLength;
    }

    long getCharLength() throws SQLException {
        if (lobLength == 0) {
            return 0;
        }

        if (lobCharLength > 0) {
            return lobCharLength;
        }

        lobCharLength = 0;
        byte[] tmpBuffer = this.getStepByteBuffer();
        long bytesSize = lobLength;
        long starPos = 0;
        while (bytesSize > 0) {
            int readSize = this.getBytes(starPos, tmpBuffer);
            if (readSize <= 0) {
                break;
            }
            String strValue = new String(tmpBuffer, 0, readSize, CharacterSet.getCharSet(session.getCharset()));
            lobCharLength += strValue.length();
            bytesSize -= readSize;
            starPos += readSize;
        }

        return lobCharLength;
    }

    public int getStepSize() {
        if (chunkSize <= 0) {
            return 0;
        }
        return chunkSize * STEP_COUNT;
    }

    private void checkBufferSize() {
        if ((cacheData == null) || (cacheData.length < getStepSize())) {
            cacheData = new byte[getStepSize()];
        }
    }

    public int getBytes(long lobOffset, byte[] data) throws SQLException {
        if (data == null) {
            return 0;
        }

        if ((lobOffset >= startPos) && (lobOffset < endPos)) {
            int catchStart = (int)(lobOffset - startPos);
            int copyLen = Math.min(data.length, (int)(endPos - lobOffset));
            System.arraycopy(cacheData, catchStart, data, 0, copyLen);
            return copyLen;
        }

        if (lobOffset < lobLength) {
            checkBufferSize();
            int reqLen = getStepSize();
            if (reqLen > (lobLength - lobOffset)) {
                reqLen = (int)(lobLength - lobOffset);
            }
            int cacheDataLen = session.getLobData(this, reqLen, lobOffset, cacheData);
            startPos = lobOffset;
            endPos = lobOffset + cacheDataLen;

            int copyLen = Math.min(cacheDataLen, data.length);
            System.arraycopy(cacheData, 0, data, 0, copyLen);
            return copyLen;
        }

        return 0;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public void initCacheBuffer(int cacheLength) {
        this.cacheData = new byte[cacheLength];
    }

    public void setEndPos(long endPos) {
        this.endPos = endPos;
    }

    public void setCacheData(byte[] srcData, int srcPos, int dataLen) {
        if ((cacheData == null) || (cacheData.length < dataLen)) {
            this.cacheData = new byte[dataLen];
        }
        System.arraycopy(srcData, srcPos, cacheData, 0, dataLen);
    }

    public void setLobLocator(byte[] lobLocator) {
        this.lobLocator = lobLocator;
    }

    public byte[] getLobLocator() {
        if (lobLocator == null) {
            return null;
        }
        byte[] data = new byte[lobLocator.length];
        System.arraycopy(lobLocator, 0, data, 0, lobLocator.length);
        return data;
    }

    public void setLobLength(long lobLength) {
        this.lobLength = lobLength;
    }

    public void setChunkSize(int chunkSize) {
        this.chunkSize = chunkSize;
    }

    public long length() throws SQLException {
        return lobLength;
    }

    private byte[] getStepByteBuffer() {
        if (stepBuffer != null) {
            return stepBuffer;
        }

        int stepSize = this.getStepSize();
        if (this.getStepSize() > 0) {
            stepBuffer = new byte[stepSize];
        } else {
            stepBuffer = new byte[(int) lobLength];
        }

        return stepBuffer;
    }

    public byte[] getBytes(long pos, int length) throws SQLException {
        if ((pos < 1) || (length < 0)) {
            throw SQLError.createSQLException("invalid parameter", YasState.DATA_ERROR);
        }

        long start = pos - 1;
        if ((length == 0) || (lobLength == 0) || (start >= lobLength)) {
            return new byte[0];
        }

        int byteLen = (int) Math.min(length, lobLength);
        if (start + byteLen > lobLength) {
            byteLen = (int) (lobLength - start);
        }
        if (byteLen <= 0 ) {
            return new byte[0];
        }

        this.resetCache();
        byte[] stepBytes = this.getStepByteBuffer();
        byte[] dataBytes = new byte[byteLen];
        int dataIndex = 0;

        while (byteLen > 0) {
            int copyLen = this.getBytes(start, stepBytes);
            if (copyLen <= 0) {
                break;
            }

            if (copyLen > byteLen) {
                copyLen = byteLen;
            }

            System.arraycopy(stepBytes, 0, dataBytes, dataIndex, copyLen);
            start += copyLen;
            dataIndex += copyLen;
            byteLen -= copyLen;
        }

        return dataBytes;
    }

    private void resetCache() {
        if ((this.lobLocator != null) && (this.startPos != 0)) {
            this.startPos = 0;
            this.endPos = 0;
        }
    }

    public String getSubString(long pos, int length) throws SQLException {
        if ((pos < 1) || (length < 0)) {
            throw SQLError.createSQLException("invalid parameter", YasState.DATA_ERROR);
        }

        if ((lobLength > 0) && (lobCharLength <= 0)) {
            this.getCharLength();
        }

        long charStart = pos - 1;
        if ((length == 0) || (lobCharLength == 0) || (charStart >= lobCharLength)) {
            return "";
        }

        int strLen = (int) Math.min(length, lobCharLength);
        if (charStart + strLen > lobCharLength) {
            strLen = (int) (lobCharLength - charStart);
        }
        if (strLen <= 0) {
            return "";
        }

        resetCache();
        StringBuilder stringBuilder = new StringBuilder();

        byte[] strBytes = null;
        int stepSize = this.getStepSize();
        if (this.getStepSize() > 0) {
            strBytes = new byte[stepSize];
        } else {
            strBytes = new byte[(int) lobLength];
        }

        long byteStart = 0L;
        long readCharLen = 0L;
        String readStr = null;
        while (readCharLen < charStart + 1) {
            int bytesLen = this.getBytes(byteStart, strBytes);
            byteStart += bytesLen;

            readStr = new String(strBytes, 0, bytesLen, CharacterSet.getCharSet(session.getCharset()));
            readCharLen += readStr.length();
        }

        if (readStr.length() > 0) {
            stringBuilder.append(readStr.substring(readStr.length() - (int)(readCharLen - charStart)));
            strLen -= stringBuilder.length();
        }

        while (strLen > 0) {
            int bytesLen = this.getBytes(byteStart, strBytes);
            if (bytesLen <= 0) {
                break;
            }

            String strValue = new String(strBytes, 0, bytesLen, CharacterSet.getCharSet(session.getCharset()));
            stringBuilder.append(strValue);

            byteStart += bytesLen;
            strLen -= strValue.length();
        }

        if (strLen < 0) {
            return stringBuilder.substring(0, stringBuilder.length() + strLen);
        }

        return stringBuilder.toString();
    }

    public int setString(long pos, String str) throws SQLException {
        int strLength = str.length();
        if (strLength > YasConstants.LOB_WRITE_CHAR_STEP_LEN
                && (innerLobType == LOB_LOCATOR_KNL || innerLobType == LOB_LOCATOR_KNL_IN_ROW)) {
            return setStringByLobLocator(pos, str);
        }
        long reqPos = pos;
        int sendLen = 0;
        while (sendLen < strLength) {
            String reqString;
            if (strLength > sendLen + YasConstants.LOB_WRITE_CHAR_STEP_LEN) {
                reqString =  str.substring(sendLen, sendLen + YasConstants.LOB_WRITE_CHAR_STEP_LEN);
            } else {
                reqString =  str.substring(sendLen);
            }

            byte[] bytes = reqString.getBytes(CharacterSet.getCharSet(session.getCharset()));
            long bytesPos = reqPos - 1;
            this.lobLength = this.session.writeLob(this, bytesPos, bytes, 0, bytes.length);
            reqPos += YasConstants.LOB_WRITE_CHAR_STEP_LEN;
            sendLen += YasConstants.LOB_WRITE_CHAR_STEP_LEN;
        }
        this.innerLobType = this.lobLocator[0] & 0xFF;

        if (this.chunkSize <= 0) {
            this.chunkSize = this.session.getLobChunkSize(this);
        }

        this.startPos = 0;
        this.endPos = 0;
        this.lobCharLength = Math.max((pos + str.length() - 1), this.lobCharLength);
        this.updated = true;
        if (isKnlLob()) {
            this.session.addUpdatedKnlLob(this.yasLob);
        }
        return strLength;
    }

    public int appendString(String str) throws SQLException {
        int strLength = str.length();
        int sendLen = 0;
        while (sendLen < strLength) {
            String reqString;
            if (strLength > sendLen + YasConstants.LOB_WRITE_CHAR_STEP_LEN) {
                reqString =  str.substring(sendLen, sendLen + YasConstants.LOB_WRITE_CHAR_STEP_LEN);
            } else {
                reqString =  str.substring(sendLen);
            }
            byte[] bytes = reqString.getBytes(CharacterSet.getCharSet(session.getCharset()));
            this.lobLength = this.session.writeLob(this, LOB_WRITE_APPEND_DATA_FLAG, bytes, 0, bytes.length);
            sendLen += YasConstants.LOB_WRITE_CHAR_STEP_LEN;
        }
        this.innerLobType = this.lobLocator[0] & 0xFF;

        if (this.chunkSize <= 0) {
            this.chunkSize = this.session.getLobChunkSize(this);
        }

        this.lobCharLength += str.length();
        this.updated = true;
        if (isKnlLob()) {
            this.session.addUpdatedKnlLob(this.yasLob);
        }
        return strLength;
    }

    public int setBytes(long pos, byte[] bytes, int start, int length) throws SQLException {
        if (length > YasConstants.LOB_WRITE_STEP_LEN
                && (innerLobType == LOB_LOCATOR_KNL || innerLobType == LOB_LOCATOR_KNL_IN_ROW)) {
            return setBytesByLobLocator(pos, bytes, start, length);
        }

        long bytesPos = pos - 1;
        this.lobLength = this.session.writeLob(this, bytesPos, bytes, start, length);

        this.innerLobType = this.lobLocator[0] & 0xFF;

        if (this.chunkSize <= 0) {
            this.chunkSize = this.session.getLobChunkSize(this);
        }
        if (this.startPos > bytesPos) {
            this.resetCache();
        } else if (this.endPos > bytesPos ) {
            this.endPos = bytesPos;
        }
        this.updated = true;
        if (isKnlLob()) {
            this.session.addUpdatedKnlLob(this.yasLob);
        }
        return length;
    }

    public void free() throws SQLException {
        this.session.closeLob(this);
    }

    public void truncate(long len) throws SQLException {
        if ((len < 0L) || (len > this.lobLength)) {
            throw SQLError.createSQLException("invalid parameter", YasState.DATA_ERROR);
        }
        this.lobLength = this.session.trimLob(this, len);
        if (this.chunkSize <= 0) {
            this.chunkSize = this.session.getLobChunkSize(this);
        }
        if (this.startPos > this.lobLength) {
            this.resetCache();
        } else if (this.endPos > this.lobLength) {
            this.endPos = this.lobLength;
        }
        if (this.lobCharLength != 0) {
            this.lobCharLength = len;
        }
        this.updated = true;
        if (isKnlLob()) {
            this.session.addUpdatedKnlLob(this.yasLob);
        }
    }

    public boolean isUpdated() {
        return updated;
    }

    public void setUpdated(boolean updated) {
        this.updated = updated;
    }

    public int setStringByLobLocator(long pos, String str) throws SQLException {
        int strLength = str.length();
        YasClob tempClob = (YasClob)session.getConnection().createClob();
        try {
            tempClob.setString(1,str);

            byte[] bytes = tempClob.getLobLocator();
            long bytesPos = pos - 1;
            this.lobLength = this.session.writeLobByLobLocator(this, bytesPos, bytes);
            this.innerLobType = this.lobLocator[0] & 0xFF;

            if (this.chunkSize <= 0) {
                this.chunkSize = this.session.getLobChunkSize(this);
            }

            this.startPos = 0;
            this.endPos = 0;
            this.lobCharLength = Math.max((pos + str.length() - 1), this.lobCharLength);
            this.updated = true;
            if (isKnlLob()) {
                this.session.addUpdatedKnlLob(this.yasLob);
            }
            return strLength;
        } finally {
            tempClob.free();
        }
    }

    public int setBytesByLobLocator(long pos, byte[] bytes, int start, int length) throws SQLException {
        YasBlob tempBlob = (YasBlob)session.getConnection().createBlob();
        try {
            tempBlob.setBytes(1, bytes, start, length);

            byte[] reqLobLocator = tempBlob.getLobLocator();
            long bytesPos = pos - 1;
            this.lobLength = this.session.writeLobByLobLocator(this, bytesPos, reqLobLocator);

            this.innerLobType = this.lobLocator[0] & 0xFF;

            if (this.chunkSize <= 0) {
                this.chunkSize = this.session.getLobChunkSize(this);
            }
            if (this.startPos > bytesPos) {
                this.resetCache();
            } else if (this.endPos > bytesPos ) {
                this.endPos = bytesPos;
            }
            this.updated = true;
            if (isKnlLob()) {
                this.session.addUpdatedKnlLob(this.yasLob);
            }
            return length;
        } finally {
            tempBlob.free();
        }
    }

    public int getLobType() {
        return lobType;
    }

    public void setLobType(int lobType) {
        this.lobType = lobType;
    }

    public int getCsLobLocatorSize() {
        if (this.lobLocator != null) {
            return lobLocator.length;
        }
        if (session.getConnectVersion() == ConnectVersion.VER1) {
            return YasConstants.LOB_LOCATOR_SIZE_VER1;
        }
        return YasConstants.LOB_LOCATOR_SIZE;
    }

    public void setYasLob(YasLargeObject yasLob) {
        this.yasLob = yasLob;
    }

    private boolean isKnlLob() {
        if (innerLobType == LOB_LOCATOR_KNL || innerLobType == LOB_LOCATOR_KNL_IN_ROW) {
            return true;
        }
        return false;
    }
}
