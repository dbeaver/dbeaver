/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import java.sql.SQLException;

public class CachedResultSet extends ResultSetImpl {
    private boolean kept = false;

    CachedResultSet(StatementImpl creatorStmt, Field[] fields, RowData rows, int maxRows,
                    int maxFieldSize, int rsType, int rsConcurrency, int rsHoldability) throws SQLException {
        super(creatorStmt, fields, rows, maxRows, maxFieldSize, rsType, rsConcurrency, rsHoldability);
        this.setFetchSize(creatorStmt.getFetchSize());
        this.setFetchDirection(FETCH_FORWARD);
        this.setStmtQueryResult(true);

        this.rowData.cacheAllRows();
    }

    @Override
    public boolean isKept() {
        return kept;
    }

    @Override
    public void setKept(boolean kept) {
        this.kept = kept;
    }
}
