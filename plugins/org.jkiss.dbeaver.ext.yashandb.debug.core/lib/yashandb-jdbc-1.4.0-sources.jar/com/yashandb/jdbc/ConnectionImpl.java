/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.Session;
import com.yashandb.SessionImpl;
import com.yashandb.YasConstants;
import com.yashandb.conf.ConnectionUrl;
import com.yashandb.conf.HostSpec;
import com.yashandb.conf.YasProperty;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;
import com.yashandb.util.Messages;

import java.io.IOException;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLPermission;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Timer;
import java.util.concurrent.Executor;

public class ConnectionImpl implements YasConnection {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConnectionImpl.class);

    private Session session;

    private int rsHoldability = ResultSet.HOLD_CURSORS_OVER_COMMIT;

    private boolean autoCommit = true;

    private SQLWarning firstWarning = null;

    protected java.sql.DatabaseMetaData metadata;

    protected int defaultFetchSize;

    private final String creatingURL;

    private String serverType;

    private volatile Timer timer;

    protected Map<String, Class<?>> typemap = new HashMap<String, Class<?>>();

    private static final SQLPermission SQL_PERMISSION_ABORT = new SQLPermission("callAbort");

    private static final SQLPermission SQL_PERMISSION_NETWORK_TIMEOUT = new SQLPermission(
            "setNetworkTimeout");

    private int isolationLevel = Connection.TRANSACTION_READ_COMMITTED;

    private boolean readOnly = false;

    @Override
    public Statement createStatement() throws SQLException {
        return createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
    }

    @Override
    public PreparedStatement prepareStatement(String sql) throws SQLException {
        return prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
    }

    @Override
    public CallableStatement prepareCall(String sql) throws SQLException {
        return prepareCall(sql, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
    }

    @Override
    public String nativeSQL(String sql) throws SQLException {
        checkClosed();

        return sql;
    }

    @Override
    public synchronized Timer getTimer() {
        if (timer == null) {
            timer = new Timer("YashanDB Connection Timer", true);
        }
        return timer;
    }

    @Override
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        checkClosed();

        if (this.autoCommit == autoCommit) {
            return;
        }

        if (!this.autoCommit) {
            commit();
        }

        this.autoCommit = autoCommit;
        LOGGER.debug(" setAutoCommit = {}", autoCommit);

    }

    @Override
    public boolean getAutoCommit() throws SQLException {
        checkClosed();
        return this.autoCommit;
    }

    @Override
    public void commit() throws SQLException {
        checkClosed();

        if (autoCommit) {
            throw SQLError.createSQLException(Messages.get("Cannot commit when autoCommit is enabled."),
                    YasState.NO_ACTIVE_SQL_TRANSACTION);
        }

        if (session.getTransactionState() != TransactionState.XACT_END) {
            session.commit();
        }
    }

    @Override
    public void rollback() throws SQLException {
        checkClosed();

        if (autoCommit) {
            throw SQLError.createSQLException(Messages.get("Cannot rollback when autoCommit is enabled."),
                    YasState.NO_ACTIVE_SQL_TRANSACTION);
        }

        if (session.getTransactionState() != TransactionState.XACT_END) {
            session.rollback();
        } else {
            // just log for debugging
            LOGGER.debug("Rollback requested but no transaction in progress");
        }
    }

    @Override
    public YasDebugCallableStatement createDebugStatement(String sql, long objectId, int subprogramId,
                                                          int version) throws SQLException {
        checkClosed();
        if ((sql == null) || sql.trim().isEmpty()) {
            throw new SQLException("SQL String cannot be NULL or empty");
        }
        sql = sql.trim();

        return new YasDebugCallableStatement(this, sql, ResultSet.TYPE_FORWARD_ONLY,
                ResultSet.CONCUR_READ_ONLY, getHoldability(), objectId, subprogramId, version);
    }

    @Override
    public void close() throws SQLException {
        if (session == null || session.isClosed()) {
            return;
        }

        session.abortDebug();
        session.close();
        if (timer != null) {
            timer.cancel();
        }
    }

    @Override
    public boolean isClosed() throws SQLException {
        return session.isClosed();
    }

    @Override
    public DatabaseMetaData getMetaData() throws SQLException {
        checkClosed();
        if (metadata == null) {
            metadata = new YasDatabaseMetaData(this);
        }
        return metadata;
    }

    @Override
    public void setReadOnly(boolean readOnly) throws SQLException {
        checkClosed();
        synchronized (this) {
            if (this.getTransactionState() == TransactionState.IDLE
                    || this.getTransactionState() == TransactionState.XACT_END ) {
                this.readOnly = readOnly;
            } else {
                throw SQLError.createSQLException(
                        Messages.get("The readOnly cannot be changed during a transaction."),
                        YasState.ACTIVE_SQL_TRANSACTION);
            }
        }
    }

    @Override
    public boolean isReadOnly() throws SQLException {
        checkClosed();
        return readOnly;
    }

    @Override
    public void setCatalog(String catalog) throws SQLException {
        checkClosed();
    }

    @Override
    public String getCatalog() throws SQLException {
        checkClosed();
        return session.getDatabase();
    }

    @Override
    public void setTransactionIsolation(int level) throws SQLException {
        checkClosed();
        if (session.getTransactionState() != TransactionState.XACT_END) {
            throw SQLError.createSQLException(
                    Messages.get("Cannot change transaction isolation level in the middle of a transaction."),
                    YasState.ACTIVE_SQL_TRANSACTION);
        }

        if (level != Connection.TRANSACTION_READ_COMMITTED
                && level != Connection.TRANSACTION_SERIALIZABLE) {
            throw SQLError.createSQLException(
                    Messages.get("Only READ_COMMITTED and SERIALIZABLE are valid transaction isolation level"),
                    YasState.DATA_ERROR);
        }

        this.session.setTransactionIsolation(level);
        LOGGER.debug("setTransactionIsolation = {}", level);
        this.isolationLevel = level;
    }

    @Override
    public int getTransactionIsolation() throws SQLException {
        checkClosed();
        return this.isolationLevel;
    }

    @Override
    public synchronized SQLWarning getWarnings() throws SQLException {
        checkClosed();
        SQLWarning newWarnings = session.getWarnings(); // NB: also clears them.
        if (firstWarning == null) {
            firstWarning = newWarnings;
        } else {
            firstWarning.setNextWarning(newWarnings); // Chain them on.
        }

        return firstWarning;
    }

    @Override
    public void clearWarnings() throws SQLException {
        checkClosed();
        session.getWarnings(); // Clear and discard.
        firstWarning = null;
    }

    @Override
    public Statement createStatement(int resultSetType, int resultSetConcurrency)
            throws SQLException {
        checkClosed();
        return createStatement(resultSetType, resultSetConcurrency, getHoldability());
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
            throws SQLException {
        checkClosed();
        return prepareStatement(sql, resultSetType, resultSetConcurrency, getHoldability());
    }

    @Override
    public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
            throws SQLException {
        checkClosed();
        return prepareCall(sql, resultSetType, resultSetConcurrency, getHoldability());
    }

    @Override
    public Map<String, Class<?>> getTypeMap() throws SQLException {
        checkClosed();
        if (typemap == null) {
            typemap = new HashMap<String, Class<?>>();
        }
        return typemap;
    }

    @Override
    public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
        checkClosed();
        typemap = map;
        LOGGER.debug("setTypeMap = {}", map);
    }

    @Override
    public void setHoldability(int holdability) throws SQLException {
        checkClosed();

        switch (holdability) {
            case ResultSet.CLOSE_CURSORS_AT_COMMIT:
                rsHoldability = holdability;
                break;
            case ResultSet.HOLD_CURSORS_OVER_COMMIT:
                rsHoldability = holdability;
                break;
            default:
                throw SQLError.createSQLException(
                        Messages.get("Unknown ResultSet holdability setting: {0}.", holdability),
                        YasState.INVALID_PARAMETER_VALUE);
        }
        LOGGER.debug("setHoldability = {}", holdability);

    }

    @Override
    public int getHoldability() throws SQLException {
        checkClosed();
        return rsHoldability;
    }

    @Override
    public synchronized Savepoint setSavepoint() throws SQLException {
        checkClosed();

        if (autoCommit) {
            LOGGER.error("Can not set savepoint when autoCommit is enabled.");
            throw SQLError.createSQLException(Messages.get("Can not set savepoint when autoCommit is enabled."),
                    YasState.NO_ACTIVE_SQL_TRANSACTION);
        }

        return this.session.setSavepoint();
    }

    @Override
    public synchronized Savepoint setSavepoint(String name) throws SQLException {
        checkClosed();

        if (autoCommit) {
            LOGGER.error("Can not set savepoint when autoCommit is enabled.");
            throw SQLError.createSQLException(Messages.get("Can not set savepoint when autoCommit is enabled."),
                    YasState.NO_ACTIVE_SQL_TRANSACTION);
        }

        return this.session.setSavepoint(name);
    }

    @Override
    public synchronized void rollback(Savepoint savepoint) throws SQLException {
        checkClosed();

        if (autoCommit) {
            LOGGER.error("Can not rollback savepoint when autoCommit is enabled.");
            throw SQLError.createSQLException(Messages.get("Can not rollback savepoint when autoCommit is enabled."),
                    YasState.NO_ACTIVE_SQL_TRANSACTION);
        }

        if (savepoint == null) {
            return;
        }

        this.session.rollback(savepoint);
    }

    @Override
    public void releaseSavepoint(Savepoint savepoint) throws SQLException {
        checkClosed();
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "releaseSavepoint");
    }

    @Override
    public Statement createStatement(int resultSetType, int resultSetConcurrency,
                                     int resultSetHoldability) throws SQLException {
        checkClosed();
        return new StatementImpl(this, resultSetType, resultSetConcurrency, resultSetHoldability);
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency,
                                              int resultSetHoldability) throws SQLException {
        checkClosed();
        if ((sql == null) || sql.trim().isEmpty()) {
            throw new SQLException("SQL String cannot be NULL or empty");
        }
        sql = sql.trim();

        return new PreparedStatementImpl(this, sql, resultSetType, resultSetConcurrency,
                resultSetHoldability);
    }

    @Override
    public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency,
                                         int resultSetHoldability) throws SQLException {
        checkClosed();
        if ((sql == null) || sql.trim().isEmpty()) {
            throw new SQLException("SQL String cannot be NULL or empty");
        }
        sql = sql.trim();

        return new YasCallableStatement(this, sql,
                resultSetType, resultSetConcurrency, resultSetHoldability);
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
        ReturnResultSetMetaData autoKey = new ReturnResultSetMetaData(sql);
        if (autoGeneratedKeys != Statement.NO_GENERATED_KEYS && autoKey.isInsert()) {
            if (autoGeneratedKeys == Statement.RETURN_GENERATED_KEYS) {
                PreparedStatementImpl stmt = (PreparedStatementImpl) this.prepareStatement(autoKey.getNewSql());
                stmt.autoKey = autoKey;
                stmt.autoGeneratedKeys = true;
                stmt.returnParamCount = 1;
                stmt.registerReturnParamsForAutoKey();
                return stmt;
            } else {
                throw SQLError.createSQLException(Messages.get("Invalid argument(s) in call."),
                        YasState.INVALID_PARAMETER_TYPE);
            }
        } else {
            return this.prepareStatement(sql);
        }
    }

    @Override
    public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
        ReturnResultSetMetaData autoKey = new ReturnResultSetMetaData(sql,columnIndexes);
        if (!autoKey.isInsert()) {
            return prepareStatement(sql);
        } else if (columnIndexes != null && columnIndexes.length != 0) {
            this.doDescribeTable(autoKey);
            PreparedStatementImpl stmt = (PreparedStatementImpl) this.prepareStatement(autoKey.getNewSql());
            stmt.autoKey = autoKey;
            stmt.autoGeneratedKeys = true;
            stmt.returnParamCount = columnIndexes.length;
            stmt.registerReturnParamsForAutoKey();
            return stmt;
        } else {
            throw SQLError.createSQLException(Messages.get("Invalid argument(s) in call."),
                    YasState.INVALID_PARAMETER_TYPE);
        }

    }

    @Override
    public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
        ReturnResultSetMetaData autoKey = new ReturnResultSetMetaData(sql, columnNames);
        if (!autoKey.isInsert()) {
            return this.prepareStatement(sql);
        }
        if (columnNames != null && columnNames.length != 0) {
            this.doDescribeTable(autoKey);
            PreparedStatementImpl stmt = (PreparedStatementImpl) this.prepareStatement(autoKey.getNewSql());
            stmt.autoKey = autoKey;
            stmt.autoGeneratedKeys = true;
            stmt.returnParamCount = columnNames.length;
            stmt.registerReturnParamsForAutoKey();
            return stmt;
        }
        throw SQLError.createSQLException(Messages.get("Invalid argument(s) in call."),
                YasState.INVALID_PARAMETER_TYPE);

    }

    @Override
    public void doDescribeTable(ReturnResultSetMetaData autoKeys) throws SQLException {
        String tableName = autoKeys.getTableName();
        tableName = tableName.trim();
        String[] nameList = tableName.split("\\.");
        if (nameList.length != 1 && nameList.length != 2) {
            throw SQLError.createSQLException(Messages.get("Invalid argument(s) in call."),
                    YasState.INVALID_PARAMETER_TYPE);
        }
        DatabaseMetaData databaseMetaData = this.getMetaData();
        List<String> names = new ArrayList<>();
        List<Integer> types = new ArrayList<>();
        List<Integer> lens = new ArrayList<>();
        List<Boolean> nullables = new ArrayList<>();
        List<Integer> precs = new ArrayList<>();
        List<Integer> scales = new ArrayList<>();
        List<String> tnames = new ArrayList<>();

        int colCount = 0;
        ResultSet rs;
        if (nameList.length == 1) {
            rs = databaseMetaData.getColumns(null, getSchema(), nameList[0], null);
            // table without schema then autocomplete current session's schema
        } else {
            rs = databaseMetaData.getColumns(null, nameList[0], nameList[1], null);
        }
        while (rs.next()) {
            names.add(rs.getString("COLUMN_NAME"));
            types.add(YasTypes.getYasType(rs.getInt("DATA_TYPE")));
            lens.add(rs.getInt("COLUMN_SIZE"));
            nullables.add(rs.getBoolean("NULLABLE"));
            precs.add(rs.getInt("NUM_PREC_RADIX"));
            scales.add(rs.getInt("DECIMAL_DIGITS"));
            tnames.add(rs.getString("TYPE_NAME"));
            colCount++;
        }

        autoKeys.initDescribedData(colCount, names, types, lens, nullables,
            precs, scales, tnames);
    }

    @Override
    public Clob createClob() throws SQLException {
        checkClosed();
        YasClob clob = this.session.createClob();
        return clob;
    }

    @Override
    public Blob createBlob() throws SQLException {
        checkClosed();
        YasBlob blob = this.session.createBlob();
        return blob;
    }

    @Override
    public NClob createNClob() throws SQLException {
        checkClosed();
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "createNClob()");
    }

    @Override
    public SQLXML createSQLXML() throws SQLException {
        checkClosed();
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "createSQLXML()");
    }

    private synchronized int checkConnectValid(int timeout) {
        try {
            Statement statement = this.createStatement();
            Throwable throwable = null;
            try {
                statement.setQueryTimeout(timeout);
                statement.executeQuery("select 'x' from dual");
            } catch (Throwable queryThrow) {
                throwable = queryThrow;
                throw queryThrow;
            } finally {
                if (statement != null) {
                    if (throwable != null) {
                        try {
                            statement.close();
                        } catch (Throwable closeThrow) {
                            throwable.addSuppressed(closeThrow);
                        }
                    } else {
                        statement.close();
                    }
                }
            }

            return 0;
        } catch (SQLException sqlException) {
            return -1;
        }
    }

    @Override
    public boolean isValid(int timeout) throws SQLException {
        if (timeout < 0) {
            throw new SQLException("isValid timeout cannot be negative.");
        }

        if (isClosed()) {
            return false;
        }

        return checkConnectValid(timeout) == 0;
    }

    @Override
    public void setClientInfo(String name, String value) throws SQLClientInfoException {
        // TODO:
    }

    @Override
    public void setClientInfo(Properties properties) throws SQLClientInfoException {
        // TODO:
    }

    @Override
    public String getClientInfo(String name) throws SQLException {
        // TODO:
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getClientInfo()");
    }

    @Override
    public Properties getClientInfo() throws SQLException {
        // TODO:
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getClientInfo()");
    }

    @Override
    public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
        checkClosed();
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "createArrayOf()");
    }

    @Override
    public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
        checkClosed();
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "createStruct(String, Object[])");
    }

    @Override
    public void setSchema(String schema) throws SQLException {
        checkClosed();
        if ((schema == null) || schema.isEmpty()) {
            throw SQLError.createSQLException("invalid parameter", YasState.DATA_ERROR);
        }
        this.session.setSchema(schema);
    }

    @Override
    public String getSchema() throws SQLException {
        checkClosed();
        return this.session.getSchema();
    }

    @Override
    public void abort(Executor executor) throws SQLException {
        if (executor == null) {
            throw new SQLException("executor is null");
        }
        if (isClosed()) {
            return;
        }

        SQL_PERMISSION_ABORT.checkGuard(this);

        this.session.abort(executor);
    }

    @Override
    public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
        checkClosed();

        if (milliseconds < 0) {
            throw SQLError.createSQLException(
                    Messages.get("Network timeout must be a value greater than or equal to 0."),
                    YasState.INVALID_PARAMETER_VALUE);
        }

        SecurityManager securityManager = System.getSecurityManager();
        if (securityManager != null) {
            securityManager.checkPermission(SQL_PERMISSION_NETWORK_TIMEOUT);
        }

        try {
            session.setNetworkTimeout(milliseconds);
        } catch (IOException ioe) {
            throw SQLError.createSQLException(Messages.get("Unable to set network timeout."),
                    YasState.COMMUNICATION_ERROR, ioe);
        }
    }

    @Override
    public int getNetworkTimeout() throws SQLException {
        checkClosed();

        try {
            return session.getNetworkTimeout();
        } catch (IOException ioe) {
            throw SQLError.createSQLException(Messages.get("Unable to get network timeout."),
                    YasState.COMMUNICATION_ERROR, ioe);
        }
    }

    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        checkClosed();
        if (iface.isAssignableFrom(getClass())) {
            return iface.cast(this);
        }
        throw new SQLException("Cannot unwrap to " + iface.getName());
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        checkClosed();
        return iface.isAssignableFrom(getClass());
    }

    /*
     * implements of YasConnection
     */

    @Override
    public Map<String, String> getParameterStatuses() {
        return session.getParameterStatuses();
    }

    @Override
    public String getParameterStatus(String parameterName) {
        return session.getParameterStatus(parameterName);
    }

    @Override
    public void cancelQuery() throws SQLException {
        checkClosed();
        this.session.cancel();
    }

    @Override
    public Session getSession() {
        return session;
    }

    @Override
    public byte[] encodeString(String str) throws SQLException {
        return str.getBytes();
    }

    @Override
    public boolean getStandardConformingStrings() {
        return session.getStandardConformingStrings();
    }

    @Override
    public Logger getLogger() {
        return LOGGER;
    }

    @Override
    public TransactionState getTransactionState() {
        return session.getTransactionState();
    }

    @Override
    public String getServerType() {
        return this.serverType;
    }

    /*
     * internel method
     */

    protected void checkClosed() throws SQLException {
        if (isClosed()) {
            throw SQLError.createSQLException(Messages.get("This connection has been closed."),
                    YasState.CONNECTION_DOES_NOT_EXIST);
        }
    }

    public int getDefaultFetchSize() {
        return defaultFetchSize;
    }

    public String getURL() {
        return creatingURL;
    }

    public String getUserName() throws SQLException {
        return session.getUser();
    }

    public void setDefaultFetchSize(int fetchSize) throws SQLException {
        if (fetchSize < 0) {
            throw SQLError.createSQLException(Messages.get("Fetch size must be a value greater to or equal to 0."),
                    YasState.INVALID_PARAMETER_VALUE);
        }

        this.defaultFetchSize = fetchSize;
        LOGGER.debug("setDefaultFetchSize = {}", fetchSize);
    }

    private ResultSet execSQLQuery(String s) throws SQLException {
        return execSQLQuery(s, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
    }

    private ResultSet execSQLQuery(String s, int resultSetType, int resultSetConcurrency)
            throws SQLException {
        YasStatement stat = (YasStatement) createStatement(resultSetType, resultSetConcurrency);
        boolean hasResultSet = stat.executeInternal(s);

        while (!hasResultSet && stat.getUpdateCount() != -1) {
            hasResultSet = stat.getMoreResults();
        }

        if (!hasResultSet) {
            throw SQLError.createSQLException(Messages.get("No results were returned by the query."),
                    YasState.NO_DATA);
        }

        // Transfer warnings to the connection, since the user never
        // has a chance to see the statement itself.
        SQLWarning warnings = stat.getWarnings();
        if (warnings != null) {
            addWarning(warnings);
        }

        return stat.getResultSet();
    }

    public void addWarning(SQLWarning warn) {
        // Add the warning to the chain
        if (firstWarning != null) {
            firstWarning.setNextWarning(warn);
        } else {
            firstWarning = warn;
        }

    }

    private ConnectionImpl(ConnectionUrl connectionUrl) throws SQLException {
        HostSpec[] hostSpecs = connectionUrl.hostSpecs();
        if (hostSpecs == null) {
            throw SQLError.createSQLException(Messages.get("Invalid JDBC URL: {0}", connectionUrl.getUrl()),
                    YasState.INVALID_PARAMETER_VALUE);
        }

        String user = connectionUrl.user();
        String database = connectionUrl.database();
        Properties info = connectionUrl.getProps();

        // Print out the driver version number
        LOGGER.debug(YasConstants.DRIVER_FULL_NAME);

        this.creatingURL = connectionUrl.getUrl();

        this.serverType = connectionUrl.getServerType();

        setDefaultFetchSize(YasProperty.DEFAULT_ROW_FETCH_SIZE.getInt(info));

        // Now make the initial connection and set up local state
        this.session = new SessionImpl(this, hostSpecs, user, info);

        try {
            this.session.connect();
        } catch (SQLException e) {
            if (e.getMessage().contains("YAS-00410 protocol error, invalid login packet")
                    && this.session.getConnectVersion() != ConnectVersion.VER1) {
                this.session.setConnectVersion(ConnectVersion.VER1);
                this.session.connect();
            } else {
                throw e;
            }
        }
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        ConnectionImpl cloneConnection = (ConnectionImpl) super.clone();
        cloneConnection.autoCommit = false;

        cloneConnection.session = (Session) ((SessionImpl) this.session).clone();
        cloneConnection.session.setConnection(cloneConnection);

        return cloneConnection;
    }

    public static Connection getInstance(ConnectionUrl connectionUrl) throws SQLException {
        return new ConnectionImpl(connectionUrl);
    }
}
