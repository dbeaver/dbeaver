/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.YasResultSet;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;
import com.yashandb.util.YasSQL;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ResultSetFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResultSetFactory.class);

    public static YasResultSet createCachedResultSet(StatementImpl creatorStmt, Field[] fields, RowData rowData)
            throws SQLException {
        int resultSetType = creatorStmt.getResultSetType();
        int resultSetConcurrency = creatorStmt.getResultSetConcurrency();
        int maxRows = creatorStmt.getMaxRows();
        int maxFieldSize = creatorStmt.getMaxFieldSize();
        int rsHoldability = creatorStmt.getResultSetHoldability();

        return new CachedResultSet(creatorStmt, fields, rowData, maxRows, maxFieldSize, resultSetType,
                resultSetConcurrency, rsHoldability);
    }

    public static YasResultSet createResultSet(StatementImpl creatorStmt, Field[] fields, RowData rowData,
                                               int maxRows, int maxFieldSize, int rsType, int rsConcurrency,
                                               int rsHoldability) throws SQLException {
        ResultSetImpl newResult = null;
        int resultSetType = rsType;
        int resultSetConcurrency = rsConcurrency;
        if (creatorStmt.yasSQL != null
                && ( rsType == ResultSet.TYPE_SCROLL_SENSITIVE || rsConcurrency == ResultSet.CONCUR_UPDATABLE)) {
            YasSQL yasSQL = creatorStmt.yasSQL;
            // Clear the Statement yashanSQL
            creatorStmt.yasSQL = null;
            if (!yasSQL.canScrollSensitive() && rsType == ResultSet.TYPE_SCROLL_SENSITIVE) {
                //Downgrade ResultSetType
                if (!yasSQL.canScrollInSensitive()) {
                    resultSetType = ResultSet.TYPE_FORWARD_ONLY;
                    LOGGER.debug("Downgrade the ResultSet to TYPE_FORWARD_ONLY:" + yasSQL.getSQL());
                } else {
                    resultSetType = ResultSet.TYPE_SCROLL_INSENSITIVE;
                    LOGGER.debug("Downgrade the ResultSet to TYPE_SCROLL_INSENSITIVE:" + yasSQL.getSQL());
                }
                //To do:SQLWarn
            }

            if (!yasSQL.canUpdatable() && rsConcurrency == ResultSet.CONCUR_UPDATABLE) {
                //Downgrade ResultSet Concurrency
                resultSetConcurrency = ResultSet.CONCUR_READ_ONLY;
                LOGGER.debug("Downgrade the ResultSet to CONCUR_READ_ONLY:" + yasSQL.getSQL());
                //To do:SQLWarn
            }

            if (yasSQL.canRowID() && yasSQL.canScrollSensitive()
                    && resultSetType == ResultSet.TYPE_SCROLL_SENSITIVE) {
                newResult = new ScrollableSensitiveResultSet(creatorStmt, fields, rowData,
                        maxRows, maxFieldSize, resultSetType, resultSetConcurrency,
                        rsHoldability, yasSQL);
            } else if (yasSQL.canRowID() && yasSQL.canUpdatable()
                    && resultSetConcurrency == ResultSet.CONCUR_UPDATABLE) {
                newResult = new UpdatableResultSet(creatorStmt, fields, rowData,
                        maxRows, maxFieldSize, resultSetType, resultSetConcurrency,
                        rsHoldability, yasSQL);
            }
        }

        if (newResult == null) {
            newResult = new ResultSetImpl(creatorStmt, fields, rowData,
                    maxRows, maxFieldSize, resultSetType, resultSetConcurrency,
                    rsHoldability);
            newResult.setFetchSize(creatorStmt.getFetchSize());
            newResult.setFetchDirection(creatorStmt.getFetchDirection());
        }
        return newResult;
    }

}
