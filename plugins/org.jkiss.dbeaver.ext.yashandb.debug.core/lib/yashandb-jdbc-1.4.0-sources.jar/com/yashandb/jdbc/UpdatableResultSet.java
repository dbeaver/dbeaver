/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.protocol.accessor.Accessor;
import com.yashandb.util.Messages;
import com.yashandb.util.YasSQL;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class UpdatableResultSet extends ResultSetImpl {

    /*
        This UpdatableResultSet can support following type:
        TYPE_SCROLL_SENSITIVE   CONCUR_READ_ONLY
        TYPE_SCROLL_SENSITIVE   CONCUR_UPDATABLE
        TYPE_FORWARD_ONLY       CONCUR_UPDATABLE
        TYPE_SCROLL_INSENSITIVE CONCUR_UPDATABLE
     */
    protected YasSQL yasSQL = null;
    protected PreparedStatement updatePreparedStatement = null;
    protected PreparedStatement insertPreparedStatement = null;
    protected PreparedStatement deletePreparedStatement = null;
    protected PreparedStatement refreshPreparedStatement = null;

    // metadata for this resultset.
    protected Field[] originalfields;
    protected Row savedCurrentRow;
    ResultSetMetaData resultSetmetaData = null;
    protected int updateCount = 0;
    protected int deleteCount = 0;
    protected int insertCount = 0;

    public UpdatableResultSet(StatementImpl originalQuery, Field[] fields, RowData rows, int maxRows,
                       int maxFieldSize, int rsType, int rsConcurrency, int rsHoldability,
                              YasSQL yasSQL) throws SQLException {
        super(originalQuery, fields, rows, maxRows, maxFieldSize, rsType, rsConcurrency,rsHoldability);
        this.yasSQL = yasSQL;
        this.updatable = true;
        originalfields = this.fields;
        this.fields = detachRowIDFromFields(this.fields);
        this.accessors = detachRowIDFromAccessors(this.accessors);
        resultSetmetaData = getMetaData();
    }

    @Override
    public synchronized void moveToInsertRow() throws SQLException {
        checkUpdatable();
        this.onInsertRow = true;
        if (this.doingUpdates ) {
            // Clear update statement
            this.doingUpdates = false;
        }
        this.savedCurrentRow = this.thisRow;
    }

    @Override
    public void moveToCurrentRow() throws SQLException {
        checkClosed();
        // Cancel Insert
        synchronized (connection) {
            if (this.onInsertRow) {
                this.onInsertRow = false;
                this.thisRow = this.savedCurrentRow;
            }
            if (thisRow == null) {
                if (currentRow > -1) {
                    this.thisRow = this.rowData.getAt(currentRow);
                }
            }
        }
    }

    @Override
    protected void checkUpdatable() throws SQLException {
        super.checkUpdatable();
        if (!this.onInsertRow && !doingUpdates) {
            doingUpdates = true;
        }
    }

    @Override
    public synchronized void insertRow() throws SQLException {
        checkUpdatable();
        synchronized (connection) {
            if (!this.onInsertRow) {
                throw SQLError.createSQLException("Please move to insert row first", YasState.UNKNOWN_STATE);
            }
            if (updateValues.size() == 0) {
                throw SQLError.createSQLException("No data to insert", YasState.UNKNOWN_STATE);
            }
            boolean[] updateColumn = new boolean[resultSetmetaData.getColumnCount()];
            for (int i = 0; i < resultSetmetaData.getColumnCount(); i++) {
                if (this.updateValues.containsKey(resultSetmetaData.getColumnName(i + 1))) {
                    updateColumn[i] = true;
                } else {
                    updateColumn[i] = false;
                }
            }

            if (insertPreparedStatement != null) {
                insertPreparedStatement.close();
            }
            String insertSql = yasSQL.getInsertSQL(this.resultSetmetaData, updateColumn);
            insertPreparedStatement = this.connection.prepareStatement(insertSql);

            // Todo: Retruning RowID
            int setCount = 1;
            for (int i = 0; i < resultSetmetaData.getColumnCount(); i++) {
                if (updateColumn[i]) {
                    String columnName = resultSetmetaData.getColumnName(i + 1);
                    int scaleLength = updateScales.get(columnName) == null ? -1 : this.updateScales.get(columnName);
                    if (this.updateSQLTypes.containsKey(columnName)) {
                        insertPreparedStatement.setObject(setCount++,
                                this.updateValues.get(columnName),
                                updateSQLTypes.get(columnName),scaleLength);
                    } else {
                        insertPreparedStatement.setObject(setCount++,
                                this.updateValues.get(columnName),
                                resultSetmetaData.getColumnType(i + 1),scaleLength);
                    }
                }
            }
            insertCount = insertPreparedStatement.executeUpdate();
            insertPreparedStatement.close();
            insertPreparedStatement = null;

            // Cancel row insert
            clearRowBuffer(false);
            this.onInsertRow = false;
        }
    }

    @Override
    public void refreshRow() throws SQLException {
        refreshRow(((UpdatableRow)thisRow).getRowID());
        if (this.thisRow != null) {
            this.rowData.refreshRow(thisRow, this.currentRow);
        }
    }

    public void refreshRow(byte[] rowID) throws SQLException {
        if (refreshPreparedStatement == null) {
            String refreshSql = yasSQL.getRefreshSQL(this.resultSetmetaData);
            refreshPreparedStatement = this.connection.prepareStatement(refreshSql);
        }
        refreshPreparedStatement.setString(1,new YasRowID(rowID).toString());
        ResultSet rs = refreshPreparedStatement.executeQuery();
        if (rs.next()) {
            if ( this.thisRow == null) {
                this.thisRow = this.savedCurrentRow;
            }
            for (int i = 1; i < this.thisRow.data.length; i++) {
                this.thisRow.data[i] = rs.getBytes(i + 1);
            }
        } else {
            throw SQLError.createSQLException("Can't refresh the row data,may be the row is deleted",
                    YasState.UNKNOWN_STATE);
        }
        rs.close();
    }

    @Override
    public synchronized void updateRow() throws SQLException {
        checkUpdatable();
        synchronized (connection) {
            doUpdate();
            //Refresh Row
            if (updateCount > 0) {
                refreshRow();
            }
        }
    }

    public void doUpdate() throws SQLException {
        checkUpdatable();
        if ( this.onInsertRow) {
            throw SQLError.createSQLException("On insert row", YasState.UNKNOWN_STATE);
        } else if (!this.doingUpdates) {
            throw SQLError.createSQLException("No update data", YasState.UNKNOWN_STATE);
        } else if ( this.thisRow == null) {
            throw SQLError.createSQLException("Current row is invalid", YasState.UNKNOWN_STATE);
        }

        if (updateValues.size() == 0) {
            // No action should do
            return;
        }

        boolean[] updateColumn = new boolean[resultSetmetaData.getColumnCount()];
        for (int i = 0;i < resultSetmetaData.getColumnCount();i++) {
            if (this.updateValues.containsKey(resultSetmetaData.getColumnName(i + 1))) {
                updateColumn[i] = true;
            } else {
                updateColumn[i] = false;
            }
        }

        if ( updatePreparedStatement != null ) {
            updatePreparedStatement.close();
        }
        String updateSql = yasSQL.getUpdateSQL(this.resultSetmetaData,updateColumn);
        updatePreparedStatement = this.connection.prepareStatement(updateSql);

        int setCount = 1;
        for (int i = 0;i < resultSetmetaData.getColumnCount();i++) {
            if (updateColumn[i]) {
                String columnName = resultSetmetaData.getColumnName(i + 1);
                int scaleLength = updateScales.get(columnName) == null ? -1 : this.updateScales.get(columnName);
                if (this.updateSQLTypes.containsKey(columnName)) {
                    updatePreparedStatement.setObject(setCount++,
                            this.updateValues.get(columnName),
                            updateSQLTypes.get(columnName),scaleLength);
                } else {
                    updatePreparedStatement.setObject(setCount++,
                            this.updateValues.get(columnName),
                            resultSetmetaData.getColumnType(i + 1),scaleLength);
                }
            }
        }
        updatePreparedStatement.setString(setCount,new YasRowID(((UpdatableRow)thisRow).getRowID()).toString());
        updateCount = updatePreparedStatement.executeUpdate();
        updatePreparedStatement.close();
        updatePreparedStatement = null;

        //Clear Env
        this.doingUpdates = false;
        clearRowBuffer(false);
    }

    @Override
    public synchronized void updateNull(int columnIndex) throws SQLException {
        checkUpdatable();
        updateValues.put(resultSetmetaData.getColumnName(columnIndex), null);
    }

    @Override
    public synchronized void deleteRow() throws SQLException {
        checkUpdatable();
        synchronized (connection) {
            doDelete();
            if (deleteCount > 0) {
                this.thisRow = null;
                this.rowData.removeRow(this.currentRow);
                this.currentRow--;
            }
        }
    }

    public void doDelete() throws SQLException {
        checkUpdatable();
        if (onInsertRow) {
            throw SQLError.createSQLException("On insert row", YasState.UNKNOWN_STATE);
        } else if (this.rowDeleted() || this.thisRow == null) {
            throw SQLError.createSQLException("Current row is invalid", YasState.UNKNOWN_STATE);
        }

        if (deletePreparedStatement == null) {
            String deleteSql = yasSQL.getDeleteSQL();
            deletePreparedStatement = this.connection.prepareStatement(deleteSql);
        }
        deletePreparedStatement.setString(1,new YasRowID(((UpdatableRow)thisRow).getRowID()).toString());
        deleteCount = deletePreparedStatement.executeUpdate();
    }

    @Override
    public void cancelRowUpdates() throws SQLException {
        checkClosed();
        if (onInsertRow) {
            throw SQLError.createSQLException(Messages.get("Cannot call cancelRowUpdates() when on the insert row."),
                    YasState.INVALID_CURSOR_STATE);
        }

        if (doingUpdates) {
            doingUpdates = false;

            clearRowBuffer(true);
        }
    }

    public boolean rowDeleted() throws SQLException {
        checkClosed();
        return deleteCount > 0;
    }

    public boolean rowInserted() throws SQLException {
        checkClosed();
        return insertCount > 0;
    }

    public boolean rowUpdated() throws SQLException {
        checkClosed();
        return updateCount > 0;
    }

    @Override
    protected void closeInternally() throws SQLException {
        super.closeInternally();
        if (updatePreparedStatement != null ) {
            this.updatePreparedStatement.close();
        }

        if (insertPreparedStatement != null ) {
            this.insertPreparedStatement.close();
        }

        if (deletePreparedStatement != null ) {
            this.deletePreparedStatement.close();
        }

        if (refreshPreparedStatement != null ) {
            this.refreshPreparedStatement.close();
        }
    }

    Field[] detachRowIDFromFields(Field[] fields) {
        Field[] tempFields = new Field[fields.length - 1];
        System.arraycopy(fields,1,tempFields,0,fields.length - 1);
        return tempFields;
    }

    Accessor[] detachRowIDFromAccessors(Accessor[] accessors) {
        Accessor[] tempAccessors = new Accessor[accessors.length - 1];
        System.arraycopy(accessors,1,tempAccessors,0,accessors.length - 1);
        return tempAccessors;
    }

    private void clearUpdateCount() {
        this.updateCount = 0;
        this.insertCount = 0;
        this.deleteCount = 0;
    }

    @Override
    public boolean next() throws SQLException {
        clearUpdateCount();
        clearRowBuffer(false);
        onInsertRow = false;
        doingUpdates = false;

        return super.next();
    }

    @Override
    protected void prepareMove() throws SQLException {
        super.prepareMove();
        clearUpdateCount();
        clearRowBuffer(false);
        onInsertRow = false;
        doingUpdates = false;
    }

    @Override
    public boolean previous() throws SQLException {
        synchronized (this.connection) {
            boolean isDeleted = this.rowDeleted();
            if (isDeleted) {
                //Adjust previous after deleteRow
                checkScrollable();
                prepareMove();
                this.currentRow = this.rowData.getPosition();
                if (currentRow > -1) {
                    this.thisRow = this.rowData.getAt(currentRow);
                } else {
                    return false; // already before first
                }
            } else {
                return super.previous();
            }
            return true;
        }
    }

    protected void updateValue(int columnIndex, Object value, java.sql.SQLType targetSqlType,
                             int scaleOrLength) throws SQLException {
        checkUpdatable();
        if (!onInsertRow && (isBeforeFirst() || isAfterLast() || rowData.isEmpty())) {
            throw SQLError.createSQLException(
                    Messages.get(
                            "Cannot update the ResultSet because it is either before "
                                    + "the start or after the end of the results."),
                    YasState.INVALID_CURSOR_STATE);
        }
        checkColumnIndex(columnIndex);
        doingUpdates = !onInsertRow;
        ResultSetMetaData md = resultSetmetaData;
        if (value == null) {
            updateNull(columnIndex);
        } else {
            updateValues.put(md.getColumnName(columnIndex), value);
        }

        if (targetSqlType != null) {
            updateSQLTypes.put(md.getColumnName(columnIndex), targetSqlType);
        } else {
            updateSQLTypes.remove(md.getColumnName(columnIndex));
        }

        if (scaleOrLength != 0) {
            updateScales.put(md.getColumnName(columnIndex),scaleOrLength);
        } else {
            updateScales.remove(md.getColumnName(columnIndex));
        }
    }
}
