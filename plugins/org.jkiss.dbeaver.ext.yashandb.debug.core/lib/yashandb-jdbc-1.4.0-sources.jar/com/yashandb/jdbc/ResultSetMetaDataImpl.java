/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.YasConstants;
import com.yashandb.core.DataType;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.Messages;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;

public class ResultSetMetaDataImpl implements ResultSetMetaData {
    YasConnection connection;
    Field[] fields;

    private boolean fieldInfoFetched;

    public ResultSetMetaDataImpl(){

    }

    public ResultSetMetaDataImpl(YasConnection connection, Field[] fields) {
        this.connection = connection;
        this.fields = fields;
        this.fieldInfoFetched = false;
    }

    public int getColumnCount() throws SQLException {
        return fields.length;
    }

    public boolean isAutoIncrement(int column) throws SQLException {
        return false;
    }

    public boolean isCaseSensitive(int column) throws SQLException {
        int type = getColumnType(column);
        return type == Types.CHAR || type == Types.VARCHAR || type == Types.NCHAR
            || type == Types.NVARCHAR || type == Types.CLOB;
    }

    @Override
    public boolean isSearchable(int column) throws SQLException {
        int type = getColumnType(column);
        return (type != Types.LONGVARBINARY && type != Types.LONGVARCHAR && type != Types.BLOB
            && type != Types.CLOB && type != Types.NCLOB && type != Types.STRUCT
            && type != Types.ARRAY && type != Types.REF && type != Types.REF_CURSOR);
    }

    @Override
    public boolean isCurrency(int column) throws SQLException {
        int type = getColumnType(column);
        return type == Types.NUMERIC;
    }

    @Override
    public int isNullable(int column) throws SQLException {
        Field field = getField(column);
        return field == null ? ResultSetMetaData.columnNullable
            : field.getNullable() == 1 ? ResultSetMetaData.columnNullable
                : ResultSetMetaData.columnNoNulls;
    }

    @Override
    public boolean isSigned(int column) throws SQLException {
        return true;
    }

    @Override
    public int getColumnDisplaySize(int column) throws SQLException {
        Field field = getField(column);

        int sqlType = field.getSQLType();
        int precision = field.getPrecision();
        int scale = field.getScale();

        switch (sqlType) {
            case YasTypes.BOOLEAN:
                return YasConstants.MAX_SIZE_BOOL;
            case YasTypes.TINYINT:
                return YasConstants.MAX_SIZE_TINY_INT;
            case YasTypes.SMALLINT:
                return YasConstants.MAX_SIZE_SMALL_INT;
            case YasTypes.INTEGER:
                return YasConstants.MAX_SIZE_INT;
            case YasTypes.BIGINT:
                return YasConstants.MAX_SIZE_BIGINT;
            case YasTypes.ROWID:
                return YasConstants.MAX_SIZE_ROWID;

            case YasTypes.REAL:
                return YasConstants.MAX_SIZE_FLOAT;
            case YasTypes.DOUBLE:
                return YasConstants.MAX_SIZE_DOUBLE;

            case YasTypes.DATE:
            case YasTypes.TIME:
            case YasTypes.TIMESTAMP:
            case YasTypes.TIMESTAMP_TZ:
                return YasConstants.MAX_SIZE_DATE;

            case YasTypes.CHAR:
            case YasTypes.VARCHAR:
            case YasTypes.NCHAR:
            case YasTypes.NVARCHAR:
            case YasTypes.BIT:
                return field.getSize();

            case YasTypes.NUMBER: {
                if (scale > 0) {
                    if (precision > scale) {
                        // p + 1(.) + 1(sign)
                        return precision + 2;
                    } else {
                        // scale + 1(.) + 1(sign)
                        return scale + 2;
                    }
                } else {
                    if (scale == YasConstants.INVALID_NUMBER_SCALE) {
                        return YasConstants.MAX_SIZE_DEFAULT_NUMBER;
                    }

                    // p - s + 1(sign)
                    return precision - scale + 1;
                }
            }
            case YasTypes.DS_INTERVAL:
                return precision + YasConstants.EXTRA_SIZE_INTERVAL_DS + scale;

            case YasTypes.YM_INTERVAL:
                return precision + YasConstants.EXTRA_SIZE_INTERVAL_YM;

            default:
                return YasConstants.DEFAULT_DISPLAY_SIZE;
        }
    }

    @Override
    public String getColumnLabel(int column) throws SQLException {
        Field field1 = getField(column);
        return field1.getName();
    }

    @Override
    public String getColumnName(int column) throws SQLException {
        return getColumnLabel(column);
    }

    @Override
    public String getSchemaName(int column) throws SQLException {
        return "";
    }

    @Override
    public int getPrecision(int column) throws SQLException {
        Field field = getField(column);

        int sqlType = field.getSQLType();
        switch (sqlType) {
            case YasTypes.TINYINT:
                return 3;
            case YasTypes.SMALLINT:
                return 5;
            case YasTypes.INTEGER:
                return 10;
            case YasTypes.BIGINT:
                return 19;

            case YasTypes.CHAR:
            case YasTypes.VARCHAR:
            case YasTypes.NCHAR:
            case YasTypes.NVARCHAR:
            case YasTypes.BIT:
                return field.getSize();

            case YasTypes.NUMBER:
            case YasTypes.DS_INTERVAL:
            case YasTypes.YM_INTERVAL:
                return field.getPrecision();

            default:
                return 0;
        }
    }

    @Override
    public int getScale(int column) throws SQLException {
        Field field = getField(column);

        int sqlType = field.getSQLType();
        int scale = field.getScale();
        if ((scale < 0) && (sqlType != YasTypes.NUMBER)) {
            return 0;
        }
        return scale;
    }

    @Override
    public String getTableName(int column) throws SQLException {
        return "";
    }

    @Override
    public String getCatalogName(int column) throws SQLException {
        return "";
    }

    public int getColumnType(int column) throws SQLException {
        return getSQLType(column);
    }

    public String getColumnTypeName(int column) throws SQLException {
        Field field = getField(column);
        return field.getTypeName();
    }

    public boolean isReadOnly(int column) throws SQLException {
        return false;
    }

    public boolean isWritable(int column) throws SQLException {
        return true;
    }

    public boolean isDefinitelyWritable(int column) throws SQLException {
        return false;
    }

    protected Field getField(int columnIndex) throws SQLException {
        if (columnIndex < 1 || columnIndex > fields.length) {
            throw SQLError.createSQLException(
                    Messages.get("The column index is out of range: {0}, number of columns: {1}.",
                            columnIndex, fields.length),
                    YasState.INVALID_PARAMETER_VALUE);
        }
        return fields[columnIndex - 1];
    }

    protected int getSQLType(int columnIndex) throws SQLException {
        return fields[columnIndex - 1].getSQLType();
    }

    public String getColumnClassName(int column) throws SQLException {
        Field field = getField(column);
        if ( field.getYasType() == DataType.BIT && field.getSize() == 1 ) {
            return Boolean.class.getName();
        } else {
            return YasTypes.getTypeClassName(field.getYasType());
        }
    }

    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        return iface.isAssignableFrom(getClass());
    }

    public <T> T unwrap(Class<T> iface) throws SQLException {
        if (iface.isAssignableFrom(getClass())) {
            return iface.cast(this);
        }
        throw new SQLException("Cannot unwrap to " + iface.getName());
    }
}
