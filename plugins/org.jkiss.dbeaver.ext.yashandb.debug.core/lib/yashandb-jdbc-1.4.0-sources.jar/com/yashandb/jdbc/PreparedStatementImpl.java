/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.CancelQueryTask;
import com.yashandb.ParameterList;
import com.yashandb.Session;
import com.yashandb.SimpleParameterList;
import com.yashandb.YasConstants;
import com.yashandb.core.DataType;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.protocol.TypeConverter;
import com.yashandb.util.ByteStreamWriter;
import com.yashandb.util.Messages;
import com.yashandb.util.Utils;
import com.yashandb.util.YasEscapeProcessor;
import com.yashandb.util.YasTime;
import com.yashandb.util.YasTimestamp;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.JDBCType;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.util.ArrayList;
import java.util.Map;

class PreparedStatementImpl extends StatementImpl implements PreparedStatement {
    private YasParameterMetaData parameterMetaData;
    private String preparedSQL;

    PreparedStatementImpl(ConnectionImpl connection, String sql, int rsType, int rsConcurrency,
                          int rsHoldability) throws SQLException {
        super(connection, rsType, rsConcurrency, rsHoldability);
        setPoolable(true); // As per JDBC spec: prepared and callable statements are poolable by

        preparedSQL = YasEscapeProcessor.process(sql);
        if (this.resultsetConcurrency == ResultSet.CONCUR_UPDATABLE
                || this.resultsetType == ResultSet.TYPE_SCROLL_SENSITIVE) {
            this.yasSQL = buildYasSQL(preparedSQL);
            if (yasSQL.canUpdatable() || yasSQL.canScrollSensitive()) {
                //Rewrite Sql
                preparedSQL = yasSQL.getRowIDAppendSQL();
            }
        }
        serverPrepare(preparedSQL);
    }

    protected void serverPrepare(String sql) throws SQLException {
        connection.getSession().prepare(this, sql);
    }

    /*
     * A Prepared SQL query is executed and its ResultSet is returned
     *
     * @return a ResultSet that contains the data produced by the * query - never null
     *
     * @exception SQLException if a database access error occurs
     */
    @Override
    public ResultSet executeQuery() throws SQLException {
        executeInternal(0);
        return getQueryResultSet();
    }

    @Override
    public int executeUpdate() throws SQLException {
        executeInternal(Session.QUERY_NO_RESULTS);
        return getExecuteUpdateResult();
    }

    @Override
    public long executeLargeUpdate() throws SQLException {
        executeInternal(Session.QUERY_NO_RESULTS);
        return getExecuteLargeUpdateResult();
    }

    @Override
    public boolean execute() throws SQLException {
        return executeInternal(0);
    }

    private boolean executeInternal(int flags) throws SQLException {
        ParameterList[] parameterLists = null;
        if (preparedParameters != null) {
            parameterLists = new ParameterList[1];
            parameterLists[0] = preparedParameters;
        }
        synchronized (this) {
            checkClosed();
            closeForNextExecution();

            if (this.timeout > 0) {
                CancelQueryTask cancelQueryTask = null;
                try {
                    cancelQueryTask = startTimer();
                    this.currentResultSet = connection.getSession().execute(this, parameterLists, 0, 0, 0);
                } finally {
                    killTimerTask(cancelQueryTask);
                }
            } else {
                this.currentResultSet = connection.getSession().execute(this, parameterLists, 0, 0, 0);
            }

            return currentResultSet.reallyResult();
        }
    }

    public void setNull(int parameterIndex, int sqlType) throws SQLException {
        checkClosed();

        if (parameterIndex < 1 || parameterIndex > geParameters().getParameterCount()) {
            throw SQLError.createSQLException(
                    Messages.get("The column index is out of range: {0}, number of columns: {1}.",
                            parameterIndex, geParameters().getParameterCount()),
                    YasState.INVALID_PARAMETER_VALUE);
        }

        int yashanType = YasTypes.getYasType(sqlType);
        geParameters().setNull(parameterIndex, yashanType);
    }

    @Override
    public void setBoolean(int parameterIndex, boolean x) throws SQLException {
        checkClosed();
        geParameters().setIntParameter(parameterIndex, x ? 1 : 0, DataType.BOOLEAN);
    }

    public void setBit(int parameterIndex, Object x) throws SQLException {
        checkClosed();
        try {
            if ( x == null) {
                setNull(parameterIndex,Types.BIT);
            } else if (x instanceof Boolean) {
                byte[] bits = new byte[1];
                bits[0] = (byte)(((Boolean) x).booleanValue() ? 1 : 0);
                geParameters().setBinaryParameter(parameterIndex, bits, DataType.BIT);
            } else if (x instanceof byte[]) {
                geParameters().setBinaryParameter(parameterIndex, (byte[])x, DataType.BIT);
            } else if (x instanceof String) {
                setLong(parameterIndex, Long.parseLong((String) x));
            } else if (x instanceof Number) {
                setLong(parameterIndex, ((Number) x).longValue());
            } else {
                throw SQLError.TransformException(x.getClass().getName(), "Bit");
            }
        } catch (Exception e) {
            throw SQLError.TransformException(x.getClass().getName(), "Bit", e);
        }
    }

    @Override
    public void setByte(int parameterIndex, byte x) throws SQLException {
        checkClosed();
        geParameters().setIntParameter(parameterIndex, x, DataType.TINYINT);
    }

    @Override
    public void setShort(int parameterIndex, short x) throws SQLException {
        checkClosed();
        geParameters().setIntParameter(parameterIndex, x, DataType.SMALLINT);
    }

    @Override
    public void setInt(int parameterIndex, int x) throws SQLException {
        checkClosed();
        geParameters().setIntParameter(parameterIndex, x, DataType.INTEGER);
    }

    @Override
    public void setLong(int parameterIndex, long x) throws SQLException {
        checkClosed();
        geParameters().setIntParameter(parameterIndex, x, DataType.BIGINT);
    }

    @Override
    public void setFloat(int parameterIndex, float x) throws SQLException {
        checkClosed();
        geParameters().setFloatParameter(parameterIndex, x, DataType.FLOAT);
    }

    @Override
    public void setDouble(int parameterIndex, double x) throws SQLException {
        checkClosed();
        geParameters().setDoubleParameter(parameterIndex, x, DataType.DOUBLE);
    }

    public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
        setNumber(parameterIndex, x);
    }

    public void setString(int parameterIndex, String x) throws SQLException {
        checkClosed();
        if (x == null) {
            geParameters().setNull(parameterIndex, DataType.VARCHAR);
        } else {
            bindString(parameterIndex, x);
        }
    }

    @Override
    public void setBytes(int parameterIndex, byte[] x) throws SQLException {
        checkClosed();

        if ((null == x) || (x.length == 0)) {
            geParameters().setNull(parameterIndex, DataType.RAW);
            return;
        }

        byte[] copy = new byte[x.length];
        System.arraycopy(x, 0, copy, 0, x.length);
        geParameters().setBytea(parameterIndex, copy, 0, x.length);
    }

    private void setByteStreamWriter(int parameterIndex, ByteStreamWriter x) throws SQLException {
        geParameters().setBytea(parameterIndex, x);
    }

    public void setDate(int parameterIndex, java.sql.Date x) throws SQLException {
        geParameters().setDateParameter(parameterIndex, x, DataType.DATE);
    }

    public void setTime(int parameterIndex, Time x) throws SQLException {
        geParameters().setTimeParameter(parameterIndex, x, DataType.SHORTTIME);
    }

    public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
        geParameters().setTimeStampParameter(parameterIndex, x, DataType.TIMESTAMP);
    }

    private void setDsInterval(int parameterIndex, long interval) throws SQLException {
        geParameters().setDsIntervalParameter(parameterIndex, interval, DataType.DS_INTERVAL);
    }

    private void setYmInterval(int parameterIndex, int interval) throws SQLException {
        geParameters().setYmIntervalParameter(parameterIndex, interval, DataType.YM_INTERVAL);
    }

    public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
        checkClosed();
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setAsciiStream()");
    }

    public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
        checkClosed();
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setUnicodeStream()");
    }

    public void setBinaryStream(int parameterIndex, InputStream inputStream, int length) throws SQLException {
        checkClosed();
        if (length < 0) {
            throw SQLError.createSQLException(Messages.get("Invalid stream length {0}.", length),
                    YasState.INVALID_PARAMETER_VALUE);
        }

        if ((inputStream == null) || (length == 0)) {
            geParameters().setNull(parameterIndex, DataType.RAW);
            return;
        }

        geParameters().setBytea(parameterIndex, inputStream, length);
    }

    public void clearParameters() throws SQLException {
        checkClosed();
        if (preparedParameters != null) {
            preparedParameters.clear();
        }
        if (this.autoGeneratedKeys) {
            this.registerReturnParamsForAutoKey();
        }
    }

    private void setMap(int parameterIndex, Map<?, ?> x) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setMap");
    }

    private void setNumber(int parameterIndex, Number x) throws SQLException {
        checkClosed();
        if (x == null) {
            setNull(parameterIndex, Types.DECIMAL);
        } else {
            geParameters().setNumberParameter(parameterIndex, x, DataType.NUMBER);
        }
    }

    @Override
    public void setObject(int parameterIndex, Object in, int targetSqlType, int scale)
            throws SQLException {
        checkClosed();

        if (in == null) {
            setNull(parameterIndex, targetSqlType);
            return;
        }
        switch (targetSqlType) {
            case Types.INTEGER:
            case Types.TINYINT:
            case Types.SMALLINT:
                setInt(parameterIndex, TypeConverter.castToInt(in, targetSqlType));
                break;
            case Types.BIGINT:
                setLong(parameterIndex, TypeConverter.castToLong(in, targetSqlType));
                break;
            case Types.REAL:
                setFloat(parameterIndex, TypeConverter.castToFloat(in, targetSqlType));
                break;
            case Types.DOUBLE:
            case Types.FLOAT:
                setDouble(parameterIndex, TypeConverter.castToDouble(in, targetSqlType));
                break;
            case Types.DECIMAL:
            case Types.NUMERIC:
                setBigDecimal(parameterIndex, TypeConverter.castToBigDecimal(in, scale, targetSqlType));
                break;
            case Types.BOOLEAN:
                setBoolean(parameterIndex, TypeConverter.castToBoolean(in));
                break;
            case Types.BIT:
                setBit(parameterIndex, in);
                break;
            case Types.CHAR:
            case Types.VARCHAR:
            case Types.LONGVARCHAR:
            case YasTypes.JSON:
                setString(parameterIndex, TypeConverter.castToString(in, targetSqlType, scale));
                break;
            case Types.DATE:
                setDate(parameterIndex, TypeConverter.castToDate(in));
                break;
            case Types.TIME:
                setTime(parameterIndex, TypeConverter.castToTime(in));
                break;
            case Types.TIME_WITH_TIMEZONE:
                setTimeWithTimezone(parameterIndex, in);
                break;
            case Types.TIMESTAMP:
                setTimestamp(parameterIndex, TypeConverter.castToTimeStamp(in));
                break;
            case Types.TIMESTAMP_WITH_TIMEZONE:
                setTimestampWithTimezone(parameterIndex, in);
                break;
            case YasTypes.DS_INTERVAL:
                setDsInterval(parameterIndex, TypeConverter.castToDsInterval(in));
                break;
            case YasTypes.YM_INTERVAL:
                setYmInterval(parameterIndex, TypeConverter.castToYmInterval(in));
                break;
            case Types.BINARY:
            case Types.VARBINARY:
            case Types.LONGVARBINARY:
                setBinary(parameterIndex, in, targetSqlType, scale);
                break;
            case Types.NCHAR:
            case Types.NVARCHAR:
            case Types.LONGNVARCHAR:
                setNString(parameterIndex, (String) in);
                break;
            case Types.BLOB:
                setBlob(parameterIndex, in);
                break;
            case Types.CLOB:
                setClob(parameterIndex, in);
                break;
            case Types.ARRAY:
                setArray(parameterIndex, in);
                break;
            case Types.REF:
                setRef(parameterIndex, in);
                break;
            case Types.DATALINK:
                setURL(parameterIndex, in);
                break;
            case Types.NCLOB:
                setNClob(parameterIndex, in);
                break;
            case Types.SQLXML:
                setSQLXML(parameterIndex, in);
                break;
            case Types.DISTINCT:
                bindString(parameterIndex, in.toString());
                break;
            case Types.ROWID:
                setRowId(parameterIndex, in);
                break;
            case Types.OTHER:
                if (in instanceof Map) {
                    setMap(parameterIndex, (Map<?, ?>) in);
                } else {
                    bindString(parameterIndex, in.toString());
                }
                break;
            default:
                throw SQLError.createSQLException(Messages.get("Unsupported Types value: {0}", targetSqlType),
                        YasState.INVALID_PARAMETER_TYPE);
        }
    }

    public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
        setObject(parameterIndex, x, targetSqlType, -1);
    }

    /*
     * This stores an Object into a parameter.
     */
    public void setObject(int parameterIndex, Object x) throws SQLException {
        checkClosed();
        if (x == null) {
            setNull(parameterIndex, Types.OTHER);
        } else if (x instanceof String) {
            setString(parameterIndex, (String) x);
        } else if (x instanceof BigDecimal) {
            setBigDecimal(parameterIndex, (BigDecimal) x);
        } else if (x instanceof Short) {
            setShort(parameterIndex, (Short) x);
        } else if (x instanceof Integer) {
            setInt(parameterIndex, (Integer) x);
        } else if (x instanceof Long) {
            setLong(parameterIndex, (Long) x);
        } else if (x instanceof Float) {
            setFloat(parameterIndex, (Float) x);
        } else if (x instanceof Double) {
            setDouble(parameterIndex, (Double) x);
        } else if (x instanceof byte[]) {
            setBytes(parameterIndex, (byte[]) x);
        } else if (x instanceof ByteStreamWriter) {
            setByteStreamWriter(parameterIndex, (ByteStreamWriter) x);
        } else if (x instanceof java.sql.Date) {
            setDate(parameterIndex, (java.sql.Date) x);
        } else if (x instanceof Time) {
            setTime(parameterIndex, (Time) x);
        } else if (x instanceof Timestamp) {
            setTimestamp(parameterIndex, (Timestamp) x);
        } else if (x instanceof Boolean) {
            setBoolean(parameterIndex, (Boolean) x);
        } else if (x instanceof Byte) {
            setByte(parameterIndex, (Byte) x);
        } else if (x instanceof Blob) {
            setBlob(parameterIndex, (Blob) x);
        } else if (x instanceof Clob) {
            setClob(parameterIndex, (Clob) x);
        } else if (x instanceof Array) {
            setArray(parameterIndex, (Array) x);
        } else if (x instanceof Character) {
            setString(parameterIndex, ((Character) x).toString());
        } else if (x instanceof java.time.LocalDate) {
            setDate(parameterIndex, (java.time.LocalDate) x);
        } else if (x instanceof java.time.LocalTime) {
            setTime(parameterIndex, (java.time.LocalTime) x);
        } else if (x instanceof java.time.LocalDateTime) {
            setTimestamp(parameterIndex, (java.time.LocalDateTime) x);
        } else if (x instanceof java.time.OffsetDateTime) {
            setTimestamp(parameterIndex, (java.time.OffsetDateTime) x);
        } else if (x instanceof Map) {
            setMap(parameterIndex, (Map<?, ?>) x);
        } else if (x instanceof Number) {
            setNumber(parameterIndex, (Number) x);
        } else if (x instanceof Reader) {
            setCharacterStream(parameterIndex,(Reader) x);
        } else if (x instanceof InputStream) {
            setBinaryStream(parameterIndex,(InputStream) x);
        } else if (x instanceof SQLXML) {
            setSQLXML(parameterIndex,(SQLXML) x);
        } else if (x instanceof RowId) {
            setRowId(parameterIndex,(RowId) x);
        } else if (x instanceof Ref) {
            setRef(parameterIndex,(Ref) x);
        } else {
            // Can't infer a type.
            throw SQLError.createSQLException(Messages.get(
                    "Can''t infer the SQL type to use for an instance of {0}."
                            + " Use setObject() with an explicit Types value to specify the type to use.",
                    x.getClass().getName()), YasState.INVALID_PARAMETER_TYPE);
        }
    }

    /**
     * Returns the SQL statement with the current template values substituted.
     *
     * @return SQL statement with the current template values substituted
     */
    public String toString() {
        return super.toString();
    }

    /**
     * This version is for values that should turn into strings e.g. setString directly calls
     * bindString with no escaping; the per-protocol ParameterList does escaping as needed.
     *
     * @param paramIndex parameter index
     * @param s          value
     * @throws SQLException if something goes wrong
     */
    private void bindString(int paramIndex, String s) throws SQLException {
        geParameters().setStringParameter(paramIndex, s);
    }

    @Override
    public void addBatch(String sql) throws SQLException {
        checkClosed();

        throw SQLError.createSQLException(
                Messages.get("Can''t use query methods that take a query string on a PreparedStatement."),
                YasState.WRONG_OBJECT_TYPE);
    }

    @Override
    public synchronized void addBatch() throws SQLException {
        checkClosed();
        if (batchParameters == null) {
            batchParameters = new ArrayList<>();
        }
        // we need to create copies of our parameters, otherwise the values can be changed
        if ( batchParameters.size() >= Short.MAX_VALUE) {
            throw SQLError.createSQLException(
                    "Can not add batch more than " + Short.MAX_VALUE,
                    YasState.WRONG_OBJECT_TYPE);
        }

        if ( this.preparedParameters != null) {
            batchParameters.add(geParameters().copy());
        } else {
            super.addBatch(this.preparedSQL);
        }
    }

    public ResultSetMetaData getMetaData() throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getMetaData");
    }

    public void setArray(int i, java.sql.Array x) throws SQLException {
        checkClosed();
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setArray()");
    }

    public void setArray(int i, Object x) throws SQLException {
        if (x instanceof Array) {
            setArray(i, (Array) x);
        } else {
            throw SQLError.TransformException(x.getClass().getName(), "ARRAY");
        }
    }

    @Override
    public void setBlob(int i, Blob x) throws SQLException {
        checkClosed();
        geParameters().setBlobParameter(i, x, DataType.BLOB);
    }

    private void setBlob(int parameterIndex, Object in) throws SQLException {
        if (in instanceof Blob) {
            setBlob(parameterIndex, (Blob) in);
        } else if (in instanceof InputStream) {
            setBlob(parameterIndex, (InputStream) in);
        } else {
            throw SQLError.TransformException(in.getClass().getName(),"BLOB");
        }
    }

    private String readerToString(Reader value, int maxLength) throws SQLException {
        try {
            int bufferSize = Math.min(maxLength, 1024);
            StringBuilder v = new StringBuilder(bufferSize);
            char[] buf = new char[bufferSize];
            int nRead = 0;
            while (nRead > -1 && v.length() < maxLength) {
                nRead = value.read(buf, 0, Math.min(bufferSize, maxLength - v.length()));
                if (nRead > 0) {
                    v.append(buf, 0, nRead);
                }
            }
            return v.toString();
        } catch (IOException ioe) {
            throw SQLError.createSQLException(Messages.get("Provided Reader failed."), YasState.UNEXPECTED_ERROR,
                    ioe);
        }
    }

    public void setCharacterStream(int i, java.io.Reader x, int length) throws SQLException {
        checkClosed();

        if (x == null) {
            setNull(i, Types.VARCHAR);
            return;
        }

        if (length < 0) {
            throw SQLError.createSQLException(Messages.get("Invalid stream length {0}.", length),
                    YasState.INVALID_PARAMETER_VALUE);
        }

        setString(i, readerToString(x, length));
    }

    @Override
    public void setClob(int i, Clob x) throws SQLException {
        checkClosed();
        geParameters().setClobParameter(i, x, DataType.CLOB);
    }

    private void setClob(int i, Object x) throws SQLException {
        if (x instanceof Clob) {
            setClob(i, (Clob) x);
        } else if (x instanceof Reader) {
            setClob(i, (Reader) x);
        } else {
            throw SQLError.TransformException(x.getClass().getName(), "CLOB");
        }
    }

    /*
     * Sets the designated parameter to SQL NULL.  This version of setNull should
     * be used for STRUCT, ARRAY and REF type parameters.
     * @param paramIndex the first parameter is 1, the second is 2, ...
     * @param sqlType a value from java.sql.Types
     * @param sqlName the fully-qualified name of an SQL user-named type,
     * ignored if the parameter is not a user-named type or REF
     * @exception SQLException if a database access error occurs
     */
    public void setNull(int parameterIndex, int sqlType, String typeName) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setNull()");
    }

    public void setRef(int i, Ref x) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setRef(int,Ref)");
    }

    public void setRef(int parameterIndex, Object in) throws SQLException {
        if (in instanceof Ref) {
            setRef(parameterIndex, (Ref) in);
        } else {
            throw SQLError.TransformException(in.getClass().getName(), "REF");
        }
    }

    public void setURL(int parameterIndex, Object in) throws SQLException {
        if (in instanceof Ref) {
            setURL(parameterIndex, (URL) in);
        } else {
            throw SQLError.TransformException(in.getClass().getName(), "DATALINK");
        }
    }

    public void setNClob(int parameterIndex, Object in) throws SQLException {
        if (in instanceof NClob) {
            setNClob(parameterIndex, (NClob) in);
        } else {
            throw SQLError.TransformException(in.getClass().getName(), "NCLOB");
        }
    }

    public void setSQLXML(int parameterIndex, Object in) throws SQLException {
        if (in instanceof SQLXML) {
            setSQLXML(parameterIndex, (SQLXML) in);
        } else {
            throw SQLError.TransformException(in.getClass().getName(), "SQLXML");
        }
    }

    public void setRowId(int parameterIndex, Object in) throws SQLException {
        if (in instanceof RowId) {
            setRowId(parameterIndex, (RowId) in);
        } else {
            throw SQLError.TransformException(in.getClass().getName(), "ROWID");
        }
    }

    public void setDate(int i, java.sql.Date d, java.util.Calendar cal) throws SQLException {
        setDate(i, d);
    }

    public void setTime(int i, Time t, java.util.Calendar cal) throws SQLException {
        setTime(i,t);
    }

    public void setTimestamp(int i, Timestamp t, java.util.Calendar cal) throws SQLException {
        setTimestamp(i, t);
    }

    private void setDate(int i, java.time.LocalDate localDate) throws SQLException {
        if (localDate == null) {
            geParameters().setNull(i,DataType.DATE);
        } else {
            setDate(i, Date.valueOf(localDate));
        }
    }

    private void setTime(int i, java.time.LocalTime localTime) throws SQLException {
        if (localTime == null) {
            geParameters().setNull(i,DataType.SHORTTIME);
        } else {
            setTime(i, YasTime.valueOf(localTime));
        }
    }

    private void setTimestamp(int i, java.time.LocalDateTime localDateTime) throws SQLException {
        if (localDateTime == null) {
            geParameters().setNull(i,DataType.TIMESTAMP);
        } else {
            setTimestamp(i, Timestamp.valueOf(localDateTime));
        }
    }

    private void setTimestamp(int i, java.time.OffsetDateTime offsetDateTime) throws SQLException {
        if (offsetDateTime == null) {
            geParameters().setNull(i,DataType.TIMESTAMP);
        } else {
            setTimestamp(i, Timestamp.valueOf(offsetDateTime.toLocalDateTime()));
        }
    }

    private YasParameterMetaData createParameterMetaData() throws SQLException {
        return new YasParameterMetaData(connection, parameterFields);
    }

    public void setObject(int parameterIndex, Object x, java.sql.SQLType targetSqlType,
                          int scaleOrLength) throws SQLException {
        setObject(parameterIndex,x,targetSqlType.getVendorTypeNumber(),scaleOrLength );
    }

    public void setObject(int parameterIndex, Object x, java.sql.SQLType targetSqlType)
            throws SQLException {
        setObject(parameterIndex,x,targetSqlType.getVendorTypeNumber() );
    }

    public void setRowId(int parameterIndex, RowId x) throws SQLException {
        checkClosed();

        if (x == null) {
            geParameters().setNull(parameterIndex, DataType.ROWID);
            return;
        }

        geParameters().setRowIdParameter(parameterIndex, x);
    }

    public void setNString(int parameterIndex, String value) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setNString(int, String)");
    }

    public void setNCharacterStream(int parameterIndex, Reader value, long length)
            throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setNCharacterStream(int, Reader, long)");
    }

    public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setNCharacterStream(int, Reader)");
    }

    public void setCharacterStream(int parameterIndex, Reader value, long length)
            throws SQLException {
        if (length > Integer.MAX_VALUE) {
            throw SQLError.createSQLException(
                    Messages.get("Stream is too large to send over the protocol."),
                    YasState.NUMERIC_CONSTANT_OUT_OF_RANGE);
        }
        String s = (value != null) ? readerToString(value, (int) length) : null;
        setString(parameterIndex, s);
    }

    public void setCharacterStream(int parameterIndex, Reader value) throws SQLException {
        String s = (value != null) ? readerToString(value, Integer.MAX_VALUE) : null;
        setString(parameterIndex, s);
    }

    @Override
    public void setBinaryStream(int parameterIndex, InputStream value, long length)
            throws SQLException {
        checkClosed();

        if (length > Integer.MAX_VALUE) {
            throw SQLError.createSQLException(
                    Messages.get("Stream is too large to send over the protocol."),
                    YasState.NUMERIC_CONSTANT_OUT_OF_RANGE);
        }

        this.setBinaryStream(parameterIndex, value, (int) length);
    }

    @Override
    public void setBinaryStream(int parameterIndex, InputStream value) throws SQLException {
        checkClosed();

        if (value == null) {
            geParameters().setNull(parameterIndex, DataType.RAW);
            return;
        }

        geParameters().setBytea(parameterIndex, value);
    }

    public void setAsciiStream(int parameterIndex, InputStream value, long length)
            throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setAsciiStream(int, InputStream, long)");
    }

    public void setAsciiStream(int parameterIndex, InputStream value) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setAsciiStream(int, InputStream)");
    }

    public void setNClob(int parameterIndex, NClob value) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setNClob(int, NClob)");
    }

    public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
        if (connection.getSession().getConnectVersion() == ConnectVersion.VER1) {
            throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setClob(int, Reader, long)");
        }

        checkClosed();

        if (length < 0) {
            throw SQLError.createSQLException(Messages.get("Invalid stream length {0}.", length),
                    YasState.INVALID_PARAMETER_VALUE);
        }

        if (reader == null || length == 0L) {
            geParameters().setNull(parameterIndex, DataType.CLOB);
            return;
        }

        int nRead;
        int buffSize = (int)Math.min(YasConstants.READER_BUFF_SIZE, length);
        char[] tempCharBuf = new char[buffSize];
        try {
            nRead = reader.read(tempCharBuf);
        } catch (IOException ioe) {
            throw SQLError.createSQLException(Messages.get("Access Provided Reader failed."), YasState.UNEXPECTED_ERROR,
                    ioe);
        }

        if (nRead == -1) {
            throw SQLError.createSQLException(length + " character of CLOB data can not be read", YasState.DATA_ERROR);
        }

        if (nRead == YasConstants.READER_BUFF_SIZE) {
            Clob clob = this.connection.getSession().preProcessReaderBinding(reader, tempCharBuf, length);
            long clobLength = clob.length();
            if (length > clobLength) {
                clob.free();
                throw SQLError.createSQLException(
                        length - clobLength + " character of CLOB data can not be read", YasState.DATA_ERROR);
            }
            this.setClob(parameterIndex, clob);
            return;
        }

        if (length > nRead) {
            throw SQLError.createSQLException(
                    length - nRead + " character of CLOB data can not be read", YasState.DATA_ERROR);
        }

        setString(parameterIndex, String.valueOf(tempCharBuf, 0, nRead));
    }

    public void setClob(int parameterIndex, Reader reader) throws SQLException {
        if (connection.getSession().getConnectVersion() == ConnectVersion.VER1) {
            throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setClob(int, Reader)");
        }

        checkClosed();

        if (reader == null) {
            geParameters().setNull(parameterIndex, DataType.CLOB);
            return;
        }

        int nRead;
        char[] tempCharBuf = new char[YasConstants.READER_BUFF_SIZE];
        try {
            nRead = reader.read(tempCharBuf);
        } catch (IOException ioe) {
            throw SQLError.createSQLException(Messages.get("Access Provided Reader failed."), YasState.UNEXPECTED_ERROR,
                    ioe);
        }

        if (nRead == -1) {
            geParameters().setNull(parameterIndex, DataType.CLOB);
            return;
        }

        if (nRead == YasConstants.READER_BUFF_SIZE) {
            Clob clob = this.connection.getSession().preProcessReaderBinding(reader, tempCharBuf, Long.MAX_VALUE);
            this.setClob(parameterIndex, clob);
            return;
        }

        setString(parameterIndex, String.valueOf(tempCharBuf, 0, nRead));
    }

    @Override
    public void setBlob(int parameterIndex, InputStream inputStream, long length)
            throws SQLException {
        checkClosed();
        if (length < 0) {
            throw SQLError.createSQLException(Messages.get("Invalid stream length {0}.", length),
                    YasState.INVALID_PARAMETER_VALUE);
        }

        if ((inputStream == null) || (length == 0)) {
            setNull(parameterIndex, Types.BLOB);
            return;
        }

        this.setBinaryStream(parameterIndex, inputStream, length);
    }

    @Override
    public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
        checkClosed();

        if (inputStream == null) {
            setNull(parameterIndex, Types.BLOB);
            return;
        }

        this.setBinaryStream(parameterIndex, inputStream);
    }

    public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setNClob(int, Reader, long)");
    }

    public void setNClob(int parameterIndex, Reader reader) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setNClob(int, Reader)");
    }

    public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {
        checkClosed();
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setSQLXML(int, SQLXML)");
    }

    public void setURL(int parameterIndex, java.net.URL x) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setURL(int,URL)");
    }

    private long[] executeLargeBatchWithAutoKey() throws SQLException {
        this.generatedKeysResults = null;
        this.autoKey.withBatchInsert = true;
        ParameterList[] parameterLists = batchParameters.toArray(new ParameterList[0]);
        long []ret = new long[parameterLists.length];
        for (int i = 0; i < parameterLists.length; i++) {
            geParameters().clear();
            geParameters().appendAll(parameterLists[i].copy());
            executeInternal(Session.QUERY_NO_RESULTS);
            ret[i] = getExecuteLargeUpdateResult();
        }
        return ret;
    }

    @Override
    public synchronized long[] executeLargeBatch() throws SQLException {
        checkClosed();
        closeForNextExecution();

        if ( this.preparedParameters != null) {
            if ((batchParameters == null) || batchParameters.isEmpty()) {
                return new long[0];
            }

            if (batchParameters.size() > 1 && this.autoGeneratedKeys) {
                try {
                    return executeLargeBatchWithAutoKey();
                } finally {
                    this.clearBatch();
                }
            }

            try {
                ParameterList[] parameterLists = batchParameters.toArray(new ParameterList[0]);
                executeInternal(this, parameterLists, 0);
                long[] ret;
                if (parameterLists.length > 1) {
                    int[] iret = currentResultSet.getBatchUpdateCounts();
                    if (iret != null) {
                        ret = Utils.toLongArray(iret);
                    } else {
                        ret = new long[1];
                        ret[0] = currentResultSet.getUpdateCount();
                    }
                } else {
                    ret = new long[1];
                    ret[0] = currentResultSet.getUpdateCount();
                }
                return ret;
            } finally {
                this.clearBatch();
            }
        } else {
            return super.executeLargeBatch();
        }
    }

    public ParameterMetaData getParameterMetaData() throws SQLException {
        checkClosed();
        if (parameterMetaData == null) {
            parameterMetaData = createParameterMetaData();
        }
        if (this.autoGeneratedKeys) {
            parameterMetaData.setThrowUnsupported(true);
        }
        return parameterMetaData;
    }

    @Override
    public void setParameters(Field[] parameterFields) throws SQLException {
        this.parameterFields = parameterFields;
        this.preparedParameters = new SimpleParameterList(parameterFields.length);
        this.preparedParameters.setCharset(this.getSession().getCharset());
    }

    @Override
    public synchronized void clearBatch() throws SQLException {
        if (batchParameters != null) {
            batchParameters.clear();
        }
    }

    protected ParameterList geParameters() throws SQLException {
        if (this.preparedParameters == null) {
            throw SQLError.createSQLException(
                    "Invalid column index.",
                    YasState.INVALID_PARAMETER_VALUE);
        }
        return this.preparedParameters;
    }

    void registerReturnParamsForAutoKey() throws SQLException {
        int[] returnTypes = this.autoKey.returnTypes;
        int count = returnTypes.length;
        int start = this.preparedParameters.getParameterCount() - count;

        for (int i = 0; i < count; ++i) {
            int pos = start + i;
            this.registerReturnParameterInternal(pos, returnTypes[i]);
        }
    }

    private void setBinary(int parameterIndex, Object in, int targetSqlType, int scale) throws SQLException {
        if (in instanceof String) {
            setString(parameterIndex,(String) in);
        } else if (in instanceof byte[]) {
            setBytes(parameterIndex,(byte[]) in );
        } else if (in instanceof InputStream) {
            setBytes(parameterIndex, TypeConverter.getBytesByInputStream((InputStream) in, scale));
        } else {
            throw SQLError.TransformException(in.getClass().getName(), JDBCType.valueOf(targetSqlType).getName());
        }
    }

    private void setTimeWithTimezone(int parameterIndex, Object in) throws SQLException {
        if (in instanceof OffsetDateTime) {
            setTime(parameterIndex, Time.valueOf(((OffsetDateTime) in).toLocalDateTime().toLocalTime()));
        } else if (in instanceof OffsetTime) {
            setTime(parameterIndex, Time.valueOf(((OffsetTime) in).toLocalTime()));
        } else {
            throw SQLError.TransformException(in.getClass().getName(), "TIME_WITH_TIMEZONE");
        }
    }

    private void setTimestampWithTimezone(int parameterIndex, Object in) throws SQLException {
        if (in instanceof OffsetDateTime) {
            setTimestamp(parameterIndex, (OffsetDateTime) in);
        } else if (in instanceof YasTimestamp) {
            setObject(parameterIndex, in);
        } else {
            throw SQLError.TransformException(in.getClass().getName(), "TIMESTAMP_WITH_TIMEZONE");
        }
    }
}
