/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

public class UpdatableRow extends Row {
    public UpdatableRow(byte[][] data) {
        super(data);
    }

    /**
     * Get the data for the given field
     * The RowID index is -1,as a hidden row
     * @param index 1-based field position in the tuple
     * @return byte array of the data
     */
    public byte[] get(int index) {
        return data[index + 1];
    }

    public byte[] getRowID() {
        return data[0];
    }

}
