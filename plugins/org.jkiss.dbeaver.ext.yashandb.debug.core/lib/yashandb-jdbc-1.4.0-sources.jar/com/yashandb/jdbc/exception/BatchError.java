/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.exception;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BatchError extends ServerErrorMessage {
    private static final Pattern pattern = Pattern.compile("\\[line: [0-9]+ column: [0-9]+\\] YAS-[0-9]+ ");

    public BatchError(int errCode, String msg) {
        super(errCode,0,0,msg);
    }

    @Override
    public String toString() {
        return "YAS-" + String.format("%05d", errCode) + " " + this.msg;
    }

    public static String converMsgToBatchMsg(String msg) {
        Matcher matcher = pattern.matcher(msg);
        if (matcher.find()) {
            return msg.substring(matcher.end());
        }
        return null;
    }
}
