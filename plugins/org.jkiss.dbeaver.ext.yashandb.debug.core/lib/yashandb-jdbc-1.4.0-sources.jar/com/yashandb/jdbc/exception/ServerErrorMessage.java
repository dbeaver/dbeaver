/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.exception;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * int line;
 * int column;
 * int errCode;
 * int msgLen;
 * String msg;
 */
public class ServerErrorMessage implements Serializable {
    protected int errCode;
    private int line;
    private int column;
    protected String msg;

    public ServerErrorMessage(int errCode, int line, int column, String msg) {
        this.errCode = errCode;
        this.line = line;
        this.column = column;
        this.msg = msg;
    }

    public int getErrCode() {
        return errCode;
    }

    public String getSQLState() {
        return Integer.toString(errCode);
    }

    public String getNonSensitiveErrorMessage() {
        return null;
    }

    public String getMessage() {
        return this.msg;
    }

    public List<Integer> getOtherErrorCode() {
        List<Integer> list = new ArrayList();

        String[] msgs = this.msg.split("\n");
        for (String m : msgs) {
            if (m == null || m.trim().length() == 0 || !m.contains("YAS-")) {
                continue;
            }
            try {
                int index = m.indexOf("YAS-");
                list.add(Integer.parseInt(m.substring(index + 4,index + 9)));
            } catch (Exception e) {
                // do nothing
            }
        }
        return list;
    }

    @Override
    public String toString() {
        return "[line: " + this.line + " column: " + this.column + "] "
                + "YAS-" + String.format("%05d", errCode) + " " + this.msg;
    }
}
