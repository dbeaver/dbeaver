/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.exception;

import java.sql.BatchUpdateException;

public class YasBatchUpdateException extends BatchUpdateException {

    private int rowNum = 0;

    private BatchError batchError = null;

    public BatchError getBatchError() {
        return batchError;
    }

    public int getRowNum() {
        return rowNum;
    }

    public YasBatchUpdateException(int rowNum, BatchError batchError, int[] updateCounts) {
        super(batchError.toString() + " at batch index " + (rowNum + 1), updateCounts);

        this.rowNum = rowNum;
        this.batchError = batchError;
    }
}
