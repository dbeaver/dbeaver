/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.exception;

import com.yashandb.exception.YasState;
import com.yashandb.util.Messages;

import java.sql.SQLException;

public class YasException extends SQLException {

    private ServerErrorMessage serverError;

    public YasException(String msg, YasState state, Throwable cause) {
        super(Messages.get(msg), state == null ? null : state.getState(), cause);
    }

    public YasException(String msg, YasState state) {
        super(Messages.get(msg), state == null ? null : state.getState());
    }

    public YasException(ServerErrorMessage serverError) {
        this(serverError, true);
    }

    public YasException(ServerErrorMessage serverError, boolean detail) {
        super(detail ? serverError.toString() : serverError.getNonSensitiveErrorMessage(),
                serverError.getSQLState(), serverError.getErrCode());
        this.serverError = serverError;
    }

    public ServerErrorMessage getServerErrorMessage() {
        return serverError;
    }

}
