/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.exception;

import com.yashandb.exception.YasState;
import com.yashandb.util.Messages;

import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;

public class SQLError {

    public static YasException createSQLException(String message, YasState sqlState) {
        return new YasException(message, sqlState);
    }

    public static YasException createSQLException(String message, YasState sqlState, Throwable cause) {
        return new YasException(message, sqlState, cause);
    }

    public static SQLException createSQLException(ServerErrorMessage serverError, boolean detail) {
        return createSQLException(serverError, detail, null);
    }

    public static SQLException createSQLException(ServerErrorMessage serverError, boolean detail, Throwable cause) {
        SQLExceptionType sqlExceptionType = SQLExceptionType.findServerSQLExceptionType(serverError);
        SQLException exception = sqlExceptionType != null
                ? sqlExceptionType.newSQLException(serverError.toString(),serverError.getErrCode())
                : new YasException(serverError, detail);
        if (cause != null) {
            exception.initCause(cause);
        }
        return exception;
    }

    /**
     * This method throws an SQLException for an unimplemented method.
     *
     * @param callClass    the call Class
     * @param functionName the name of the unimplemented function with the type of its arguments
     * @return YasException with a localized message giving the complete description of the
     * unimplemeted function
     */
    public static SQLException createSQLFeatureNotSupportedException(Class<?> callClass,
                                                                     String functionName) {
        return new SQLFeatureNotSupportedException(
                Messages.get("Method {0} is not yet implemented.", callClass.getName() + "." + functionName),
                YasState.NOT_IMPLEMENTED.getState());
    }

    public static YasException OverFlowException(final String fromType, final String toType) {
        return SQLError.createSQLException(Messages.get("Convert an instance of {0} to type {1} OverFlow",
                fromType.toUpperCase(), toType.toUpperCase()), YasState.DATA_ERROR);
    }

    public static YasException TransformException(final String fromType, final String toType) {
        return TransformException(fromType, toType, null);
    }

    public static YasException TransformException(final String fromType, final String toType,
                                                  final Exception cause) {
        return SQLError.createSQLException(
                Messages.get("Cannot convert an instance of {0} to type {1}",
                        fromType.toUpperCase(), toType.toUpperCase()),
                YasState.INVALID_PARAMETER_TYPE, cause);
    }

    public static YasException ConvertValueException(final String fromType, final String value,
                                                     final String toType) {
        return ConvertValueException(fromType, value, toType, null);
    }

    public static YasException ConvertValueException(final String fromType, final String value,
                                                     final String toType, final Exception cause) {
        return SQLError.createSQLException(
                Messages.get("Cannot convert {0} value \"{1}\" to type {2}",
                        fromType.toUpperCase(), value, toType.toUpperCase()),
                YasState.INVALID_PARAMETER_TYPE, cause);
    }
}
