/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;
import com.yashandb.util.YasSQL;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ScrollableSensitiveResultSet extends UpdatableResultSet {

    int prefetchRowIDSize = 10;
    boolean hasMore = true;
    private static final Logger LOGGER = LoggerFactory.getLogger(ScrollableSensitiveResultSet.class);

    public ScrollableSensitiveResultSet(StatementImpl originalQuery, Field[] fields, RowData rows, int maxRows,
                              int maxFieldSize, int rsType, int rsConcurrency, int rsHoldability,
                              YasSQL yasSQL) throws SQLException {
        super(originalQuery, fields, rows, maxRows, maxFieldSize, rsType, rsConcurrency,rsHoldability, yasSQL);

        if ( rsConcurrency == ResultSet.CONCUR_UPDATABLE) {
            this.updatable = true;
        } else {
            this.updatable = false;
        }
        if ( this.fetchSize > 10) {
            prefetchRowIDSize = this.fetchSize;
        }
    }

    @Override
    public boolean next() throws SQLException {
        return relative(1);
    }

    @Override
    public boolean absolute(int index) throws SQLException {
        boolean result = super.absolute(index);
        if ( thisRow != null) {
            try {
                refreshRow(((UpdatableRow) thisRow).getRowID());
            } catch (SQLException e) {
                // For deleted row
                LOGGER.debug("absolute(" + index + ") failed:" + e.getMessage(), e);
            }
        }

        return result;
    }

    @Override
    public void beforeFirst() throws SQLException {
        absolute(0);
    }

    @Override
    public boolean first() throws SQLException {
        return absolute(1);
    }

    @Override
    public boolean isBeforeFirst() throws SQLException {
        synchronized (this.connection) {
            checkClosed();
            return this.currentRow == -1;
        }
    }

    @Override
    public boolean isFirst() throws SQLException {
        synchronized (this.connection) {
            checkClosed();
            if (currentRow == 0L) {
                return true;
            }
            return false;
        }
    }

    @Override
    public boolean last() throws SQLException {
        return absolute(-1);
    }

    @Override
    public boolean previous() throws SQLException {
        if (this.currentRow == -1) {
            // Can't previous,do nothing
            return false;
        }
        return absolute((int)this.currentRow);
    }

    @Override
    public boolean relative(int rows) throws SQLException {
        if (currentRow + 1 + rows < 0 ) {
            beforeFirst();
            return false;
        }
        return absolute((int)currentRow + 1 + rows);
    }

    @Override
    public synchronized void updateRow() throws SQLException {
        doUpdate();
        //Refresh Row
        if (updateCount > 0) {
            refreshRow(((UpdatableRow)thisRow).getRowID());
        }
    }
}
