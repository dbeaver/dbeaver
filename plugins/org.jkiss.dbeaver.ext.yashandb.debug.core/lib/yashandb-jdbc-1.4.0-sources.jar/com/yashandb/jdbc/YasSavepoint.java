/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.SQLException;
import java.sql.Savepoint;

public class YasSavepoint implements Savepoint {

    enum SavePointType {
        UNKNOWN_TYPE,
        ID_TYPE,
        NAMED_TYPE,
    }

    private SavePointType pointType;

    private int pointId;

    private String pointName;

    private static final int INVALID_ID = -1;

    private static final int MAX_ID = 0xEFFFFFFF;

    private static int seedId = 0;

    public YasSavepoint() {
        pointType = SavePointType.ID_TYPE;
        pointId = generateId();
        pointName = null;
    }

    public YasSavepoint(String savepointName) {
        if (savepointName != null) {
            savepointName = savepointName.trim();
        }

        if ((savepointName == null) || savepointName.isEmpty()) {
            pointType = SavePointType.ID_TYPE;
            pointId = generateId();
            pointName = null;
        } else {
            pointType = SavePointType.NAMED_TYPE;
            pointName = savepointName;
            pointId = INVALID_ID;
        }
    }

    @Override
    public int getSavepointId() throws SQLException {
        if (pointType == SavePointType.NAMED_TYPE) {
            throw SQLError.createSQLException("wrong savepoint type", YasState.UNEXPECTED_ERROR);
        }

        return pointId;
    }

    @Override
    public String getSavepointName() throws SQLException {
        if (pointType == SavePointType.ID_TYPE) {
            throw SQLError.createSQLException("wrong savepoint type", YasState.UNEXPECTED_ERROR);
        }

        return pointName;
    }

    private synchronized int generateId() {
        seedId = (seedId + 1) % MAX_ID;
        return seedId;
    }
}
