/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import java.sql.SQLType;

public enum YasType implements SQLType {

    //JDBC DataType
    BIT("BIT", YasTypes.BIT),
    TINYINT("TINYINT", YasTypes.TINYINT),
    SMALLINT("SMALLINT", YasTypes.SMALLINT),
    INTEGER("INTEGER", YasTypes.INTEGER),
    BIGINT("BIGINT", YasTypes.BIGINT),
    FLOAT("FLOAT", YasTypes.FLOAT),
    DOUBLE("DOUBLE", YasTypes.DOUBLE),
    BOOLEAN("BOOLEAN", YasTypes.BOOLEAN),
    REAL("REAL", YasTypes.REAL),
    NUMERIC("NUMERIC", YasTypes.NUMERIC),
    DECIMAL("DECIMAL", YasTypes.DECIMAL),

    DATE("DATE", YasTypes.DATE),
    TIMESTAMP("TIMESTAMP", YasTypes.TIMESTAMP),
    TIMESTAMP_TZ("TIMESTAMP_TZ", YasTypes.TIMESTAMP_TZ),
    TIMESTAMP_LTZ("TIMESTAMP_LTZ", YasTypes.TIMESTAMP_LTZ),

    CHAR("CHAR", YasTypes.CHAR),
    NCHAR("NCHAR", YasTypes.NCHAR),
    VARCHAR("VARCHAR", YasTypes.VARCHAR),
    NVARCHAR("NVARCHAR", YasTypes.NVARCHAR),

    BLOB("BLOB", YasTypes.BLOB),
    CLOB("CLOB", YasTypes.CLOB),
    NCLOB("CLOB", YasTypes.CLOB),

    ROWID("ROWID", YasTypes.ROWID),
    STRUCT("STRUCT", YasTypes.STRUCT),
    ARRAY("ARRAY", YasTypes.ARRAY),
    REF("REF", YasTypes.REF),
    BINARY("BINARY", YasTypes.BINARY),
    VARBINARY("VARBINARY", YasTypes.VARBINARY),
    LONGVARBINARY("LONGVARBINARY", YasTypes.LONGVARBINARY),
    NULL("NULL", YasTypes.NULL),
    OTHER("OTHER", YasTypes.OTHER),

    //Yas Extend DataType
    UNKNOWN("UNKNOWN", YasTypes.UNKNOWN),
    UTINYINT("UTINYINT", YasTypes.UTINYINT),
    USMALLINT("USMALLINT", YasTypes.USMALLINT),
    UINTEGER("UINTEGER", YasTypes.UINTEGER),
    UBIGINT("UBIGINT", YasTypes.UBIGINT),
    SHORTDATE("SHORTDATE", YasTypes.SHORTDATE),
    SHORTTIME("SHORTTIME", YasTypes.SHORTTIME),
    NUMBER("NUMBER", YasTypes.NUMBER),

    YM_INTERVAL("YM_INTERVAL", YasTypes.YM_INTERVAL),
    DS_INTERVAL("DS_INTERVAL", YasTypes.DS_INTERVAL),
    RAW("RAW", YasTypes.RAW);


    private final int code;
    private final String typeName;

    YasType(String name, int type) {
        this.code = type;
        this.typeName = name;
    }

    /**
     * Returns the {@code SQLType} name that represents a SQL data type.
     *
     * @return The name of this {@code SQLType}.
     */
    @Override
    public String getName() {
        return this.name();
    }

    /**
     * Returns the name of the vendor that supports this data type. The value returned typically is
     * the package name for this vendor.
     *
     * @return The name of the vendor for this data type
     */
    @Override
    public String getVendor() {
        return "YashanDB";
    }

    /**
     *  Returns SQL Type for the data type
     *
     * @return An Integer representing the vendor specific data type
     */
    @Override
    public Integer getVendorTypeNumber() {
        return this.code;
    }

}
