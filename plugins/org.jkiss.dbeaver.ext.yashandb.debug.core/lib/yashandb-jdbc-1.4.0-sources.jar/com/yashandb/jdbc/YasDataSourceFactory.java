/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;

import java.text.MessageFormat;
import java.util.Hashtable;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.Reference;
import javax.naming.StringRefAddr;
import javax.naming.spi.ObjectFactory;

/**
 * A factory for creating an Yas datasource.
 */
public class YasDataSourceFactory implements ObjectFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(YasDataSourceFactory.class);

    public static final String DATA_SOURCE_CLASS_NAME = YasDataSource.class.getName();
    public static final String XA_DATA_SOURCE_CLASS_NAME = "";
    public static final String POOL_DATA_SOURCE_CLASS_NAME = "";


    /**
     * Create DataSource with obj
     * The name,nameCtx,environment is unused in the method
     *
     * @param refObj The possibly null object containing location or reference
     *              information that can be used in creating an object.
     * @param name The name of this object relative to <code>nameCtx</code>,
     *              or null if no name is specified.
     * @param nameCtx The context relative to which the <code>name</code>
     *              parameter is specified, or null if <code>name</code> is
     *              relative to the default initial context.
     * @param environment The possibly null environment that is used in
     *              creating the object.
     * @return The object created; null if an object cannot be created.
     * @exception Exception if this object factory encountered an exception
     * while attempting to create an object, and no other object factories are
     * to be tried.
     */
    @Override
    public Object getObjectInstance(Object refObj, Name name,
                                    Context nameCtx, Hashtable<?, ?> environment) throws Exception {
        Reference ref = (Reference) refObj;
        String className = ref.getClassName();
        Properties prop = new Properties();
        YasDataSource ads = null;
        LOGGER.debug("getObjectInstance {},name {}",ref,className);

        if (className != null && (className.equals(DATA_SOURCE_CLASS_NAME)
                || className.equals(XA_DATA_SOURCE_CLASS_NAME)
                || className.equals(POOL_DATA_SOURCE_CLASS_NAME))) {
            // YashanDB XA DataSource
        } else {
            // Set Default DataSource
            className = DATA_SOURCE_CLASS_NAME;
        }

        try {
            ads = (YasDataSource) Class.forName(className).newInstance();
        } catch (Exception e) {
            throw new RuntimeException(MessageFormat.format(
                    "YasDataSourceFactory", new Object[] { className, e.toString() }));
        }

        if (ads != null) {
            StringRefAddr st = null;

            if ((st = (StringRefAddr) ref.get("url")) != null) {
                ads.setURL((String) st.getContent());
            }

            if ((st = (StringRefAddr) ref.get("user")) != null) {
                ads.setUser((String) st.getContent());
            }

            if ((st = (StringRefAddr) ref.get("password")) != null) {
                ads.setPassword((String) st.getContent());
            }

            if ((st = (StringRefAddr) ref.get("description")) != null) {
                ads.setDescription((String) st.getContent());
            }

            if ((st = (StringRefAddr) ref.get("serverName")) != null) {
                ads.setServerName((String) st.getContent());
            }

            if ((st = (StringRefAddr) ref.get("databasename")) != null) {
                ads.setDatabaseName((String) st.getContent());
            }

            if ((st = (StringRefAddr) ref.get("portNumber")) != null) {
                String pn = (String) st.getContent();
                ads.setPortNumber(Integer.parseInt(pn));
            }
            if ((st = (StringRefAddr) ref.get("sslRootCer")) != null) {
                String sslRootCer = (String) st.getContent();
                ads.setSslRootCer(sslRootCer);
            }
        }

        return ads;
    }
}
