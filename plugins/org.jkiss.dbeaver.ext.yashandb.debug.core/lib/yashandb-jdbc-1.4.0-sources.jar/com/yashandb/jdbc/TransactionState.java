/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

public enum TransactionState {
    IDLE,
    OPEN,
    XACT_PHASE1,
    XACT_END
}
