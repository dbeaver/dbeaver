/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.core.DataType;
import com.yashandb.core.SqlKind;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.jdbc.exception.YasException;
import com.yashandb.util.Messages;
import com.yashandb.util.YasSQL;

import java.sql.SQLException;
import java.util.List;

public class ReturnResultSetMetaData extends ResultSetMetaDataImpl {
    int[] colIndexes;
    String[] colNames;
    String originalSql;

    String newSql;
    YasSQL parser = null;
    SqlKind sqlKind;

    int autoKeyType;
    int numColumns;
    String[] tableColumnNames;
    int[] tableColumnTypes;
    int[] tableMaxLengths;
    boolean[] tableNullables;
    int[] tablePrecisions;
    int[] tableScales;
    String[] tableTypeNames;

    int[] returnTypes;
    String tableName;

    Field[] autoKeyFields;
    Boolean withBatchInsert = false;

    public ReturnResultSetMetaData(String sql) {
        this.sqlKind = SqlKind.UNINITIALIZED;
        this.originalSql = sql;
        this.autoKeyType = 0;
    }

    public ReturnResultSetMetaData(String sql, int[] cols) {
        this.sqlKind = SqlKind.UNINITIALIZED;
        this.originalSql = sql;
        this.autoKeyType = 1;
        this.colIndexes = cols;
    }

    public ReturnResultSetMetaData(String sql, String[] colNames) {
        this.sqlKind = SqlKind.UNINITIALIZED;
        this.originalSql = sql;
        this.colNames = colNames;
        this.autoKeyType = 2;
    }

    public String getNewSql() throws SQLException {
        if (newSql != null) {
            return newSql;
        }
        switch (autoKeyType) {
            case 0:
                newSql = this.originalSql + " RETURNING ROWID INTO " + '?';
                this.returnTypes = new int[1];
                this.returnTypes[0] = DataType.ROWID;
                this.autoKeyFields = new Field[1];
                this.autoKeyFields[0] = new Field(0,"ROWID",DataType.ROWID,20,0,0,0);
                break;
            case 1:
                this.autoKeyFields = new Field[this.colIndexes.length];
                getNewSqlByIndex();
                break;
            case 2:
                this.autoKeyFields = new Field[this.colNames.length];
                getNewSqlByNames();
                break;
        }
        return this.newSql;
    }

    private int getReturnParamTypeCode(int index, String name, int[] colIndexes) throws SQLException {
        for (int i = 0; i < this.tableColumnNames.length; i++) {
            if (name.equalsIgnoreCase(this.tableColumnNames[i])) {
                colIndexes[index] = i + 1;
                return this.tableColumnTypes[i];
            }
        }

        throw SQLError.createSQLException(Messages.get("Invalid argument(s) in call."),
                YasState.INVALID_PARAMETER_TYPE);
    }

    private void getNewSqlByNames() throws SQLException {
        if (this.tableColumnNames.length == 0) {
            throw SQLError.createSQLException(Messages.get("Table does not exist."),
                    YasState.UNDEFINED_TABLE);
        }

        this.returnTypes = new int[this.colNames.length];
        this.colIndexes = new int[this.colNames.length];

        StringBuilder sbuf = new StringBuilder(this.originalSql);
        sbuf.append(" RETURNING ");

        int i;
        for (i = 0; i < this.colNames.length; i++) {
            int code = this.getReturnParamTypeCode(i, this.colNames[i], this.colIndexes);
            this.returnTypes[i] = code;
            sbuf.append(this.colNames[i]);
            if (i < this.colNames.length - 1) {
                sbuf.append(", ");
            }
            int pos = this.colIndexes[i] - 1;
            this.autoKeyFields[i] = new Field(i, this.tableColumnNames[pos], this.tableColumnTypes[pos],
                    this.tableMaxLengths[pos], this.tableNullables[pos] ? 1 : 0,
                    this.tablePrecisions[pos], this.tableScales[pos]);
        }

        sbuf.append(" INTO ");

        for (i = 0; i < this.colNames.length - 1; ++i) {
            sbuf.append("?, ");
        }

        sbuf.append('?');
        this.newSql = new String(sbuf);
    }

    private void getNewSqlByIndex() throws YasException {
        if (this.tableColumnNames.length == 0) {
            throw SQLError.createSQLException(Messages.get("Table does not exist."),
                    YasState.UNDEFINED_TABLE);
        }
        this.returnTypes = new int[this.colIndexes.length];
        StringBuilder sbuf = new StringBuilder(this.originalSql);
        sbuf.append(" RETURNING ");

        int i;
        for (i = 0; i < this.colIndexes.length; ++i) {
            int pos = this.colIndexes[i] - 1;
            if (pos < 0 || pos >= this.tableColumnNames.length) {
                throw SQLError.createSQLException(Messages.get("Invalid argument(s) in call."),
                    YasState.INVALID_PARAMETER_TYPE);
            }

            int var2 = this.tableColumnTypes[pos];
            String var5 = this.tableColumnNames[pos];
            this.returnTypes[i] = var2;
            sbuf.append(var5.contains(" ") ? String.format("\"%s\"", var5) : var5);
            if (i < this.colIndexes.length - 1) {
                sbuf.append(", ");
            }
            this.autoKeyFields[i] = new Field(i, this.tableColumnNames[pos], this.tableColumnTypes[pos],
                    this.tableMaxLengths[pos], this.tableNullables[pos] ? 1 : 0,
                    this.tablePrecisions[pos], this.tableScales[pos]);
        }

        sbuf.append(" INTO ");

        for (i = 0; i < this.colIndexes.length - 1; ++i) {
            sbuf.append("?, ");
        }

        sbuf.append("?");
        this.newSql = new String(sbuf);
    }

    public boolean isInsert() throws YasException {
        if (sqlKind == SqlKind.UNINITIALIZED) {
            parseSQL();
        }
        return this.sqlKind == SqlKind.INSERT;
    }

    private void parseSQL() throws YasException {
        if (this.originalSql == null) {
            throw SQLError.createSQLException(Messages.get("Invalid argument(s) in call."),
                YasState.INVALID_PARAMETER_TYPE);
        }
        if (parser == null) {
            this.parser = new YasSQL(originalSql);
        } else {
            this.parser.parseSQL(originalSql);
        }
        this.sqlKind = this.parser.getSqlKind();
    }

    public void initDescribedData(int count, List<String> colName, List<Integer> colType,
        List<Integer> maxLen,
        List<Boolean> nullable, List<Integer> precision,
        List<Integer> scale, List<String> typeName) throws SQLException {
        allocateSpaceForDescribedData(count);
        for (int i = 0; i < count; i++) {
            fillDescribedData(i, colName.get(i), colType.get(i), maxLen.get(i), nullable.get(i),
                precision.get(i), scale.get(i), typeName.get(i));
        }
    }

    void allocateSpaceForDescribedData(int var1) throws SQLException {
        this.numColumns = var1;
        this.tableColumnNames = new String[var1];
        this.tableColumnTypes = new int[var1];
        this.tableMaxLengths = new int[var1];
        this.tableNullables = new boolean[var1];
        this.tablePrecisions = new int[var1];
        this.tableScales = new int[var1];
        this.tableTypeNames = new String[var1];
    }

    void fillDescribedData(int index, String name, int type, int len, boolean nullable,
        int precisions, int scale, String typename) throws SQLException {
        this.tableColumnNames[index] = name;
        this.tableColumnTypes[index] = type;
        this.tableMaxLengths[index] = len;
        this.tableNullables[index] = nullable;
        this.tablePrecisions[index] = precisions;
        this.tableScales[index] = scale;
        this.tableTypeNames[index] = typename;
    }

    String getTableName() throws SQLException {
        if (this.tableName != null) {
            return this.tableName;
        }
        String upperCase = this.originalSql.trim().toUpperCase();
        int pos = upperCase.indexOf("INSERT");
        pos = upperCase.indexOf("INTO", pos);
        if (pos < 0) {
            throw SQLError.createSQLException(Messages.get("Invalid argument(s) in call."),
                YasState.INVALID_PARAMETER_TYPE);
        } else {
            int length = upperCase.length();

            int start;
            for (start = pos + 5; start < length && upperCase.charAt(start) == ' '; ++start) {
            }

            if (start >= length) {
                throw SQLError.createSQLException(Messages.get("Invalid argument(s) in call."),
                    YasState.INVALID_PARAMETER_TYPE);
            } else {
                int end;
                if (upperCase.charAt(start) == '"') {
                    end = start + 1;
                    end = upperCase.indexOf(34, end) + 1;
                    if (start >= end - 2) {
                        throw SQLError.createSQLException(
                            Messages.get("Invalid argument(s) in call."),
                            YasState.INVALID_PARAMETER_TYPE);
                    }
                } else {
                    for (end = start; end < length && upperCase.charAt(end) != ' '
                        && upperCase.charAt(end) != '('; ++end) {
                    }

                    if (start >= end) {

                        throw SQLError.createSQLException(
                            Messages.get("Invalid argument(s) in call."),
                            YasState.INVALID_PARAMETER_TYPE);
                    }
                }

                this.tableName = upperCase.substring(start, end);
                return this.tableName;
            }
        }

    }

}
