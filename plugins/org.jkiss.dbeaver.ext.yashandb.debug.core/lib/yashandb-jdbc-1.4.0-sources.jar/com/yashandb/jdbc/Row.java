/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

/**
 * Class representing a row in a {@link java.sql.ResultSet}.
 */
public class Row {

    final boolean forUpdate;
    byte[][] data;

    /**
     * The metadata of the fields of this result set.
     */
    protected Field[] metadata;

    /**
     * Construct an empty tuple. Used in updatable result sets.
     *
     * @param length the number of fields in the tuple.
     */
    public Row(int length) {
        this(new byte[length][], true);
    }

    /**
     * Construct a populated tuple. Used when returning results.
     *
     * @param data the tuple data
     */
    public Row(byte[][] data) {
        this(data, false);
    }

    private Row(byte[][] data, boolean forUpdate) {
        this.data = data;
        this.forUpdate = forUpdate;
    }

    /**
     * Get the data for the given field
     *
     * @param index 0-based field position in the tuple
     * @return byte array of the data
     */
    public byte[] get(int index) {
        return data[index];
    }

    /**
     * Create a copy of the tuple for updating.
     *
     * @return a copy of the tuple that allows updates
     */
    public Row updateableCopy() {
        return copy(true);
    }

    /**
     * Create a read-only copy of the tuple
     *
     * @return a copy of the tuple that does not allow updates
     */
    public Row readOnlyCopy() {
        return copy(false);
    }

    private Row copy(boolean forUpdate) {
        byte[][] dataCopy = new byte[data.length][];
        System.arraycopy(data, 0, dataCopy, 0, data.length);
        return new Row(dataCopy, forUpdate);
    }

    /**
     * Set the given field to the given data.
     *
     * @param index     0-based field position
     * @param fieldData the data to set
     */
    public void set(int index, byte[] fieldData) {
        if (!forUpdate) {
            throw new IllegalArgumentException("Attempted to write to readonly tuple");
        }
        data[index] = fieldData;
    }

    /**
     * Set the given data.
     *
     *
     * @param data the tuple data
     */
    public void set(byte[][] data) {
        this.data = data;
    }

    /**
     * Get the given data.
     *
     */
    public byte[][] get() {
        return data;
    }
}
