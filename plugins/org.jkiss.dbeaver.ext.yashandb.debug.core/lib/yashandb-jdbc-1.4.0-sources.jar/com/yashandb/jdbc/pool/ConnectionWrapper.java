/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.pool;

import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.NClob;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

/*
 * This class is a logical/proxy connections used in the connection pool.
 * When a user retrieves a connection from the pool, he gets a
 * logical connection which is nothing but a wrapper of the physical
 * connection.
 * All method invocations are forwarded to underlying connection unless the close method was previously called,
 * in which case a SQLException is thrown. The
 * close method performs a 'logical close' on the connection.
 */
public class ConnectionWrapper implements Connection {
    protected Connection physicalConn = null;
    protected YasPooledConnection pooledConnection;

    private boolean closed;
    private boolean isXa;

    protected static ConnectionWrapper getInstance(YasPooledConnection pooledConnection,
                                                   Connection connection, boolean isXa)
            throws SQLException {
        return new ConnectionWrapper(pooledConnection, connection, isXa);
    }

    /**
     * Construct a new LogicalHandle and set instance variables
     *
     * @param pooledConnection
     *            reference to object that instantiated this object
     * @param connection
     *            physical connection to db
     * @param isXa
     *            is it for XA connection?
     *
     * @throws SQLException
     *             if an error occurs.
     */
    public ConnectionWrapper(YasPooledConnection pooledConnection,
                             Connection connection, boolean isXa) throws SQLException {
        this.physicalConn = connection;
        this.pooledConnection = pooledConnection;
        this.closed = false;
        this.isXa = isXa;
    }

    /**
     * Fires connection error event if required, before re-throwing exception
     *
     * @param sqlEx
     *            the SQLException that has occurred
     * @throws SQLException
     *             (rethrown)
     */
    protected void checkConnectionError(SQLException sqlEx) throws SQLException {
        if (this.pooledConnection != null) {
            this.pooledConnection.callConnectionEventListeners(pooledConnection.CONNECTION_ERROR_EVENT, sqlEx);
        }
        throw sqlEx;
    }

    @Override
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        try {
            checkConnection();
            this.physicalConn.setAutoCommit(autoCommit);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public boolean getAutoCommit() throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.getAutoCommit();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return false; // we don't reach this code, compiler can't tell
    }

    @Override
    public void setCatalog(String catalog) throws SQLException {
        try {
            checkConnection();
            this.physicalConn.setCatalog(catalog);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public String getCatalog() throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.getCatalog();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public boolean isClosed() throws SQLException {
        return (this.closed || this.physicalConn.isClosed());
    }

    @Override
    public void setHoldability(int arg0) throws SQLException {
        try {
            checkConnection();
            this.physicalConn.setHoldability(arg0);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public int getHoldability() throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.getHoldability();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return Statement.CLOSE_CURRENT_RESULT; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.DatabaseMetaData getMetaData() throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.getMetaData();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public void setReadOnly(boolean readOnly) throws SQLException {
        try {
            checkConnection();
            this.physicalConn.setReadOnly(readOnly);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public boolean isReadOnly() throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.isReadOnly();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return false; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.Savepoint setSavepoint() throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.setSavepoint();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.Savepoint setSavepoint(String arg0) throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.setSavepoint(arg0);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public void setTransactionIsolation(int level) throws SQLException {
        try {
            checkConnection();
            this.physicalConn.setTransactionIsolation(level);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public int getTransactionIsolation() throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.getTransactionIsolation();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return TRANSACTION_REPEATABLE_READ; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.util.Map<String, Class<?>> getTypeMap() throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.getTypeMap();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
        try {
            this.physicalConn.setTypeMap(map);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public java.sql.SQLWarning getWarnings() throws SQLException {
        try {
            return this.physicalConn.getWarnings();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public void clearWarnings() throws SQLException {
        try {
            checkConnection();
            this.physicalConn.clearWarnings();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public void commit() throws SQLException {
        try {
            checkConnection();
            this.physicalConn.commit();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public java.sql.Statement createStatement() throws SQLException {
        try {
            checkConnection();
            return StatementWrapper.getInstance(this, this.pooledConnection, this.physicalConn.createStatement());
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
        try {
            checkConnection();
            return StatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.createStatement(resultSetType, resultSetConcurrency));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency,
                                              int resultSetHoldability) throws SQLException {
        try {
            checkConnection();
            return StatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.createStatement(resultSetType,resultSetConcurrency,resultSetHoldability));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public String nativeSQL(String sql) throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.nativeSQL(sql);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.CallableStatement prepareCall(String sql) throws SQLException {
        try {
            checkConnection();
            return CallableStatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.prepareCall(sql));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.CallableStatement prepareCall(String sql, int resultSetType,
                                                  int resultSetConcurrency) throws SQLException {
        try {
            checkConnection();
            return CallableStatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.prepareCall(sql, resultSetType, resultSetConcurrency));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.CallableStatement prepareCall(String sql, int resultSetType,
                                                  int resultSetConcurrency,
                                                  int resultSetHoldability) throws SQLException {
        try {
            checkConnection();
            return CallableStatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.prepareCall(sql, resultSetType, resultSetConcurrency,resultSetHoldability));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.PreparedStatement prepareStatement(String sql) throws SQLException {
        java.sql.PreparedStatement res = null;
        try {
            checkConnection();
            return PreparedStatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.prepareStatement(sql));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null;
    }

    @Override
    public java.sql.PreparedStatement prepareStatement(String sql,
           int resultSetType, int resultSetConcurrency) throws SQLException {
        try {
            checkConnection();
            return PreparedStatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.prepareStatement(sql,resultSetType,resultSetConcurrency));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.PreparedStatement prepareStatement(String sql, int resultSetType,
           int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        try {
            checkConnection();
            return PreparedStatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.prepareStatement(sql, resultSetType, resultSetConcurrency,resultSetHoldability));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.PreparedStatement prepareStatement(String sql, int resultSetType) throws SQLException {
        try {
            checkConnection();
            return PreparedStatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.prepareStatement(sql,resultSetType));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.PreparedStatement prepareStatement(String sql, int[] columnIndexes ) throws SQLException {
        try {
            checkConnection();
            return PreparedStatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.prepareStatement(sql,columnIndexes));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public java.sql.PreparedStatement prepareStatement(String sql, String[] columnNames ) throws SQLException {
        try {
            checkConnection();
            return PreparedStatementWrapper.getInstance(this, this.pooledConnection,
                    this.physicalConn.prepareStatement(sql,columnNames));
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // we don't reach this code, compiler can't tell
    }

    @Override
    public void releaseSavepoint(Savepoint savepoint) throws SQLException {
        try {
            checkConnection();
            this.physicalConn.releaseSavepoint(savepoint);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public void rollback() throws SQLException {
        try {
            checkConnection();
            this.physicalConn.rollback();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public void rollback(Savepoint savepoint) throws SQLException {
        try {
            checkConnection();
            this.physicalConn.rollback(savepoint);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    /**
     * The physical connection is not actually closed.
     * the physical connection is closed when the application server calls YasPooledConnection.close(). this
     * object is de-referenced by the pooled connection each time
     * YasPooledConnection.getConnection() is called by app server.
     *
     * @throws SQLException
     *             if an error occurs
     */
    @Override
    public void close() throws SQLException {
        try {
            close(true);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    protected void close(boolean fireClosedEvent) throws SQLException {
        synchronized (this.pooledConnection) {
            if (this.closed) {
                return;
            }

            if (fireClosedEvent) {
                this.pooledConnection.callConnectionEventListeners(
                        YasPooledConnection.CONNECTION_CLOSED_EVENT, null);
            }

            // set closed status to true so that if application client tries
            // to make additional calls a sqlException will be thrown.
            // The physical connection is re-used by
            // the pooled connection each time getConnection is called.
            this.closed = true;
        }
    }

    @Override
    public void setSchema(String schema) throws SQLException {
        checkConnection();
        this.physicalConn.setSchema(schema);
    }

    @Override
    public String getSchema() throws SQLException {
        checkConnection();
        return this.physicalConn.getSchema();
    }

    @Override
    public void abort(Executor executor) throws SQLException {
        try {
            checkConnection();
            this.physicalConn.abort(executor);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
        try {
            checkConnection();
            this.physicalConn.setNetworkTimeout(executor,milliseconds);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
    }

    @Override
    public int getNetworkTimeout() throws SQLException {
        try {
            checkConnection();
            return this.physicalConn.getNetworkTimeout();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
        return 0;
    }

    @Override
    public Clob createClob() throws SQLException {
        try {
            checkConnection();
            return ((java.sql.Connection) this.physicalConn).createClob();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // never reached, but compiler can't tell
    }

    @Override
    public Blob createBlob() throws SQLException {
        try {
            checkConnection();
            return ((java.sql.Connection) this.physicalConn).createBlob();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // never reached, but compiler can't tell
    }

    @Override
    public NClob createNClob() throws SQLException {
        try {
            checkConnection();
            return ((java.sql.Connection) this.physicalConn).createNClob();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // never reached, but compiler can't tell
    }

    @Override
    public SQLXML createSQLXML() throws SQLException {
        try {
            checkConnection();
            return ((java.sql.Connection) this.physicalConn).createSQLXML();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // never reached, but compiler can't tell
    }

    @Override
    public synchronized boolean isValid(int timeout) throws SQLException {
        try {
            checkConnection();
            return ((java.sql.Connection) this.physicalConn).isValid(timeout);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return false; // never reached, but compiler can't tell
    }

    @Override
    public void setClientInfo(String name, String value) throws SQLClientInfoException {
        try {
            checkConnection();
            ((java.sql.Connection) this.physicalConn).setClientInfo(name, value);
        } catch (SQLException sqlException) {
            try {
                checkConnectionError(sqlException);
            } catch (SQLException sqlEx2) {
                SQLClientInfoException clientEx = new SQLClientInfoException();
                clientEx.initCause(sqlEx2);
                throw clientEx;
            }
        }
    }

    @Override
    public void setClientInfo(Properties properties) throws SQLClientInfoException {
        try {
            checkConnection();
            this.physicalConn.setClientInfo(properties);
        } catch (SQLException sqlException) {
            try {
                checkConnectionError(sqlException);
            } catch (SQLException sqlEx2) {
                SQLClientInfoException clientEx = new SQLClientInfoException();
                clientEx.initCause(sqlEx2);
                throw clientEx;
            }
        }
    }

    @Override
    public String getClientInfo(String name) throws SQLException {
        try {
            return ((java.sql.Connection) this.physicalConn).getClientInfo(name);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // never reached, but compiler can't tell
    }

    @Override
    public Properties getClientInfo() throws SQLException {
        try {
            return ((java.sql.Connection) this.physicalConn).getClientInfo();
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // never reached, but compiler can't tell
    }

    @Override
    public java.sql.Array createArrayOf(String typeName, Object[] elements) throws SQLException {
        try {
            checkConnection();
            return ((java.sql.Connection) this.physicalConn).createArrayOf(typeName, elements);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // never reached, but compiler can't tell
    }

    @Override
    public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
        try {
            checkConnection();
            return ((java.sql.Connection) this.physicalConn).createStruct(typeName, attributes);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }

        return null; // never reached, but compiler can't tell
    }

    @Override
    public synchronized <T> T unwrap(java.lang.Class<T> iface) throws java.sql.SQLException {
        try {
            checkConnection();
            return this.physicalConn.unwrap(iface);
        } catch (SQLException sqlException) {
            checkConnectionError(sqlException);
        }
        return null;
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        boolean isInstance = iface.isInstance(this);

        if (isInstance) {
            return true;
        }

        return (iface.getName().equals("com.yashandb.jdbc.YasConnection")
                || iface.getName().equals(java.sql.Connection.class.getName())
                || iface.getName().equals(AutoCloseable.class.getName()));
    }

    private void checkConnection() throws SQLException {
        if (physicalConn == null || this.isClosed()) {
            throw new SQLException("Connection is closed.");
        }
    }

}
