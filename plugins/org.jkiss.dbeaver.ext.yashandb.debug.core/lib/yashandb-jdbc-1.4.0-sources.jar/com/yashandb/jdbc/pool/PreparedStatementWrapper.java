/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.pool;

import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;

/*
    PreparedStatementWrapper is a proxy of PreparedStatement.
    It will wrap most of method in PreparedStatement,and process the error and close event in the method.
 */
public class PreparedStatementWrapper extends StatementWrapper implements PreparedStatement {
    private static final Logger LOGGER = LoggerFactory.getLogger(PreparedStatementWrapper.class);

    protected static PreparedStatementWrapper getInstance(ConnectionWrapper c,
        YasPooledConnection conn, PreparedStatement toWrap) throws SQLException {
        return new PreparedStatementWrapper(c, conn, toWrap);
    }

    PreparedStatementWrapper(ConnectionWrapper c, YasPooledConnection conn, PreparedStatement toWrap) {
        super(c, conn, toWrap);
    }

    /**
     * Fires connection error event if required, before re-throwing exception
     *
     * @param sqlEx
     *            the SQLException that has occurred
     * @throws SQLException
     *             (rethrown)
     */
    @Override
    protected void checkErrorEvent(SQLException sqlEx) throws SQLException {
        LOGGER.warn("checkErrorEvent:" + sqlEx.getMessage());
        if (this.pooledConnection != null) {
            this.pooledConnection.callStatementEventListeners(pooledConnection.STATEMENT_ERROR_EVENT,
                    (PreparedStatement)this.wrappedStmt, sqlEx);
        }
        throw sqlEx;
    }

    @Override
    public void setArray(int parameterIndex, Array x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setArray(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setAsciiStream(parameterIndex, x, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setBigDecimal(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setBinaryStream(parameterIndex, x, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBlob(int parameterIndex, Blob x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setBlob(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBoolean(int parameterIndex, boolean x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setBoolean(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setByte(int parameterIndex, byte x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setByte(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBytes(int parameterIndex, byte[] x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setBytes(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setCharacterStream(parameterIndex, reader, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setClob(int parameterIndex, Clob x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setClob(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setDate(int parameterIndex, Date x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setDate(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setDate(parameterIndex, x, cal);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setDouble(int parameterIndex, double x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setDouble(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setFloat(int parameterIndex, float x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setFloat(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setInt(int parameterIndex, int x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setInt(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setLong(int parameterIndex, long x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setLong(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((PreparedStatement) this.wrappedStmt).getMetaData();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public void setNull(int parameterIndex, int sqlType) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setNull(parameterIndex, sqlType);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNull(int parameterIndex, int sqlType, String typeName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setNull(parameterIndex, sqlType, typeName);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setObject(int parameterIndex, Object x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setObject(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setObject(parameterIndex, x, targetSqlType);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setObject(parameterIndex, x, targetSqlType, scale);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public ParameterMetaData getParameterMetaData() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((PreparedStatement) this.wrappedStmt).getParameterMetaData();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public void setRef(int parameterIndex, Ref x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setRef(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setShort(int parameterIndex, short x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setShort(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setString(int parameterIndex, String x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setString(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setTime(int parameterIndex, Time x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setTime(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setTime(parameterIndex, x, cal);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setTimestamp(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setTimestamp(parameterIndex, x, cal);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setURL(int parameterIndex, URL x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setURL(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    @Deprecated
    public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setUnicodeStream(parameterIndex, x, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void addBatch() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).addBatch();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void clearParameters() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).clearParameters();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public boolean execute() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((PreparedStatement) this.wrappedStmt).execute();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public ResultSet executeQuery() throws SQLException {
        ResultSet rs = null;
        try {
            if (this.wrappedStmt == null) {
                throw sqlException;
            }
            rs = ((PreparedStatement) this.wrappedStmt).executeQuery();
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return rs;
    }

    @Override
    public int executeUpdate() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((PreparedStatement) this.wrappedStmt).executeUpdate();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public void setRowId(int parameterIndex, RowId x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setRowId(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNString(int parameterIndex, String value) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setNString(parameterIndex, value);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNCharacterStream(int parameterIndex, Reader value, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setNCharacterStream(parameterIndex, value, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNClob(int parameterIndex, NClob value) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setNClob(parameterIndex, value);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setClob(parameterIndex, reader, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setBlob(parameterIndex, inputStream, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setNClob(parameterIndex, reader, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setSQLXML(parameterIndex, xmlObject);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setAsciiStream(parameterIndex, x, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setBinaryStream(parameterIndex, x, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setCharacterStream(parameterIndex, reader, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setAsciiStream(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setBinaryStream(parameterIndex, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setCharacterStream(parameterIndex, reader);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

    }

    @Override
    public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setNCharacterStream(parameterIndex, value);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

    }

    @Override
    public void setClob(int parameterIndex, Reader reader) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setClob(parameterIndex, reader);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

    }

    @Override
    public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setBlob(parameterIndex, inputStream);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNClob(int parameterIndex, Reader reader) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setNClob(parameterIndex, reader);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {

        boolean isInstance = iface.isInstance(this);

        if (isInstance) {
            return true;
        }

        String interfaceClassName = iface.getName();

        return (interfaceClassName.equals("com.mysql.cj.jdbc.Statement")
                || interfaceClassName.equals("java.sql.Statement")
                || interfaceClassName.equals("java.sql.Wrapper")
                || interfaceClassName.equals("java.sql.PreparedStatement"));
    }

    @Override
    public synchronized <T> T unwrap(java.lang.Class<T> iface) throws java.sql.SQLException {
        try {
            if ("java.sql.Statement".equals(iface.getName()) || "java.sql.PreparedStatement".equals(iface.getName())
                    || "java.sql.Wrapper.class".equals(iface.getName())) {
                return iface.cast(this);
            }
        } catch (ClassCastException cce) {
            checkErrorEvent(new SQLException("Common.UnableToUnwrap:" + cce.getMessage()));
        }
        return null;
    }

    @Override
    public synchronized void close() throws SQLException {
        if (this.pooledConnection == null) {
            // no-op
            return;
        }

        try {
            super.close();
        } finally {
            this.pooledConnection.callStatementEventListeners(
                    this.pooledConnection.STATEMENT_CLOSED_EVENT,this,null);
        }
    }

    @Override
    public long executeLargeUpdate() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((PreparedStatement) this.wrappedStmt).executeLargeUpdate();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public void setObject(int parameterIndex, Object x, SQLType targetSqlType) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setObject(parameterIndex, x, targetSqlType);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setObject(int parameterIndex, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((PreparedStatement) this.wrappedStmt).setObject(parameterIndex, x, targetSqlType, scaleOrLength);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }
}
