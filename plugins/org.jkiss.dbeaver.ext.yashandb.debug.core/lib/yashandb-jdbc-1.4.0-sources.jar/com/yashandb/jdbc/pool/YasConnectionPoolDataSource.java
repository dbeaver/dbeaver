/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.pool;

import com.yashandb.jdbc.YasConnection;
import com.yashandb.jdbc.YasDataSource;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;

/**
 * A Connection Pool DataSource object is a factory for Connection objects. An object that
 * implements the DataSource interface will typically be registered with a JNDI
 * service provider. A JDBC driver that is accessed via the DataSource API does
 * not automatically register itself with the DriverManager.
 * It is used to obtain a physical connection and instantiate and return a YasPooledConnection.
 */
public class YasConnectionPoolDataSource extends YasDataSource implements ConnectionPoolDataSource {
    private static final long serialVersionUID = -547457772975661201L;
    private static final Logger LOGGER = LoggerFactory.getLogger(YasConnectionPoolDataSource.class);

    @Override
    public synchronized PooledConnection getPooledConnection() throws SQLException {
        return getPooledConnection(this.getUser(),this.password);
    }

    @Override
    public synchronized PooledConnection getPooledConnection(String user, String password) throws SQLException {
        LOGGER.debug("getPooledConnection with {}" ,user);
        Connection connection = getConnection(user,password);
        PooledConnection pooledConnection = YasPooledConnection.getInstance((YasConnection)connection);

        return pooledConnection;
    }

}
