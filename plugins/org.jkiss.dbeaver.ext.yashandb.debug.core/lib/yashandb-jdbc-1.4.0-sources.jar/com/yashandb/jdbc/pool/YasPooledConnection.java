/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.pool;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.sql.ConnectionEvent;
import javax.sql.ConnectionEventListener;
import javax.sql.PooledConnection;
import javax.sql.StatementEvent;
import javax.sql.StatementEventListener;

/**
 * YasPooledConnection is used to wrap and return a physical connection within a logical handle.
 * It also registers and notifies ConnectionEventListeners of any
 * ConnectionEvents, It implements javax.sql.PooledConnection.
 */
public class YasPooledConnection implements PooledConnection, Serializable {
    //The flag for an exception being thrown.
    public static final int CONNECTION_ERROR_EVENT = 1;
    //The flag for a connection being closed.
    public static final int CONNECTION_CLOSED_EVENT = 2;
    //The flag for an exception being thrown.
    public static final int STATEMENT_ERROR_EVENT = 3;
    //The flag for a statement being closed.
    public static final int STATEMENT_CLOSED_EVENT = 4;

    private static final long serialVersionUID = 6677891687109972348L;

    // To represent the latest Object Handle
    protected transient Connection logicalHandle = null;
    // Connection Representing the physical Connection
    protected transient Connection physicalConn = null;

    private Map<ConnectionEventListener, ConnectionEventListener> connectionEventListeners;
    private Map<StatementEventListener, StatementEventListener> statementEventListeners ;

    protected static YasPooledConnection getInstance(Connection connection) throws SQLException {
        return new YasPooledConnection(connection);
    }

    public YasPooledConnection(Connection connection) {
        this.physicalConn = connection;
        this.connectionEventListeners = new HashMap<>();
        this.statementEventListeners = new HashMap<>();
    }

    @Override
    public Connection getConnection() throws SQLException {
        return getConnection(false);
    }

    protected synchronized Connection getConnection( boolean isXa) throws SQLException {
        if (this.physicalConn == null) {
            SQLException sqlException = new SQLException("Physical Connection doesn't exist");
            callConnectionEventListeners(CONNECTION_ERROR_EVENT, sqlException);
            throw sqlException;
        }

        try {
            // Close the Previous logical Handle
            if (this.logicalHandle != null) {
                (this.logicalHandle).close();
            }

            this.logicalHandle = ConnectionWrapper.getInstance(this, this.physicalConn, isXa);
        } catch (SQLException sqlException) {
            callConnectionEventListeners(CONNECTION_ERROR_EVENT, sqlException);
            throw sqlException;
        }

        return this.logicalHandle;
    }

    @Override
    public synchronized void close() throws SQLException {
        if (this.physicalConn != null) {
            this.physicalConn.close();
            this.physicalConn = null;
        }

        if (this.connectionEventListeners != null) {
            this.connectionEventListeners.clear();
            this.connectionEventListeners = null;
        }

        if (this.statementEventListeners != null) {
            this.statementEventListeners.clear();
            this.statementEventListeners = null;
        }
    }

    @Override
    public void addConnectionEventListener(ConnectionEventListener listener) {
        if (this.connectionEventListeners != null) {
            this.connectionEventListeners.put(listener, listener);
        }
    }

    @Override
    public void removeConnectionEventListener(ConnectionEventListener listener) {
        if (this.connectionEventListeners != null) {
            this.connectionEventListeners.remove(listener);
        }
    }

    @Override
    public void addStatementEventListener(StatementEventListener listener) {
        if (this.statementEventListeners != null) {
            this.statementEventListeners.put(listener, listener);
        }
    }

    @Override
    public void removeStatementEventListener(StatementEventListener listener) {
        if (this.statementEventListeners != null) {
            this.statementEventListeners.remove(listener);
        }
    }

    /**
     * Notifies all registered ConnectionEventListeners of ConnectionEvents.
     * Instantiates a new ConnectionEvent which wraps sqlException and invokes
     * either connectionClose or connectionErrorOccurred on listener as
     * appropriate.
     *
     * @param eventType
     *            value indicating whether connectionClosed or
     *            connectionErrorOccurred called
     * @param sqlException
     *            the exception being thrown
     */
    protected synchronized void callConnectionEventListeners(int eventType, SQLException sqlException) {
        if (this.connectionEventListeners == null) {
            return;
        }

        Iterator<Map.Entry<ConnectionEventListener, ConnectionEventListener>> iterator =
                this.connectionEventListeners.entrySet().iterator();
        ConnectionEvent connectionevent = new ConnectionEvent(this, sqlException);

        while (iterator.hasNext()) {
            ConnectionEventListener connectioneventlistener = iterator.next().getValue();

            if (eventType == CONNECTION_CLOSED_EVENT) {
                connectioneventlistener.connectionClosed(connectionevent);
            } else if (eventType == CONNECTION_ERROR_EVENT) {
                connectioneventlistener.connectionErrorOccurred(connectionevent);
            }
        }
    }

    /**
     * Notifies all registered StatementEventListeners of StatementEvent.
     * Instantiates a new statementEvent which wraps sqlException and invokes
     * either statementClosed or statementErrorOccurred on listener as
     * appropriate.
     *
     * @param eventType
     *            value indicating whether statementClosed or
     *            statementErrorOccurred called
     * @param sqlException
     *            the exception being thrown
     */
    protected synchronized void callStatementEventListeners(int eventType,
                                                            PreparedStatement pstmt , SQLException sqlException) {
        if (this.statementEventListeners == null) {
            return;
        }

        Iterator<Map.Entry<StatementEventListener, StatementEventListener>> iterator =
                this.statementEventListeners.entrySet().iterator();
        StatementEvent statementEvent = new StatementEvent(this, pstmt,sqlException);

        while (iterator.hasNext()) {
            StatementEventListener statementEventListener = iterator.next().getValue();

            if (eventType == STATEMENT_CLOSED_EVENT) {
                statementEventListener.statementClosed(statementEvent);
            } else if (eventType == STATEMENT_ERROR_EVENT) {
                statementEventListener.statementErrorOccurred(statementEvent);
            }
        }
    }
}
