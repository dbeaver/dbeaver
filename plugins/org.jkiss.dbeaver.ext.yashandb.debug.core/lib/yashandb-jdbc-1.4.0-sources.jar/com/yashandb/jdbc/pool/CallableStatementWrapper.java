/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.pool;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;

/*
    CallableStatementWrapper is a proxy of CallableStatement.
    It will wrap most of method in CallableStatement,and process the error and close event in the method.
 */
public class CallableStatementWrapper extends PreparedStatementWrapper implements CallableStatement {
    protected static CallableStatementWrapper getInstance(ConnectionWrapper c,
        YasPooledConnection conn, CallableStatement toWrap) throws SQLException {
        return new CallableStatementWrapper(c, conn, toWrap);
    }

    /**
     * @param c
     *            ConnectionWrapper
     * @param conn
     *            MysqlPooledConnection
     * @param toWrap
     *            CallableStatement
     */
    public CallableStatementWrapper(ConnectionWrapper c, YasPooledConnection conn, CallableStatement toWrap) {
        super(c, conn, toWrap);
    }

    @Override
    public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterIndex, sqlType);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterIndex, sqlType, scale);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public boolean wasNull() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).wasNull();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false;
    }

    @Override
    public String getString(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getString(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public boolean getBoolean(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getBoolean(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false;
    }

    @Override
    public byte getByte(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getByte(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public short getShort(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getShort(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public int getInt(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getInt(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public long getLong(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getLong(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public float getFloat(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getFloat(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public double getDouble(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getDouble(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    @Deprecated
    public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getBigDecimal(parameterIndex, scale);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public byte[] getBytes(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getBytes(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Date getDate(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getDate(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Time getTime(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getTime(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Timestamp getTimestamp(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getTimestamp(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Object getObject(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getObject(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getBigDecimal(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Object getObject(int parameterIndex, Map<String, Class<?>> typeMap) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getObject(parameterIndex, typeMap);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Ref getRef(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getRef(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Blob getBlob(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getBlob(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Clob getClob(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getClob(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Array getArray(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getArray(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Date getDate(int parameterIndex, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getDate(parameterIndex, cal);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Time getTime(int parameterIndex, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getTime(parameterIndex, cal);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getTimestamp(parameterIndex, cal);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public void registerOutParameter(int paramIndex, int sqlType, String typeName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(paramIndex, sqlType, typeName);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void registerOutParameter(String parameterName, int sqlType) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterName, sqlType);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterName, sqlType, scale);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterName, sqlType, typeName);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public URL getURL(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getURL(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public void setURL(String parameterName, URL val) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setURL(parameterName, val);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNull(String parameterName, int sqlType) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setNull(parameterName, sqlType);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBoolean(String parameterName, boolean x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setBoolean(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setByte(String parameterName, byte x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setByte(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setShort(String parameterName, short x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setShort(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setInt(String parameterName, int x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setInt(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setLong(String parameterName, long x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setLong(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setFloat(String parameterName, float x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setFloat(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setDouble(String parameterName, double x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setDouble(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBigDecimal(String parameterName, BigDecimal x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setBigDecimal(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setString(String parameterName, String x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setString(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBytes(String parameterName, byte[] x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setBytes(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setDate(String parameterName, Date x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setDate(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setTime(String parameterName, Time x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setTime(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setTimestamp(String parameterName, Timestamp x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setTimestamp(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setAsciiStream(String parameterName, InputStream x, int length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setAsciiStream(parameterName, x, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

    }

    @Override
    public void setBinaryStream(String parameterName, InputStream x, int length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setBinaryStream(parameterName, x, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setObject(String parameterName, Object x, int targetSqlType, int scale) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setObject(parameterName, x, targetSqlType, scale);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setObject(String parameterName, Object x, int targetSqlType) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setObject(parameterName, x, targetSqlType);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setObject(String parameterName, Object x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setObject(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setCharacterStream(String parameterName, Reader reader, int length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setCharacterStream(parameterName, reader, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setDate(String parameterName, Date x, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setDate(parameterName, x, cal);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setTime(String parameterName, Time x, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setTime(parameterName, x, cal);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setTimestamp(parameterName, x, cal);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNull(String parameterName, int sqlType, String typeName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setNull(parameterName, sqlType, typeName);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public String getString(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getString(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public boolean getBoolean(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getBoolean(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false;
    }

    @Override
    public byte getByte(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getByte(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public short getShort(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getShort(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return 0;
    }

    @Override
    public int getInt(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getInt(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return 0;
    }

    @Override
    public long getLong(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getLong(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public float getFloat(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getFloat(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public double getDouble(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getDouble(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public byte[] getBytes(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getBytes(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Date getDate(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getDate(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Time getTime(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getTime(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Timestamp getTimestamp(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getTimestamp(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Object getObject(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getObject(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public BigDecimal getBigDecimal(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getBigDecimal(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Object getObject(String parameterName, Map<String, Class<?>> typeMap) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getObject(parameterName, typeMap);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Ref getRef(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getRef(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Blob getBlob(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getBlob(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Clob getClob(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getClob(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Array getArray(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getArray(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Date getDate(String parameterName, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getDate(parameterName, cal);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Time getTime(String parameterName, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getTime(parameterName, cal);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Timestamp getTimestamp(String parameterName, Calendar cal) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getTimestamp(parameterName, cal);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public URL getURL(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getURL(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public RowId getRowId(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getRowId(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public RowId getRowId(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getRowId(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public void setRowId(String parameterName, RowId x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setRowId(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNString(String parameterName, String value) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setNString(parameterName, value);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNCharacterStream(String parameterName, Reader reader, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setNCharacterStream(parameterName, reader, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNClob(String parameterName, NClob value) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setNClob(parameterName, value);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setClob(String parameterName, Reader reader, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setClob(parameterName, reader, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBlob(String parameterName, InputStream x, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setBlob(parameterName, x, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNClob(String parameterName, Reader reader, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setNClob(parameterName, reader, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public NClob getNClob(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getNClob(parameterName);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public NClob getNClob(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getNClob(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public void setSQLXML(String parameterName, SQLXML xmlObject) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setSQLXML(parameterName, xmlObject);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public SQLXML getSQLXML(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getSQLXML(parameterIndex);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public SQLXML getSQLXML(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getSQLXML(parameterName);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public String getNString(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getNString(parameterIndex);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public String getNString(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getNString(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Reader getNCharacterStream(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getNCharacterStream(parameterIndex);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Reader getNCharacterStream(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getNCharacterStream(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public Reader getCharacterStream(int parameterIndex) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getCharacterStream(parameterIndex);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public Reader getCharacterStream(String parameterName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return ((CallableStatement) this.wrappedStmt).getCharacterStream(parameterName);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public void setBlob(String parameterName, Blob x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setBlob(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setClob(String parameterName, Clob x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setClob(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setAsciiStream(String parameterName, InputStream x, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setAsciiStream(parameterName, x, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBinaryStream(String parameterName, InputStream x, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setBinaryStream(parameterName, x, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setCharacterStream(String parameterName, Reader reader, long length) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setCharacterStream(parameterName, reader, length);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setAsciiStream(String parameterName, InputStream x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setAsciiStream(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBinaryStream(String parameterName, InputStream x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setBinaryStream(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setCharacterStream(String parameterName, Reader reader) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setCharacterStream(parameterName, reader);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNCharacterStream(String parameterName, Reader reader) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setNCharacterStream(parameterName, reader);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setClob(String parameterName, Reader reader) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setClob(parameterName, reader);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setBlob(String parameterName, InputStream x) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setBlob(parameterName, x);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setNClob(String parameterName, Reader reader) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).setNClob(parameterName, reader);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public <T> T getObject(int parameterIndex, Class<T> type) throws SQLException {
        if (this.wrappedStmt != null) {
            return null; // TODO
        }
        throw sqlException; 
    }

    @Override
    public <T> T getObject(String parameterName, Class<T> type) throws SQLException {
        if (this.wrappedStmt != null) {
            return null; // TODO
        }
        throw sqlException; 
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {

        boolean isInstance = iface.isInstance(this);

        if (isInstance) {
            return true;
        }

        String interfaceClassName = iface.getName();

        return (interfaceClassName.equals("com.mysql.cj.jdbc.Statement")
                || interfaceClassName.equals("java.sql.Statement")
                || interfaceClassName.equals("java.sql.Wrapper")
                || interfaceClassName.equals("java.sql.PreparedStatement")
                || interfaceClassName.equals("java.sql.CallableStatement"));
    }

    @Override
    public void close() throws SQLException {
        super.close();
    }

    @Override
    public synchronized <T> T unwrap(java.lang.Class<T> iface) throws java.sql.SQLException {
        try {
            if ("java.sql.Statement".equals(iface.getName())
                    || "java.sql.CallableStatement".equals(iface.getName())
                    || "java.sql.PreparedStatement".equals(iface.getName())
                    || "java.sql.Wrapper.class".equals(iface.getName())) {
                return iface.cast(this);
            }
            throw new SQLException("Common.UnableToUnwrap");
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public void registerOutParameter(int parameterIndex, SQLType sqlType) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterIndex, sqlType);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void registerOutParameter(int parameterIndex, SQLType sqlType, int scale) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterIndex, sqlType, scale);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void registerOutParameter(int parameterIndex, SQLType sqlType, String typeName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterIndex, sqlType, typeName);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void registerOutParameter(String parameterName, SQLType sqlType) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterName, sqlType);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void registerOutParameter(String parameterName, SQLType sqlType, int scale) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterName, sqlType, scale);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void registerOutParameter(String parameterName, SQLType sqlType, String typeName) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ((CallableStatement) this.wrappedStmt).registerOutParameter(parameterName, sqlType, typeName);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

}
