/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc.pool;

import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;

/*
    StatementWrapper is a proxy of Statement.
    It will wrap most of method in statement,and process the error and close event in the method.
 */
public class StatementWrapper implements Statement {
    private static final Logger LOGGER = LoggerFactory.getLogger(StatementWrapper.class);
    protected Statement wrappedStmt;
    protected ConnectionWrapper wrappedConn;
    protected YasPooledConnection pooledConnection;
    protected SQLException sqlException = new SQLException("Statement.AlreadyClosed");

    protected static StatementWrapper getInstance(ConnectionWrapper c,
                                                  YasPooledConnection conn, Statement toWrap) throws SQLException {
        return new StatementWrapper(c, conn, toWrap);
    }

    public StatementWrapper(ConnectionWrapper c, YasPooledConnection conn, Statement toWrap) {
        this.pooledConnection = conn;
        this.wrappedStmt = toWrap;
        this.wrappedConn = c;
    }

    /**
     * Fires connection error event if required, before re-throwing exception
     *
     * @param sqlEx
     *            the SQLException that has occurred
     * @throws SQLException
     *             (rethrown)
     */
    protected void checkErrorEvent(SQLException sqlEx) throws SQLException {
        LOGGER.warn("checkErrorEvent:" + sqlEx.getMessage());
        if (this.pooledConnection != null) {
            this.pooledConnection.callConnectionEventListeners(pooledConnection.CONNECTION_ERROR_EVENT, sqlEx);
        }
        throw sqlEx;
    }

    @Override
    public Connection getConnection() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedConn;
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public void setCursorName(String name) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.setCursorName(name);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setEscapeProcessing(boolean enable) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.setEscapeProcessing(enable);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void setFetchDirection(int direction) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.setFetchDirection(direction);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public int getFetchDirection() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getFetchDirection();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return ResultSet.FETCH_FORWARD; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public void setFetchSize(int rows) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.setFetchSize(rows);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public int getFetchSize() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getFetchSize();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public ResultSet getGeneratedKeys() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getGeneratedKeys();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public void setMaxFieldSize(int max) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.setMaxFieldSize(max);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public int getMaxFieldSize() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getMaxFieldSize();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public void setMaxRows(int max) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.setMaxRows(max);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public int getMaxRows() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getMaxRows();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public boolean getMoreResults() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getMoreResults();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false;
    }

    @Override
    public boolean getMoreResults(int current) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getMoreResults(current);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false;
    }

    @Override
    public void setQueryTimeout(int seconds) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.setQueryTimeout(seconds);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public int getQueryTimeout() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getQueryTimeout();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public ResultSet getResultSet() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                ResultSet rs = this.wrappedStmt.getResultSet();
                return rs;
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public int getResultSetConcurrency() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getResultSetConcurrency();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0;
    }

    @Override
    public int getResultSetHoldability() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getResultSetHoldability();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return Statement.CLOSE_CURRENT_RESULT;
    }

    @Override
    public int getResultSetType() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getResultSetType();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return ResultSet.TYPE_FORWARD_ONLY;
    }

    @Override
    public int getUpdateCount() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getUpdateCount();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1;
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getWarnings();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null;
    }

    @Override
    public void addBatch(String sql) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.addBatch(sql);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void cancel() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.cancel();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void clearBatch() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.clearBatch();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void clearWarnings() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.clearWarnings();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public void close() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.close();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        } finally {
            this.wrappedStmt = null;
            //this.pooledConnection = null;
        }
    }

    @Override
    public boolean execute(String sql, int autoGeneratedKeys) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.execute(sql, autoGeneratedKeys);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public boolean execute(String sql, int[] columnIndexes) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.execute(sql, columnIndexes);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public boolean execute(String sql, String[] columnNames) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.execute(sql, columnNames);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public boolean execute(String sql) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.execute(sql);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public int[] executeBatch() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.executeBatch();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public ResultSet executeQuery(String sql) throws SQLException {
        ResultSet rs = null;
        try {
            if (this.wrappedStmt == null) {
                throw sqlException;
            }
            rs = this.wrappedStmt.executeQuery(sql);
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return rs;
    }

    @Override
    public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.executeUpdate(sql, autoGeneratedKeys);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public int executeUpdate(String sql, int[] columnIndexes) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.executeUpdate(sql, columnIndexes);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public int executeUpdate(String sql, String[] columnNames) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.executeUpdate(sql, columnNames);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public int executeUpdate(String sql) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.executeUpdate(sql);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public synchronized <T> T unwrap(java.lang.Class<T> iface) throws java.sql.SQLException {
        try {
            if ("java.sql.Statement".equals(iface.getName()) || "java.sql.Wrapper.class".equals(iface.getName())) {
                return iface.cast(this);
            }
            throw new SQLException("Common.UnableToUnwrap");
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return null;
    }

    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {

        boolean isInstance = iface.isInstance(this);

        if (isInstance) {
            return true;
        }

        String interfaceClassName = iface.getName();

        return (interfaceClassName.equals("com.mysql.cj.jdbc.Statement")
                || interfaceClassName.equals("java.sql.Statement")
                || interfaceClassName.equals("java.sql.Wrapper"));
    }

    @Override
    public boolean isClosed() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.isClosed();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false; // We never get here, compiler can't tell
    }

    @Override
    public void setPoolable(boolean poolable) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.setPoolable(poolable);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public boolean isPoolable() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.isPoolable();
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return false; // We never get here, compiler can't tell
    }

    @Override
    public void closeOnCompletion() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.closeOnCompletion();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }

    @Override
    public boolean isCloseOnCompletion() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return wrappedStmt.isCloseOnCompletion();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
        return false;
    }

    @Override
    public long[] executeLargeBatch() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.executeLargeBatch();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return null; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public long executeLargeUpdate(String sql) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.executeLargeUpdate(sql);
            }
            throw sqlException;
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public long executeLargeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.executeLargeUpdate(sql, autoGeneratedKeys);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public long executeLargeUpdate(String sql, int[] columnIndexes) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.executeLargeUpdate(sql, columnIndexes);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public long executeLargeUpdate(String sql, String[] columnNames) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.executeLargeUpdate(sql, columnNames);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public long getLargeMaxRows() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getLargeMaxRows();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return 0; // we actually never get here, but the compiler can't figure that out
    }

    @Override
    public long getLargeUpdateCount() throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                return this.wrappedStmt.getLargeUpdateCount();
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }

        return -1;
    }

    @Override
    public void setLargeMaxRows(long max) throws SQLException {
        try {
            if (this.wrappedStmt != null) {
                this.wrappedStmt.setLargeMaxRows(max);
            } else {
                throw sqlException;
            }
        } catch (SQLException sqlEx) {
            checkErrorEvent(sqlEx);
        }
    }
}
