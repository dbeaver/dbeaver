/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.Query;
import com.yashandb.YasResultSet;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.SQLException;
import java.sql.Statement;

/**
 * This interface defines the public YashanDB extensions to java.sql.Statement. All Statements
 * constructed by the YashanDB driver implement YasStatement.
 */
public interface YasStatement extends Statement, Query {

    // We can't use Long.MAX_VALUE or Long.MIN_VALUE for java.sql.date
    // because this would break the 'normalization contract' of the
    // java.sql.Date API.
    // The follow values are the nearest MAX/MIN values with hour,
    // minute, second, millisecond set to 0 - this is used for
    // -infinity / infinity representation in Java
    long DATE_POSITIVE_INFINITY = 9223372036825200000L;
    long DATE_NEGATIVE_INFINITY = -9223372036832400000L;
    long DATE_POSITIVE_SMALLER_INFINITY = 185543533774800000L;
    long DATE_NEGATIVE_SMALLER_INFINITY = -185543533774800000L;

    /**
     * Execute a query, passing additional query flags.
     *
     * @param sql the query to execute (JDBC-style query)
     * @return true if there is a result set
     * @throws SQLException if something goes wrong.
     */
    boolean executeInternal(String sql) throws SQLException;

    int getColumnCount();

    YasResultSet createResultSet(RowData rowData) throws SQLException;

    default void createParameterResult(Row outParameters) throws SQLException {
        throw SQLError.createSQLException("no out parameters", YasState.DATA_ERROR);
    }

    void setStream(YasInputStream stream) throws SQLException;

    void drainStream() throws SQLException;

    void closeStream(int columnIndex) throws SQLException;

    boolean getIsBatchError();

    void setIsBatchError(boolean batchError);

    String getBatchError(int batchIndex);

    void addImplicitResultSet(YasResultSet resultSet);
}
