/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.SQLException;

public interface YasLargeObject {
    void freeTemp() throws SQLException;

    void setConnection(YasConnection connection);

    int getStepSize() throws SQLException;

    int getBytes(long lobOffset, byte[] data) throws SQLException;

    default String getString(long lobOffset, int length) throws SQLException {
        throw SQLError.createSQLException("lob getString not support", YasState.DATA_ERROR);
    }

    long getLobLength() throws SQLException;

    default int writeBytes(long pos, byte[] bytes, int offset, int len) throws SQLException {
        throw SQLError.createSQLException("lob write bytes not support", YasState.DATA_ERROR);
    }

    default int writeString(long pos, String str) throws SQLException {
        throw SQLError.createSQLException("lob write string not support", YasState.DATA_ERROR);
    }

    void rollback() throws SQLException;

    void commit() throws SQLException;
}
