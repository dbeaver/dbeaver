/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.SessionImpl;
import com.yashandb.protocol.ExecuteResult;
import com.yashandb.protocol.Packet;
import com.yashandb.util.YasSQL;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RowDataFactory {

    public static RowData createRowDataImpl(SessionImpl session, StatementImpl stmt,
                                            Packet ack, ExecuteResult result) throws SQLException {
        RowDataImpl rowDataImpl;
        YasSQL yasSQL = stmt.getYasSQL();
        if (stmt.getResultSetType() == ResultSet.TYPE_SCROLL_INSENSITIVE
            || stmt.getResultSetType() == ResultSet.TYPE_SCROLL_SENSITIVE) {
            rowDataImpl = new ScrollableRowDataImpl(session,stmt,ack,result);
        } else {
            rowDataImpl = new RowDataImpl(session,stmt,ack,result);
        }

        if (yasSQL != null && yasSQL.canRowID()) {
            rowDataImpl.setHasRowID(true);
        }

        return rowDataImpl;
    }

    public static RowData createStaticRow(Row row) throws SQLException {
        return new StaticRowData(row);
    }

    public static RowData createDynamicRow(Row row) throws SQLException {
        return new DynamicRowData(row);
    }
}
