/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.core.DataType;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.Messages;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;

public class YasTypes {

    // Copied from java.sql.Types.
    // It is not possible to subclass java.sql.Types
    // because java.sql.Types has defined a private constructor to
    // prevent instantiation.
    public static final int BIT = Types.BIT;
    public static final int TINYINT = Types.TINYINT;
    public static final int SMALLINT = Types.SMALLINT;
    public static final int INTEGER = Types.INTEGER;
    public static final int BIGINT = Types.BIGINT;
    public static final int FLOAT = Types.FLOAT;
    public static final int DOUBLE = Types.DOUBLE;
    public static final int BOOLEAN = Types.BOOLEAN;
    public static final int REAL = Types.REAL;
    public static final int NUMERIC = Types.NUMERIC;
    public static final int NUMBER = Types.NUMERIC;
    public static final int DECIMAL = Types.DECIMAL;

    public static final int TIME = Types.TIME;
    public static final int DATE = Types.DATE;
    public static final int TIMESTAMP = Types.TIMESTAMP;
    public static final int TIMESTAMP_TZ = Types.TIMESTAMP_WITH_TIMEZONE;
    public static final int TIMESTAMP_LTZ = Types.TIMESTAMP_WITH_TIMEZONE;
    public static final int SHORTTIME = Types.TIME;

    public static final int CHAR = Types.CHAR;
    public static final int NCHAR = Types.NCHAR;
    public static final int VARCHAR = Types.VARCHAR;
    public static final int NVARCHAR = Types.NVARCHAR;

    public static final int CLOB = Types.CLOB;
    public static final int BLOB = Types.BLOB;
    public static final int NCLOB = Types.NCLOB;

    public static final int ROWID = Types.ROWID;
    public static final int STRUCT = Types.STRUCT;
    public static final int ARRAY = Types.ARRAY;
    public static final int REF = Types.REF;
    public static final int BINARY =  Types.BINARY;
    public static final int RAW = Types.BINARY;
    public static final int VARBINARY = Types.VARBINARY;
    public static final int LONGVARBINARY = Types.LONGVARBINARY;

    public static final int NULL = Types.NULL;
    public static final int UNKNOWN = Types.NULL;
    public static final int OTHER = Types.OTHER;

    public static final int REF_CURSOR = 2012;

    // YashanDB Extend DataType
    private static final int YASHAN_JDBC_TYPES_BASE = 3000;

    public static final int YM_INTERVAL = YASHAN_JDBC_TYPES_BASE + 1;
    public static final int DS_INTERVAL = YASHAN_JDBC_TYPES_BASE + 2;
    public static final int UTINYINT = YASHAN_JDBC_TYPES_BASE + 3;
    public static final int USMALLINT = YASHAN_JDBC_TYPES_BASE + 4;
    public static final int UINTEGER = YASHAN_JDBC_TYPES_BASE + 5;
    public static final int UBIGINT = YASHAN_JDBC_TYPES_BASE + 6;
    public static final int SHORTDATE = YASHAN_JDBC_TYPES_BASE + 7;

    public static final int CURSOR = YASHAN_JDBC_TYPES_BASE + 8;
    public static final int JSON = YASHAN_JDBC_TYPES_BASE + 9;

    public static int getSQLType(int yashanType) {
        switch (yashanType) {
            case DataType.TINYINT:
                return Types.TINYINT;
            case DataType.SMALLINT:
                return Types.SMALLINT;
            case DataType.INTEGER:
                return Types.INTEGER;
            case DataType.BIGINT:
                return Types.BIGINT;
            case DataType.FLOAT:
                return Types.REAL;
            case DataType.DOUBLE:
                return Types.DOUBLE;
            case DataType.NUMBER:
                return Types.NUMERIC;
            case DataType.SHORTTIME:
                return Types.TIME;
            case DataType.DATE:
                return Types.DATE;
            case DataType.TIMESTAMP:
                return Types.TIMESTAMP;
            case DataType.TIMESTAMP_TZ:
                return Types.TIMESTAMP_WITH_TIMEZONE;
            case DataType.TIMESTAMP_LTZ:
                return Types.TIMESTAMP_WITH_TIMEZONE;
            case DataType.CHAR:
                return Types.CHAR;
            case DataType.NCHAR:
                return Types.NCHAR;
            case DataType.VARCHAR:
                return Types.VARCHAR;
            case DataType.NVARCHAR:
                return Types.NVARCHAR;
            case DataType.RAW:
                return Types.BINARY;
            case DataType.CLOB:
                return Types.CLOB;
            case DataType.BLOB:
                return Types.BLOB;
            case DataType.BIT:
                return Types.BIT;
            case DataType.BOOLEAN:
                return Types.BOOLEAN;
            case DataType.ROWID:
                return Types.ROWID;
            case DataType.UNKNOWN:
                return Types.NULL;
            case DataType.YM_INTERVAL:
                return YasTypes.YM_INTERVAL;
            case DataType.DS_INTERVAL:
                return YasTypes.DS_INTERVAL;
            case DataType.UTINYINT:
                return YasTypes.UTINYINT;
            case DataType.USMALLINT:
                return YasTypes.USMALLINT;
            case DataType.UINTEGER:
                return YasTypes.UINTEGER;
            case DataType.UBIGINT:
                return YasTypes.UBIGINT;
            case DataType.SHORTDATE:
                return YasTypes.SHORTDATE;
            case DataType.CURSOR:
                return YasTypes.CURSOR;
            case DataType.JSON:
                return YasTypes.JSON;
            default:
                return Types.OTHER;
        }
    }

    public static int getYasType(int sqlType) throws SQLException {
        int yashanType;
        switch (sqlType) {
            case Types.INTEGER:
                yashanType = DataType.INTEGER;
                break;
            case Types.TINYINT:
                yashanType = DataType.TINYINT;
                break;
            case Types.SMALLINT:
                yashanType = DataType.SMALLINT;
                break;
            case Types.BIGINT:
                yashanType = DataType.BIGINT;
                break;
            case Types.BIT:
                yashanType = DataType.BIT;
                break;
            case Types.BOOLEAN:
                yashanType = DataType.BOOLEAN;
                break;
            case Types.REAL:
                yashanType = DataType.FLOAT;
                break;
            case Types.DOUBLE:
            case Types.FLOAT:
                yashanType = DataType.DOUBLE;
                break;
            case Types.DECIMAL:
            case Types.NUMERIC:
                yashanType = DataType.NUMBER;
                break;
            case Types.CHAR:
                yashanType = DataType.CHAR;
                break;
            case Types.VARCHAR:
            case Types.LONGVARCHAR:
                yashanType = DataType.VARCHAR;
                break;
            case Types.DATE:
                yashanType = DataType.DATE;
                break;
            case Types.TIME:
            case Types.TIME_WITH_TIMEZONE:
                yashanType = DataType.SHORTTIME;
                break;
            case Types.TIMESTAMP_WITH_TIMEZONE:
            case Types.TIMESTAMP:
                yashanType = DataType.TIMESTAMP;
                break;
            case YasTypes.DS_INTERVAL:
                yashanType = DataType.DS_INTERVAL;
                break;
            case YasTypes.YM_INTERVAL:
                yashanType = DataType.YM_INTERVAL;
                break;
            case Types.BINARY:
            case Types.VARBINARY:
            case Types.LONGVARBINARY:
                yashanType = DataType.RAW;
                break;
            case Types.BLOB:
                yashanType = DataType.BLOB;
                break;
            case Types.CLOB:
                yashanType = DataType.CLOB;
                break;
            case Types.ROWID:
                yashanType = DataType.ROWID;
                break;
            case Types.ARRAY:
            case Types.DISTINCT:
            case Types.STRUCT:
            case Types.NULL:
            case Types.OTHER:
                yashanType = DataType.UNKNOWN;
                break;
            case YasTypes.REF_CURSOR:
            case YasTypes.CURSOR:
                yashanType = DataType.CURSOR;
                break;
            case YasTypes.JSON:
                yashanType = DataType.JSON;
                break;
            default:
                // Bad Types value.
                throw SQLError.createSQLException(Messages.get("Unknown Types value."),
                        YasState.INVALID_PARAMETER_TYPE);
        }

        return yashanType;
    }

    public static String getTypeClassName(int yashanType) {
        switch (yashanType) {
            case DataType.TINYINT:
            case DataType.SMALLINT:
            case DataType.INTEGER:
                return Integer.class.getName();
            case DataType.BIGINT:
                return Long.class.getName();
            case DataType.FLOAT:
                return Float.class.getName();
            case DataType.DOUBLE:
                return Double.class.getName();
            case DataType.NUMBER:
                return BigDecimal.class.getName();
            case DataType.SHORTTIME:
                return Time.class.getName();
            case DataType.DATE:
                return Date.class.getName();
            case DataType.TIMESTAMP:
                return Timestamp.class.getName();
            case DataType.TIMESTAMP_TZ:
                return Timestamp.class.getName();
            case DataType.TIMESTAMP_LTZ:
                return Timestamp.class.getName();
            case DataType.CHAR:
            case DataType.NCHAR:
            case DataType.VARCHAR:
            case DataType.NVARCHAR:
                return String.class.getName();
            case DataType.RAW:
                return byte[].class.getName();
            case DataType.CLOB:
                return Clob.class.getName();
            case DataType.BLOB:
                return Blob.class.getName();
            case DataType.BIT:
                return byte[].class.getName();
            case DataType.BOOLEAN:
                return Boolean.class.getName();
            case DataType.ROWID:
                return RowId.class.getName();
            case DataType.UNKNOWN:
                return null;
            case DataType.YM_INTERVAL:
                return String.class.getName();
            case DataType.DS_INTERVAL:
                return String.class.getName();
            case DataType.UTINYINT:
            case DataType.USMALLINT:
            case DataType.UINTEGER:
                return Integer.class.getName();
            case DataType.UBIGINT:
                return Long.class.getName();
            case DataType.SHORTDATE:
                return Date.class.getName();
            default:
                return null;
        }
    }

}
