/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.YasConstants;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;

public class YasBlobOutputStream extends OutputStream {

    private YasLargeObject largeObject = null;

    private long lobPos = 0L;

    private int cachePos = 0;

    private byte[] cacheData = null;

    private boolean isClosed = false;

    private final Object lock = new Object();

    YasBlobOutputStream(YasLargeObject largeObject, long lobPos) throws SQLException {
        this.largeObject = largeObject;
        this.lobPos = lobPos;

        cachePos = 0;

        int stepSize = largeObject.getStepSize();
        if (stepSize > 0) {
            cacheData = new byte[stepSize];
        } else {
            cacheData = new byte[YasConstants.LONG_BIND_SIZE];
        }
    }

    private void ensureOpen() throws IOException {
        if (isClosed) {
            throw new IOException("stream closed");
        }
    }

    @Override
    public void flush() throws IOException {
        synchronized (this.lock) {
            ensureOpen();

            if (cachePos > 0) {
                try {
                    this.largeObject.writeBytes(this.largeObject.getLobLength() + 1, this.cacheData, 0, cachePos);
                } catch (Exception exception) {
                    throw new IOException(exception.getMessage());
                }

                cachePos = 0;
            }
        }
    }

    @Override
    public void write(int b) throws IOException {
        synchronized (this.lock) {
            ensureOpen();

            if (cachePos >= (cacheData.length - 1)) {
                this.flush();
            }

            this.cacheData[cachePos] = (byte) b;
            cachePos++;
        }
    }

    @Override
    public void close() throws IOException {
        synchronized (this.lock) {
            if (isClosed) {
                return;
            }

            this.flush();
            super.close();
            isClosed = true;
        }
    }
}
