/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import java.sql.SQLException;
import java.util.List;

public interface Debugger {

    void pdbgStart() throws SQLException;

    DebugBreakpoint pdbgAddBreakpoint(long objectId, int subprogramId, int lineNum) throws SQLException;

    void pdbgDeleteBreakpoint(DebugBreakpoint breakpoint) throws SQLException;

    List<DebugBreakpoint> pdbgShowBreakpoints() throws SQLException;

    void pdbgDeleteAllBreakpoints() throws SQLException;

    void pdbgStepInto() throws SQLException;

    void pdbgStepOut() throws SQLException;

    void pdbgContinue() throws SQLException;

    void pdbgStepNext() throws SQLException;

    List<DebugVar> pdbgShowFrameVariables() throws SQLException;

    List<DebugFrame> pdbgShowFrames() throws SQLException;

    long getRunObjectId() throws SQLException;

    int getRunSubprogramId() throws SQLException;

    int getRunLineNum() throws SQLException;

    boolean isDebugOn();

    void pdbgAbort() throws SQLException;
}
