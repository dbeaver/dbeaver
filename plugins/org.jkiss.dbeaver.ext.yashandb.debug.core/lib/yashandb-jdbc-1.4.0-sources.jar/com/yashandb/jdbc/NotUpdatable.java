/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.exception.YasState;
import com.yashandb.util.Messages;

import java.sql.SQLException;

/**
 * Thrown when a result sate is not updatable
 */
public class NotUpdatable extends SQLException {

    /**
     * Creates a new NotUpdatable exception.
     */
    public NotUpdatable() {
        this(Messages.get(
                "ResultSet is not updatable."
                        + " The query that generated this result set must select only one table,"
                        + " and not include distinct and aggregate function. "));

    }

    /**
     * Append the given reason to the not updatable message if the reason is not null.
     */
    public NotUpdatable(String reason) {
        super(reason, YasState.UNKNOWN_STATE.getState());
    }
}