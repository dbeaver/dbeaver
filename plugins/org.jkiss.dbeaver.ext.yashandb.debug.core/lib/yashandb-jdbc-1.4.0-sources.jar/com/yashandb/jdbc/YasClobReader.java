/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;

public class YasClobReader extends Reader {

    private YasLargeObject largeObject;

    private int charPos = 0;

    private int cacheCharacterLen = 0;

    private long lobOffset = 1L;

    private long steamLobRemainSize = 0L;

    private StringBuilder stringBuilder;

    private boolean isClosed = false;

    public YasClobReader(YasLargeObject largeObject) throws SQLException {
        this.largeObject = largeObject;
        this.steamLobRemainSize = largeObject.getLobLength();

        int cacheSize = largeObject.getStepSize();
        if (cacheSize <= 0) {
            cacheSize = (int) largeObject.getLobLength();
        }

        this.stringBuilder = new StringBuilder(cacheSize);

        String clobStr = largeObject.getString(1, cacheSize);
        this.stringBuilder.append(clobStr);

        this.cacheCharacterLen = clobStr.length();
    }

    public YasClobReader(YasLargeObject largeObject, long pos, long length) throws SQLException {
        if ((pos < 1) || (length < 0)) {
            throw SQLError.createSQLException("invalid parameter", YasState.INVALID_PARAMETER_VALUE);
        }

        long start = pos - 1;
        long lobLength = largeObject.getLobLength();
        if ((length == 0) || (lobLength == 0) || (start >= lobLength)) {
            return;
        }

        this.largeObject = largeObject;
        long readLobLen = Math.min(length, lobLength);
        if (start + readLobLen > lobLength) {
            readLobLen = lobLength - start;
        }

        steamLobRemainSize = readLobLen;

        int cacheSize = largeObject.getStepSize();
        if (cacheSize <= 0) {
            cacheSize = (int) largeObject.getLobLength();
        }
        this.stringBuilder = new StringBuilder(cacheSize);

        this.lobOffset = pos;
        String clobStr = this.largeObject.getString(pos, this.stringBuilder.capacity());
        this.stringBuilder.append(clobStr);

        cacheCharacterLen = clobStr.length();
    }

    private void ensureOpen() throws IOException {
        if (isClosed) {
            throw new IOException("reader closed");
        }
    }

    @Override
    public int read(char[] cbuf, int off, int len) throws IOException {
        ensureOpen();

        if (steamLobRemainSize <= 0) {
            return -1;
        }

        int charLen = Math.min(len, cbuf.length - off);
        if (charLen <= 0) {
            throw new IOException("invalid parameter");
        }

        charLen = Math.min(charLen, cacheCharacterLen - charPos);
        if (charLen > steamLobRemainSize) {
            charLen = (int) steamLobRemainSize;
        }

        stringBuilder.getChars(charPos, charPos + charLen, cbuf, off);
        charPos += charLen;
        steamLobRemainSize -= charLen;

        if ((charPos >= cacheCharacterLen) && (steamLobRemainSize > 0L)) {
            lobOffset += cacheCharacterLen;
            try {
                this.stringBuilder.delete(0, stringBuilder.length());
                String clobStr = this.largeObject.getString(lobOffset, this.stringBuilder.capacity());
                this.stringBuilder.append(clobStr);
                charPos = 0;
                cacheCharacterLen = clobStr.length();
            } catch (SQLException sqlException) {
                throw new IOException(sqlException.getMessage());
            }
        }

        return charLen;
    }

    @Override
    public void close() throws IOException {
        if (!isClosed) {
            isClosed = true;
        }
    }
}
