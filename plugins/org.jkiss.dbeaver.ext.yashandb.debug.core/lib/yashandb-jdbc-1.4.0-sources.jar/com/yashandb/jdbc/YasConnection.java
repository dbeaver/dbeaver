/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.Session;
import com.yashandb.log.Logger;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import java.util.Timer;

public interface YasConnection extends Connection, Cloneable {

    void doDescribeTable(ReturnResultSetMetaData autoKeys) throws SQLException;

    Map<String, String> getParameterStatuses();

    /**
     * Shorthand for getParameterStatuses().get(...) .
     *
     * @param parameterName case-insensitive parameter name
     * @return parameter value if defined, or null if no parameter known
     * @see #getParameterStatuses
     */
    String getParameterStatus(String parameterName);

    /**
     * Cancel the current query executing on this connection.
     *
     * @throws SQLException if something goes wrong.
     */
    void cancelQuery() throws SQLException;

    /**
     * Get the Session implementation for this connection.
     *
     * @return the (non-null) session
     */
    Session getSession();

    /**
     * Encode a string using the database's client_encoding (usually UTF8, but can vary on older
     * server versions). This is used when constructing synthetic resultsets (for example, in metadata
     * methods).
     *
     * @param str the string to encode
     * @return an encoded representation of the string
     * @throws SQLException if something goes wrong.
     */
    byte[] encodeString(String str) throws SQLException;

    boolean getStandardConformingStrings();

    // Get the per-connection logger.
    Logger getLogger();

    /**
     * Get the current transaction state of this connection.
     *
     * @return current transaction state of this connection
     */
    TransactionState getTransactionState();

    Timer getTimer();

    /**
     * Get default fetch size
     * @return default fetch size
     */
    int getDefaultFetchSize();

    /**
     * Set default fetch size
     *
     */
    void setDefaultFetchSize(int fetchSize) throws SQLException;

    String getServerType();

    YasDebugCallableStatement createDebugStatement(String sql, long objectId, int subprogramId, int version)
            throws SQLException;
}
