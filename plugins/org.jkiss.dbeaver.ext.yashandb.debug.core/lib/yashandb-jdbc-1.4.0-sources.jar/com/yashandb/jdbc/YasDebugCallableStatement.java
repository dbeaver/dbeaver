/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.ParameterList;
import com.yashandb.YasConstants;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.jdbc.exception.YasException;
import com.yashandb.protocol.DebugOperation;
import com.yashandb.util.Messages;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class YasDebugCallableStatement extends YasCallableStatement implements Debugger {

    private boolean debugOn = false;

    private long runObjectId = -1L;

    private int runSubprogramId = -1;

    private int runLineNum = -1;

    private long debugObjectId;

    private int debugSubprogramId;

    private int debugVersion;

    private List<DebugBreakpoint> breakpointList = new ArrayList<>();

    YasDebugCallableStatement(ConnectionImpl connection, String sql, int rsType, int rsConcurrency, int rsHoldability ,
                              long objectId, int subprogramId, int version) throws SQLException {
        super(connection, sql, rsType, rsConcurrency, rsHoldability);
        this.debugObjectId = objectId;
        this.debugSubprogramId = subprogramId;
        this.debugVersion = version;
    }

    @Override
    public void pdbgAbort() throws SQLException {
        checkDebugOn();
        connection.getSession().pdbgAbort(this);
    }

    private void initBreakpoints() {
        if (breakpointList.isEmpty()) {
            return;
        }
        for (DebugBreakpoint debugBreakpoint : breakpointList) {
            debugBreakpoint.setId(-1);
        }
    }

    @Override
    public void pdbgStart() throws SQLException {
        if (this.debugOn) {
            throw new YasException("This DebugMode has been opened", YasState.OBJECT_NOT_IN_STATE);
        }

        ParameterList[] parameterLists = null;
        if (preparedParameters != null) {
            parameterLists = new ParameterList[1];
            parameterLists[0] = preparedParameters;
        }
        synchronized (this) {
            checkClosed();
            closeForNextExecution();

            this.currentResultSet = connection.getSession().pdbgExecute(this, parameterLists);

            if (debugOn) {
                checkSoVersion();
                syncBreakpoints();
            }
        }
    }

    private void checkSoVersion() throws SQLException {
        checkDebugOn();
        connection.getSession().pdbgCheckVersion(this, this.debugObjectId, this.debugSubprogramId,
                this.debugVersion);
    }

    @Override
    public DebugBreakpoint pdbgAddBreakpoint(long objectId, int subprogramId, int lineNum)
            throws SQLException {
        if (lineNum < 1) {
            throw SQLError.createSQLException("invalid parameter, ''lineNum'' should not be < 1",
                    YasState.INVALID_PARAMETER_VALUE);
        }
        checkClosed();

        if (breakpointAlreadyExist(objectId, subprogramId, lineNum)) {
            throw new YasException("Break point has already exists.", YasState.DATA_ERROR);
        }
        DebugBreakpointImpl debugBreakpoint = new DebugBreakpointImpl(objectId, subprogramId, lineNum);

        breakpointList.add(debugBreakpoint);

        if (this.debugOn) {
            syncBreakpoints();
        }
        return debugBreakpoint;
    }

    private void syncBreakpoints() throws SQLException {
        checkDebugOn();
        List<DebugBreakpoint> syncBreakpointList = new ArrayList<>();

        for (DebugBreakpoint debugBreakpoint : breakpointList) {
            if (debugBreakpoint.getId() == -1) {
                syncBreakpointList.add(debugBreakpoint);
            }
        }

        if (syncBreakpointList.isEmpty()) {
            return;
        }
        connection.getSession().pdbgAddBreakpoint(this, syncBreakpointList);
    }

    private boolean breakpointAlreadyExist(long objectId, int subprogramId, int lineNum) {
        if (breakpointList.isEmpty()) {
            return false;
        }

        for (DebugBreakpoint debugBreakpoint : breakpointList) {
            if (debugBreakpoint.getObjectId() != objectId) {
                continue;
            }
            if (debugBreakpoint.getSubprogramId() != subprogramId) {
                continue;
            }
            if (debugBreakpoint.getLineNum() != lineNum) {
                continue;
            }
            return true;
        }

        return false;
    }

    @Override
    public void pdbgDeleteBreakpoint(DebugBreakpoint breakpoint) throws SQLException {
        if (breakpoint == null) {
            throw SQLError.createSQLException("invalid parameter, ''breakpoint'' should not be null.",
                    YasState.INVALID_PARAMETER_VALUE);
        }
        checkClosed();
        DebugBreakpoint delteBreakpoint = null;
        for (DebugBreakpoint debugBreakpoint : breakpointList) {
            if (breakpoint.equals(debugBreakpoint)) {
                delteBreakpoint = debugBreakpoint;
                break;
            }
        }

        if (delteBreakpoint == null) {
            throw new YasException("Break point does not exist.", YasState.DATA_ERROR);
        }

        if (this.debugOn) {
            List<DebugBreakpoint> delteBreakpointList = new ArrayList<>();
            delteBreakpointList.add(delteBreakpoint);
            connection.getSession().pdbgDeleteBreakpoint(this, delteBreakpointList);
        }
        breakpointList.remove(delteBreakpoint);

    }

    @Override
    public List<DebugBreakpoint> pdbgShowBreakpoints() throws SQLException {
        checkClosed();
        return breakpointList;
    }

    private void checkDebugOn() throws SQLException {
        checkClosed();

        if (!this.debugOn) {
            throw SQLError.createSQLException(Messages.get("This DebugMode has been closed."),
                    YasState.OBJECT_NOT_IN_STATE);
        }
    }

    @Override
    public void pdbgDeleteAllBreakpoints() throws SQLException {
        checkClosed();
        if (breakpointList.isEmpty()) {
            return;
        }

        if (this.debugOn) {
            connection.getSession().pdbgDeleteBreakpoint(this, breakpointList);
        }
        breakpointList.clear();
    }

    @Override
    public void pdbgStepInto() throws SQLException {
        checkDebugOn();
        this.currentResultSet = connection.getSession().pdbgStepDebug(this, DebugOperation.DBG_STEP_INTO);
    }

    @Override
    public void pdbgStepOut() throws SQLException {
        checkDebugOn();
        this.currentResultSet = connection.getSession().pdbgStepDebug(this, DebugOperation.DBG_STEP_OUT);
    }

    @Override
    public void pdbgContinue() throws SQLException {
        checkDebugOn();
        this.currentResultSet = connection.getSession().pdbgStepDebug(this, DebugOperation.DBG_CONTINUE);
    }

    @Override
    public void pdbgStepNext() throws SQLException {
        checkDebugOn();
        this.currentResultSet = connection.getSession().pdbgStepDebug(this, DebugOperation.DBG_STEP_NEXT);
    }

    @Override
    public List<DebugVar> pdbgShowFrameVariables() throws SQLException {
        checkDebugOn();
        return connection.getSession().pdbgShowVars(this);
    }

    @Override
    public List<DebugFrame> pdbgShowFrames() throws SQLException {
        checkDebugOn();
        return connection.getSession().pdbgShowFrames(this);
    }

    public void setDebugStatus(int debugStatus, long objectId, int subprogramId, int lineNum) {
        if (debugStatus == YasConstants.DEBUG_STATUS_OFF) {
            debugOn = false;
            initBreakpoints();
            this.runObjectId = -1L;
            this.runSubprogramId = -1;
            this.runLineNum = -1;
            return;
        }
        debugOn = true;
        this.runObjectId = objectId;
        this.runSubprogramId = subprogramId;
        this.runLineNum = lineNum;
    }

    public long getRunObjectId() throws SQLException {
        checkDebugOn();
        return runObjectId;
    }

    public int getRunSubprogramId() throws SQLException {
        checkDebugOn();
        return runSubprogramId;
    }

    public int getRunLineNum() throws SQLException {
        checkDebugOn();
        return runLineNum;
    }

    @Override
    public void close() throws SQLException {
        if (isClosed()) {
            return;
        }
        if (this.debugOn) {
            this.pdbgAbort();
        }
        super.close();
    }

    @Override
    public boolean isDebugOn() {
        return debugOn;
    }
}
