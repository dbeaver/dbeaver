/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

public interface DebugVar {

    int getDataType();

    int getBlockNo();

    String getName();

    Boolean isGlobal();

    Object getVar();

}
