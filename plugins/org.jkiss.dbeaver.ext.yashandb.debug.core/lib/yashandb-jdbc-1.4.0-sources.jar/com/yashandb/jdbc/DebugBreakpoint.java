/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

public interface DebugBreakpoint {
    int getId();

    long getObjectId();

    int getSubprogramId();

    int getLineNum();

    void setId(int id);
}
