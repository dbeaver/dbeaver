/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

public interface DebugFrame {
    String getClassInfo();

    String getMethodInfo();

    int getLineNum();

    int getBlockNo();
}
