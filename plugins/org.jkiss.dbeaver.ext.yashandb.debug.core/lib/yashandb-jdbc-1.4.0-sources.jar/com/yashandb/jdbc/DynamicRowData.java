/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.YasResultSet;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.SQLException;
import java.util.ArrayList;

public class DynamicRowData implements RowData {

    protected ArrayList<Row> rows;
    int curr;
    int rowCount;

    DynamicRowData(Row row) {
        rows = new ArrayList<>();
        rows.add(row);
        curr = -1;
        rowCount = 1;
    }

    @Override
    public void addRow(Row row) throws SQLException {
        rows.add(row);
        rowCount++;
    }

    @Override
    public void afterLast() throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "afterLast");
    }

    @Override
    public void beforeFirst() throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "beforeFirst");
    }

    @Override
    public void beforeLast() throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "beforeLast");
    }

    @Override
    public void close() throws SQLException {
        rows = null;
    }

    @Override
    public Row getAt(long index) throws SQLException {
        if (index > Integer.MAX_VALUE) {
            throw SQLError.createSQLException("Not support resultsize greater than " + Integer.MAX_VALUE,
                    YasState.INVALID_PARAMETER_VALUE);
        }
        return rows.get((int)index);
    }

    @Override
    public long getFetchedRowCount() throws SQLException {
        return rowCount;
    }

    @Override
    public YasResultSet getOwner() {
        return null;
    }

    @Override
    public boolean hasNext() throws SQLException {
        return (curr + 1) < rowCount;
    }

    @Override
    public boolean isAfterLast() throws SQLException {
        return false;
    }

    @Override
    public boolean isBeforeFirst() throws SQLException {
        return false;
    }

    @Override
    public boolean isDynamic() throws SQLException {
        return false;
    }

    @Override
    public boolean isEmpty() throws SQLException {
        return false;
    }

    @Override
    public boolean isFirst() throws SQLException {
        return false;
    }

    @Override
    public boolean isLast() throws SQLException {
        return false;
    }

    @Override
    public void moveRowRelative(long rows) throws SQLException {

    }

    @Override
    public Row next() throws SQLException {
        if (curr >= rowCount) {
            return null;
        }
        return getAt(++curr);
    }

    @Override
    public void removeRow(long index) throws SQLException {

    }

    @Override
    public void setCurrentRow(long rowNumber) throws SQLException {

    }

    @Override
    public void setOwner(ResultSetImpl rs) {

    }

    @Override
    public long size() throws SQLException {
        return rowCount;
    }

    @Override
    public void setMetadata(Field[] metadata) {

    }

    @Override
    public void decodeRows(int start) throws SQLException {

    }

    @Override
    public long getPosition() {
        return curr;
    }

    @Override
    public void setMaxRows(long maxRows) {

    }

    @Override
    public void absolute(long index) throws SQLException {

    }

    @Override
    public void refreshRow(Row row, long index) {

    }
}
