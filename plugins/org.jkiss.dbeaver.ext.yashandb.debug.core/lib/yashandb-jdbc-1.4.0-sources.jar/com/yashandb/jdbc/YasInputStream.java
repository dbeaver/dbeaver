/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import java.io.InputStream;

public abstract class YasInputStream extends InputStream {

    private int columnIndex;

    public int getColumnIndex() {
        return columnIndex;
    }
}
