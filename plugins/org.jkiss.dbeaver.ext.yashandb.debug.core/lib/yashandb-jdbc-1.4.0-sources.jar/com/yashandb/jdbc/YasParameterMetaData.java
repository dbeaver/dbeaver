/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.Messages;

import java.sql.ParameterMetaData;
import java.sql.SQLException;

public class YasParameterMetaData implements ParameterMetaData {

    private final YasConnection connection;
    private final Field[] fields;
    private boolean throwUnsupportedFeature = false;

    public YasParameterMetaData(YasConnection connection, Field[] parameterFields) {
        this.connection = connection;
        this.fields = parameterFields;
    }

    public void setThrowUnsupported(boolean throwUnsupported) {
        this.throwUnsupportedFeature = throwUnsupported;
    }

    @Override
    public String getParameterClassName(int param) throws SQLException {
        checkParamIndex(param);
        return "";
    }

    @Override
    public int getParameterCount() {
        if (fields == null) {
            return 0;
        }
        return fields.length;
    }

    /**
     * {@inheritDoc} For now report all parameters as inputs. CallableStatements may have one output,
     * but ignore that for now.
     */
    public int getParameterMode(int param) throws SQLException {
        checkParamIndex(param);
        return ParameterMetaData.parameterModeIn;
    }

    @Override
    public int getParameterType(int param) throws SQLException {
        checkParamIndex(param);
        Field field = getField(param);
        return field.getYasType();
    }

    @Override
    public String getParameterTypeName(int param) throws SQLException {
        checkParamIndex(param);
        Field field = getField(param);
        return field.getTypeName();
    }

    // we don't know this
    public int getPrecision(int param) throws SQLException {
        checkParamIndex(param);
        Field field = getField(param);
        return field.getPrecision();
    }

    // we don't know this
    public int getScale(int param) throws SQLException {
        checkParamIndex(param);
        Field field = getField(param);
        return field.getScale();
    }

    // we can't tell anything about nullability
    public int isNullable(int param) throws SQLException {
        checkParamIndex(param);
        return ParameterMetaData.parameterNullableUnknown;
    }

    @Override
    public boolean isSigned(int param) throws SQLException {
        checkParamIndex(param);
        return false;
    }

    private void checkParamIndex(int param) throws SQLException {
        if (throwUnsupportedFeature) {
            throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "checkParamIndex for autoKey");
        }

        if (fields == null) {
            throw SQLError.createSQLException("The parameter count is 0", YasState.DATA_ERROR);
        }

        if (param < 1 || param > fields.length) {
            throw SQLError.createSQLException(
                    Messages.get("The parameter index is out of range: {0}, number of parameters: {1}.",
                            param, fields.length),
                    YasState.INVALID_PARAMETER_VALUE);
        }
    }

    private Field getField(int columnIndex) throws SQLException {
        checkParamIndex(columnIndex);
        return fields[columnIndex - 1];
    }

    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        return iface.isAssignableFrom(getClass());
    }

    public <T> T unwrap(Class<T> iface) throws SQLException {
        if (iface.isAssignableFrom(getClass())) {
            return iface.cast(this);
        }
        throw new SQLException("Cannot unwrap to " + iface.getName());
    }
}
