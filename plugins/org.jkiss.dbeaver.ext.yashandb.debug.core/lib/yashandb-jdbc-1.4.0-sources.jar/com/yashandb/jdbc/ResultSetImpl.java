/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.YasResultSet;
import com.yashandb.core.DataType;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.BatchError;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;
import com.yashandb.protocol.accessor.Accessor;
import com.yashandb.protocol.accessor.AccessorFactory;
import com.yashandb.util.Messages;
import com.yashandb.util.YasByte;
import com.yashandb.util.YasObject;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ResultSetImpl implements YasResultSet {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResultSetImpl.class);

    protected final YasConnection connection; // the connection we belong to

    protected final YasStatement owningStatement; // Statement we originated from

    private long updateCount;

    private final boolean reallyResult;

    private boolean stmtQueryResult = false;

    private boolean isClosed;

    protected boolean updatable = false;
    protected boolean doingUpdates = false;
    protected HashMap<String, Object> updateValues = null;
    protected HashMap<String, SQLType> updateSQLTypes = null;
    protected HashMap<String, Integer> updateScales = null;
    private List<PrimaryKey> primaryKeys; // list of primary keys
    private boolean singleTable = false;
    private String tableName = null;

    private final int resultsetType;
    private final int resultsetConcurrency;
    private int fetchDirection = ResultSet.FETCH_FORWARD;

    // metadata for this resultset.
    protected Field[] fields;

    protected Accessor[] accessors;

    protected long maxRows;

    protected final int maxFieldSize; // Maximum field size in this resultset (might be 0).

    protected long currentRow = -1;

    protected int rowOffset; // Offset of row 0 in the actual resultset
    protected Row thisRow; // copy of the current result row
    protected SQLWarning warnings = null; // The warning chain
    /**
     * True if the last obtained column value was SQL NULL as specified by {@link #wasNull}. The value
     * is always updated by the {@link #checkResultSet} method.
     */
    protected Boolean wasNullFlag;
    protected boolean onInsertRow = false;

    private Row rowBuffer = null; // updateable rowbuffer

    protected int fetchSize; // Current fetch size (might be 0).

    private Map<String, Integer> columnNameIndexMap; // Speed up findColumn by caching lookups

    private ResultSetMetaData rsMetaData;

    /**
     * The actual rows
     */
    protected RowData rowData; // The results

    /**
     * Batch Rows and Batch Errors
     */
    private int[] dmlRows = null;

    private HashMap<Integer, BatchError> batchErrors = null;

    private ArrayList<Integer> dmlRowList = null;

    protected ResultSetMetaData createMetaData() throws SQLException {
        return new ResultSetMetaDataImpl(connection, fields);
    }

    public ResultSetMetaData getMetaData() throws SQLException {
        checkClosed();
        if (rsMetaData == null) {
            rsMetaData = createMetaData();
        }
        return rsMetaData;
    }

    ResultSetImpl(StatementImpl creatorStmt, Field[] fields, RowData rows,
                  int maxRows, int maxFieldSize, int rsType, int rsConcurrency, int rsHoldability)
            throws SQLException {
        // Fail-fast on invalid null inputs
        if (rows == null) {
            throw new NullPointerException("packet must be non-null");
        }
        if (fields == null) {
            throw new NullPointerException("fields must be non-null");
        }

        this.owningStatement = creatorStmt;
        this.connection = (YasConnection) creatorStmt.getConnection();
        this.fields = fields;
        this.rowData = rows;
        this.isClosed = false;
        this.accessors = AccessorFactory.generateAccessors(fields, this.connection.getSession());
        this.maxRows = maxRows;
        this.maxFieldSize = maxFieldSize;
        this.resultsetType = rsType;
        this.resultsetConcurrency = rsConcurrency;

        this.updateCount = 0;
        this.reallyResult = true;
    }

    public ResultSetImpl(YasConnection conn, YasStatement creatorStmt) {
        this.updateCount = 0;
        this.reallyResult = true;
        this.owningStatement = creatorStmt;
        this.resultsetType = ResultSet.TYPE_FORWARD_ONLY;
        this.resultsetConcurrency = ResultSet.CONCUR_READ_ONLY;
        this.connection = conn;
        this.rowData = null;
        this.isClosed = false;
        this.fields = null;
        this.accessors = null;
        this.maxRows = 0;
        this.maxFieldSize = 0;
    }

    public ResultSetImpl(long updateCount, YasConnection conn, YasStatement creatorStmt) {
        this.updateCount = updateCount;
        this.reallyResult = false;
        this.owningStatement = creatorStmt;
        this.resultsetType = ResultSet.TYPE_FORWARD_ONLY;
        this.resultsetConcurrency = ResultSet.CONCUR_READ_ONLY;
        this.connection = conn;
        this.rowData = null;
        this.isClosed = false;
        this.fields = null;
        this.accessors = null;
        this.maxRows = 0;
        this.maxFieldSize = 0;
    }

    public ResultSetImpl(long updateCount, YasConnection conn, YasStatement creatorStmt, int[] dmlRows,
                         HashMap<Integer, BatchError> batchErrors) {
        this.updateCount = updateCount;
        this.reallyResult = false;
        this.owningStatement = creatorStmt;
        this.resultsetType = ResultSet.TYPE_FORWARD_ONLY;
        this.resultsetConcurrency = ResultSet.CONCUR_READ_ONLY;
        this.connection = conn;
        this.rowData = null;
        this.isClosed = false;
        this.fields = null;
        this.accessors = null;
        this.maxRows = 0;
        this.maxFieldSize = 0;
        this.dmlRows = dmlRows;
        this.batchErrors = batchErrors;
    }

    public java.net.URL getURL(int columnIndex) throws SQLException {
        LOGGER.debug("getURL columnIndex: {}", columnIndex);
        checkClosed();
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getURL(int)");
    }

    public java.net.URL getURL(String columnName) throws SQLException {
        return getURL(findColumn(columnName));
    }

    protected Object internalGetObject(int columnIndex, Field field) throws SQLException {
        switch (getSQLType(columnIndex)) {
            case Types.BOOLEAN:
                return getBoolean(columnIndex);
            case Types.BIT:
                if (field.getSize() == 1) {
                    return getBoolean(columnIndex);
                }
                return getBytes(columnIndex);
            case Types.SQLXML:
                return getSQLXML(columnIndex);
            case Types.TINYINT:
            case Types.SMALLINT:
            case Types.INTEGER:
                return getInt(columnIndex);
            case Types.BIGINT:
                return getLong(columnIndex);
            case Types.NUMERIC:
            case Types.DECIMAL:
                return getBigDecimal(columnIndex,field.getScale());
            case Types.REAL:
                return getFloat(columnIndex);
            case Types.FLOAT:
            case Types.DOUBLE:
                return getDouble(columnIndex);
            case Types.CHAR:
            case Types.VARCHAR:
            case Types.LONGVARCHAR:
            case YasTypes.JSON:
                return getString(columnIndex);
            case Types.DATE:
                return getDate(columnIndex);
            case Types.TIME:
                return getTime(columnIndex);
            case Types.TIMESTAMP:
                return getTimestamp(columnIndex);
            case YasTypes.DS_INTERVAL:
            case YasTypes.YM_INTERVAL:
                return getString(columnIndex);
            case Types.BINARY:
            case Types.VARBINARY:
            case Types.LONGVARBINARY:
                return getBytes(columnIndex);
            case Types.ARRAY:
                return getArray(columnIndex);
            case Types.CLOB:
                return getClob(columnIndex);
            case Types.BLOB:
                return getBlob(columnIndex);
            case Types.ROWID:
                return getRowId(columnIndex);
            default:
                return null;
        }
    }

    protected void checkScrollable() throws SQLException {
        checkClosed();
        if (resultsetType == ResultSet.TYPE_FORWARD_ONLY) {
            throw SQLError.createSQLException(
                    Messages.get("Operation requires a scrollable ResultSet, but this ResultSet is FORWARD_ONLY."),
                    YasState.INVALID_CURSOR_STATE);
        }
    }

    @Override
    public boolean absolute(int index) throws SQLException {
        synchronized (this.connection) {
            //forward only, not support.
            checkScrollable();
            prepareMove();

            if (index == 0) {
                // before first
                rowData.beforeFirst();
                this.thisRow = null;
                this.currentRow = rowData.getPosition();
                return false;
            } else if (index < 0) {
                // -1 is last
                //Get Last Row,-1 is last row
                rowData.afterLast();
                long rowIndex = rowData.getPosition();
                if (maxRows > 0 && rowIndex > maxRows) {
                    rowIndex = maxRows + index;
                } else {
                    rowIndex = rowIndex + index;
                }
                if (rowIndex < 0) {
                    // before first
                    rowData.beforeFirst();
                    this.thisRow = null;
                    this.currentRow = rowData.getPosition();
                    return false;
                } else {
                    rowData.setCurrentRow(rowIndex);
                    this.currentRow = this.rowData.getPosition();
                    this.thisRow = this.rowData.getAt(currentRow);
                }
            } else {
                //index > 0
                if (maxRows > 0 && maxRows < index) {
                    index = (int) maxRows;
                }
                rowData.setCurrentRow(index - 1);

                long rowIndex = rowData.getPosition();
                if (index - 1 > rowIndex || (index - 1 == rowIndex && !rowData.hasNext())) {
                    // out of range,set it after last
                    this.thisRow = null;
                    this.currentRow = rowData.getPosition();
                    return false;
                } else {
                    this.currentRow = this.rowData.getPosition();
                    this.thisRow = this.rowData.getAt(currentRow);
                }
            }
            return true;
        }
    }

    @Override
    public void afterLast() throws SQLException {
        synchronized (this.connection) {
            checkScrollable();
            rowData.afterLast();
            this.thisRow = null;
            this.currentRow = rowData.getPosition();
        }
    }

    @Override
    public void beforeFirst() throws SQLException {
        absolute(0);
    }

    @Override
    public boolean first() throws SQLException {
        return absolute(1);
    }

    @Override
    public Array getArray(String colName) throws SQLException {
        return getArray(findColumn(colName));
    }

    @Override
    public Array getArray(int i) throws SQLException {
        checkResultSet(i);
        if (wasNullFlag) {
            return null;
        }
        return null;
    }

    @Override
    public java.math.BigDecimal getBigDecimal(int columnIndex) throws SQLException {
        LOGGER.debug("getBigDecimal columnIndex: {}", columnIndex);
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return null;
        }

        this.owningStatement.closeStream(columnIndex);

        int col = columnIndex - 1;
        return this.accessors[col].getBigDecimal(thisRow.get(col));
    }

    public java.math.BigDecimal getBigDecimal(String columnName) throws SQLException {
        return getBigDecimal(findColumn(columnName));
    }

    public Blob getBlob(String columnName) throws SQLException {
        return getBlob(findColumn(columnName));
    }

    public Blob getBlob(int i) throws SQLException {
        checkResultSet(i);
        if (wasNullFlag) {
            return null;
        }

        int col = i - 1;
        return this.accessors[col].getBlob(thisRow.get(col), this.connection.getSession());
    }

    public java.io.Reader getCharacterStream(String columnName) throws SQLException {
        return getCharacterStream(findColumn(columnName));
    }

    public java.io.Reader getCharacterStream(int columnIndex) throws SQLException {
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return null;
        }

        int col = columnIndex - 1;
        int type = fields[col].getYasType();
        Reader reader;
        switch (type) {
            case DataType.VARCHAR:
            case DataType.CHAR:
            case DataType.NVARCHAR:
            case DataType.NCHAR:
                reader = new StringReader(getString(columnIndex));
                break;
            default:
                throw SQLError.createSQLException(
                        Messages.get("getCharacterStream not implemented for type {0}", fields[col].getTypeName()),
                        YasState.WRONG_OBJECT_TYPE);
        }

        return reader;
    }

    public Clob getClob(String columnName) throws SQLException {
        return getClob(findColumn(columnName));
    }

    public Clob getClob(int i) throws SQLException {
        checkResultSet(i);
        if (wasNullFlag) {
            return null;
        }

        int col = i - 1;
        return this.accessors[col].getClob(thisRow.get(col), this.connection.getSession());
    }

    public int getConcurrency() throws SQLException {
        checkClosed();
        return resultsetConcurrency;
    }

    @Override
    public java.sql.Date getDate(int i, java.util.Calendar cal) throws SQLException {
        LOGGER.debug("getDate columnIndex: {}", i);

        checkResultSet(i);
        if (wasNullFlag) {
            return null;
        }

        int col = i - 1;
        this.owningStatement.closeStream(col);

        return this.accessors[col].getDate(thisRow.get(col),cal);
    }

    @Override
    public Time getTime(int i, java.util.Calendar cal) throws SQLException {
        LOGGER.debug("getTime columnIndex: {}", i);

        checkResultSet(i);
        if (wasNullFlag) {
            return null;
        }

        int col = i - 1;
        this.owningStatement.closeStream(col);

        return this.accessors[col].getTime(thisRow.get(col),cal);
    }

    @Override
    public Timestamp getTimestamp(int i, java.util.Calendar cal) throws SQLException {
        LOGGER.debug("getTimestamp columnIndex: {}", i);

        checkResultSet(i);
        if (wasNullFlag) {
            return null;
        }

        int col = i - 1;
        this.owningStatement.closeStream(col);

        return this.accessors[col].getTimestamp(thisRow.get(col),cal);
    }

    public java.sql.Date getDate(String c, java.util.Calendar cal) throws SQLException {
        return getDate(findColumn(c), cal);
    }

    public Time getTime(String c, java.util.Calendar cal) throws SQLException {
        return getTime(findColumn(c), cal);
    }

    public Timestamp getTimestamp(String c, java.util.Calendar cal) throws SQLException {
        return getTimestamp(findColumn(c), cal);
    }

    public int getFetchDirection() throws SQLException {
        checkClosed();
        return fetchDirection;
    }

    public Object getObjectImpl(String columnName, Map<String, Class<?>> map) throws SQLException {
        return getObjectImpl(findColumn(columnName), map);
    }

    /*
     * This checks against map for the type of column i, and if found returns an object based on that
     * mapping. The class must implement the SQLData interface.
     */
    public Object getObjectImpl(int i, Map<String, Class<?>> map) throws SQLException {
        checkClosed();
        if (map == null || map.isEmpty()) {
            return getObject(i);
        }
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getObjectImpl(int,Map)");
    }

    public Ref getRef(String columnName) throws SQLException {
        return getRef(findColumn(columnName));
    }

    public Ref getRef(int i) throws SQLException {
        checkClosed();
        // The backend doesn't yet have SQL3 REF types
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getRef(int)");
    }

    @Override
    public int getRow() throws SQLException {
        synchronized (this.connection) {
            checkClosed();

            if ((currentRow == rowData.getFetchedRowCount()) || ((maxRows > 0) && (currentRow == maxRows))) {
                return 0;
            }

            return (int)(currentRow + 1);
        }
    }

    // This one needs some thought, as not all ResultSets come from a statement
    public Statement getStatement() throws SQLException {
        checkClosed();
        return this.owningStatement;
    }

    public int getType() throws SQLException {
        checkClosed();
        return resultsetType;
    }

    @Override
    public boolean isAfterLast() throws SQLException {
        synchronized (this.connection) {
            checkClosed();
            return this.rowData.isAfterLast();
        }
    }

    @Override
    public boolean isBeforeFirst() throws SQLException {
        synchronized (this.connection) {
            checkClosed();
            return this.rowData.isBeforeFirst();
        }
    }

    @Override
    public boolean isFirst() throws SQLException {
        synchronized (this.connection) {
            checkClosed();
            if (currentRow == 0L) {
                return true;
            }

            return false;
        }
    }

    @Override
    public boolean isLast() throws SQLException {
        synchronized (this.connection) {
            checkScrollable();
            return this.rowData.isLast();
        }
    }

    @Override
    public boolean last() throws SQLException {
        return absolute(-1);
    }

    @Override
    public boolean previous() throws SQLException {
        if (this.currentRow == -1) {
            return false;
        }
        return absolute((int)this.currentRow);
    }

    @Override
    public boolean relative(int rows) throws SQLException {
        if (currentRow + 1 + rows < 0 ) {
            beforeFirst();
            return false;
        }
        return absolute((int)currentRow + 1 + rows);
    }

    public void setFetchDirection(int direction) throws SQLException {
        checkClosed();
        switch (direction) {
            case ResultSet.FETCH_FORWARD:
                break;
            case ResultSet.FETCH_REVERSE:
            case ResultSet.FETCH_UNKNOWN:
                checkScrollable();
                break;
            default:
                throw SQLError.createSQLException(
                        Messages.get("Invalid fetch direction constant: {0}.", direction),
                        YasState.INVALID_PARAMETER_VALUE);
        }

        this.fetchDirection = direction;
    }

    public synchronized void cancelRowUpdates() throws SQLException {
        throw new NotUpdatable();
    }

    public synchronized void deleteRow() throws SQLException {
        throw new NotUpdatable();
    }

    @Override
    public synchronized void insertRow() throws SQLException {
        throw new NotUpdatable();
    }

    @Override
    public synchronized void moveToCurrentRow() throws SQLException {
        throw new NotUpdatable();
    }

    @Override
    public synchronized void moveToInsertRow() throws SQLException {
        throw new NotUpdatable();
    }

    // rowBuffer is the temporary storage for the row
    protected synchronized void clearRowBuffer(boolean copyCurrentRow) throws SQLException {

        // inserts want an empty array while updates want a copy of the current row
        if (copyCurrentRow && thisRow != null) {
            rowBuffer = thisRow.updateableCopy();
        } else {
            rowBuffer = new Row(fields.length);
        }

        // clear the updateValues hash map for the next set of updates
        if (updateValues != null) {
            updateValues.clear();
            updateSQLTypes.clear();
            updateScales.clear();
        }
    }

    public boolean rowDeleted() throws SQLException {
        checkClosed();
        return false;
    }

    public boolean rowInserted() throws SQLException {
        checkClosed();
        return false;
    }

    public boolean rowUpdated() throws SQLException {
        checkClosed();
        return false;
    }

    public synchronized void updateAsciiStream(int columnIndex, java.io.InputStream x, int length)
            throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateAsciiStream()");
    }

    public synchronized void updateBigDecimal(int columnIndex, java.math.BigDecimal x)
            throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateBinaryStream(int columnIndex, java.io.InputStream x, int length)
            throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateBinaryStream()");
    }

    public synchronized void updateBoolean(int columnIndex, boolean x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateByte(int columnIndex, byte x) throws SQLException {
        updateValue(columnIndex, String.valueOf(x));
    }

    public synchronized void updateBytes(int columnIndex, byte[] x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateCharacterStream(int columnIndex, java.io.Reader x, int length)
            throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateCharacterStream()");
    }

    public synchronized void updateDate(int columnIndex, java.sql.Date x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateDouble(int columnIndex, double x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateFloat(int columnIndex, float x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateInt(int columnIndex, int x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateLong(int columnIndex, long x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateNull(int columnIndex) throws SQLException {
        throw new NotUpdatable();
    }

    public synchronized void updateNull(String columnName) throws SQLException {
        updateNull(findColumn(columnName));
    }

    public synchronized void updateObject(int columnIndex, Object x) throws SQLException {
        updateObject(columnIndex, x,0);
    }

    public synchronized void updateObject(int columnIndex, Object x, int scale) throws SQLException {
        updateValue(columnIndex, x, scale);
    }

    @Override
    public void refreshRow() throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "refreshRow");
    }

    @Override
    public synchronized void updateRow() throws SQLException {
        throw new NotUpdatable();
    }

    public synchronized void updateShort(int columnIndex, short x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateString(int columnIndex, String x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateTime(int columnIndex, Time x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public synchronized void updateTimestamp(int columnIndex, Timestamp x) throws SQLException {
        updateValue(columnIndex, x);

    }

    @Override
    public synchronized void updateBoolean(String columnName, boolean x) throws SQLException {
        updateBoolean(findColumn(columnName), x);
    }

    public synchronized void updateByte(String columnName, byte x) throws SQLException {
        updateByte(findColumn(columnName), x);
    }

    public synchronized void updateShort(String columnName, short x) throws SQLException {
        updateShort(findColumn(columnName), x);
    }

    public synchronized void updateInt(String columnName, int x) throws SQLException {
        updateInt(findColumn(columnName), x);
    }

    public synchronized void updateLong(String columnName, long x) throws SQLException {
        updateLong(findColumn(columnName), x);
    }

    public synchronized void updateFloat(String columnName, float x) throws SQLException {
        updateFloat(findColumn(columnName), x);
    }

    public synchronized void updateDouble(String columnName, double x) throws SQLException {
        updateDouble(findColumn(columnName), x);
    }

    public synchronized void updateBigDecimal(String columnName, BigDecimal x) throws SQLException {
        updateBigDecimal(findColumn(columnName), x);
    }

    public synchronized void updateString(String columnName, String x) throws SQLException {
        updateString(findColumn(columnName), x);
    }

    public synchronized void updateBytes(String columnName, byte[] x) throws SQLException {
        updateBytes(findColumn(columnName), x);
    }

    public synchronized void updateDate(String columnName, java.sql.Date x) throws SQLException {
        updateDate(findColumn(columnName), x);
    }

    public synchronized void updateTime(String columnName, java.sql.Time x) throws SQLException {
        updateTime(findColumn(columnName), x);
    }

    public synchronized void updateTimestamp(String columnName, java.sql.Timestamp x)
            throws SQLException {
        updateTimestamp(findColumn(columnName), x);
    }

    public synchronized void updateAsciiStream(String columnName, java.io.InputStream x, int length)
            throws SQLException {
        throw new NotUpdatable();
    }

    public synchronized void updateBinaryStream(String columnName, java.io.InputStream x, int length)
            throws SQLException {
        updateBinaryStream(findColumn(columnName), x, length);
    }

    public synchronized void updateCharacterStream(String columnName, java.io.Reader reader,
                                                   int length) throws SQLException {
        updateCharacterStream(findColumn(columnName), reader, length);
    }

    public synchronized void updateObject(String columnName, Object x, int scale)
            throws SQLException {
        updateObject(findColumn(columnName), x);
    }

    public synchronized void updateObject(String columnName, Object x) throws SQLException {
        updateObject(findColumn(columnName), x);
    }

    /**
     * Is this ResultSet updateable?
     */

    boolean isUpdatable() throws SQLException {
        checkClosed();

        if (resultsetConcurrency == ResultSet.CONCUR_READ_ONLY) {
            throw SQLError.createSQLException(
                    Messages.get("ResultSets with concurrency CONCUR_READ_ONLY cannot be updated."),
                    YasState.INVALID_CURSOR_STATE);
        }

        if (updatable) {
            return true;
        } else {
            return false;
        }
    }

    private void setRowBufferColumn(int columnIndex, Object valueObject) throws SQLException {
        if (valueObject instanceof YasObject) {
            String value = ((YasObject) valueObject).getValue();
            rowBuffer.set(columnIndex, (value == null) ? null : connection.encodeString(value));
        } else {
            switch (getSQLType(columnIndex + 1)) {

                // boolean needs to be formatted as t or f instead of true or false
                case Types.BIT:
                case Types.BOOLEAN:
                    rowBuffer.set(columnIndex, connection
                            .encodeString(((Boolean) valueObject).booleanValue() ? "t" : "f"));
                    break;
                //
                // toString() isn't enough for date and time types; we must format it correctly
                // or we won't be able to re-parse it.
                //
                case Types.DATE:
                    break;

                case Types.TIME:
                    break;

                case Types.TIMESTAMP:
                    break;

                case Types.NULL:
                    // Should never happen?
                    break;

                case Types.BINARY:
                case Types.LONGVARBINARY:
                case Types.VARBINARY:
                    try {
                        rowBuffer.set(columnIndex,
                                YasByte.toYasString((byte[]) valueObject).getBytes("ISO-8859-1"));
                    } catch (UnsupportedEncodingException e) {
                        throw SQLError.createSQLException(
                                Messages.get("The JVM claims not to support the encoding: {0}", "ISO-8859-1"),
                                YasState.UNEXPECTED_ERROR, e);
                    }
                    break;

                default:
                    rowBuffer.set(columnIndex, connection.encodeString(String.valueOf(valueObject)));
                    break;
            }

        }
    }

    private void updateRowBuffer(PreparedStatement insertStatement) throws SQLException {
        for (Map.Entry<String, Object> entry : updateValues.entrySet()) {
            int columnIndex = findColumn(entry.getKey()) - 1;
            Object valueObject = entry.getValue();
            setRowBufferColumn(columnIndex, valueObject);
        }

        if (insertStatement == null) {
            return;
        }
        final ResultSet generatedKeys = insertStatement.getGeneratedKeys();
        try {
            generatedKeys.next();

            int numKeys = primaryKeys.size();

            for (int i = 0; i < numKeys; i++) {
                final PrimaryKey key = primaryKeys.get(i);
                int columnIndex = key.index - 1;
                Object valueObject = generatedKeys.getObject(key.name);
                setRowBufferColumn(columnIndex, valueObject);
            }
        } finally {
            generatedKeys.close();
        }
    }

    public void setFetchSize(int rows) throws SQLException {
        synchronized (this.connection) {
            checkClosed();
            if (rows < 0) {
                throw SQLError.createSQLException(Messages.get("Fetch size must be a value greater to or equal to 0."),
                        YasState.INVALID_PARAMETER_VALUE);
            }
            fetchSize = rows;
        }
    }

    public int getFetchSize() throws SQLException {
        synchronized (this.connection) {
            checkClosed();
            return fetchSize;
        }
    }

    @Override
    public boolean next() throws SQLException {
        synchronized (this.connection) {
            checkClosed();

            if (this.onInsertRow) {
                this.onInsertRow = false;
            }

            if (this.doingUpdates) {
                this.doingUpdates = false;
            }

            boolean hasNext;
            if (!reallyResult()) {
                throw SQLError.createSQLException("ResultSet is from update", YasState.NO_DATA);
            }

            this.owningStatement.drainStream();

            if ((maxRows > 0) && (currentRow >= maxRows - 1)) {
                currentRow = maxRows;
                return false;
            }

            if (this.rowData == null) {
                return false;
            }

            if (!this.rowData.hasNext()) {
                hasNext = false;
            } else {
                this.thisRow = this.rowData.next();
                currentRow++;

                if (this.thisRow == null) {
                    hasNext = false;
                } else {
                    clearWarnings();
                    hasNext = true;
                }
            }

            if (!hasNext) {
                currentRow = this.rowData.getFetchedRowCount();
            }

            return hasNext;
        }
    }

    @Override
    public void close() throws SQLException {
        synchronized (this) {
            if (!isClosed) {
                closeInternally();
            }
        }
    }

    protected void closeInternally() throws SQLException {
        rowData = null;
        isClosed = true;

        if (stmtQueryResult && !this.owningStatement.isClosed()
                && this.owningStatement.isCloseOnCompletion()) {
            this.owningStatement.close();
        }
    }

    public boolean wasNull() throws SQLException {
        checkClosed();
        if (wasNullFlag == null) {
            throw new SQLException("No Data Read");
        }
        return wasNullFlag;
    }

    private boolean isLobType(int sqlType) {
        if ((sqlType == YasTypes.CLOB) || (sqlType == YasTypes.BLOB) || (sqlType == YasTypes.NCLOB)) {
            return true;
        }

        return false;
    }

    @Override
    public String getString(int columnIndex) throws SQLException {
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return null;
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);

        if (isLobType(fields[col].getSQLType())) {
            return accessors[col].getString(thisRow.get(col));
        }

        return accessors[col].getString(truncBytes(columnIndex, thisRow.get(col)));
    }

    @Override
    public boolean getBoolean(int columnIndex) throws SQLException {
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return false;
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);

        return this.accessors[col].getBoolean(thisRow.get(col));
    }

    @Override
    public byte getByte(int columnIndex) throws SQLException {
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return 0; // SQL NULL
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);

        return this.accessors[col].getByte(thisRow.get(col));
    }

    @Override
    public short getShort(int columnIndex) throws SQLException {
        LOGGER.debug("getShort columnIndex: {}", columnIndex);
        checkResultSet(columnIndex);

        if (wasNullFlag) {
            return 0; // SQL NULL
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);

        return this.accessors[col].getShort(thisRow.get(col));
    }

    @Override
    public int getInt(int columnIndex) throws SQLException {
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return 0; // SQL NULL
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);

        return this.accessors[col].getInt(thisRow.get(col));
    }

    @Override
    public long getLong(int columnIndex) throws SQLException {
        LOGGER.debug("getLong columnIndex: {}", columnIndex);
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return 0; // SQL NULL
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);

        return this.accessors[col].getLong(thisRow.get(col));
    }

    @Override
    public float getFloat(int columnIndex) throws SQLException {
        LOGGER.debug("getFloat columnIndex: {}", columnIndex);
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return 0; // SQL NULL
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);

        return this.accessors[col].getFloat(thisRow.get(col));
    }

    @Override
    public double getDouble(int columnIndex) throws SQLException {
        LOGGER.debug("getDouble columnIndex: {}", columnIndex);
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return 0; // SQL NULL
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);

        return this.accessors[col].getDouble(thisRow.get(col));
    }

    public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
        LOGGER.debug("getBigDecimal columnIndex: {}", columnIndex);
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return null; // SQL NULL
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);
        return this.accessors[col].getBigDecimal(thisRow.get(col));
    }

    /**
     * {@inheritDoc}
     *
     * <p>In normal use, the bytes represent the raw values returned by the backend. However, if the
     * column is an OID, then it is assumed to refer to a Large Object, and that object is returned as
     * a byte array.</p>
     *
     * <p><b>Be warned</b> If the large object is huge, then you may run out of memory.</p>
     */
    @Override
    public byte[] getBytes(int columnIndex) throws SQLException {
        LOGGER.debug("getBytes columnIndex: {}", columnIndex);
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return null;
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);

        if (isLobType(fields[col].getSQLType())) {
            return this.accessors[col].getBytes(thisRow.get(col));
        }
        return this.accessors[col].getBytes(truncBytes(columnIndex, thisRow.get(col)));

    }

    public java.sql.Date getDate(int columnIndex) throws SQLException {
        return getDate(columnIndex, null);
    }

    public Time getTime(int columnIndex) throws SQLException {
        LOGGER.debug("getTime columnIndex: {}", columnIndex);
        return getTime(columnIndex, null);
    }

    public Timestamp getTimestamp(int columnIndex) throws SQLException {
        return getTimestamp(columnIndex, null);
    }

    public InputStream getAsciiStream(int columnIndex) throws SQLException {
        LOGGER.debug("getAsciiStream columnIndex: {}", columnIndex);
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return null;
        }

        int col = columnIndex - 1;
        int type = fields[col].getYasType();
        InputStream inputStream;
        switch (type) {
            case DataType.VARCHAR:
            case DataType.CHAR:
            case DataType.NVARCHAR:
            case DataType.NCHAR:
                inputStream = new ByteArrayInputStream(getString(columnIndex).getBytes(StandardCharsets.US_ASCII));
                break;
            default:
                throw SQLError.createSQLException(
                        Messages.get("getAsciiStream not implemented for type {0}", fields[col].getTypeName()),
                        YasState.WRONG_OBJECT_TYPE);
        }

        return inputStream;
    }

    public InputStream getUnicodeStream(int columnIndex) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getUnicodeStream(int)");
    }

    public InputStream getBinaryStream(int columnIndex) throws SQLException {
        LOGGER.debug("getBinaryStream columnIndex: {}", columnIndex);
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return null;
        }

        int col = columnIndex - 1;
        int type = fields[col].getYasType();
        InputStream inputStream;
        switch (type) {
            case DataType.VARCHAR:
            case DataType.CHAR:
            case DataType.NVARCHAR:
            case DataType.NCHAR:
                inputStream = new ByteArrayInputStream(getBytes(columnIndex));
                break;
            case DataType.BLOB:
                inputStream = this.getBlob(columnIndex).getBinaryStream();
                break;
            default:
                throw SQLError.createSQLException(
                        Messages.get("getBinaryStream not implemented for type {0}", fields[col].getTypeName()),
                        YasState.WRONG_OBJECT_TYPE);
        }

        return inputStream;
    }

    public String getString(String columnName) throws SQLException {
        return getString(findColumn(columnName));
    }

    @Override
    public boolean getBoolean(String columnName) throws SQLException {
        return getBoolean(findColumn(columnName));
    }

    public byte getByte(String columnName) throws SQLException {

        return getByte(findColumn(columnName));
    }

    public short getShort(String columnName) throws SQLException {
        return getShort(findColumn(columnName));
    }

    public int getInt(String columnName) throws SQLException {
        return getInt(findColumn(columnName));
    }

    public long getLong(String columnName) throws SQLException {
        return getLong(findColumn(columnName));
    }

    public float getFloat(String columnName) throws SQLException {
        return getFloat(findColumn(columnName));
    }

    public double getDouble(String columnName) throws SQLException {
        return getDouble(findColumn(columnName));
    }

    public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException {
        return getBigDecimal(findColumn(columnName), scale);
    }

    public byte[] getBytes(String columnName) throws SQLException {
        return getBytes(findColumn(columnName));
    }

    public java.sql.Date getDate(String columnName) throws SQLException {
        return getDate(findColumn(columnName));
    }

    public Time getTime(String columnName) throws SQLException {
        return getTime(findColumn(columnName), null);
    }

    public Timestamp getTimestamp(String columnName) throws SQLException {
        return getTimestamp(findColumn(columnName));
    }

    public InputStream getAsciiStream(String columnName) throws SQLException {
        return getAsciiStream(findColumn(columnName));
    }

    public InputStream getUnicodeStream(String columnName) throws SQLException {
        return getUnicodeStream(findColumn(columnName));
    }

    public InputStream getBinaryStream(String columnName) throws SQLException {
        return getBinaryStream(findColumn(columnName));
    }

    public SQLWarning getWarnings() throws SQLException {
        checkClosed();
        return warnings;
    }

    public void clearWarnings() throws SQLException {
        checkClosed();
        warnings = null;
    }

    protected void addWarning(SQLWarning warnings) {
        if (this.warnings != null) {
            this.warnings.setNextWarning(warnings);
        } else {
            this.warnings = warnings;
        }
    }

    public String getCursorName() throws SQLException {
        checkClosed();
        return null;
    }

    @Override
    public Object getObject(int columnIndex) throws SQLException {
        LOGGER.debug( "getObject columnIndex: {}", columnIndex);
        Field field;

        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return null;
        }

        field = fields[columnIndex - 1];
        if (field == null) {
            wasNullFlag = true;
            return null;
        }

        Object result = internalGetObject(columnIndex, field);
        if (result != null) {
            return result;
        }
        //TODO: getObject
        return null;
    }

    public Object getObject(String columnName) throws SQLException {
        return getObject(findColumn(columnName));
    }

    public int findColumn(String columnName) throws SQLException {
        checkClosed();

        int col = findColumnIndex(columnName);
        if (col == 0) {
            throw SQLError.createSQLException(
                    Messages.get("The column name {0} was not found in this ResultSet.", columnName),
                    YasState.UNDEFINED_COLUMN);
        }
        return col;
    }

    public static Map<String, Integer> createColumnNameIndexMap(Field[] fields) {
        Map<String, Integer> columnNameIndexMap = new HashMap<String, Integer>(fields.length * 2);
        // The JDBC spec says when you have duplicate columns names,
        // the first one should be returned. So load the map in
        // reverse order so the first ones will overwrite later ones.
        for (int i = fields.length - 1; i >= 0; i--) {
            String columnName = fields[i].getName();
            columnNameIndexMap.put(columnName.toLowerCase(Locale.US), i + 1);

        }
        return columnNameIndexMap;
    }

    private int findColumnIndex(String columnName) {
        if (columnNameIndexMap == null) {
            if (owningStatement != null) {
                columnNameIndexMap = owningStatement.getResultSetColumnNameIndexMap();
            }
            if (columnNameIndexMap == null) {
                columnNameIndexMap = createColumnNameIndexMap(fields);
            }
        }

        Integer index = columnNameIndexMap.get(columnName);
        if (index != null) {
            return index;
        }

        index = columnNameIndexMap.get(columnName.toLowerCase(Locale.US));
        if (index != null) {
            columnNameIndexMap.put(columnName, index);
            return index;
        }

        index = columnNameIndexMap.get(columnName.toUpperCase(Locale.US));
        if (index != null) {
            columnNameIndexMap.put(columnName, index);
            return index;
        }

        return 0;
    }

    protected int getSQLType(int column) throws SQLException {
        Field field = fields[column - 1];
        return field.getSQLType();
    }

    protected void checkUpdatable() throws SQLException {
        checkClosed();

        if (!isUpdatable()) {
            throw SQLError.createSQLException(
                    Messages.get(
                            "ResultSet is not updateable."
                                    + " The query that generated this result set must select only one table,"
                                    + " and not have aggregate function. "
                                    + "See the JDBC 2.1 API Specification,"
                                    + " section 5.6 for more details."),
                    YasState.INVALID_CURSOR_STATE);
        }

        if (updateValues == null) {
            // allow every column to be updated without a rehash.
            updateValues = new HashMap<String, Object>((int) (fields.length / 0.75), 0.75f);
            updateSQLTypes = new HashMap<String, SQLType>((int) (fields.length / 0.75), 0.75f);
            updateScales = new HashMap<String, Integer>((int) (fields.length / 0.75), 0.75f);
        }
    }

    protected void checkClosed() throws SQLException {
        if (isClosed) {
            throw SQLError.createSQLException(Messages.get("This ResultSet is closed."),
                    YasState.OBJECT_NOT_IN_STATE);
        }
    }

    protected void checkColumnIndex(int column) throws SQLException {
        if (column < 1 || column > fields.length) {
            throw SQLError.createSQLException(
                    Messages.get("The column index is out of range: {0}, number of columns: {1}.",
                            column, fields.length),
                    YasState.INVALID_PARAMETER_VALUE);
        }
    }

    /**
     * Checks that the result set is not closed, it's positioned on a valid row and that the given
     * column number is valid. Also updates the {@link #wasNullFlag} to correct value.
     *
     * @param column The column number to check. Range starts from 1.
     * @throws SQLException If state or column is invalid.
     */
    protected void checkResultSet(int column) throws SQLException {
        checkClosed();
        if (thisRow == null) {
            throw SQLError.createSQLException(
                    Messages.get("ResultSet not positioned properly, perhaps you need to call next."),
                    YasState.INVALID_CURSOR_STATE);
        }
        checkColumnIndex(column);
        wasNullFlag = (thisRow.get(column - 1) == null);
    }

    private boolean isColumnTrimmable(int columnIndex) throws SQLException {
        switch (getSQLType(columnIndex)) {
            case Types.CHAR:
            case Types.VARCHAR:
            case Types.NCHAR:
            case Types.NVARCHAR:
            case Types.LONGVARCHAR:
            case Types.LONGNVARCHAR:
            case Types.BINARY:
            case Types.VARBINARY:
            case Types.LONGVARBINARY:
                return true;
        }
        return false;
    }

    private byte[] truncBytes(int columnIndex, byte[] bytes) throws SQLException {
        int bytesLen = bytes.length;
        if (maxFieldSize > 0 && bytesLen > maxFieldSize && isColumnTrimmable(columnIndex)) {
            bytesLen = maxFieldSize;
        }

        byte[] newBytes = new byte[bytesLen];
        System.arraycopy(bytes, 0, newBytes, 0, bytesLen);
        return newBytes;
    }

    protected void updateValue(int columnIndex, Object value) throws SQLException {
        updateValue(columnIndex,value,0);
    }

    protected void updateValue(int columnIndex, Object value,int scaleOrLength) throws SQLException {
        updateValue(columnIndex,value,null,scaleOrLength);
    }

    protected void updateValue(int columnIndex, Object value, java.sql.SQLType targetSqlType,
                               int scaleOrLength) throws SQLException {
        throw new NotUpdatable();
    }

    private class PrimaryKey {

        int index; // where in the result set is this primaryKey
        String name; // what is the columnName of this primary Key

        PrimaryKey(int index, String name) {
            this.index = index;
            this.name = name;
        }

        Object getValue() throws SQLException {
            return getObject(index);
        }
    }

    public void updateRef(int columnIndex, Ref x) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateRef(int,Ref)");
    }

    public void updateRef(String columnName, Ref x) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateRef(String,Ref)");
    }

    public void updateBlob(int columnIndex, Blob x) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateBlob(int,Blob)");
    }

    public void updateBlob(String columnName, Blob x) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateBlob(String,Blob)");
    }

    public void updateClob(int columnIndex, Clob x) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateClob(int,Clob)");
    }

    public void updateClob(String columnName, Clob x) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateClob(String,Clob)");
    }

    public void updateArray(int columnIndex, Array x) throws SQLException {
        updateObject(columnIndex, x);
    }

    public void updateArray(String columnName, Array x) throws SQLException {
        updateArray(findColumn(columnName), x);
    }

    public <T> T getObject(int columnIndex, Class<T> type) throws SQLException {
        if (type == null) {
            throw new SQLException("Invalid Parameter, Class Type is null");
        }

        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return null;
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(col);

        return accessors[col].getObject(thisRow.get(col), type, connection);
    }

    public <T> T getObject(String columnLabel, Class<T> type) throws SQLException {
        return getObject(findColumn(columnLabel), type);
    }

    public Object getObject(String s, Map<String, Class<?>> map) throws SQLException {
        return getObjectImpl(s, map);
    }

    public Object getObject(int i, Map<String, Class<?>> map) throws SQLException {
        return getObjectImpl(i, map);
    }

    public void updateObject(int columnIndex, Object x, java.sql.SQLType targetSqlType,
                             int scaleOrLength) throws SQLException {
        updateValue(columnIndex,x,targetSqlType,scaleOrLength);
    }

    public void updateObject(String columnLabel, Object x, java.sql.SQLType targetSqlType,
                             int scaleOrLength) throws SQLException {
        updateObject(findColumn(columnLabel), x,targetSqlType,scaleOrLength);
    }

    public void updateObject(int columnIndex, Object x, java.sql.SQLType targetSqlType)
            throws SQLException {
        updateObject(columnIndex,x,targetSqlType,0);
    }

    public void updateObject(String columnLabel, Object x, java.sql.SQLType targetSqlType)
            throws SQLException {
        updateObject(findColumn(columnLabel), x,targetSqlType);
    }

    public RowId getRowId(int columnIndex) throws SQLException {
        LOGGER.debug("getRowId columnIndex: {}", columnIndex);
        checkResultSet(columnIndex);
        if (wasNullFlag) {
            return null;
        }

        int col = columnIndex - 1;
        this.owningStatement.closeStream(columnIndex);

        return this.accessors[col].getRowId(thisRow.get(col));
    }

    public RowId getRowId(String columnName) throws SQLException {
        return getRowId(findColumn(columnName));
    }

    public void updateRowId(int columnIndex, RowId x) throws SQLException {
        updateValue(columnIndex, x);
    }

    public void updateRowId(String columnName, RowId x) throws SQLException {
        updateRowId(findColumn(columnName), x);
    }

    public int getHoldability() throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getHoldability()");
    }

    /**
     * Does the result set contain rows, or is it the result of a DDL or DML statement?
     */
    @Override
    public boolean reallyResult() {
        if (this.rowData != null) {
            return true;
        }
        return this.reallyResult;
    }

    @Override
    public void setStmtQueryResult(boolean stmtQuery) {
        this.stmtQueryResult = stmtQuery;
    }

    /**
     * Returns the server informational message returned from a DDL or DML statement (if any), or null
     * if none.
     */
    @Override
    public String getServerInfo() {
        return null;
    }

    /**
     * Returns the update count for this result set (if one exists), otherwise -1.
     *
     * @return the update count for this result set (if one exists), otherwise -1.
     */
    @Override
    public long getUpdateCount() {
        return this.updateCount;
    }

    /**
     * Returns the AUTO_INCREMENT value for the DDL/DML statement which created this result set.
     *
     * @return the AUTO_INCREMENT value for the DDL/DML statement which created this result set.
     */
    @Override
    public long getUpdateID() {
        return 0;
    }

    /**
     * Closes this ResultSet and releases resources.
     *
     * @param calledExplicitly was realClose called by the standard ResultSet.close() method, or was
     *                         it closed internally by the driver?
     */
    @Override
    public void realClose(boolean calledExplicitly) throws SQLException {

    }

    public boolean isClosed() throws SQLException {
        return isClosed;
    }

    /**
     * Sets the first character of the query that was issued to create this result set. The character
     * should be upper-cased.
     */
    @Override
    public void setFirstCharOfQuery(char firstCharUpperCase) {

    }

    /**
     * Sets the statement that "owns" this result set (usually used when the result set should
     * internally "belong" to one statement, but is created by another.
     */
    @Override
    public void setOwningStatement(StatementImpl owningStatement) {

    }

    /**
     * Returns the first character of the query that was issued to create this result set,
     * upper-cased.
     */
    @Override
    public char getFirstCharOfQuery() {
        return 0;
    }

    /**
     * Clears the reference to the next result set in a multi-result set "chain".
     */
    @Override
    public void clearNextResult() {

    }

    @Override
    public void appendResults(long updateCount, int[] dmlRows, Map<Integer, BatchError> batchErrors) {
        this.updateCount += updateCount;
        if (this.dmlRowList == null) {
            this.dmlRowList = new ArrayList<>();
            if (this.dmlRows != null) {
                for (int affectedRows : this.dmlRows) {
                    this.dmlRowList.add(affectedRows);
                }
            }
        }

        int preDmlRows = this.dmlRowList.size();

        if (dmlRows != null) {
            for (int affectedRows : dmlRows) {
                this.dmlRowList.add(affectedRows);
            }
        } else {
            this.dmlRowList.add((int) updateCount);
        }

        if (batchErrors == null) {
            return;
        }

        if (this.batchErrors == null) {
            this.batchErrors = new HashMap<>();
        }

        for (Map.Entry<Integer, BatchError> entry : batchErrors.entrySet()) {
            int errorRowNum = entry.getKey() + preDmlRows;
            BatchError batchError = entry.getValue();
            this.batchErrors.put(errorRowNum, batchError);
        }
    }

    /**
     * Returns the next ResultSet in a multi-resultset "chain", if any, null if none exists.
     */
    @Override
    public YasResultSet getNextResultSet() {
        return null;
    }

    /**
     * Builds a hash between column names and their indices for fast retrieval. This is done lazily to
     * support findColumn() and get*(String), as it can be more expensive than just retrieving result
     * set values by ordinal index.
     */
    @Override
    public void buildIndexMapping() throws SQLException {

    }

    @Override
    public void initializeWithMetadata() throws SQLException {

    }

    /**
     * Used by DatabaseMetadata implementations to coerce the metadata returned by metadata queries
     * into that required by the JDBC specification.
     *
     * @param metadataFields the coerced metadata to be applied to result sets returned by "SHOW ..."
     *                       or SELECTs on INFORMATION_SCHEMA performed on behalf of methods in
     *                       DatabaseMetadata.
     */
    @Override
    public void redefineFieldsForDBMD(Field[] metadataFields) {

    }

    @Override
    public int getBytesSize() throws SQLException {
        return 0;
    }

    public void updateNString(int columnIndex, String nString) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateNString(int, String)");
    }

    public void updateNString(String columnName, String nString) throws SQLException {
        updateNString(findColumn(columnName), nString);
    }

    public void updateNClob(int columnIndex, NClob nClob) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateNClob(int, NClob)");
    }

    public void updateNClob(String columnName, NClob nClob) throws SQLException {
        updateNClob(findColumn(columnName), nClob);
    }

    public void updateNClob(int columnIndex, Reader reader) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateNClob(int, Reader)");
    }

    public void updateNClob(String columnName, Reader reader) throws SQLException {
        updateNClob(findColumn(columnName), reader);
    }

    public void updateNClob(int columnIndex, Reader reader, long length) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateNClob(int, Reader, long)");
    }

    public void updateNClob(String columnName, Reader reader, long length) throws SQLException {
        updateNClob(findColumn(columnName), reader, length);
    }

    public NClob getNClob(int columnIndex) throws SQLException {
        LOGGER.debug("getNClob columnIndex: {}", columnIndex);
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getNClob(int)");
    }

    public NClob getNClob(String columnName) throws SQLException {
        return getNClob(findColumn(columnName));
    }

    public void updateBlob(int columnIndex, InputStream inputStream, long length)
            throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "updateBlob(int, InputStream, long)");
    }

    public void updateBlob(String columnName, InputStream inputStream, long length)
            throws SQLException {
        updateBlob(findColumn(columnName), inputStream, length);
    }

    public void updateBlob(int columnIndex, InputStream inputStream) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateBlob(int, InputStream)");
    }

    public void updateBlob(String columnName, InputStream inputStream) throws SQLException {
        updateBlob(findColumn(columnName), inputStream);
    }

    public void updateClob(int columnIndex, Reader reader, long length) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateClob(int, Reader, long)");
    }

    public void updateClob(String columnName, Reader reader, long length) throws SQLException {
        updateClob(findColumn(columnName), reader, length);
    }

    public void updateClob(int columnIndex, Reader reader) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "updateClob(int, Reader)");
    }

    public void updateClob(String columnName, Reader reader) throws SQLException {
        updateClob(findColumn(columnName), reader);
    }

    public SQLXML getSQLXML(int columnIndex) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getSQLXML(int, Reader)");
    }

    public SQLXML getSQLXML(String columnName) throws SQLException {
        return getSQLXML(findColumn(columnName));
    }

    public void updateSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException {
        updateValue(columnIndex, xmlObject);
    }

    public void updateSQLXML(String columnName, SQLXML xmlObject) throws SQLException {
        updateSQLXML(findColumn(columnName), xmlObject);
    }

    public String getNString(int columnIndex) throws SQLException {
        LOGGER.debug("getNString columnIndex: {}", columnIndex);
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getNString(int)");
    }

    public String getNString(String columnName) throws SQLException {
        return getNString(findColumn(columnName));
    }

    public Reader getNCharacterStream(int columnIndex) throws SQLException {
        LOGGER.debug("getNCharacterStream columnIndex: {}", columnIndex);
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "getNCharacterStream(int)");
    }

    public Reader getNCharacterStream(String columnName) throws SQLException {
        return getNCharacterStream(findColumn(columnName));
    }

    public void updateNCharacterStream() throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "updateNCharacterStream(int, Reader, int)");
    }

    public void updateNCharacterStream(String columnName, Reader x, int length) throws SQLException {
        updateNCharacterStream(findColumn(columnName), x);
    }

    public void updateNCharacterStream(int columnIndex, Reader x) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "updateNCharacterStream(int, Reader)");
    }

    public void updateNCharacterStream(String columnName, Reader x) throws SQLException {
        updateNCharacterStream(findColumn(columnName), x);
    }

    public void updateNCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "updateNCharacterStream(int, Reader, long)");
    }

    public void updateNCharacterStream(String columnName, Reader x, long length) throws SQLException {
        updateNCharacterStream(findColumn(columnName), x, length);
    }

    public void updateCharacterStream(int columnIndex, Reader reader, long length)
            throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "updateCharaceterStream(int, Reader, long)");
    }

    public void updateCharacterStream(String columnName, Reader reader, long length)
            throws SQLException {
        updateCharacterStream(findColumn(columnName), reader, length);
    }

    public void updateCharacterStream(int columnIndex, Reader reader) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "updateCharaceterStream(int, Reader)");
    }

    public void updateCharacterStream(String columnName, Reader reader) throws SQLException {
        updateCharacterStream(findColumn(columnName), reader);
    }

    public void updateBinaryStream(int columnIndex, InputStream inputStream, long length)
            throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "updateBinaryStream(int, InputStream, long)");
    }

    public void updateBinaryStream(String columnName, InputStream inputStream, long length)
            throws SQLException {
        updateBinaryStream(findColumn(columnName), inputStream, length);
    }

    public void updateBinaryStream(int columnIndex, InputStream inputStream) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "updateBinaryStream(int, InputStream)");
    }

    public void updateBinaryStream(String columnName, InputStream inputStream) throws SQLException {
        updateBinaryStream(findColumn(columnName), inputStream);
    }

    public void updateAsciiStream(int columnIndex, InputStream inputStream, long length)
            throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "updateAsciiStream(int, InputStream, long)");
    }

    public void updateAsciiStream(String columnName, InputStream inputStream, long length)
            throws SQLException {
        updateAsciiStream(findColumn(columnName), inputStream, length);
    }

    public void updateAsciiStream(int columnIndex, InputStream inputStream) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "updateAsciiStream(int, InputStream)");
    }

    public void updateAsciiStream(String columnName, InputStream inputStream) throws SQLException {
        updateAsciiStream(findColumn(columnName), inputStream);
    }

    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        return iface.isAssignableFrom(getClass());
    }

    public <T> T unwrap(Class<T> iface) throws SQLException {
        if (iface.isAssignableFrom(getClass())) {
            return iface.cast(this);
        }
        throw new SQLException("Cannot unwrap to " + iface.getName());
    }

    protected void prepareMove() throws SQLException {
        if (this.onInsertRow) {
            this.onInsertRow = false;
        }

        if (this.doingUpdates) {
            this.doingUpdates = false;
        }
        this.owningStatement.drainStream();

        if (!reallyResult()) {
            throw SQLError.createSQLException("ResultSet is from update", YasState.NO_DATA);
        }
    }

    @Override
    public long getFetchedRowCount() throws SQLException {
        if (this.reallyResult && rowData != null) {
            return rowData.getFetchedRowCount() ;
        } else {
            return -1L;
        }
    }

    @Override
    public int[] getBatchUpdateCounts() {
        if (this.dmlRowList == null) {
            return dmlRows;
        }

        int[] updateCounts = new int[this.dmlRowList.size()];
        for (int i = 0; i < this.dmlRowList.size(); i++) {
            updateCounts[i] = this.dmlRowList.get(i);
        }
        return updateCounts;
    }

    @Override
    public Map<Integer, BatchError> getBatchErrors() {
        return this.batchErrors;
    }

    @Override
    public String getBatchError(int batchIndex) {
        if ( batchErrors != null) {
            BatchError be = batchErrors.get(batchIndex);
            if (be != null) {
                return be.toString();
            }
        }
        return null;
    }
}
