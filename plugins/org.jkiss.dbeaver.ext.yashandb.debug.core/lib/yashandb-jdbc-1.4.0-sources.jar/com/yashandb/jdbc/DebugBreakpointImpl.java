/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

public class DebugBreakpointImpl implements DebugBreakpoint {
    private int id;

    private long objectId;

    private int subprogramId;

    private int lineNum;

    public DebugBreakpointImpl(long objectId, int subprogramId, int lineNum) {
        this.objectId = objectId;
        this.subprogramId = subprogramId;
        this.lineNum = lineNum;
        this.id = -1;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public long getObjectId() {
        return objectId;
    }

    public int getSubprogramId() {
        return subprogramId;
    }

    public int getLineNum() {
        return lineNum;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof DebugBreakpoint)) {
            return false;
        }
        DebugBreakpoint breakpoint = (DebugBreakpoint) obj;
        if (breakpoint.getObjectId() != this.objectId) {
            return false;
        }
        if (breakpoint.getSubprogramId() != this.subprogramId) {
            return false;
        }
        if (breakpoint.getLineNum() != this.lineNum) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
