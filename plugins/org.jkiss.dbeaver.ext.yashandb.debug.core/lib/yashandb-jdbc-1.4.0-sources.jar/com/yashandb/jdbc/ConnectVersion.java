/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

public enum ConnectVersion {
    VER1("VER1", 0x01000001),
    VER2("VER2", 0x01000002),
    UNINITIALIZED("uninitialized", 0x01000000);

    private final String verName;
    private final int verNumber;

    ConnectVersion(String verName, int verNumber) {
        this.verName = verName;
        this.verNumber = verNumber;
    }

    public static ConnectVersion valueOf(int versionNum) {
        switch (versionNum) {
            case 0x01000001:
                return VER1;
            case 0x01000002:
                return VER2;
            default:
                return UNINITIALIZED;
        }
    }

    public int getValue() {
        return this.verNumber;
    }

    public String getName() {
        return verName;
    }

    public static ConnectVersion getMaxConnectVersion() {
        return VER2;
    }
}
