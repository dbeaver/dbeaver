/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.core.DataType;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.Messages;

import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.SQLException;

public class YasBlob implements Blob, YasLargeObject {

    private YasLobProcessor lobProcessor = null;

    private YasConnection connection = null;

    private boolean isTempLob = false;

    private boolean isFree = false;

    private boolean inValid = false;

    public YasBlob(boolean isTempLob) {
        this.isTempLob = isTempLob;
    }

    public void setLobProcessor(YasLobProcessor processor) {
        this.lobProcessor = processor;
        this.lobProcessor.setLobType(DataType.BLOB);
        this.lobProcessor.setYasLob(this);
    }

    public YasLobProcessor getLobProcessor() {
        return lobProcessor;
    }

    private void checkClosed() throws SQLException {
        if (this.connection.isClosed()) {
            throw SQLError.createSQLException(Messages.get("This connection has been closed."),
                    YasState.CONNECTION_DOES_NOT_EXIST);
        }

        if (isFree) {
            throw SQLError.createSQLException("the lob has been freed", YasState.DATA_ERROR);
        }

        if (inValid) {
            throw SQLError.createSQLException("the lob is inValid", YasState.DATA_ERROR);
        }
    }

    @Override
    public synchronized long length() throws SQLException {
        checkClosed();
        return lobProcessor.getLobLength();
    }

    @Override
    public synchronized byte[] getBytes(long pos, int length) throws SQLException {
        checkClosed();
        return lobProcessor.getBytes(pos, length);
    }

    @Override
    public synchronized InputStream getBinaryStream() throws SQLException {
        checkClosed();
        return new YasLobInputStream(this);
    }

    @Override
    public long position(byte[] pattern, long start) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "position(byte[] pattern, long start)");
    }

    @Override
    public long position(Blob pattern, long start) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                "position(Blob pattern, long start)");
    }

    private void checkPos(long pos) throws SQLException {
        if (pos < 1L) {
            throw SQLError.createSQLException("invalid parameter, ''pos'' should not be < 1",
                    YasState.INVALID_PARAMETER_VALUE);
        }

        if (connection.getSession().getConnectVersion() == ConnectVersion.VER1) {
            if (pos != (this.length() + 1)) {
                throw SQLError.createSQLException("temp lob write only support append mode, "
                                + "''pos'' should be lob length + 1",
                        YasState.INVALID_PARAMETER_VALUE);
            }
        } else {
            if (pos > this.length() + 1) {
                throw SQLError.createSQLException("invalid parameter, ''len'' should not be > lob length + 1",
                        YasState.INVALID_PARAMETER_VALUE);
            }
        }

    }

    @Override
    public synchronized int setBytes(long pos, byte[] bytes) throws SQLException {
        checkClosed();
        checkPos(pos);
        if (bytes == null) {
            return 0;
        }

        preProcessTempInRowLob();

        return lobProcessor.setBytes(pos, bytes, 0, bytes.length);
    }

    @Override
    public synchronized int setBytes(long pos, byte[] bytes, int offset, int len) throws SQLException {
        checkClosed();
        checkPos(pos);
        if (bytes == null) {
            return 0;
        }

        if ((offset < 0) || (offset >= bytes.length) || (len <= 0) || (offset + len > bytes.length)) {
            throw SQLError.createSQLException("parameter ''offset'' or ''len'' is invalid",
                    YasState.INVALID_PARAMETER_VALUE);
        }

        if (!supportUpdateKnlLob()) {
            throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                    "setBytes(long pos, byte[] bytes, int offset, int len)");
        }

        preProcessTempInRowLob();

        return lobProcessor.setBytes(pos, bytes, offset, len);
    }

    @Override
    public OutputStream setBinaryStream(long pos) throws SQLException {
        checkClosed();
        checkPos(pos);

        return new YasBlobOutputStream(this, pos);
    }

    @Override
    public void truncate(long len) throws SQLException {
        if (connection.getSession().getConnectVersion() == ConnectVersion.VER1) {
            throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                    "truncate(long len)");
        }

        checkClosed();

        if (len < 0L || len > this.length()) {
            throw SQLError.createSQLException("invalid parameter, ''len'' should be between 0 and lob length",
                    YasState.INVALID_PARAMETER_VALUE);
        }

        preProcessTempInRowLob();

        lobProcessor.truncate(len);
    }

    @Override
    public synchronized void free() throws SQLException {
        if (this.connection.isClosed()) {
            throw SQLError.createSQLException(Messages.get("This connection has been closed."),
                    YasState.CONNECTION_DOES_NOT_EXIST);
        }

        if (!isFree) {
            if (isTempLob) {
                lobProcessor.free();
            } else {
                this.connection.getSession().removeUpdatedKnlLob(this);
            }
            isFree = true;
        }
    }

    @Override
    public void setConnection(YasConnection connection) {
        this.connection = connection;
    }

    @Override
    public void freeTemp() throws SQLException {
        this.free();
    }

    @Override
    public int getStepSize() throws SQLException {
        checkClosed();
        return lobProcessor.getStepSize();
    }

    @Override
    public synchronized int getBytes(long lobOffset, byte[] data) throws SQLException {
        checkClosed();
        return lobProcessor.getBytes(lobOffset, data);
    }

    @Override
    public long getLobLength() throws SQLException {
        return this.length();
    }

    private void checkStreamParameters(long pos, long length) throws SQLException {
        long lobLength = this.getLobLength();
        if ((pos < 1) || (pos > lobLength) || (length < 0) || (pos + length - 1 > lobLength)) {
            throw SQLError.createSQLException("invalid parameter", YasState.INVALID_PARAMETER_VALUE);
        }
    }

    @Override
    public synchronized InputStream getBinaryStream(long pos, long length) throws SQLException {
        checkClosed();
        checkStreamParameters(pos, length);
        return new YasLobInputStream(this, pos, length);
    }

    @Override
    public int writeBytes(long pos, byte[] bytes, int offset, int len) throws SQLException {
        return this.setBytes(pos, bytes, offset, len);
    }

    private void preProcessTempInRowLob() throws SQLException {
        if (lobProcessor.getInnerLobType() != YasLobProcessor.LOB_LOCATOR_TEMP_IN_ROW) {
            return;
        }
        YasBlob tempBlob = (YasBlob)this.connection.createBlob();
        tempBlob.setBytes(1,this.getBytes(1,(int)this.length()));
        this.setLobProcessor(tempBlob.getLobProcessor());
        isTempLob = true;
    }

    public void rollback() throws SQLException {
        if (this.lobProcessor.isUpdated()) {
            inValid = true;
        }
    }

    public void commit() throws SQLException {
        if (this.lobProcessor.isUpdated()) {
            this.lobProcessor.setUpdated(false);
        }
    }

    public byte[] getLobLocator() {
        return lobProcessor.getLobLocator();
    }

    private boolean supportUpdateKnlLob() {
        if (!isTempLob && connection.getSession().getConnectVersion() == ConnectVersion.VER1) {
            return false;
        }
        return true;
    }
}
