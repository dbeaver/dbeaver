/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.YasConstants;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;

public class YasClobOutputStream extends OutputStream {
    private YasLargeObject largeObject = null;

    private long lobPos = 0L;

    private StringBuilder stringBuilder  = null;

    private boolean isClosed = false;

    private final Object lock = new Object();

    YasClobOutputStream(YasLargeObject largeObject, long lobPos) throws SQLException {
        this.largeObject = largeObject;
        this.lobPos = lobPos;

        int stepSize = largeObject.getStepSize();
        if (stepSize > 0) {
            stringBuilder = new StringBuilder(stepSize);
        } else {
            stringBuilder = new StringBuilder(YasConstants.LONG_BIND_SIZE);
        }
    }

    private void ensureOpen() throws IOException {
        if (isClosed) {
            throw new IOException("stream closed");
        }
    }

    @Override
    public void flush() throws IOException {
        synchronized (this.lock) {
            ensureOpen();

            if (stringBuilder.length() > 0) {
                try {
                    this.largeObject.writeString(this.largeObject.getLobLength() + 1, stringBuilder.toString());
                } catch (Exception exception) {
                    throw new IOException(exception.getMessage());
                }

                stringBuilder.delete(0, stringBuilder.length());
            }
        }
    }

    @Override
    public void write(int b) throws IOException {
        synchronized (this.lock) {
            ensureOpen();

            if (stringBuilder.length() >=  stringBuilder.capacity()) {
                this.flush();
            }

            this.stringBuilder.append((char) b);
        }
    }

    @Override
    public void close() throws IOException {
        synchronized (this.lock) {
            if (isClosed) {
                return;
            }

            this.flush();
            super.close();
            isClosed = true;
        }
    }
}
