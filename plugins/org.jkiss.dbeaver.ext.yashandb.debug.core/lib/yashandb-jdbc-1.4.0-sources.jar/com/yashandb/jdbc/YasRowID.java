/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.jdbc;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.util.ByteConverter;

import java.sql.RowId;
import java.sql.SQLException;

public class YasRowID implements RowId {

    private byte[] data;
    private String strValue;
    private static final int ROW_ID_LEN = 16;
    private static final int ROWID_MAX_SPACE = 2048;
    private static final int ROWID_MAX_FILEID = 64;
    private static final int ROWID_MAX_BLOCKID = 64 * 1024 * 1024;
    private static final int ROWID_MAX_DIR = 4096;

    private static final int ROWID_STRING_SEGMENT = 5;

    public YasRowID(byte[] bytes) throws SQLException {
        if (bytes.length != ROW_ID_LEN) {
            throw SQLError.createSQLException("rowid data size should be " + ROW_ID_LEN + " bytes",
                    YasState.DATA_ERROR);
        }

        data = new byte[ROW_ID_LEN];
        System.arraycopy(bytes, 0, data, 0, ROW_ID_LEN);
        convertDataToStr();
    }

    public YasRowID(String strValue) throws SQLException {
        if (strValue == null) {
            throw SQLError.createSQLException("The parameter can not be empty", YasState.INVALID_PARAMETER_VALUE);
        }

        this.strValue = strValue;
        this.data = new byte[ROW_ID_LEN];
        convertStrToData();
    }

    private void convertDataToStr() {
        long dataObjectId = ((data[7] & 0xFFL) << 56 | (data[6] & 0xFFL) << 48
                            | (data[5] & 0xFFL) << 40 | (data[4] & 0xFFL) << 32
                            | (data[3] & 0xFFL) << 24 | (data[2] & 0xFFL) << 16
                            | (data[1] & 0xFFL) << 8 | (data[0] & 0xFFL) );
        int file = (data[8] & 0x3F);
        int block = ((data[11] & 0xFF) << 18) | ((data[10] & 0xFF) << 10)
                | ((data[9] & 0xFF) << 2) | ((data[8] & 0xC0) >> 6);
        int dir = ((data[13] & 0xFF) << 8) | (data[12] & 0xFF);
        int space = ((data[15] & 0xFF) << 8) | ((data[14] & 0xFF));
        strValue = String.format("%d:%d:%d:%d:%d",dataObjectId, space, file, block, dir);
    }

    private void convertStrToData() throws SQLException {
        String[] split = strValue.split(":");
        if (split.length == ROWID_STRING_SEGMENT) {
            long dataObjectId;
            int space;
            int file;
            int block;
            int dir;
            try {
                dataObjectId = Long.valueOf(split[0]);
                space = Integer.valueOf(split[1]).intValue();
                file = Integer.valueOf(split[2]).intValue();
                block = Integer.valueOf(split[3]).intValue();
                dir = Integer.valueOf(split[4]).intValue();
            } catch (NumberFormatException e) {
                throw SQLError.createSQLException("invalid ROWID string", YasState.INVALID_PARAMETER_VALUE);
            }

            if (space >= ROWID_MAX_SPACE || file >= ROWID_MAX_FILEID || block >= ROWID_MAX_BLOCKID
                    || dir >= ROWID_MAX_DIR) {
                throw SQLError.createSQLException("invalid ROWID string", YasState.INVALID_PARAMETER_VALUE);
            }

            ByteConverter.int8(data, 0, dataObjectId);
            data[8] = (byte) (file | (block << 6));
            data[9] = (byte) (block >>> 2);
            data[10] = (byte) (block >>> 10);
            data[11] = (byte) (block >>> 18);
            ByteConverter.int2(data, 12, dir);
            ByteConverter.int2(data, 14, space);
            return;
        }

        throw SQLError.createSQLException("invalid ROWID string", YasState.INVALID_PARAMETER_VALUE);
    }

    @Override
    public byte[] getBytes() {
        return strValue.getBytes();
    }

    @Override
    public String toString() {
        return strValue;
    }

    public byte[] getRowIdBytes() {
        if (data == null) {
            return null;
        }
        byte[] resData = new byte[ROW_ID_LEN];
        System.arraycopy(this.data, 0, resData, 0, ROW_ID_LEN);
        return resData;
    }

}
