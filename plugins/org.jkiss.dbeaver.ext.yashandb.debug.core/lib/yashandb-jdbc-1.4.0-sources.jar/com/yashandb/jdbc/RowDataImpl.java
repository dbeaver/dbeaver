/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */
// Copyright (c) 2021, Open Cloud Limited.

package com.yashandb.jdbc;

import com.yashandb.Session;
import com.yashandb.SessionImpl;
import com.yashandb.YasResultSet;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.jdbc.exception.YasException;
import com.yashandb.protocol.ExecuteResult;
import com.yashandb.protocol.Packet;

import java.sql.SQLException;
import java.util.ArrayList;

public class RowDataImpl implements RowData {
    protected Session session;
    protected YasStatement stmt;
    protected Packet fromServer;
    protected long currRows;
    protected boolean hasMore;
    protected boolean hasRowID = false;

    protected long batchRows;
    protected int marginColumns;
    protected ArrayList<Row> rows;
    protected byte[][] marginRow;

    protected long fetchedRowCount = 0L;
    protected long maxRows = 0L;

    protected int arrayRowsSize = 0;
    protected boolean isReuse = false;

    public RowDataImpl(SessionImpl session, YasStatement stmt, Packet ack, ExecuteResult result) {
        this.session = session;
        this.stmt = stmt;
        this.fromServer = ack;
        this.batchRows = result.getBatchRows();
        this.marginColumns = result.getMarginColumns();
        this.hasMore = result.isHasMoreRows();
        this.currRows = -1;
        this.rows = new ArrayList<>();
        marginRow = null;

        fetchedRowCount = batchRows;
    }

    @Override
    public void addRow(Row row) throws SQLException {
        rows.add(row);
        arrayRowsSize++;
    }

    public void addRow(byte[][] rowData) throws SQLException {
        // If the currRows is reseted, it can be reuse
        synchronized (rows) {
            if (isReuse && rows.size() > arrayRowsSize) {
                //Reuse the Row Data Object
                rows.get(arrayRowsSize).set(rowData);
                arrayRowsSize++;
            } else {
                if (hasRowID) {
                    addRow(new UpdatableRow(rowData));
                } else {
                    addRow(new Row(rowData));
                }
            }
        }
    }

    @Override
    public void afterLast() throws SQLException {
        notSupported();
    }

    @Override
    public void beforeFirst() throws SQLException {
        notSupported();
    }

    @Override
    public void beforeLast() throws SQLException {
        notSupported();
    }

    @Override
    public void close() throws SQLException {
        this.session = null;
        this.stmt = null;
        this.fromServer = null;
    }

    @Override
    public Row getAt(long index) throws SQLException {
        if (index > Integer.MAX_VALUE) {
            throw SQLError.createSQLException("Not support resultsize greater than " + Integer.MAX_VALUE,
                    YasState.INVALID_PARAMETER_VALUE);
        }
        return rows.get((int)index);
    }

    @Override
    public long getFetchedRowCount() throws SQLException {
        return fetchedRowCount;
    }

    @Override

    public YasResultSet getOwner() {
        return null;
    }

    @Override
    public boolean hasNext() throws SQLException {
        if (currRows < batchRows) {
            return true;
        }

        if ((currRows == batchRows) && hasMore) {
            return true;
        }

        return false;
    }

    @Override
    public boolean isAfterLast() throws SQLException {
        return false;
    }

    @Override
    public boolean isBeforeFirst() throws SQLException {
        return false;
    }

    @Override
    public boolean isDynamic() throws SQLException {
        return true;
    }

    @Override
    public boolean isEmpty() throws SQLException {
        return this.isBeforeFirst() && this.isAfterLast();
    }

    @Override
    public boolean isFirst() throws SQLException {
        return false;
    }

    @Override
    public boolean isLast() throws SQLException {
        return false;
    }

    @Override
    public void moveRowRelative(long rows) throws SQLException {

    }

    @Override
    public void absolute(long index) throws SQLException {

    }

    @Override
    public Row next() throws SQLException {

        if (currRows + 1 < batchRows) {
            return getAt(++currRows);
        } else if (hasMore) {
            fetchMore();
            if (batchRows == 0) {
                return null;
            }
            return getAt(++currRows);
        }
        return null;
    }

    protected void fetchMore() throws SQLException {
        currRows = -1;
        arrayRowsSize = 0;
        isReuse = true;
        fetchMoreWithoutClear();
        isReuse = false;
    }

    protected void fetchMoreWithoutClear() throws SQLException {
        for (;;) {
            int lastMargin = marginColumns;
            Packet ack = session.fetch(stmt, stmt.getFetchSize());

            ExecuteResult result = new ExecuteResult(ack);
            batchRows = result.getBatchRows();
            marginColumns = result.getMarginColumns();
            hasMore = result.isHasMoreRows();
            session.setTransactionState(result.getXactStatus());
            fromServer = ack;
            if (lastMargin > 0) {
                if (batchRows == 0) {
                    fetchFromPacket(marginRow, ack, lastMargin, marginColumns);
                    continue;
                } else {
                    fetchFromPacket(marginRow, ack, lastMargin, stmt.getColumnCount());
                    addRow(marginRow);
                    marginRow = null;
                }
            }

            decodeRows(lastMargin > 0 ? 1 : 0);
            fetchedRowCount += batchRows;
            break;
        }
    }

    @Override
    public void removeRow(long index) throws SQLException {
        if ( index >= 0 && index < rows.size()) {
            synchronized (rows) {
                rows.remove((int)index);
                this.batchRows--;
                this.fetchedRowCount--;
                this.currRows--;
                this.arrayRowsSize--;
            }
        }
    }

    @Override
    public void setCurrentRow(long rowNumber) throws SQLException {
        notSupported();
    }

    @Override
    public void setOwner(ResultSetImpl rs) {

    }

    @Override
    public long size() throws SQLException {
        return RESULT_SET_SIZE_UNKNOWN;
    }

    @Override
    public void setMetadata(Field[] metadata) {
    }

    @Override
    public void decodeRows(int start) throws SQLException {
        for (int i = start; i < batchRows; i++) {
            byte[][] rowData = getReuseRowData();
            fetchFromPacket(rowData, fromServer, 0, stmt.getColumnCount());
            addRow(rowData);
        }

        if (marginColumns > 0) {
            byte[][] rowData = new byte[stmt.getColumnCount()][];
            fetchFromPacket(rowData, fromServer, 0, marginColumns);
            this.marginRow = rowData;
        }
    }

    private void notSupported() throws SQLException {
        throw new YasException("Operation not supported for streaming result sets", YasState.UNKNOWN_STATE);
    }

    private void fetchFromPacket(byte[][] row, Packet fetchFrom, int start, int end) {
        for (int i = start; i < end; i++) {
            int len = fetchFrom.getRowSize();
            if (len == 0) {
                row[i] = null;
                continue;
            }

            if ( isReuse && row[i] != null && row[i].length == len) {
                row[i] = fetchFrom.getBytes(len,row[i]);
            } else {
                row[i] = fetchFrom.getBytes(len);
            }
        }
    }

    @Override
    public long getPosition() {
        return this.currRows;
    }

    @Override
    public void setMaxRows(long maxRows) {
        this.maxRows = maxRows;
    }

    public void setHasRowID(boolean hasRowID) {
        this.hasRowID  = hasRowID;
    }

    @Override
    public void refreshRow(Row row,long index) {
        synchronized (rows) {
            rows.set((int)index, row);
        }
    }

    @Override
    public void cacheAllRows() throws SQLException {
        while (this.hasMore) {
            fetchMoreWithoutClear();
        }

        this.batchRows = this.fetchedRowCount;
    }

    //If the currRows is reset,then it can reuse the RowData Object
    public byte[][] getReuseRowData() {
        synchronized (rows) {
            if (isReuse && rows.size() > arrayRowsSize) {
                return rows.get(arrayRowsSize).get();
            } else {
                return new byte[stmt.getColumnCount()][];
            }
        }
    }
}
