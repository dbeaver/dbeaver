/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.log;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class LoggerFactory {

    static ILogFactory iLogFactory;
    static boolean hasSlf4jLog = false;
    static ConcurrentMap<String, Logger> loggerMap = new ConcurrentHashMap();

    // Check has slf4j
    // If the slf4j is not in class path ,then use JDK logger
    static {
        String msg = "";
        synchronized (LoggerFactory.class) {

            try {
                Class.forName("org.slf4j.LoggerFactory");
                hasSlf4jLog = true;
                iLogFactory = new SLF4JLoggerFactory();
            } catch (ClassNotFoundException e) {
                hasSlf4jLog = false;
                msg = "Can't find org.slf4j.LoggerFactory,use JDK Logger.";
            }

            if (iLogFactory == null) {
                iLogFactory = new JDKLoggerFactory();
            }
        }

        getLogger(LoggerFactory.class).debug("{} Logger type is {}.",msg,getLoggerType());
    }

    public static Logger getLogger(Class clazz) {
        if ( clazz == null) {
            return getLogger("");
        }
        return getLogger(clazz.getName());
    }

    public static Logger getLogger(String name) {
        Logger logger = loggerMap.get(name);
        if (logger == null) {
            logger = iLogFactory.getLogger(name);
            loggerMap.putIfAbsent(name,logger);
        }
        return logger;
    }

    public static String getLoggerType() {
        return iLogFactory.getLoggerType();
    }
}
