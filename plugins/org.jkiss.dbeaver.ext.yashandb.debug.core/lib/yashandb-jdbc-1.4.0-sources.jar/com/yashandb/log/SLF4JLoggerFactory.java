/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.log;

import org.slf4j.LoggerFactory;

public class SLF4JLoggerFactory implements ILogFactory {

    @Override
    public Logger getLogger(Class clazz) {
        return new SLF4JLoggerAdapter(LoggerFactory.getLogger(clazz.getName()));
    }

    @Override
    public Logger getLogger(String name) {
        return new SLF4JLoggerAdapter(LoggerFactory.getLogger(name));
    }

    @Override
    public String getLoggerType() {
        return "SLF4J Logger";
    }
}
