/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.log;

public class SLF4JLoggerAdapter implements Logger {
    org.slf4j.Logger logger;

    protected SLF4JLoggerAdapter(org.slf4j.Logger logger) {
        this.logger = logger;
    }

    @Override
    public String getName() {
        return logger.getName();
    }

    @Override
    public void trace(String msg) {
        logger.trace(msg);
    }

    @Override
    public void trace(String format, Object arg) {
        logger.trace(format,arg);
    }

    @Override
    public void trace(String format, Object... arguments) {
        logger.trace(format,arguments);
    }

    @Override
    public void trace(String msg, Throwable t) {
        logger.trace(msg,t);
    }

    @Override
    public void debug(String msg) {
        logger.debug(msg);
    }

    @Override
    public void debug(String format, Object arg) {
        logger.debug(format,arg);
    }

    @Override
    public void debug(String format, Object... arguments) {
        logger.debug(format,arguments);
    }

    @Override
    public void debug(String msg, Throwable t) {
        logger.debug(msg,t);
    }

    @Override
    public void info(String msg) {
        logger.info(msg);
    }

    @Override
    public void info(String format, Object arg) {
        logger.info(format,arg);
    }

    @Override
    public void info(String format, Object... arguments) {
        logger.info(format,arguments);
    }

    @Override
    public void info(String msg, Throwable t) {
        logger.info(msg,t);
    }

    @Override
    public void warn(String msg) {
        logger.warn(msg);
    }

    @Override
    public void warn(String format, Object arg) {
        logger.warn(format,arg);
    }

    @Override
    public void warn(String format, Object... arguments) {
        logger.warn(format,arguments);
    }

    @Override
    public void warn(String msg, Throwable t) {
        logger.warn(msg,t);
    }

    @Override
    public void error(String msg) {
        logger.error(msg);
    }

    @Override
    public void error(String format, Object arg) {
        logger.error(format,arg);
    }

    @Override
    public void error(String format, Object... arguments) {
        logger.error(format,arguments);
    }

    @Override
    public void error(String msg, Throwable t) {
        logger.error(msg,t);
    }

    @Override
    public boolean isDebugEnabled() {
        return logger.isDebugEnabled();
    }

    @Override
    public boolean isErrorEnabled() {
        return logger.isErrorEnabled();
    }

    @Override
    public boolean isInfoEnabled() {
        return logger.isInfoEnabled();
    }

    @Override
    public boolean isTraceEnabled() {
        return logger.isTraceEnabled();
    }

    @Override
    public boolean isWarnEnabled() {
        return logger.isWarnEnabled();
    }
}
