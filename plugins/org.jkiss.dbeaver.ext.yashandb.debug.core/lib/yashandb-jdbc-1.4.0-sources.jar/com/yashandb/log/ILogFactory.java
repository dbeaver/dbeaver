/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.log;

public interface ILogFactory {
    Logger getLogger(Class clazz);

    Logger getLogger(String name);

    String getLoggerType();
}
