/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.log;

public class JDKLoggerFactory implements ILogFactory {

    @Override
    public Logger getLogger(Class clazz) {
        java.util.logging.Logger logger = java.util.logging.Logger.getLogger(clazz.getName());
        logger.setUseParentHandlers(true);
        return new JDKLoggerAdapter(logger);
    }

    @Override
    public Logger getLogger(String name) {
        java.util.logging.Logger logger = java.util.logging.Logger.getLogger(name);
        logger.setUseParentHandlers(true);
        return new JDKLoggerAdapter(logger);
    }

    @Override
    public String getLoggerType() {
        return "JDK Logger";
    }
}
