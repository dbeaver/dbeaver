/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.log;

import java.util.logging.Level;

public class JDKLoggerAdapter implements Logger {
    java.util.logging.Logger logger;

    protected JDKLoggerAdapter(java.util.logging.Logger logger) {
        this.logger = logger;

    }

    @Override
    public String getName() {
        return logger.getName();
    }

    @Override
    public void trace(String msg) {
        logger.log(Level.FINEST, msg);
    }

    @Override
    public void trace(String format, Object arg) {
        logger.log(Level.FINEST,LoggerHelper.format(format,arg));
    }

    @Override
    public void trace(String format, Object... arguments) {
        logger.log(Level.FINEST,LoggerHelper.arrayFormat(format,arguments));
    }

    @Override
    public void trace(String msg, Throwable t) {
        logger.log(Level.FINEST, msg,t);
    }

    @Override
    public void debug(String msg) {
        logger.log(Level.FINE, msg);
    }

    @Override
    public void debug(String format, Object arg) {
        logger.log(Level.FINE, LoggerHelper.format(format,arg));
    }

    @Override
    public void debug(String format, Object... arguments) {
        logger.log(Level.FINE, LoggerHelper.arrayFormat(format,arguments));
    }

    @Override
    public void debug(String msg, Throwable t) {
        logger.log(Level.FINE, msg,t);
    }

    @Override
    public void info(String msg) {
        logger.log(Level.INFO, msg);
    }

    @Override
    public void info(String format, Object arg) {
        logger.log(Level.INFO, LoggerHelper.format(format,arg));
    }

    @Override
    public void info(String format, Object... arguments) {
        logger.log(Level.INFO, LoggerHelper.arrayFormat(format,arguments));
    }

    @Override
    public void info(String msg, Throwable t) {
        logger.log(Level.INFO, msg,t);
    }

    @Override
    public void warn(String msg) {
        logger.log(Level.WARNING, msg);
    }

    @Override
    public void warn(String format, Object arg) {
        logger.log(Level.WARNING, LoggerHelper.format(format,arg));
    }

    @Override
    public void warn(String format, Object... arguments) {
        logger.log(Level.WARNING, LoggerHelper.arrayFormat(format,arguments));
    }

    @Override
    public void warn(String msg, Throwable t) {
        logger.log(Level.WARNING, msg,t);
    }

    @Override
    public void error(String msg) {
        logger.log(Level.SEVERE, msg);
    }

    @Override
    public void error(String format, Object arg) {
        logger.log(Level.SEVERE, LoggerHelper.format(format,arg));
    }

    @Override
    public void error(String format, Object... arguments) {
        logger.log(Level.SEVERE, LoggerHelper.arrayFormat(format,arguments));
    }

    @Override
    public void error(String msg, Throwable t) {
        logger.log(Level.SEVERE, msg, t);
    }

    @Override
    public boolean isDebugEnabled() {
        return this.logger.isLoggable(Level.FINE);
    }

    @Override
    public boolean isErrorEnabled() {
        return this.logger.isLoggable(Level.SEVERE);
    }

    @Override
    public boolean isInfoEnabled() {
        return this.logger.isLoggable(Level.INFO);
    }

    @Override
    public boolean isTraceEnabled() {
        return this.logger.isLoggable(Level.FINEST);
    }

    @Override
    public boolean isWarnEnabled() {
        return this.logger.isLoggable(Level.WARNING);
    }
}
