/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

import com.yashandb.YasConstants;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.nio.CharBuffer;
import java.sql.SQLException;

/**
 * Helper methods to parse java base types from byte arrays.
 */
public class ByteConverter {

    private static final int NBASE = 10000;
    private static final int NUMERIC_DSCALE_MASK = 0x00003FFF;
    private static final int SIGN_MASK = 0x01;
    private static final int EXP_SIGN_MASK = 0x02;
    private static final short NUMERIC_POS = 0x0000;
    private static final short NUMERIC_NEG = 0x4000;
    private static final short NUMERIC_NAN = (short) 0xC000;
    private static final int DEC_DIGITS = 4;
    private static final int[] round_powers = {0, 1000, 100, 10};
    private static final int SHORT_BYTES = 2;

    private static final int SCALE_MIN = -131;
    private static final int SCALE_MAX = 124;

    private ByteConverter() {
        // prevent instantiation of static helper class
    }

    /**
     * Convert a number from binary representation to text representation.
     *
     * @param idx         index of the digit to be converted in the digits array
     * @param digits      array of shorts that can be decoded as the number String
     * @param buffer      the character buffer to put the text representation in
     * @param alwaysPutIt a flag that indicate whether or not to put the digit char even if it is
     *                    zero
     */
    private static void digitToString(int idx, short[] digits, CharBuffer buffer,
                                      boolean alwaysPutIt) {
        short dig = (idx >= 0 && idx < digits.length) ? digits[idx] : 0;
        for (int p = 1; p < round_powers.length; p++) {
            int pow = round_powers[p];
            short d1 = (short) (dig / pow);
            dig -= d1 * pow;
            boolean putit = (d1 > 0);
            if (putit || alwaysPutIt) {
                buffer.put((char) (d1 + '0'));
            }
        }

        buffer.put((char) (dig + '0'));
    }

    /**
     * Convert a number from binary representation to text representation.
     *
     * @param digits array of shorts that can be decoded as the number String
     * @param scale  the scale of the number binary representation
     * @param weight the weight of the number binary representation
     * @param sign   the sign of the number
     * @return String the number as String
     */
    private static String numberBytesToString(short[] digits, int scale, int weight, int sign) {
        CharBuffer buffer;
        int i;
        int d;

        /*
         * Allocate space for the result.
         *
         * i is set to the # of decimal digits before decimal point. dscale is the
         * # of decimal digits we will print after decimal point. We may generate
         * as many as DEC_DIGITS-1 excess digits at the end, and in addition we
         * need room for sign, decimal point, null terminator.
         */
        i = (weight + 1) * DEC_DIGITS;
        if (i <= 0) {
            i = 1;
        }

        buffer = CharBuffer.allocate((i + scale + DEC_DIGITS + 2));

        /*
         * Output a dash for negative values
         */
        if (sign == NUMERIC_NEG) {
            buffer.put('-');
        }

        /*
         * Output all digits before the decimal point
         */
        if (weight < 0) {
            d = weight + 1;
            buffer.put('0');
        } else {
            for (d = 0; d <= weight; d++) {
                /* In the first digit, suppress extra leading decimal zeroes */
                digitToString(d, digits, buffer, d != 0);
            }
        }

        /*
         * If requested, output a decimal point and all the digits that follow it.
         * We initially put out a multiple of DEC_DIGITS digits, then truncate if
         * needed.
         */
        if (scale > 0) {
            buffer.put('.');
            for (i = 0; i < scale; d++, i += DEC_DIGITS) {
                digitToString(d, digits, buffer, true);
            }
        }

        /*
         * terminate the string and return it
         */
        int extra = (i - scale) % DEC_DIGITS;
        return new String(buffer.array(), 0, buffer.position() - extra);
    }

    /**
     * Convert a variable length array of bytes to an integer
     *
     * @param bytes array of bytes that can be decoded as an integer
     * @return integer
     */
    public static Number numeric(byte[] bytes) {
        return numeric(bytes, 0, bytes.length);
    }

    /**
     * Convert a variable length array of bytes to an integer
     *
     * @param bytes    array of bytes that can be decoded as an integer
     * @param pos      index of the start position of the bytes array for number
     * @param numBytes number of bytes to use, length is already encoded in the binary format but this
     *                 is used for double checking
     * @return integer
     */
    public static Number numeric(byte[] bytes, int pos, int numBytes) {
        if (numBytes < 8) {
            throw new IllegalArgumentException("number of bytes should be at-least 8");
        }

        short len = ByteConverter.int2(bytes, pos);
        short weight = ByteConverter.int2(bytes, pos + 2);
        short sign = ByteConverter.int2(bytes, pos + 4);
        short scale = ByteConverter.int2(bytes, pos + 6);

        if (numBytes != (len * SHORT_BYTES + 8)) {
            throw new IllegalArgumentException("invalid length of bytes \"numeric\" value");
        }

        if (!(sign == NUMERIC_POS
                || sign == NUMERIC_NEG
                || sign == NUMERIC_NAN)) {
            throw new IllegalArgumentException("invalid sign in \"numeric\" value");
        }

        if (sign == NUMERIC_NAN) {
            return Double.NaN;
        }

        if ((scale & NUMERIC_DSCALE_MASK) != scale) {
            throw new IllegalArgumentException("invalid scale in \"numeric\" value");
        }

        short[] digits = new short[len];
        int idx = pos + 8;
        for (int i = 0; i < len; i++) {
            short d = ByteConverter.int2(bytes, idx);
            idx += 2;

            if (d < 0 || d >= NBASE) {
                throw new IllegalArgumentException("invalid digit in \"numeric\" value");
            }

            digits[i] = d;
        }

        String numString = numberBytesToString(digits, scale, weight, sign);
        return new BigDecimal(numString);
    }

    /**
     * Parses a long value from the byte array.
     *
     * @param bytes The byte array to parse.
     * @param idx   The starting index of the parse in the byte array.
     * @return parsed long value.
     */
    public static long int8(byte[] bytes, int idx) {
        return
            ((long) (bytes[idx] & 255))
                + ((long) (bytes[idx + 1] & 255) << 8)
                + ((long) (bytes[idx + 2] & 255) << 16)
                + ((long) (bytes[idx + 3] & 255) << 24)
                + ((long) (bytes[idx + 4] & 255) << 32)
                + ((long) (bytes[idx + 5] & 255) << 40)
                + ((long) (bytes[idx + 6] & 255) << 48)
                + ((long) (bytes[idx + 7] & 255) << 56);
    }

    /**
     * Parses an int value from the byte array.
     *
     * @param bytes The byte array to parse.
     * @param idx   The starting index of the parse in the byte array.
     * @return parsed int value.
     */
    public static int int4(byte[] bytes, int idx) {
        return
                ((bytes[idx] & 255))
                        + ((bytes[idx + 1] & 255) << 8)
                        + ((bytes[idx + 2] & 255) << 16)
                        + ((bytes[idx + 3] & 255) << 24);
    }

    /**
     * Parses a short value from the byte array.
     *
     * @param bytes The byte array to parse.
     * @param idx   The starting index of the parse in the byte array.
     * @return parsed short value.
     */
    public static short int2(byte[] bytes, int idx) {
        return (short) (((bytes[idx] & 255)) + ((bytes[idx + 1] & 255) << 8));
    }

    /**
     * Parses a float value from the byte array.
     *
     * @param bytes The byte array to parse.
     * @param idx   The starting index of the parse in the byte array.
     * @return parsed float value.
     */
    public static float float4(byte[] bytes, int idx) {
        return Float.intBitsToFloat(int4(bytes, idx));
    }

    /**
     * Parses a double value from the byte array.
     *
     * @param bytes The byte array to parse.
     * @param idx   The starting index of the parse in the byte array.
     * @return parsed double value.
     */
    public static double float8(byte[] bytes, int idx) {
        return Double.longBitsToDouble(int8(bytes, idx));
    }

    /**
     * Parses a BigDecimal value from the byte array.
     *
     * @param bytes The byte array to parse.
     * @param idx   The starting index of the parse in the byte array.
     * @return parsed BigDecimal value.
     */
    public static BigDecimal toBigDecimal(byte[] bytes, int idx) {
        int dataLen = bytes.length - idx;
        if (dataLen <= 2) {
            if (dataLen == 1) {
                int value = (bytes[idx] & 0xFF);
                return new BigDecimal(value);
            } else {
                int value = (ByteConverter.int2(bytes, idx) & 0xFFFF);
                return new BigDecimal(value);
            }
        }

        int numFlag = bytes[idx] & SIGN_MASK;
        int expFlag = bytes[idx] & EXP_SIGN_MASK;
        int expNumber = bytes[idx + 1] & 0xFF;
        if (expFlag == 2) {
            expNumber = -expNumber;
        }
        int signNumber = (numFlag == 1) ? -1 : 1;
        byte[] bigEndianData = getBigEndianBytes(bytes, idx + 2);
        BigInteger precision = new BigInteger(signNumber, bigEndianData);

        return new BigDecimal(precision, -expNumber);
    }

    public static long bitBytesToLong(byte[] bytes) {
        int len = bytes.length;
        if (len == 0) {
            return 0;
        }

        long value = 0;
        for (int i = 0; i < len; i++) {
            value |= ((long)(bytes[i] & 255) << (8 * i));
        }

        return value;
    }

    public static String bitBytesToString(byte[] bytes) {
        int len = bytes.length;
        if (len == 0) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        boolean oneFlag = false;
        int bit = 0;
        for (int i = len - 1; i >= 0; i--) {
            for ( int j = 7;j >= 0 ;j--) {
                bit = bytes[i] >> j & 0x1;
                if (bit == 1) {
                    oneFlag = true;
                    sb.append("1");
                } else if (oneFlag) {
                    sb.append("0");
                }
            }
        }

        String bitStr = sb.toString();
        if (bitStr.isEmpty()) {
            return "0";
        }

        return bitStr;
    }

    private static byte[] getBigEndianBytes(byte[] data, int index) {
        int bytesCnt = 0;
        byte[] precisionData = new byte[data.length - index];
        for (int i = data.length - 1; i >= index; i--) {
            precisionData[bytesCnt++] = data[i];
        }

        return precisionData;
    }

    /**
     * Encodes a long value to the byte array.
     *
     * @param target The byte array to encode to.
     * @param idx    The starting index in the byte array.
     * @param value  The value to encode.
     */
    public static void int8(byte[] target, int idx, long value) {
        target[idx] = (byte) value;
        target[idx + 1] = (byte) (value >>> 8);
        target[idx + 2] = (byte) (value >>> 16);
        target[idx + 3] = (byte) (value >>> 24);
        target[idx + 4] = (byte) (value >>> 32);
        target[idx + 5] = (byte) (value >>> 40);
        target[idx + 6] = (byte) (value >>> 48);
        target[idx + 7] = (byte) (value >>> 56);
    }

    /**
     * Encodes a int value to the byte array.
     *
     * @param target The byte array to encode to.
     * @param idx    The starting index in the byte array.
     * @param value  The value to encode.
     */
    public static void int4(byte[] target, int idx, int value) {
        target[idx] = (byte) value;
        target[idx + 1] = (byte) (value >>> 8);
        target[idx + 2] = (byte) (value >>> 16);
        target[idx + 3] = (byte) (value >>> 24);
    }

    /**
     * Encodes a int value to the byte array.
     *
     * @param target The byte array to encode to.
     * @param idx    The starting index in the byte array.
     * @param value  The value to encode.
     */
    public static void int2(byte[] target, int idx, int value) {
        target[idx] = (byte) value;
        target[idx + 1] = (byte) (value >>> 8);
    }

    /**
     * Encodes a boolean value to the byte array.
     *
     * @param target The byte array to encode to.
     * @param idx    The starting index in the byte array.
     * @param value  The value to encode.
     */
    public static void bool(byte[] target, int idx, boolean value) {
        target[idx] = value ? (byte) 1 : (byte) 0;
    }

    /**
     * Encodes a int value to the byte array.
     *
     * @param target The byte array to encode to.
     * @param idx    The starting index in the byte array.
     * @param value  The value to encode.
     */
    public static void float4(byte[] target, int idx, float value) {
        int4(target, idx, Float.floatToRawIntBits(value));
    }

    /**
     * Encodes a int value to the byte array.
     *
     * @param target The byte array to encode to.
     * @param idx    The starting index in the byte array.
     * @param value  The value to encode.
     */
    public static void float8(byte[] target, int idx, double value) {
        int8(target, idx, Double.doubleToRawLongBits(value));
    }

    /**
     * Adjust a BigDecimal if the precision larger than 38.
     *
     * @param bigDecimal  The value to adjust.
     */
    public static BigDecimal adjustNumber(BigDecimal bigDecimal) {

        if (bigDecimal.precision() <= YasConstants.MAX_NUM_PRECISION) {
            return bigDecimal;
        }

        int scale = bigDecimal.scale();
        int adjustScale = scale - (bigDecimal.precision() - YasConstants.MAX_NUM_PRECISION);

        bigDecimal = new BigDecimal(bigDecimal.toPlainString());
        bigDecimal = bigDecimal.setScale(adjustScale, RoundingMode.HALF_UP);

        return bigDecimal;
    }

    /**
     * Encodes a BigDecimal value to the byte array.
     *
     * @param target The byte array to encode to.
     * @param idx    The starting index in the byte array.
     * @param bigDecimal  The value to encode.
     */
    public static int bigDecimalToBytes(byte[] target, int idx, BigDecimal bigDecimal) throws SQLException {
        int scale = -bigDecimal.scale();
        int signum = bigDecimal.signum();
        byte[] data = null;
        if (signum < 0) {
            data = bigDecimal.negate().unscaledValue().toByteArray();
        } else {
            data = bigDecimal.unscaledValue().toByteArray();
        }

        byte signFlag = 0;
        if (signum < 0) {
            signFlag |= SIGN_MASK;
        }
        if (scale > SCALE_MAX || scale < SCALE_MIN) {
            throw SQLError.createSQLException("Overflow Exception trying to bind " + bigDecimal,
                    YasState.NUMERIC_CONSTANT_OUT_OF_RANGE);
        }
        if (scale < 0) {
            signFlag |= EXP_SIGN_MASK;
            scale = -scale;
        }
        target[idx++] = signFlag;
        target[idx++] = (byte) scale;
        for (int i = data.length - 1; i >= 0; i--) {
            target[idx++] = data[i];
        }
        return data.length + 2 ;
    }

    public static String byteToString(byte[] bytes, int start, int length, short charset) {
        return new String(bytes, start, length, CharacterSet.getCharSet(charset));
    }
}
