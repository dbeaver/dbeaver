/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

import com.yashandb.DownHostsCache;
import com.yashandb.SessionImpl;
import com.yashandb.YasConstants;
import com.yashandb.conf.HostSpec;
import com.yashandb.conf.YasProperty;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;

import java.sql.SQLException;
import java.util.Properties;

import javax.net.SocketFactory;

public class HaPrimaryConnector extends HostConnector {
    private static final Logger LOGGER = LoggerFactory.getLogger(HaPrimaryConnector.class.getName());

    private HostSpec[] hostSpecs;

    private int hostIndex = 0;

    public HaPrimaryConnector(SessionImpl session, HostSpec[] hostSpecs) {
        super(session);
        this.hostSpecs = hostSpecs;
    }

    private HostSpec nextHost() {
        if (hostIndex >= hostSpecs.length) {
            return hostSpecs[hostSpecs.length - 1];
        }
        return hostSpecs[hostIndex++];
    }

    private boolean hasNextHost() {
        return (hostIndex < hostSpecs.length);
    }

    private void resetHostSpecs() {
        if (hostSpecs.length > 1) {
            DownHostsCache.getInstance().reorderHosts(hostSpecs);
        }
        hostIndex = 0;
    }

    private boolean isPrimaryHost() throws SQLException {
        this.session.setProtocol(protocol);
        this.session.setYasSocketConnection(this.yasSocketConnection);

        return this.session.isPrimaryHost();
    }

    @Override
    public void connect(String user, Properties info) throws SQLException {
        SocketFactory socketFactory = SocketFactory.getDefault();
        resetHostSpecs();

        long startTime = System.currentTimeMillis();
        long currentTime = startTime;
        long poolTimeout = Utils.toMillisecond(YasProperty.POOL_TIMEOUT.getInt(info));

        while (true) {
            HostSpec hostSpec = nextHost();
            LOGGER.debug("Trying to establish a connection to {}", hostSpec);
            try {
                yasSocketConnection = tryConnect(user, info, socketFactory, hostSpec);
                if (isPrimaryHost()) {
                    break;
                }
                closeStream(yasSocketConnection);
            } catch (Exception e) {
                currentTime = System.currentTimeMillis();
                DownHostsCache.getInstance().markDownHost(hostSpec);
                LOGGER.warn("Connect Failed,then mark this hostSpec {}, Exception: {},spend time: {} ",
                        hostSpec, e.getMessage(), currentTime - startTime);

                if ((!hasNextHost()) && ((currentTime - startTime) > poolTimeout)) {
                    String errMsg = Messages.get("Connect Failed, spend time: {0} ms", currentTime - startTime);
                    LOGGER.error(errMsg);

                    closeStream(yasSocketConnection);
                    throw SQLError.createSQLException(Messages.get("The connection attempt failed."),
                            YasState.CONNECTION_UNABLE_TO_CONNECT, e);
                }
            }

            if (!hasNextHost()) {
                if ((currentTime - startTime) > poolTimeout) {
                    String errMsg = Messages.get("Connect Failed, spend time: {0} ms", currentTime - startTime);
                    LOGGER.error(errMsg);
                    throw SQLError.createSQLException(errMsg, YasState.CONNECTION_UNABLE_TO_CONNECT);
                }
                resetHostSpecs();

                try {
                    Thread.sleep(Utils.toMillisecond(YasConstants.ROUND_WAIT_TIME));
                } catch (InterruptedException ignored) {
                }
            }
            currentTime = System.currentTimeMillis();
        }

        this.session.setProtocol(protocol);
        this.session.setYasSocketConnection(yasSocketConnection);
    }
}
