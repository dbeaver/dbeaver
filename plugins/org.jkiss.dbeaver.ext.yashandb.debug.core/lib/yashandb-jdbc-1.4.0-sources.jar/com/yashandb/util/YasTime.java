/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

import java.sql.Time;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

/**
 * This class augments the Java built-in Time to allow for explicit setting of the time zone.
 */
public class YasTime extends Time {

    /**
     * The serial version UID.
     */
    private static final long serialVersionUID = 3592492258676494276L;

    /**
     * The optional calendar for this time.
     */
    private Calendar calendar;
    private int nanos;

    public YasTime(long time) {
        this(time, null);
    }

    public YasTime(long time, Calendar calendar) {
        super((time / 1000) * 1000);
        this.setCalendar(calendar);
        nanos = (int)((time % 1000) * 1000000);
        if (nanos < 0) {
            nanos = 1000000000 + nanos;
            super.setTime(((time / 1000) - 1) * 1000);
        }
    }

    /**
     * Sets this <code>Time</code> object to represent a point in time that is
     * <tt>time</tt> milliseconds
     */
    public void setTime(long time) {
        super.setTime((time / 1000) * 1000);
        nanos = (int)((time % 1000) * 1000000);
        if (nanos < 0) {
            nanos = 1000000000 + nanos;
            super.setTime(((time / 1000) - 1) * 1000);
        }
    }

    /**
     * Returns the number of milliseconds
     * represented by this <code>Time</code> object.
     * @see #setTime
     */
    public long getTime() {
        long time = super.getTime();
        return (time + (nanos / 1000000));
    }

    /**
     * Sets the calendar object for this time.
     *
     * @param calendar the calendar object or <code>null</code>.
     */
    public void setCalendar(Calendar calendar) {
        this.calendar = calendar;
    }

    /**
     * Returns the calendar object for this time.
     *
     * @return the calendar or <code>null</code>.
     */
    public Calendar getCalendar() {
        return calendar;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((calendar == null) ? 0 : calendar.hashCode());
        return result;
    }

    public boolean equals(YasTime at) {
        if (this.getHours() == at.getHours() && this.getMinutes() == this.getMinutes()
                && this.getSeconds() == at.getSeconds() && nanos == at.nanos) {
            return  true;
        } else {
            return false;
        }
    }

    /**
     * Tests to see if this <code>YasTime</code> object is
     * equal to the given object.
     * This version of the method <code>equals</code> has been added
     * to fix the incorrect
     * signature of <code>YasTime.equals(YasTime)</code> and to preserve backward
     * compatibility with existing class files.
     * Note: This method is not symmetric with respect to the
     * <code>equals(Object)</code> method in the base class.
     *
     * @param obj the <code>Object</code> value to compare with
     * @return <code>true</code> if the given <code>Object</code> is an instance
     *         of a <code>YasTime</code> that
     *         is equal to this <code>YasTime</code> object;
     *         <code>false</code> otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof YasTime)) {
            return false;
        }
        return this.equals((YasTime) obj);
    }

    @Override
    public Object clone() {
        YasTime clone = (YasTime) super.clone();
        if (getCalendar() != null) {
            clone.setCalendar((Calendar) getCalendar().clone());
        }
        return clone;
    }

    @Override
    public String toString() {
        int hour = super.getHours();
        int minute = super.getMinutes();
        int second = super.getSeconds();
        String hourString;
        String minuteString;
        String secondString;
        String nanosString;
        String zeros = "000000000";
        StringBuffer timestampBuf;

        if (hour < 10) {
            hourString = "0" + hour;
        } else {
            hourString = Integer.toString(hour);
        }
        if (minute < 10) {
            minuteString = "0" + minute;
        } else {
            minuteString = Integer.toString(minute);
        }
        if (second < 10) {
            secondString = "0" + second;
        } else {
            secondString = Integer.toString(second);
        }
        if (nanos == 0) {
            nanosString = "000000";
        } else {
            nanosString = Integer.toString(nanos);

            // Add leading zeros
            nanosString = zeros.substring(0, (9 - nanosString.length())) + nanosString;
            nanosString = nanosString.substring(0,6);
        }

        // do a string buffer here instead.
        timestampBuf = new StringBuffer(20 + nanosString.length());
        timestampBuf.append(hourString);
        timestampBuf.append(":");
        timestampBuf.append(minuteString);
        timestampBuf.append(":");
        timestampBuf.append(secondString);
        timestampBuf.append(".");
        timestampBuf.append(nanosString);

        return (timestampBuf.toString());
    }

    /**
     * Gets this <code>YasTime</code> object's <code>nanos</code> value.
     *
     * @return this <code>YasTime</code> object's fractional seconds component
     * @see #setNanos
     */
    public int getNanos() {
        return nanos;
    }

    /**
     * Sets this <code>YasTime</code> object's <code>nanos</code> field
     * to the given value.
     *
     * @param n the new fractional seconds component
     * @exception java.lang.IllegalArgumentException if the given argument
     *            is greater than 999999999 or less than 0
     * @see #getNanos
     */
    public void setNanos(int n) {
        if (n > 999999999 || n < 0) {
            throw new IllegalArgumentException("nanos > 999999999 or < 0");
        }
        nanos = n;
    }

    public static YasTime valueOf(LocalTime time) {
        Calendar useCal = Calendar.getInstance();
        useCal.set(Calendar.HOUR_OF_DAY, time.getHour());
        useCal.set(Calendar.MINUTE, time.getMinute());
        useCal.set(Calendar.SECOND, time.getSecond());

        long nanos = time.toNanoOfDay();
        YasTime at = new YasTime(useCal.getTimeInMillis());
        at.setNanos((int)(nanos % 1000000000));
        return at;
    }

    /**
     * Converts a string in JDBC time escape format to a <code>Time</code> value.
     *
     * @param   times in format "hh:mm:ss.[fffffffff]"
     * @return a corresponding <code>Time</code> object
     */
    public static Time valueOf(String times) {
        return valueOf(LocalTime.parse(times, DateTimeFormatter.ISO_LOCAL_TIME));
    }

    public LocalTime toLocalTime() {
        return LocalTime.of(this.getHours(),this.getMinutes(),this.getSeconds(),this.getNanos());
    }
}
