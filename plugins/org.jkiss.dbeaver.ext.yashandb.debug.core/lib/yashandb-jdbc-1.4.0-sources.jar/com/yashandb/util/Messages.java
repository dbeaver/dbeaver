/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * This class provides a wrapper around a gettext message catalog that can provide a localized
 * version of error messages. The caller provides a message String in the standard
 * java.text.MessageFormat syntax and any arguments it may need. The returned String is the
 * localized version if available or the original if not.
 */
public class Messages {

    private static final Messages message = new Messages();
    private static final Object[] noargs = new Object[0];

    public static String get(String message, Object... args) {
        return Messages.message.translate(message, args);
    }

    private ResourceBundle bundle;

    private Messages() {
        try {
            bundle = ResourceBundle.getBundle("com.yashandb.translation.messages",
                    Locale.getDefault(Locale.Category.DISPLAY));
        } catch (MissingResourceException mre) {
            // translation files have not been installed
            bundle = null;
        }
    }

    private String translate(String message, Object[] args) {
        if (bundle != null && message != null) {
            try {
                message = bundle.getString(message);
            } catch (MissingResourceException mre) {
                // If we can't find a translation, just
                // use the untranslated message.
            }
        }

        // If we don't have any parameters we still need to run
        // this through the MessageFormat(ter) to allow the same
        // quoting and escaping rules to be used for all messages.
        //
        if (args == null) {
            args = noargs;
        }

        // Replace placeholders with arguments
        //
        if (message != null) {
            message = MessageFormat.format(message, args);
        }

        return message;
    }
}
