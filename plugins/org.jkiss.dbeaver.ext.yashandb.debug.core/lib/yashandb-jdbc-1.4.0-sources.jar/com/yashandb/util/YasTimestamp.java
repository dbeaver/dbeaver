/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

import java.sql.Timestamp;
import java.util.Calendar;

/**
 * This class augments the Java built-in Timestamp to allow for explicit setting of the time zone.
 */
public class YasTimestamp extends Timestamp {

    /**
     * The serial version UID.
     */
    private static final long serialVersionUID = -6245623465210738466L;

    /**
     * The optional calendar for this timestamp.
     */
    private Calendar calendar;

    public YasTimestamp(long time) {
        this(time, null);
    }

    public YasTimestamp(long time, Calendar calendar) {
        super(time);
        this.setCalendar(calendar);
    }

    /**
     * Sets the calendar object for this timestamp.
     *
     * @param calendar the calendar object or <code>null</code>.
     */
    public void setCalendar(Calendar calendar) {
        this.calendar = calendar;
    }

    /**
     * Returns the calendar object for this timestamp.
     *
     * @return the calendar object or <code>null</code>.
     */
    public Calendar getCalendar() {
        return calendar;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((calendar == null) ? 0 : calendar.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!super.equals(obj)) {
            return false;
        }
        if (!(obj instanceof YasTimestamp)) {
            return false;
        }
        YasTimestamp other = (YasTimestamp) obj;
        if (calendar == null) {
            if (other.calendar != null) {
                return false;
            }
        } else if (!calendar.equals(other.calendar)) {
            return false;
        }
        return true;
    }

    @Override
    public Object clone() {
        YasTimestamp clone = (YasTimestamp) super.clone();
        if (getCalendar() != null) {
            clone.setCalendar((Calendar) getCalendar().clone());
        }
        return clone;
    }
}
