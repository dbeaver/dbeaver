/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

import com.yashandb.core.SqlKind;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/*
    YasSQL will analyze the sql for SCROLLABLE SENSITIVE and UPDATABLE
    And add ROWID for the query
 */
public class YasSQL {

    // Constant
    public static final String ROWID_ALIAS = "__Yas_JDBC_internal_ROWID__";
    static final String KEY_SELECT = "SELECT";
    static final String KEY_WITH = "WITH";
    static final String KEY_FROM = "FROM";
    static final String KEY_GROUP = "GROUP";
    static final String KEY_JOIN = "JOIN";
    static final String KEY_WHERE = "WHERE";
    static final String KEY_ORDER = "ORDER";
    static final String KEY_BEGIN = "BEGIN";
    static final String KEY_CALL = "CALL";
    static final String KEY_DELETE = "DELETE";
    static final String KEY_DECLARE = "DECLARE";
    static final String KEY_INSERT = "INSERT";
    static final String KEY_UPDATE = "UPDATE";
    static final String KEY_MERGE = "MERGE";
    //String KEY_FOR_UPDATE = "FOR UPDATE";
    static final String KEY_ALTER = "ALTER";
    static final String KEY_RETURNIN = "RETURNING";
    static final String KEY_INTO = "INTO";
    static final String KEY_DISTINCT = "DISTINCT";
    static final String KEY_LIMIT = "LIMIT";
    static final String KEY_TRUNCATE = "TRUNCATE";
    static final String KEY_SESSION = "SESSION";
    static final String KEY_CREATE = "CREATE";
    static final String KEY_DROP = "DROP";
    static final String KEY_BY = "BY";

    String originlSql;
    String rowIDSql = null;
    String updateSql = null;
    String insertSql = null;
    String deleteSql = null;
    String refreshSql = null;
    String tableName = null;

    static final int UNDEF = -1;
    int selectEndIndex = UNDEF;
    int fromStartIndex = UNDEF;
    int fromEndIndex = UNDEF;
    int whereStartIndex = UNDEF;
    int orderByStartIndex = UNDEF;
    boolean hasRowID = false;
    boolean canRowID = false;
    boolean isSingleTable = true;
    //boolean isInWith = false;
    boolean hasWith = false;  // When the sql has with,then it can't add rowid
    boolean hasGroupBy = false; // When the sql has group,then it can't add rowid
    boolean hasAggr = false; // When the sql has Aggr,then it can't add rowid
    boolean hasFrom = false;
    boolean hasWhere = false;
    boolean hasOrderBy = false;
    boolean hasJoin = false;
    boolean hasDML = false;
    boolean hasDDL = false;
    boolean hasAlterSession = false;
    boolean hasMerge = false;
    boolean hasCall = false;
    boolean hasLimit = false;
    boolean hasAnonymousBlock = false;
    boolean invalidColumn = false;   // column has *,?,:id

    SqlKind sqlKind = SqlKind.UNINITIALIZED;

    public YasSQL(String sql) {
        originlSql = sql;
        parseSQL();
    }

    public boolean canUpdatable() {
        //to do
        return canRowID;
    }

    public boolean canScrollSensitive() {
        //to do
        return canRowID;
    }

    public boolean canScrollInSensitive() {
        //to do
        return !hasDML && !hasDDL;
    }

    public String getRefreshSQL(ResultSetMetaData md) throws SQLException {
        if (refreshSql == null && tableName != null && md != null) {
            StringBuilder sb = new StringBuilder();

            sb.append("select rowid ");
            for ( int i = 0;i < md.getColumnCount();i++) {
                sb.append(",");
                sb.append(md.getColumnName(i + 1));
            }
            sb.append(" from ").append(tableName);
            sb.append(" where rowid = ?");
            refreshSql = sb.toString();
        }

        return refreshSql;
    }

    public String getUpdateSQL(ResultSetMetaData md,boolean[] updateFlags) throws SQLException {
        if (tableName != null && md != null) {
            StringBuilder sb = new StringBuilder();
            sb.append("update ").append(tableName).append(" set ");
            //index start from 1 to ignore rowid
            int updateCount = 0;
            for ( int i = 0;i < md.getColumnCount();i++) {
                if (updateFlags[i]) {
                    if (updateCount != 0) {
                        sb.append(",");
                    }
                    sb.append(md.getColumnName(i + 1)).append(" = ?");
                    updateCount++;
                }
            }
            sb.append(" where rowid = ?");
            updateSql = sb.toString();
        }

        return updateSql;
    }

    public String getInsertSQL(ResultSetMetaData md, boolean[] updateFlags) throws SQLException {
        if (tableName != null && md != null) {
            StringBuilder sbHeader = new StringBuilder();
            StringBuilder sbValues = new StringBuilder();

            sbHeader.append("insert into ").append(tableName).append(" (");
            sbValues.append(") values (");
            //index start from 1 to ignore rowid
            int updateCount = 0;
            for ( int i = 0;i < md.getColumnCount();i++) {
                if (updateFlags[i]) {
                    if (updateCount != 0) {
                        sbHeader.append(",");
                        sbValues.append(",");
                    }
                    sbHeader.append(md.getColumnName(i + 1));
                    sbValues.append("?");
                    updateCount++;
                }
            }
            sbValues.append(")");
            sbHeader.append(sbValues.toString());

            insertSql = sbHeader.toString();
        }

        return insertSql;
    }

    public String getDeleteSQL() throws SQLException {
        if (deleteSql == null && tableName != null ) {
            StringBuilder sb = new StringBuilder();
            sb.append("delete from ").append(tableName);
            sb.append(" where rowid = ?");
            deleteSql = sb.toString();
        }

        return deleteSql;
    }

    public String getRowIDAppendSQL() throws SQLException {
        if (rowIDSql == null) {
            if (canRowID) {
                this.hasRowID = true;
                rowIDSql = addRowID(this.originlSql);
            } else {
                rowIDSql = this.originlSql;
            }
        }
        return rowIDSql;
    }

    private boolean parseEqualWord(String sql, int beginIndex, String keyWord) {

        int endIndex =  beginIndex + keyWord.length();
        if (endIndex > sql.length()) {
            return false;
        }

        boolean isEqual = sql.substring(beginIndex,endIndex).equalsIgnoreCase(keyWord);
        if (!isEqual) {
            return false;
        }

        if (sql.length() - endIndex >= 2) {
            String tail1 = sql.substring(endIndex, endIndex + 1);
            String tail2 = sql.substring(endIndex + 1, endIndex + 2);
            return tail1.equalsIgnoreCase(" ")
                    || (tail1.equalsIgnoreCase("/") && tail2.equalsIgnoreCase("*"));
        }

        return true;
    }

    private int skipBlanks(int beginIndex) {
        while (beginIndex < originlSql.length()) {
            char c = originlSql.charAt(beginIndex);
            if (c == ' ' || c == '\0' || c == '\t' || c == '\r' || c == '\n') {
                beginIndex ++;
            } else {
                break;
            }
        }
        return beginIndex;
    }

    private int skipComment(int beginIndex) {
        int leftBoundery = 0;
        while (true) {
            char c = originlSql.charAt(beginIndex);
            if (c == '/' && beginIndex + 1 < originlSql.length() && originlSql.charAt(beginIndex + 1) == '*') {
                leftBoundery++;
                beginIndex += 2;
            } else if (c == '*' && beginIndex + 1 < originlSql.length() && originlSql.charAt(beginIndex + 1) == '/') {
                leftBoundery--;
                beginIndex += 2;
            } else {
                beginIndex++;
            }

            if (beginIndex >= originlSql.length() || leftBoundery == 0) {
                break;
            }
        }
        return beginIndex;
    }

    private void parseSQL() {
        if (originlSql == null) {
            //throw
            canRowID = false;
            hasRowID = false;
            sqlKind = SqlKind.UNINITIALIZED;
        } else {
            int len = originlSql.length();
            for (int i = 0; i < len; ) {
                int oldi = i;
                char c = originlSql.charAt(i);

                switch (c) {
                    case 'a':
                    case 'A':
                        // alter
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasDDL
                                && parseEqualWord(this.originlSql, i, KEY_ALTER)) {
                            int nextPos = skipBlanks(i + KEY_ALTER.length());
                            if (parseEqualWord(this.originlSql, nextPos, KEY_SESSION)) {
                                // alter session is readonly
                                hasAlterSession = true;
                                i = nextPos + KEY_SESSION.length();
                            } else {
                                hasDDL = true;
                                i = i + KEY_ALTER.length();
                            }
                            sqlKind = SqlKind.OTHER;
                        }
                        break;
                    case 'b':
                    case 'B':
                        // BEGIN
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasAnonymousBlock
                                && parseEqualWord(this.originlSql, i, KEY_BEGIN)) {
                            hasAnonymousBlock = true;
                            sqlKind = SqlKind.PLSQL_BLOCK;
                            i = i + KEY_BEGIN.length();
                        }
                        break;
                    case 'c':
                    case 'C':
                        // Create
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasDDL
                                && parseEqualWord(this.originlSql, i, KEY_CREATE)) {
                            hasDDL = true;
                            sqlKind = SqlKind.OTHER;
                            i = i + KEY_CREATE.length();
                        }
                        // CALL
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasCall
                                && parseEqualWord(this.originlSql, i, KEY_CALL)) {
                            hasCall = true;
                            sqlKind = SqlKind.CALL_BLOCK;
                            i = i + KEY_CALL.length();
                        }
                        break;
                    case 'd':
                    case 'D':
                        // invalid Column:  select distinct c1 from t
                        if (sqlKind == sqlKind.SELECT && !hasFrom
                                && parseEqualWord(this.originlSql, i, KEY_DISTINCT)) {
                            invalidColumn = true;
                            i = i + KEY_DISTINCT.length();
                        }
                        // Delete
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasDML
                                && parseEqualWord(this.originlSql, i, KEY_DELETE)) {
                            hasDML = true;
                            sqlKind = SqlKind.DELETE;
                            i = i + KEY_DELETE.length();
                        }
                        // Drop
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasDDL
                                && parseEqualWord(this.originlSql, i, KEY_DROP)) {
                            hasDDL = true;
                            sqlKind = SqlKind.OTHER;
                            i = i + KEY_DROP.length();
                        }
                        // DECLARE
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasAnonymousBlock
                                && parseEqualWord(this.originlSql, i, KEY_DECLARE)) {
                            hasAnonymousBlock = true;
                            sqlKind = SqlKind.PLSQL_BLOCK;
                            i = i + KEY_DECLARE.length();
                        }
                        break;
                    case 'f':
                    case 'F':
                        // From
                        if (!hasFrom && parseEqualWord(this.originlSql, i, KEY_FROM)) {
                            hasFrom = true;
                            fromStartIndex = i;
                            fromEndIndex = i + KEY_FROM.length();
                            i = i + KEY_FROM.length();
                        }
                        break;
                    case 'g':
                    case 'G':
                        // Group by
                        if (!hasGroupBy && parseEqualWord(this.originlSql, i, KEY_GROUP)) {
                            i = skipBlanks(i + KEY_GROUP.length());
                            if (parseEqualWord(this.originlSql, i, KEY_BY)) {
                                hasGroupBy = true;
                                i = i + KEY_BY.length();
                            }
                        }
                        break;
                    case 'i':
                    case 'I':
                        // Insert
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasDML
                                && parseEqualWord(this.originlSql, i, KEY_INSERT)) {
                            hasDML = true;
                            sqlKind = SqlKind.INSERT;
                            i = i + KEY_INSERT.length();
                        }
                        break;
                    case 'j':
                    case 'J':
                        // join
                        if (!hasJoin && parseEqualWord(this.originlSql, i, KEY_JOIN)) {
                            isSingleTable = false;
                            hasJoin = true;
                            i = i + KEY_JOIN.length();
                        }
                        break;
                    case 'l':
                    case 'L':
                        // Limit
                        if (hasFrom && parseEqualWord(this.originlSql, i, KEY_LIMIT)) {
                            hasLimit = true;
                            i = i + KEY_LIMIT.length();
                        }
                        break;
                    case 'm':
                    case 'M':
                        // merge
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasMerge
                                && parseEqualWord(this.originlSql, i, KEY_MERGE)) {
                            hasMerge = true;
                            sqlKind = SqlKind.MERGE;
                            i = i + KEY_MERGE.length();
                        }
                        break;
                    case 'o':
                    case 'O':
                        // Order by
                        if (!hasOrderBy && parseEqualWord(this.originlSql, i, KEY_ORDER)) {
                            i = skipBlanks(i + KEY_ORDER.length());
                            if (parseEqualWord(this.originlSql, i, KEY_BY)) {
                                hasOrderBy = true;
                                this.orderByStartIndex = i;
                                i = i + KEY_BY.length();
                            }
                        }
                        break;
                    case 's':
                    case 'S':
                        //Select
                        if (sqlKind == SqlKind.UNINITIALIZED
                                && parseEqualWord(originlSql, i, KEY_SELECT)) {
                            // whilespace or comment after select
                            selectEndIndex = i + KEY_SELECT.length();
                            sqlKind = SqlKind.SELECT;
                            i = i + KEY_SELECT.length();
                        }
                        break;
                    case 't':
                    case 'T':
                        // TRUNCATE
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasDDL
                                && parseEqualWord(this.originlSql, i, KEY_TRUNCATE)) {
                            hasDDL = true;
                            sqlKind = SqlKind.OTHER;
                            i = i + KEY_TRUNCATE.length();
                        }
                        break;
                    case 'u':
                    case 'U':
                        // Update
                        if (sqlKind == SqlKind.UNINITIALIZED && !hasDML
                                && parseEqualWord(this.originlSql, i, KEY_UPDATE)) {
                            hasDML = true;
                            sqlKind = SqlKind.UPDATE;
                            i = i + KEY_UPDATE.length();
                        }
                    case 'w':
                    case 'W':
                        // With
                        if (!hasWith && parseEqualWord(this.originlSql, i, KEY_WITH)) {
                            hasWith = true;
                            i = i + KEY_WITH.length();
                        }
                        // where
                        if (!hasWhere && parseEqualWord(this.originlSql, i, KEY_WHERE)) {
                            hasWhere = true;
                            whereStartIndex = i;
                            i = i + KEY_WHERE.length();
                        }
                        break;
                    case '?':
                    case ':':
                    case '(':
                        // invalid Column : select ?/:/( from t
                        if (sqlKind == sqlKind.SELECT && !hasFrom) {
                            invalidColumn = true;
                        }
                        break;
                    case ',':
                        // join with "," ,and the location after from ,befor group by /order by
                        if (hasFrom && !hasLimit
                                && !hasWhere && !hasGroupBy && !hasOrderBy) {
                            isSingleTable = false;
                        }
                        break;
                    case '/':
                        //Comment
                        if (i + 1 < len && originlSql.charAt(i + 1) == '*') {
                            i = skipComment(i);
                        }
                        break;
                    default:
                }

                if (oldi == i) {
                    i++;
                }

                //SkipBlanks
                i = skipBlanks(i);

                //has aggregate function for canScrollSensitive/canUpdatable

            }

            if (sqlKind == sqlKind.SELECT && isSingleTable && !hasGroupBy && !hasAggr && !hasJoin
                    && !hasWith && !hasDML && !hasDDL && !hasCall && !hasMerge && !hasAnonymousBlock
                    && !invalidColumn && !hasAlterSession) {
                canRowID = true;
                hasRowID = true;
            }

            if (canRowID && hasFrom && tableName == null) {
                if (hasWhere && whereStartIndex != UNDEF) {
                    tableName = originlSql.substring(fromEndIndex + 1,whereStartIndex - 1);
                } else if (hasOrderBy && orderByStartIndex != UNDEF) {
                    tableName = originlSql.substring(fromEndIndex + 1,orderByStartIndex - 1);
                } else {
                    tableName = originlSql.substring(fromEndIndex + 1);
                }
                tableName = tableName.trim();
                tableName = tableName.split(" ")[0];
            }
        }
    }

    private String addRowID(String sql) throws SQLException {
        if (sqlKind != sqlKind.SELECT) { // not found
            throw SQLError.createSQLException("The sql did not have select statement", YasState.UNKNOWN_STATE);
        }

        String result = "select rowid as \"" + ROWID_ALIAS + "\","
                + sql.substring(selectEndIndex);
        return result;
    }

    public boolean hasRowID() {
        return hasRowID;
    }

    public boolean canRowID() {
        return canRowID;
    }

    public boolean isReadOnlySQL() {
        return (sqlKind == sqlKind.SELECT || hasAlterSession) && !hasDML && !hasDDL && !hasCall && !hasAnonymousBlock;
    }

    // Clear State for parseSQL
    private void clearState() {
        selectEndIndex = UNDEF;
        fromEndIndex = UNDEF;
        whereStartIndex = UNDEF;
        orderByStartIndex = UNDEF;
        hasRowID = false;
        canRowID = false;
        isSingleTable = true;
        hasWith = false;  // When the sql has with,then it can't add rowid
        hasGroupBy = false; // When the sql has group,then it can't add rowid
        hasAggr = false; // When the sql has Aggr,then it can't add rowid
        hasFrom = false;
        hasWhere = false;
        hasOrderBy = false;
        hasJoin = false;
        hasDML = false;
        hasDDL = false;
        hasAlterSession = false;
        hasMerge = false;
        hasCall = false;
        hasLimit = false;
        hasAnonymousBlock = false;
        invalidColumn = false;   // column has *,?,:id

        sqlKind = sqlKind.UNINITIALIZED;
    }

    public void parseSQL(String sql) {
        originlSql = sql;
        clearState();
        parseSQL();
    }

    public boolean isSELECT() {
        if (sqlKind == sqlKind.SELECT) {
            return true;
        }
        return false;
    }

    public boolean isInsert() {
        if (this.sqlKind == SqlKind.UNINITIALIZED) {
            this.parseSQL();
        }

        return this.sqlKind == SqlKind.INSERT;
    }

    public String getSQL() {
        return originlSql;
    }

    public SqlKind getSqlKind() {
        if (this.sqlKind == SqlKind.UNINITIALIZED) {
            this.parseSQL();
        }
        return this.sqlKind;
    }

    public boolean hasOrderBy() {
        if (sqlKind == sqlKind.SELECT) {
            return hasOrderBy;
        }
        return false;
    }

    public boolean hasGroupBy() {
        if (sqlKind == sqlKind.SELECT) {
            return hasGroupBy;
        }
        return false;
    }

    public boolean hasAlterSession() {
        return hasAlterSession;
    }

}
