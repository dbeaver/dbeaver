/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */
// Copyright (c) 2021, Open Cloud Limited.

package com.yashandb.util;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.io.IOException;
import java.sql.SQLException;

/**
 * Collection of utilities used by the protocol-level code.
 */
public class Utils {

    /**
     * Turn a bytearray into a printable form, representing each byte in hex.
     *
     * @param data the bytearray to stringize
     * @return a hex-encoded printable representation of {@code data}
     */
    public static String toHexString(byte[] data) {
        StringBuilder sb = new StringBuilder(data.length * 2);
        for (byte element : data) {
            sb.append((char)nibbleToHex((byte)((element & 0xF0) >> 4)));
            sb.append((char)nibbleToHex((byte) (element & 0x0F)));
        }
        return sb.toString();
    }

    public static byte nibbleToHex(byte nibble) {
        nibble = (byte) (nibble & 0x0F);
        return (byte)((nibble < 10) ? (nibble + 48) : (nibble - 10 + 65));
    }

    /**
     * Escape the given literal {@code value} and append it to the string builder {@code sbuf}. If
     * {@code sbuf} is {@code null}, a new StringBuilder will be returned. The argument {@code
     * standardConformingStrings} defines whether the backend expects standard-conforming string
     * literals or allows backslash escape sequences.
     *
     * @param sbuf                      the string builder to append to; or {@code null}
     * @param value                     the string value
     * @param standardConformingStrings if standard conforming strings should be used
     * @return the sbuf argument; or a new string builder for sbuf == null
     * @throws SQLException if the string contains a {@code \0} character
     */
    public static StringBuilder escapeLiteral(StringBuilder sbuf, String value,
                                              boolean standardConformingStrings) throws SQLException {
        if (sbuf == null) {
            sbuf = new StringBuilder((value.length() + 10) / 10 * 11); // Add 10% for escaping.
        }
        doAppendEscapedLiteral(sbuf, value, standardConformingStrings);
        return sbuf;
    }

    /**
     * Common part for {@link #escapeLiteral(StringBuilder, String, boolean)}.
     *
     * @param sbuf                      Either StringBuffer or StringBuilder as we do not expect any
     *                                  IOException to be thrown
     * @param value                     value to append
     * @param standardConformingStrings if standard conforming strings should be used
     */
    private static void doAppendEscapedLiteral(Appendable sbuf, String value,
                                               boolean standardConformingStrings) throws SQLException {
        try {
            if (standardConformingStrings) {
                // With standard_conforming_strings on, escape only single-quotes.
                for (int i = 0; i < value.length(); ++i) {
                    char ch = value.charAt(i);
                    if (ch == '\0') {
                        throw SQLError.createSQLException(
                                Messages.get("Zero bytes may not occur in string parameters."),
                                YasState.INVALID_PARAMETER_VALUE);
                    }
                    if (ch == '\'') {
                        sbuf.append('\'');
                    }
                    sbuf.append(ch);
                }
            } else {
                // With standard_conforming_string off, escape backslashes and
                // single-quotes, but still escape single-quotes by doubling, to
                // avoid a security hazard if the reported value of
                // standard_conforming_strings is incorrect, or an error if
                // backslash_quote is off.
                for (int i = 0; i < value.length(); ++i) {
                    char ch = value.charAt(i);
                    if (ch == '\0') {
                        throw SQLError.createSQLException(
                                Messages.get("Zero bytes may not occur in string parameters."),
                                YasState.INVALID_PARAMETER_VALUE);
                    }
                    if (ch == '\\' || ch == '\'') {
                        sbuf.append(ch);
                    }
                    sbuf.append(ch);
                }
            }
        } catch (IOException e) {
            throw SQLError.createSQLException(
                    Messages.get("No IOException expected from StringBuffer or StringBuilder"),
                    YasState.UNEXPECTED_ERROR, e);
        }
    }

    /**
     * Escape the given identifier {@code value} and append it to the string builder {@code sbuf}. If
     * {@code sbuf} is {@code null}, a new StringBuilder will be returned. This method is different
     * from appendEscapedLiteral in that it includes the quoting required for the identifier while
     * {@link #escapeLiteral(StringBuilder, String, boolean)} does not.
     *
     * @param sbuf  the string builder to append to; or {@code null}
     * @param value the string value
     * @return the sbuf argument; or a new string builder for sbuf == null
     * @throws SQLException if the string contains a {@code \0} character
     */
    public static StringBuilder escapeIdentifier(StringBuilder sbuf, String value)
            throws SQLException {
        if (sbuf == null) {
            sbuf = new StringBuilder(2 + (value.length() + 10) / 10 * 11); // Add 10% for escaping.
        }
        doAppendEscapedIdentifier(sbuf, value);
        return sbuf;
    }

    /**
     * Common part for appendEscapedIdentifier.
     *
     * @param sbuf  Either StringBuffer or StringBuilder as we do not expect any IOException to be
     *              thrown.
     * @param value value to append
     */
    private static void doAppendEscapedIdentifier(Appendable sbuf, String value) throws SQLException {
        try {
            sbuf.append('"');

            for (int i = 0; i < value.length(); ++i) {
                char ch = value.charAt(i);
                if (ch == '\0') {
                    throw SQLError.createSQLException(Messages.get("Zero bytes may not occur in identifiers."),
                            YasState.INVALID_PARAMETER_VALUE);
                }
                if (ch == '"') {
                    sbuf.append(ch);
                }
                sbuf.append(ch);
            }

            sbuf.append('"');
        } catch (IOException e) {
            throw SQLError.createSQLException(
                    Messages.get("No IOException expected from StringBuffer or StringBuilder"),
                    YasState.UNEXPECTED_ERROR, e);
        }
    }

    public static String trimString(String str) {
        if (str != null) {
            return str.trim();
        }
        return str;
    }

    public static long[] toLongArray(int[] la) {
        long[] ia = new long[la.length];
        for (int i = 0; i < la.length; i++) {
            ia[i] = (long) la[i];
        }
        return ia;
    }

    public static int[] toIntArray(long[] la) {
        int[] ia = new int[la.length];
        for (int i = 0; i < la.length; i++) {
            ia[i] = (int) la[i];
        }
        return ia;
    }

    /*
     * Convert from second to millisecond
     * If the second is less 0, then return 0
     * If the millisecond greater then MAX,then return MAX
     * second: second data
     * return: millisecond data
     */
    public static int toMillisecond(int second) {
        int millisecond = second * 1000;
        if ( second < 0 ) {
            return 0;
        }

        if (millisecond < 0) {
            return Integer.MAX_VALUE;
        }
        return millisecond;
    }
}
