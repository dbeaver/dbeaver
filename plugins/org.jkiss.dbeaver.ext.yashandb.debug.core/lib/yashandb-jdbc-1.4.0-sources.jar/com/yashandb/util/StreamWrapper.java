/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */
// Copyright (c) 2021, Open Cloud Limited.

package com.yashandb.util;

import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.jdbc.exception.YasException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class StreamWrapper {

    private static final int MAX_MEMORY_BUFFER_BYTES = 51200;

    private static final String TEMP_FILE_PREFIX = "yashan-stream";

    private InputStream stream;

    private byte[] rawData;

    private int offset;

    private int length;

    public StreamWrapper(byte[] data, int offset, int length) {
        this.stream = null;
        this.rawData = data;
        this.offset = offset;
        this.length = length;
    }

    public StreamWrapper(InputStream stream, int length) throws YasException {
        readStream(stream, length);
    }

    private void readStream(InputStream inputStream, int expectLen) throws YasException {

        try {
            ByteArrayOutputStream memoryOutputStream = new ByteArrayOutputStream();
            int memoryLength = copyStream(inputStream, memoryOutputStream, expectLen, MAX_MEMORY_BUFFER_BYTES);
            byte[] rawData = memoryOutputStream.toByteArray();

            if (memoryLength == -1) {
                final int diskLength;
                final File tempFile = File.createTempFile(TEMP_FILE_PREFIX, null);
                FileOutputStream diskOutputStream = new FileOutputStream(tempFile);
                diskOutputStream.write(rawData);
                try {
                    if (expectLen != -1) {
                        expectLen -= rawData.length;
                    }
                    diskLength = copyStream(inputStream, diskOutputStream, expectLen,
                            Integer.MAX_VALUE - rawData.length);
                    if (diskLength == -1) {
                        throw SQLError.createSQLException(
                                Messages.get("Stream is too large to send over the protocol."),
                                YasState.NUMERIC_CONSTANT_OUT_OF_RANGE);
                    }
                    diskOutputStream.flush();
                } finally {
                    diskOutputStream.close();
                }
                this.offset = 0;
                this.length = rawData.length + diskLength;
                this.rawData = null;
                this.stream = new FileInputStream(tempFile) {
                    private boolean closed = false;
                    private int position = 0;

                    /**
                     * Check if we should auto-close this stream
                     */
                    private void checkShouldClose(int readResult) throws IOException {
                        if (readResult == -1) {
                            close();
                        } else {
                            position += readResult;
                            if (position >= length) {
                                close();
                            }
                        }
                    }

                    public int read(byte[] b) throws IOException {
                        if (closed) {
                            return -1;
                        }
                        int result = super.read(b);
                        checkShouldClose(result);
                        return result;
                    }

                    public int read(byte[] b, int off, int len) throws IOException {
                        if (closed) {
                            return -1;
                        }
                        int result = super.read(b, off, len);
                        checkShouldClose(result);
                        return result;
                    }

                    public void close() throws IOException {
                        if (!closed) {
                            super.close();
                            tempFile.delete();
                            closed = true;
                        }
                    }

                    protected void finalize() throws IOException {
                        // forcibly close it because super.finalize() may keep the FD open, which may prevent
                        // file deletion
                        close();
                        // javac 13 assumes it can throw Throwable
                        try {
                            super.finalize();
                        } catch (RuntimeException e) {
                            throw e;
                        } catch (Error e) {
                            throw e;
                        } catch (IOException e) {
                            throw e;
                        } catch (Throwable e) {
                            throw new RuntimeException("Unexpected exception from finalize", e);
                        }
                    }
                };
            } else {
                this.rawData = rawData;
                this.stream = null;
                this.offset = 0;
                this.length = rawData.length;
            }
        } catch (IOException e) {
            throw SQLError.createSQLException(
                    Messages.get("An I/O error occurred: " + e.getMessage()), YasState.IO_ERROR, e);
        }
    }

    public StreamWrapper(InputStream stream) throws YasException {
        readStream(stream, -1);
    }

    public InputStream getStream() {
        if (stream != null) {
            return stream;
        }

        return new java.io.ByteArrayInputStream(rawData, offset, length);
    }

    public int getLength() {
        return length;
    }

    public int getOffset() {
        return offset;
    }

    public byte[] getBytes() {
        return rawData;
    }

    public String toString() {
        return "<stream of " + length + " bytes>";
    }

    private int copyStream(InputStream inputStream, OutputStream outputStream, int expectedLen, int limit)
            throws IOException, YasException {
        int expectStreamLen = expectedLen;
        boolean checkLen = true;
        if (expectedLen == -1) {
            checkLen = false;
            expectStreamLen = Integer.MAX_VALUE;
        }

        int readLength;
        int totalLength = 0;
        byte[] buffer = new byte[2048];
        while (expectStreamLen > 0) {
            readLength = inputStream.read(buffer, 0, Math.min(buffer.length, expectStreamLen));
            if (readLength == -1) {
                if (checkLen) {
                    throw SQLError.createSQLException(
                            expectStreamLen + " byte of Blob data can not be read", YasState.DATA_ERROR);
                }
                break;
            }

            totalLength += readLength;
            expectStreamLen -= readLength;
            outputStream.write(buffer, 0, readLength);
            if (totalLength >= limit) {
                return -1;
            }
        }
        return totalLength;
    }
}
