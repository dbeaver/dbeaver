/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;

import java.security.Key;
import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class YasEncrypt {
    private static final Logger LOGGER = LoggerFactory.getLogger(YasEncrypt.class.getName());
    private static final String CHARSET = "utf-8";
    private static final String CIPHER_ALGORITHM = "AES/CBC/NoPadding";
    private static final String ALGORITHM = "AES";
    private static final String IV_PARAMETER = "0000000000000000";
    private static final int ENCRY_VERSION_SHA256 = 0x00000001;   //sha256
    private static final int TRANS_ENCRY_VERSION = 0x00000001;   //AES
    private static final int AES_ZERO_PADDING_LENGTH = 16;
    private static final int AES_BLOCK_SIZE = 16;

    public static String encryptSHA(String data,String salt,int encryptVersion) {
        String encryptData = null;
        switch (encryptVersion) {
            case ENCRY_VERSION_SHA256 :
                encryptData = encryptSHA(data,salt,"SHA-256");
                break;
            default:
                encryptData = encryptSHA(data,salt,"SHA-256");
        }
        return  encryptData;
    }

    public static byte[] encryptAES(byte[] password,byte[] data,int encryptVersion) {
        byte[] encryptData = null;
        switch (encryptVersion) {
            case TRANS_ENCRY_VERSION :
                encryptData = encryptAES(password, data);
                break;
            default:
                encryptData = encryptAES(password, data);
        }
        return  encryptData;
    }

    public static byte[] decryptAES(byte[] password,byte[] data,int encryptVersion) {
        byte[] decryptData = null;
        switch (encryptVersion) {
            case TRANS_ENCRY_VERSION :
                decryptData = decryptAES(password, data);
                break;
            default:
                decryptData = decryptAES(password, data);
        }
        return  decryptData;
    }

    private static String encryptSHA(String data,String salt,String shaType) {
        MessageDigest sha = null;
        String encryptData = null;
        try {
            sha = MessageDigest.getInstance(shaType);
            byte[] byteArray = data.getBytes(CHARSET);
            sha.update(byteArray);
            if (salt != null) {
                byte[] saltByteArray = salt.getBytes(CHARSET);
                sha.update(saltByteArray);
            }
            byte[] shaBytes = sha.digest();
            StringBuffer hexValue = new StringBuffer();
            for (int i = 0; i < shaBytes.length; i++) {
                int val = ((int) shaBytes[i]) & 0xff;
                if (val < 16) {
                    hexValue.append("0");
                }
                hexValue.append(Integer.toHexString(val));
            }
            encryptData = hexValue.toString();
            encryptData = encryptData.toUpperCase();
        } catch (Exception e) {
            LOGGER.error("No such SHA Algorithm or unsupport encoding.",e);
            return null;
        }

        return encryptData;
    }

    private static byte[] encryptAES(byte[] password, byte[] data) {
        if (password == null ) {
            return null;
        } else {
            if (password.length != AES_BLOCK_SIZE) {
                password = Arrays.copyOf(password,AES_BLOCK_SIZE);
            }
        }
        if (data == null) {
            return null;
        }

        Key secretKey = null;
        try {
            data = addZeroPadding(data,AES_ZERO_PADDING_LENGTH);
            //password = addZeroPadding(password,AES_ZERO_PADDING_LENGTH);
            secretKey = new SecretKeySpec(password,ALGORITHM);
            Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            IvParameterSpec iv = new IvParameterSpec(IV_PARAMETER.getBytes(CHARSET));
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);
            byte[] bytes = cipher.doFinal(data);

            return bytes;
        } catch (Exception e) {
            LOGGER.error("Encrypt AES failed.data:" + data.length + "," + new String(data)
                            + ",password: "  + password.length + "," + new String(password)
                            + ",secretKey: " + new String(secretKey.getEncoded()),
                    e);
            return data;
        }
    }

    private static byte[] decryptAES(byte[] password, byte[] data) {
        if (password == null ) {
            return null;
        } else {
            if (password.length > AES_BLOCK_SIZE) {
                password = Arrays.copyOf(password,AES_BLOCK_SIZE);
            }
        }

        if (data == null) {
            return null;
        } else {
            if (data.length < AES_BLOCK_SIZE) {
                data = Arrays.copyOf(data,AES_BLOCK_SIZE);
            }
        }

        Key secretKey = null;
        try {
            secretKey = new SecretKeySpec(password,ALGORITHM);
            Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            IvParameterSpec iv = new IvParameterSpec(IV_PARAMETER.getBytes(CHARSET));
            cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
            byte[] outData = cipher.doFinal(data);
            outData = removeZeroPadding(outData,AES_ZERO_PADDING_LENGTH);
            return outData;
        } catch (Exception e) {
            LOGGER.error("Decrypt AES failed.data:" + data.length + "," + new String(data)
                    + ",password: "  + password.length + "," + new String(password)
                    + ",secretKey: " + new String(secretKey.getEncoded()),e);
            return data;
        }
    }

    private static byte[] addZeroPadding(byte[] data,int paddingLength) {
        byte[] outData = null;

        if (data == null) {
            return data;
        }

        if (data.length % paddingLength != 0) {
            outData = Arrays.copyOf(data,data.length + paddingLength - data.length % paddingLength);
        } else {
            outData = data;
        }
        return outData;
    }

    private static byte[] removeZeroPadding(byte[] data,int paddingLength) {
        byte[] outData = null;
        int zeroIndex = 0;

        if (data == null) {
            return data;
        }

        int len = data.length;
        while (zeroIndex < paddingLength - 1 && len - 1 - zeroIndex > 0) {
            if (data[len - 1 - zeroIndex] == 0) {
                zeroIndex++;
                continue;
            }
            break;
        }
        if (zeroIndex > 0) {
            outData = Arrays.copyOf(data,data.length - zeroIndex);
        } else {
            outData = data;
        }
        return outData;
    }
}
