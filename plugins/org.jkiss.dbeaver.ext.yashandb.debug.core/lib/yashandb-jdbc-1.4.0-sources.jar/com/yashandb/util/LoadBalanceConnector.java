/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

import com.yashandb.SessionImpl;
import com.yashandb.conf.HostSpec;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;
import com.yashandb.protocol.NativeProtocol;
import com.yashandb.protocol.YasSocketConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.net.SocketFactory;

public class LoadBalanceConnector extends HostConnector {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoadBalanceConnector.class.getName());

    private HostSpec[] hostSpecs;

    private final Map<Integer, LinkedList<NativeProtocol>> connectedSockets = new TreeMap<>();

    public LoadBalanceConnector(SessionImpl session, HostSpec[] hostSpecs) {
        super(session);

        this.yasSocketConnection = null;
        this.hostSpecs = hostSpecs;
    }

    private int getNodeConnections() throws SQLException {
        String querySql = "select count(*) from v$session where type!='BACKGROUND'";

        int connectCnt = 0;
        Statement statement = this.session.getConnection().createStatement();
        ResultSet resultSet = statement.executeQuery(querySql);
        if (!resultSet.next()) {
            resultSet.close();
            return connectCnt;
        }

        connectCnt = resultSet.getInt(1);
        resultSet.close();
        statement.close();

        return connectCnt;
    }

    @Override
    public void connect(String user, Properties info) throws SQLException {
        SocketFactory socketFactory = SocketFactory.getDefault();

        for (HostSpec hostSpec : hostSpecs) {
            LOGGER.debug("Trying to establish a connection to {}", hostSpec);

            YasSocketConnection trySocketConn = null;
            long startTime = System.currentTimeMillis();
            try {
                trySocketConn = tryConnect(user, info, socketFactory, hostSpec);
                this.session.setYasSocketConnection(trySocketConn);
                this.session.setProtocol(this.protocol);

                int nodeConnections = this.getNodeConnections();
                if (!connectedSockets.containsKey(nodeConnections)) {
                    LinkedList<NativeProtocol> protocolList = new LinkedList<>();
                    connectedSockets.put(nodeConnections, protocolList);
                }

                connectedSockets.get(nodeConnections).add(this.protocol);
            } catch (Exception e) {
                long currentTime = System.currentTimeMillis();
                LOGGER.warn("Connect to hostSpec {} failed, Exception: {},spend time: {} ",
                        hostSpec, e.getMessage(), currentTime - startTime);

                closeStream(trySocketConn);
            }
        }

        if (connectedSockets.isEmpty()) {
            String errMsg = Messages.get("Connect Failed.");
            LOGGER.error(errMsg);
            throw SQLError.createSQLException(errMsg, YasState.CONNECTION_UNABLE_TO_CONNECT);
        }

        int nodeCount = 0;
        for (Map.Entry<Integer, LinkedList<NativeProtocol>> entry : connectedSockets.entrySet()) {
            LinkedList<NativeProtocol> protocolList = entry.getValue();
            for (NativeProtocol nativeProtocol : protocolList) {
                if (nodeCount == 0) {
                    this.yasSocketConnection = nativeProtocol.getSocketConnection();
                    this.protocol = nativeProtocol;
                    nodeCount++;
                    continue;
                }
                closeStream(nativeProtocol.getSocketConnection());
                nodeCount++;
            }
            protocolList.clear();
        }
        connectedSockets.clear();

        this.session.setProtocol(protocol);
        this.session.setYasSocketConnection(yasSocketConnection);
    }
}
