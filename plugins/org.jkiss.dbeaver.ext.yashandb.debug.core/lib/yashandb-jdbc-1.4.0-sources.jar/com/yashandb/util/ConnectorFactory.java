/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

import com.yashandb.SessionImpl;
import com.yashandb.YasConstants;
import com.yashandb.conf.HostSpec;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;

import java.sql.SQLException;

public class ConnectorFactory {

    public static HostConnector generateConnector(SessionImpl session, HostSpec[] hostSpecs, String serverType)
            throws SQLException {
        if (hostSpecs == null) {
            return null;
        }

        if (hostSpecs.length == 1) {
            return new StandAloneConnector(session, hostSpecs[0]);
        }

        switch (serverType) {
            case YasConstants.PRIMARY_TYPE:
                return new HaPrimaryConnector(session, hostSpecs);
            case YasConstants.LOAD_BALANCE_TYPE:
                return new LoadBalanceConnector(session, hostSpecs);
            default:
                throw SQLError.createSQLException(
                        Messages.get("invalid serverType: {0}", serverType), YasState.DATA_ERROR);

        }
    }
}
