/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

/**
 * Converts to and from the YashanDB byte datatype used by the backend.
 */
public class YasByte {

    /*
     * Converts a java byte[] into a YashanDB bytea string (i.e. the text representation of the bytea data
     * type)
     */
    public static String toYasString(byte[] buf) {
        if (buf == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder(2 * buf.length);
        for (byte element : buf) {
            int elementAsInt = (int) element;
            if (elementAsInt < 0) {
                elementAsInt = 256 + elementAsInt;
            }
            // we escape the same non-printable characters as the backend
            // we must escape all 8bit characters otherwise when convering
            // from java unicode to the db character set we may end up with
            // question marks if the character set is SQL_ASCII
            if (elementAsInt < 040 || elementAsInt > 0176) {
                // escape charcter with the form \000, but need two \\ because of
                // the Java parser
                stringBuilder.append("\\");
                stringBuilder.append((char) (((elementAsInt >> 6) & 0x3) + 48));
                stringBuilder.append((char) (((elementAsInt >> 3) & 0x7) + 48));
                stringBuilder.append((char) ((elementAsInt & 0x07) + 48));
            } else if (element == (byte) '\\') {
                // escape the backslash character as \\, but need four \\\\ because
                // of the Java parser
                stringBuilder.append("\\\\");
            } else {
                // other characters are left alone
                stringBuilder.append((char) element);
            }
        }
        return stringBuilder.toString();
    }
}
