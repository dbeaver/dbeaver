/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.util;

import com.yashandb.SessionImpl;
import com.yashandb.conf.HostSpec;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;

import java.io.IOException;
import java.net.ConnectException;
import java.sql.SQLException;
import java.util.Properties;

import javax.net.SocketFactory;

public class StandAloneConnector extends HostConnector {
    private static final Logger LOGGER = LoggerFactory.getLogger(StandAloneConnector.class.getName());

    private HostSpec hostSpec;

    public StandAloneConnector(SessionImpl session, HostSpec hostSpec) {
        super(session);
        this.hostSpec = hostSpec;
    }

    @Override
    public void connect(String user, Properties info) throws SQLException {
        SocketFactory socketFactory = SocketFactory.getDefault();

        long startTime = System.currentTimeMillis();
        long currentTime;

        LOGGER.debug("Trying to establish a connection to {}", hostSpec);
        try {
            try {
                yasSocketConnection = tryConnect(user, info, socketFactory, hostSpec);
            } catch (Exception e) {
                currentTime = System.currentTimeMillis();
                LOGGER.warn("Connect Failed,then mark this hostSpec {}, Exception: {},spend time: {} ",
                        hostSpec, e.getMessage(), currentTime - startTime);

                String errMsg = Messages.get("Connect Failed, spend time: {0} ms", currentTime - startTime);
                LOGGER.error(errMsg);
                throw e;
            }
        } catch (ConnectException cex) {
            closeStream(yasSocketConnection);
            throw SQLError.createSQLException(Messages.get(
                    "Connection to {0} refused. Check that the hostname and port are correct",
                    hostSpec), YasState.CONNECTION_UNABLE_TO_CONNECT, cex);
        } catch (IOException ioe) {
            closeStream(yasSocketConnection);
            throw SQLError.createSQLException(Messages.get("The connection attempt failed."),
                    YasState.CONNECTION_UNABLE_TO_CONNECT, ioe);
        } catch (SQLException se) {
            closeStream(yasSocketConnection);
            throw se;
        }

        this.session.setProtocol(protocol);
        this.session.setYasSocketConnection(yasSocketConnection);
    }
}
