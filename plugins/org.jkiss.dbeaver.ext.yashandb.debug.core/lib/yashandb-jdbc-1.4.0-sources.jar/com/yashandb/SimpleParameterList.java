/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb;

import com.yashandb.core.DataType;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.parameter.ParameterFactory;
import com.yashandb.parameter.ParameterLittleEndianFactory;
import com.yashandb.parameter.YasParameter;
import com.yashandb.protocol.Packet;
import com.yashandb.util.ByteStreamWriter;
import com.yashandb.util.Messages;
import com.yashandb.util.StreamWrapper;
import com.yashandb.util.Utils;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;

public class SimpleParameterList implements ParameterList, Cloneable {

    private ParameterFactory parameterFactory;
    private YasParameter[] yasParameters;
    private int pos = 0;

    private short charset = 0;

    public SimpleParameterList(int paramCount) {
        this.parameterFactory = new ParameterLittleEndianFactory();
        this.yasParameters = new YasParameter[paramCount];
    }

    public void setCharset(short charset) {
        this.charset = charset;
    }

    private boolean isToSetNullObject(int index, Object value, int type) {
        if (yasParameters[index] == null) {
            return false;
        }
        return (type == DataType.UNKNOWN && value == ParameterFactory.getNullObject()
                && yasParameters[index].getType() != DataType.UNKNOWN);
    }

    private void checkParameterIndex(int index) throws SQLException {
        if (index < 1 || index > yasParameters.length) {
            throw SQLError.createSQLException(
                    Messages.get("The column index is out of range: {0}, number of columns: {1}.",
                            index, yasParameters.length),
                    YasState.INVALID_PARAMETER_VALUE);
        }
    }

    private void bind(int index, Object value, int type) throws SQLException {
        checkParameterIndex(index);

        --index;
        if (isToSetNullObject(index, value, type)) {
            yasParameters[index].setValue(ParameterFactory.getNullObject());
            yasParameters[index].setInDirection();
            return;
        }

        if ((yasParameters[index] == null) || (yasParameters[index].getType() != type)) {
            YasParameter parameter = parameterFactory.getParameter(type);
            yasParameters[index] = parameter;
        }
        yasParameters[index].setValue(value);
        yasParameters[index].setInDirection();
        yasParameters[index].setCharset(this.charset);

        pos = index + 1;
    }

    @Override
    public int getParameterCount() {
        return yasParameters.length;
    }

    @Override
    public int getInParameterCount() {
        int count = 0;
        for (YasParameter yasParameter : yasParameters) {
            if (!yasParameter.isOutParameter()) {
                count++;
            }
        }
        return count;
    }

    @Override
    public void replace(int index, YasParameter parameter) throws SQLException {
        if (index < 0 || index >= yasParameters.length) {
            throw SQLError.createSQLException(
                    Messages.get("Invalid parameter index"), YasState.INVALID_PARAMETER_VALUE);
        }
        yasParameters[index] = parameter;
    }

    @Override
    public void setIntParameter(int index, long value, int type) throws SQLException {
        switch (type) {
            case DataType.BOOLEAN:
            case DataType.TINYINT:
            case DataType.SMALLINT:
            case DataType.INTEGER: {
                bind(index, (int) value, type);
                break;
            }
            case DataType.BIGINT: {
                bind(index, value, type);
                break;
            }
            default:
                throw SQLError.createSQLFeatureNotSupportedException(this.getClass(),
                    "setIntParameter with type " + type);
        }
    }

    @Override
    public void setDoubleParameter(int index, double value, int type) throws SQLException {
        bind(index, value, type);
    }

    @Override
    public void setFloatParameter(int index, float value, int type) throws SQLException {
        bind(index, value, type);
    }

    @Override
    public void setNumberParameter(int index, Number value, int type) throws SQLException {
        bind(index, value, type);
    }

    @Override
    public void setStringParameter(int index, String value) throws SQLException {
        bind(index, value, DataType.VARCHAR);
    }

    @Override
    public void setDateParameter(int index, Date date, int type) throws SQLException {
        bind(index, date, type);
    }

    @Override
    public void setTimeStampParameter(int index, Timestamp timestamp, int type) throws SQLException {
        bind(index, timestamp, type);
    }

    @Override
    public void setTimeParameter(int index, Time time, int type) throws SQLException {
        bind(index, time, type);
    }

    @Override
    public void setDsIntervalParameter(int index, long interval, int type) throws SQLException {
        bind(index, interval, type);
    }

    @Override
    public void setYmIntervalParameter(int index, int interval, int type) throws SQLException {
        bind(index, interval, type);
    }

    @Override
    public void setClobParameter(int index, Clob clob, int type) throws SQLException {
        bind(index, clob, type);
    }

    @Override
    public void setBlobParameter(int index, Blob blob, int type) throws SQLException {
        bind(index, blob, type);
    }

    @Override
    public void setBinaryParameter(int index, byte[] value, int oid) throws SQLException {
        bind(index, value, oid);
    }

    @Override
    public void setBytea(int index, byte[] data, int offset, int length) throws SQLException {
        bind(index, new StreamWrapper(data, offset, length), DataType.RAW);
    }

    @Override
    public void setBytea(int index, InputStream stream, int length) throws SQLException {
        bind(index, new StreamWrapper(stream, length), DataType.RAW);
    }

    @Override
    public void setBytea(int index, InputStream stream) throws SQLException {
        bind(index, new StreamWrapper(stream), DataType.RAW);
    }

    @Override
    public void setBytea(int index, ByteStreamWriter writer) throws SQLException {
        bind(index, writer, DataType.RAW);
    }

    @Override
    public void setText(int index, InputStream stream) throws SQLException {
        throw SQLError.createSQLFeatureNotSupportedException(this.getClass(), "setText");
    }

    @Override
    public void setNull(int index, int oid) throws SQLException {
        bind(index, ParameterFactory.getNullObject(), oid);
    }

    @Override
    public void setRowIdParameter(int index, RowId value) throws SQLException {
        bind(index, value, DataType.ROWID);
    }

    @Override
    public void registerOutParameter(int index, int yashanDataType) throws SQLException {
        checkParameterIndex(index);
        --index;

        if (yasParameters[index] == null) {
            YasParameter parameter = parameterFactory.getParameter(yashanDataType);
            yasParameters[index] = parameter;
        }

        yasParameters[index].setType(yashanDataType);
        yasParameters[index].setOutDirection();
    }

    @Override
    public String toString(int index, boolean standardConformingStrings) {
        --index;
        if (yasParameters[index] == null) {
            return "?";
        } else if (yasParameters[index].isValueNull()) {
            return "NULL";
        } else {
            String param = yasParameters[index].getValue().toString();

            // add room for quotes + potential escaping.
            StringBuilder p = new StringBuilder(3 + (param.length() + 10) / 10 * 11);

            // No E'..' here since escapeLiteral escapes all things and it does not use \123 kind of
            // escape codes
            p.append('\'');
            try {
                p = Utils.escapeLiteral(p, param, standardConformingStrings);
            } catch (SQLException sqle) {
                // This should only happen if we have an embedded null
                // and there's not much we can do if we do hit one.
                //
                // The goal of toString isn't to be sent to the server,
                // so we aren't 100% accurate (see StreamWrapper), put
                // the unescaped version of the data.
                //
                p.append(param);
            }
            p.append('\'');
            int paramType = yasParameters[index].getType();
            if (paramType == DataType.TIMESTAMP) {
                p.append("::timestamp");
            } else if (paramType == DataType.TIMESTAMP_TZ) {
                p.append("::timestamp with time zone");
            } else if (paramType == DataType.DATE) {
                p.append("::date");
            } else if (paramType == DataType.NUMBER) {
                p.append("::numeric");
            }
            return p.toString();
        }
    }

    public int getLength(int index) throws SQLException {
        --index;
        return yasParameters[index].getLength();
    }

    int writeValue(int index, Packet packet) throws SQLException {
        --index;
        return yasParameters[index].writeValue(packet);
    }

    @Override
    public SimpleParameterList clone() throws CloneNotSupportedException {
        Object clone = super.clone();
        SimpleParameterList cloneParameterList = (SimpleParameterList) clone;
        if (yasParameters != null) {
            cloneParameterList.yasParameters = this.yasParameters.clone();
            for (int i = 0; i < this.yasParameters.length; i++) {
                cloneParameterList.yasParameters[i] = this.yasParameters[i].clone();
            }
        }

        return cloneParameterList;
    }

    private void checkParameterList() throws SQLException {
        if (yasParameters == null) {
            return;
        }
        for (int i = 0; i < this.yasParameters.length; i++) {
            if (this.yasParameters[i] == null) {
                throw SQLError.createSQLException(
                        Messages.get("Parameter is missing,index: {0}", i + 1),
                        YasState.INVALID_PARAMETER_VALUE);
            }
        }
    }

    @Override
    public ParameterList copy() throws SQLException {
        checkParameterList();
        try {
            return this.clone();
        } catch (CloneNotSupportedException exception) {
            throw new SQLException(exception.getMessage());
        }
    }

    public void clear() {
        Arrays.fill(yasParameters, null);
        pos = 0;
    }

    @Override
    public YasParameter[] getParameters() {
        return yasParameters;
    }

    @Override
    public void appendAll(ParameterList list) throws SQLException {
        if (list instanceof SimpleParameterList) {
            /* only v3.SimpleParameterList is compatible with this type
            we need to create copies of our parameters, otherwise the values can be changed */
            SimpleParameterList spl = (SimpleParameterList) list;
            int inParamCount = spl.getInParameterCount();
            if ((pos + inParamCount) > yasParameters.length) {
                throw SQLError.createSQLException(
                        Messages.get("Added parameters index out of range: {0}, number of columns: {1}.",
                                (pos + inParamCount), yasParameters.length),
                        YasState.INVALID_PARAMETER_VALUE);
            }

            try {
                for (YasParameter parameter : list.getParameters()) {
                    yasParameters[pos] = parameter.clone();
                    pos = pos + 1;
                }
            } catch (CloneNotSupportedException exception) {
                throw new SQLException(exception.getMessage());
            }
        }
    }

    /**
     * Useful implementation of toString.
     *
     * @return String representation of the list values
     */
    @Override
    public String toString() {
        StringBuilder ts = new StringBuilder("<[");
        if (yasParameters.length > 0) {
            ts.append(toString(1, true));
            for (int c = 2; c <= yasParameters.length; c++) {
                ts.append(" ,").append(toString(c, true));
            }
        }
        ts.append("]>");
        return ts.toString();
    }
}
