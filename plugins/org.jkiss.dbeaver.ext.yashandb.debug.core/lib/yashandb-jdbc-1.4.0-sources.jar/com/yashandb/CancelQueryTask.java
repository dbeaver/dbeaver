/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb;

public interface CancelQueryTask {

    boolean cancel();

    Throwable getCaughtWhileCancelling();

    void setCaughtWhileCancelling(Throwable caughtWhileCancelling);

    Query getQueryToCancel();

    void setQueryToCancel(Query queryToCancel);
}
