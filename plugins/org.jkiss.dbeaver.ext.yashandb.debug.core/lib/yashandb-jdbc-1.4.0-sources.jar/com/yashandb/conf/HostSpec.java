/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.conf;

/**
 * Simple container for host and port.
 */
public class HostSpec {
    protected final String host;
    protected final int port;

    public HostSpec(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public String toString() {
        return host + ":" + port;
    }

    @Override
    public boolean equals(Object obj) {
        return obj instanceof HostSpec && port == ((HostSpec) obj).port
                && host.equals(((HostSpec) obj).host);
    }

    @Override
    public int hashCode() {
        return port ^ host.hashCode();
    }

    public Boolean shouldResolve() {
        String socksProxy = System.getProperty("socksProxyHost");
        return socksProxy == null || socksProxy.trim().isEmpty();
    }

}
