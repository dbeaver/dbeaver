/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.conf;

import com.yashandb.YasConstants;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.log.Logger;
import com.yashandb.log.LoggerFactory;
import com.yashandb.util.Messages;
import com.yashandb.util.URLCoder;

import java.sql.SQLException;
import java.util.Properties;
import java.util.Set;

public class ConnectionUrl {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConnectionUrl.class.getName());

    private final Properties props;

    private final String url;

    private final String serverType;

    public static boolean acceptsUrl(String connString) throws SQLException {
        if (connString == null) {
            throw new SQLException("url is null");
        }
        return parseURL(connString, null) != null;
    }

    /**
     * Constructs a new DriverURL, splitting the specified URL into its component parts.
     *
     * @param url      JDBC URL to parse
     * @param defaults Default properties
     * @return Properties with elements added from the url
     */
    public static Properties parseURL(String url, Properties defaults) throws SQLException {
        Properties urlProps = new Properties(defaults);

        String urlServer = url;
        String urlArgs = "";

        int qPos = url.indexOf('?');
        if (qPos != -1) {
            urlServer = url.substring(0, qPos);
            urlArgs = url.substring(qPos + 1);
        }

        if (!urlServer.startsWith("jdbc:yasdb:")) {
            LOGGER.debug("JDBC URL must start with \"jdbc:yasdb:\" but was: {}", url);
            return null;
        }
        urlServer = urlServer.substring("jdbc:yasdb:".length());

        if (urlServer.contains("://")) {
            int serverEndIndex = urlServer.indexOf(':');
            String serverType = urlServer.substring(0, serverEndIndex);
            urlProps.setProperty("SERVER_TYPE", serverType);

            urlServer = urlServer.substring(serverEndIndex + 1);
        }

        if (urlServer.startsWith("//")) {
            urlServer = urlServer.substring(2);
            int slash = urlServer.indexOf('/');
            if (slash == -1) {
                LOGGER.warn("JDBC URL must contain a / at the end of the host or port: {}",
                        url);
                return null;
            }
            urlProps.setProperty("DBNAME", URLCoder.decode(urlServer.substring(slash + 1)));

            String[] addresses = urlServer.substring(0, slash).split(",");
            StringBuilder hosts = new StringBuilder();
            StringBuilder ports = new StringBuilder();
            for (String address : addresses) {
                int portIdx = address.lastIndexOf(':');
                if (portIdx != -1 && address.lastIndexOf(']') < portIdx) {
                    String portStr = address.substring(portIdx + 1);
                    try {
                        int port = Integer.parseInt(portStr);
                        if (port < 1 || port > 65535) {
                            LOGGER.warn("JDBC URL port: {0} not valid (1:65535) ", portStr);
                            return null;
                        }
                    } catch (NumberFormatException ignore) {
                        LOGGER.warn("JDBC URL invalid port number: {0}", portStr);
                        return null;
                    }
                    ports.append(portStr);
                    hosts.append(address.subSequence(0, portIdx));
                } else {
                    LOGGER.error("JDBC URL has invalid port number");
                    throw SQLError.createSQLException(Messages.get("JDBC URL has invalid port number, url: {0}", url),
                            YasState.INVALID_PARAMETER_VALUE);
                }
                ports.append(',');
                hosts.append(',');
            }
            ports.setLength(ports.length() - 1);
            hosts.setLength(hosts.length() - 1);
            urlProps.setProperty("PORT", ports.toString());
            urlProps.setProperty("HOST", hosts.toString());
        } else {
            if (defaults == null || !defaults.containsKey("DBNAME")) {
                urlProps.setProperty("DBNAME", URLCoder.decode(urlServer));
            }
        }

        // parse the args part of the url
        String[] args = urlArgs.split("&");
        for (String token : args) {
            if (token.isEmpty()) {
                continue;
            }
            int pos = token.indexOf('=');
            if (pos == -1) {
                urlProps.setProperty(token, "");
            } else {
                urlProps.setProperty(token.substring(0, pos), URLCoder.decode(token.substring(pos + 1)));
            }
        }

        return urlProps;
    }

    public static ConnectionUrl getInstance(String url, Properties info) throws SQLException {
        // override defaults with provided properties
        Properties props = new Properties();
        if (info != null) {
            Set<String> e = info.stringPropertyNames();
            for (String propName : e) {
                String propValue = info.getProperty(propName);
                if (propValue == null) {
                    throw SQLError.createSQLException(
                            Messages.get("Properties for the driver contains a non-string value for the key ")
                                    + propName,
                            YasState.UNEXPECTED_ERROR);
                }
                props.setProperty(propName, propValue);
            }
        }
        // parse URL and add more properties
        if ((props = parseURL(url, props)) == null) {
            return null;
        }

        String serverType = props.getProperty("SERVER_TYPE");
        if ((serverType == null) || serverType.isEmpty()) {
            serverType = YasConstants.PRIMARY_TYPE;
        }
        return new ConnectionUrl(url, props, serverType);
    }

    public Properties getProps() {
        return props;
    }

    public String getUrl() {
        return url;
    }

    public String getServerType() {
        return serverType;
    }

    private ConnectionUrl(String url, Properties props, String serverType) {
        this.props = props;
        this.url = url;
        this.serverType = serverType;
    }

    /**
     * @return the address portion of the URL
     */
    public HostSpec[] hostSpecs() {
        String hostsStr = props.getProperty("HOST");
        String portsStr = props.getProperty("PORT");
        if ((hostsStr == null) || (portsStr == null)) {
            return null;
        }

        String[] hosts = hostsStr.split(",");
        String[] ports = portsStr.split(",");
        HostSpec[] hostSpecs = new HostSpec[hosts.length];
        for (int i = 0; i < hostSpecs.length; ++i) {
            hostSpecs[i] = new HostSpec(hosts[i], Integer.parseInt(ports[i]));
        }
        return hostSpecs;
    }

    /**
     * @return the username of the URL
     */
    public String user() {
        return props.getProperty("user", "");
    }

    /**
     * @return the database name of the URL
     */
    public String database() {
        return props.getProperty("DBNAME", "");
    }

}
