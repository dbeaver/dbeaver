/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb.conf;

import com.yashandb.YasConstants;
import com.yashandb.exception.YasState;
import com.yashandb.jdbc.exception.SQLError;
import com.yashandb.jdbc.exception.YasException;
import com.yashandb.util.Messages;

import java.sql.DriverPropertyInfo;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * All connection parameters that can be either set in JDBC URL, in Driver properties or in
 * datasource setters.
 */
public enum YasProperty {
    /**
     * Password to use when authenticating.
     */
    PASSWORD(
            "password",
            null,
            "Password to use when authenticating.",
            false),

    /**
     * Username to connect to the database as.
     */
    USER(
            "user",
            null,
            "Username to connect to the database as.",
            true),

    /**
     * Hostname of the YashanDB server (may be specified directly in the JDBC URL).
     */
    HOST(
            "HOST",
            null,
            "Hostname of the YashanDB server (may be specified directly in the JDBC URL)",
            false),

    /**
     * Port of the YashanDB server (may be specified directly in the JDBC URL).
     */
    PORT(
            "PORT",
            null,
            "Port of the YashanDB server (may be specified directly in the JDBC URL)"),

    PROGRAM_NAME(
            "ProgramName",
            YasConstants.DRIVER_NAME,
            "The fully qualified path for the file that contains the specified module"),

    /**
     * Default parameter for {@link java.sql.Statement#getFetchSize()}. A value of {@code 0} means
     * that need fetch all rows at once
     */
    DEFAULT_ROW_FETCH_SIZE(
            "defaultRowFetchSize",
            "10",
            "Positive number of rows that should be fetched from the database when "
                    + "more rows are needed for ResultSet by each fetch iteration"),

    /**
     * <p>File name output of the Logger, if set, the Logger will use a
     * {@link java.util.logging.FileHandler} to write to a specified file. If the parameter is not set
     * or the file can't be created the {@link java.util.logging.ConsoleHandler} will be used
     * instead.</p>
     *
     * <p>Parameter should be use together with {@link YasProperty#LOGGER_LEVEL}</p>
     */
    LOGGER_FILE(
            "loggerFile",
            null,
            "File name output of the Logger"),

    /**
     * <p>Logger level of the driver. Allowed values: {@code OFF}, {@code DEBUG} or {@code
     * TRACE}.</p>
     *
     * <p>This enable the {@link java.util.logging.Logger} of the driver based on the following
     * mapping of levels:</p>
     * <ul>
     *     <li>FINE -&gt; DEBUG</li>
     *     <li>FINEST -&gt; TRACE</li>
     * </ul>
     *
     * <p><b>NOTE:</b> The recommended approach to enable java.util.logging is using a
     * {@code logging.properties} configuration file with the property
     * {@code -D java.util.logging.config.file = myfile } or if your are using an application server
     * you should use the appropriate logging subsystem.</p>
     */
    LOGGER_LEVEL(
            "loggerLevel",
            null,
            "Logger level of the driver",
            false,
            new String[]{"OFF", "DEBUG", "TRACE"}),

    /**
     * Whether to include full server error detail in exception messages.
     */
    LOG_SERVER_ERROR_DETAIL(
            "logServerErrorDetail",
            "true",
            "Include full server error detail in exception messages. "
                    + "If disabled then only the error itself will be included."),

    /**
     * When connections that are not explicitly closed are garbage collected, log the stacktrace from
     * the opening of the connection to trace the leak source.
     */
    LOG_UNCLOSED_CONNECTIONS(
            "logUnclosedConnections",
            "false",
            "When connections that are not explicitly closed are garbage collected, "
                    + "log the stacktrace from the opening of the connection to trace the leak source"),

    /**
     * Cancel command is sent out of band over its own connection, so cancel message can itself get
     * stuck. This property controls "connect timeout" and "socket timeout" used for cancel commands.
     * The timeout is specified in seconds. Default value is 10 seconds.
     */
    CANCEL_SIGNAL_TIMEOUT(
            "cancelSignalTimeout",
            "10",
            "The timeout that is used for sending cancel command."),

    /**
     * <p>The timeout value used for socket connect operations. If connecting to the server takes
     * longer than this value, the connection is broken.</p>
     *
     * <p>The timeout is specified in seconds and a value of zero means that it is disabled.</p>
     */
    CONNECT_TIMEOUT(
            "connectTimeout",
            "10",
            "The timeout value used for socket connect operations."),

    /**
     * Specify how long to wait for establishment of a database connection. The timeout is specified
     * in seconds.
     */
    LOGIN_TIMEOUT(
            "loginTimeout",
            "300",
            "Specify how long to wait for establishment of a database connection."),

    /**
     * The timeout value used for socket read operations. If reading from the server takes longer than
     * this value, the connection is closed. This can be used as both a brute force global query
     * timeout and a method of detecting network problems. The timeout is specified in seconds and a
     * value of zero means that it is disabled.
     */
    SOCKET_TIMEOUT(
            "socketTimeout",
            "0",
            "The timeout value used for socket read operations."),

    /**
     * Yashan Database creates server processes to handle the requests of user processes connected to an session.
     * A value of {@code "shared"}, which is the default, means server process can service multiple user processes.
     * A value of {@code "dedicated"}, means server process services only one user process.
     */
    SERVER_MODE(
            "serverMode",
            "shared",
            "Dedicated or Shared server mode."
    ),

    /**
     * The timeout value used for connect primary host using configured ips.
     * The timeout is specified in seconds. Default value is 300 seconds.
     */
    POOL_TIMEOUT(
            "poolTimeout",
            "300",
            "The timeout value used for connect primary host using configured ips"),

    /**
     * Socket read buffer size (SO_RECVBUF). A value of {@code -1}, which is the default, means system
     * default.
     */
    RECEIVE_BUFFER_SIZE(
            "receiveBufferSize",
            "-1",
            "Socket read buffer size"),

    /**
     * Socket write buffer size (SO_SNDBUF). A value of {@code -1}, which is the default, means system
     * default.
     */
    SEND_BUFFER_SIZE(
            "sendBufferSize",
            "-1",
            "Socket write buffer size"),

    SSL_ROOT_CER(
            "sslRootCer",
            "",
            "Certificate Root Path",
            false),

    /**
     * Enable or disable TCP keep-alive. The default is {@code true}.
     */
    TCP_KEEP_ALIVE(
            "tcpKeepAlive",
            "true",
            "Enable or disable TCP keep-alive. The default is {@code true}."),
    ;

    private final String name;
    private final String defaultValue;
    private final boolean required;
    private final String description;
    private final String[] choices;
    private final boolean deprecated;

    YasProperty(String name, String defaultValue, String description) {
        this(name, defaultValue, description, false);
    }

    YasProperty(String name, String defaultValue, String description, boolean required) {
        this(name, defaultValue, description, required, (String[]) null);
    }

    YasProperty(String name, String defaultValue, String description, boolean required,
                String[] choices) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.required = required;
        this.description = description;
        this.choices = choices;
        try {
            this.deprecated =
                    YasProperty.class.getField(name()).getAnnotation(Deprecated.class) != null;
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        }
    }

    private static final Map<String, YasProperty> PROPS_BY_NAME =
            new HashMap<String, YasProperty>();

    static {
        for (YasProperty prop : YasProperty.values()) {
            if (PROPS_BY_NAME.put(prop.getName(), prop) != null) {
                throw new IllegalStateException("Duplicate YasProperty name: " + prop.getName());
            }
        }
    }

    /**
     * Returns the name of the connection parameter. The name is the key that must be used in JDBC URL
     * or in Driver properties
     *
     * @return the name of the connection parameter
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the default value for this connection parameter.
     *
     * @return the default value for this connection parameter or null
     */
    public String getDefaultValue() {
        return defaultValue;
    }

    /**
     * Returns the available values for this connection parameter.
     *
     * @return the available values for this connection parameter or null
     */
    public String[] getChoices() {
        return choices;
    }

    /**
     * Returns the value of the connection parameters according to the given {@code Properties} or the
     * default value.
     *
     * @param properties properties to take actual value from
     * @return evaluated value for this connection parameter
     */
    public String get(Properties properties) {
        return properties.getProperty(name, defaultValue);
    }

    /**
     * Set the value for this connection parameter in the given {@code Properties}.
     *
     * @param properties properties in which the value should be set
     * @param value      value for this connection parameter
     */
    public void set(Properties properties, String value) {
        if (value == null) {
            properties.remove(name);
        } else {
            properties.setProperty(name, value);
        }
    }

    /**
     * Return the boolean value for this connection parameter in the given {@code Properties}.
     *
     * @param properties properties to take actual value from
     * @return evaluated value for this connection parameter converted to boolean
     */
    public boolean getBoolean(Properties properties) {
        return Boolean.valueOf(get(properties));
    }

    /**
     * Return the int value for this connection parameter in the given {@code Properties}.
     *
     * @param properties properties to take actual value from
     * @return evaluated value for this connection parameter converted to int
     * @throws YasException if it cannot be converted to int.
     */
    public int getInt(Properties properties) throws YasException {
        String value = get(properties);
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException nfe) {
            throw SQLError.createSQLException(Messages.get("{0} parameter value must be an integer but was: {1}",
                    getName(), value), YasState.INVALID_PARAMETER_VALUE, nfe);
        }
    }

    /**
     * Set the boolean value for this connection parameter in the given {@code Properties}.
     *
     * @param properties properties in which the value should be set
     * @param value      boolean value for this connection parameter
     */
    public void set(Properties properties, boolean value) {
        properties.setProperty(name, Boolean.toString(value));
    }

    /**
     * Set the int value for this connection parameter in the given {@code Properties}.
     *
     * @param properties properties in which the value should be set
     * @param value      int value for this connection parameter
     */
    public void set(Properties properties, int value) {
        properties.setProperty(name, Integer.toString(value));
    }

    /**
     * Test whether this property is present in the given {@code Properties}.
     *
     * @param properties set of properties to check current in
     * @return true if the parameter is specified in the given properties
     */
    public boolean isPresent(Properties properties) {
        return getSetString(properties) != null;
    }

    /**
     * Convert this connection parameter and the value read from the given {@code Properties} into a
     * {@code DriverPropertyInfo}.
     *
     * @param properties properties to take actual value from
     * @return a DriverPropertyInfo representing this connection parameter
     */
    public DriverPropertyInfo toDriverPropertyInfo(Properties properties) {
        DriverPropertyInfo propertyInfo = new DriverPropertyInfo(name, get(properties));
        propertyInfo.required = required;
        propertyInfo.description = description;
        propertyInfo.choices = choices;
        return propertyInfo;
    }

    /**
     * Return the property if exists but avoiding the default. Allowing the caller to detect the lack
     * of a property.
     *
     * @param properties properties bundle
     * @return the value of a set property
     */
    public String getSetString(Properties properties) {
        Object o = properties.get(name);
        if (o instanceof String) {
            return (String) o;
        }
        return null;
    }
}
