/*
 * Copyright (c) 2023, YashanDB Development Group
 * See the LICENSE file in the project root for more information.
 */

package com.yashandb;

import com.yashandb.jdbc.Field;
import com.yashandb.jdbc.exception.BatchError;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

/**
 * This interface is intended to be used by implementors of statement interceptors so that
 * implementors can create static or dynamic (via java.lang.reflect.Proxy) proxy instances of
 * ResultSets. It consists of methods outside of java.sql.Result that are used internally by other
 * classes in the driver.
 *
 * <p>This interface, although public is <strong>not</strong> designed to be consumed publicly other
 * than for the statement interceptor use case.
 */
public interface YasResultSet extends ResultSet {
    /**
     * Does the result set contain rows, or is it the result of a DDL or DML
     * statement?
     */
    boolean reallyResult();

    /**
     * Returns the server informational message returned from a DDL or DML
     * statement (if any), or null if none.
     */
    String getServerInfo();

    /**
     * Returns the update count for this result set (if one exists), otherwise
     * -1.
     *
     */
    long getUpdateCount();

    /**
     * Returns the AUTO_INCREMENT value for the DDL/DML statement which created
     * this result set.
     */
    long getUpdateID();

    /**
     * Closes this ResultSet and releases resources.
     *
     * @param calledExplicitly was realClose called by the standard ResultSet.close() method,
     *                         or was it closed internally by the
     *                         driver?
     */
    void realClose(boolean calledExplicitly) throws SQLException;

    /**
     * Returns true if this ResultSet is closed
     */
    boolean isClosed() throws SQLException;

    /**
     * Sets the first character of the query that was issued to create
     * this result set. The character should be upper-cased.
     */
    void setFirstCharOfQuery(char firstCharUpperCase);

    /**
     * Sets the statement that "owns" this result set (usually used when the
     * result set should internally "belong" to one statement, but is created
     * by another.
     */
    void setOwningStatement(com.yashandb.jdbc.StatementImpl owningStatement);

    /**
     * Returns the first character of the query that was issued to create this
     * result set, upper-cased.
     */
    char getFirstCharOfQuery();

    /**
     * Clears the reference to the next result set in a multi-result set
     * "chain".
     */
    void clearNextResult();

    /**
     * Returns the next ResultSet in a multi-resultset "chain", if any,
     * null if none exists.
     */
    YasResultSet getNextResultSet();

    /**
     * Builds a hash between column names and their indices for fast retrieval.
     * This is done lazily to support findColumn() and get*(String), as it
     * can be more expensive than just retrieving result set values by ordinal
     * index.
     */
    void buildIndexMapping() throws SQLException;

    void initializeWithMetadata() throws SQLException;

    /**
     * Used by DatabaseMetadata implementations to coerce the metadata returned
     * by metadata queries into that required by the JDBC specification.
     *
     * @param metadataFields the coerced metadata to be applied to result sets
     *                       returned by "SHOW ..." or SELECTs on INFORMATION_SCHEMA performed on behalf
     *                       of methods in DatabaseMetadata.
     */
    void redefineFieldsForDBMD(Field[] metadataFields);

    int getBytesSize() throws SQLException;

    long getFetchedRowCount() throws SQLException;

    int[] getBatchUpdateCounts();

    String getBatchError(int batchIndex);

    void setStmtQueryResult(boolean stmtQuery);

    default Map<Integer, BatchError> getBatchErrors() {
        return null;
    }

    default void appendResults(long updateCount, int[] dmlRows, Map<Integer, BatchError> batchErrors) {
    }

    default boolean isKept() {
        return false;
    }

    default void setKept(boolean kept) {
    }
}
